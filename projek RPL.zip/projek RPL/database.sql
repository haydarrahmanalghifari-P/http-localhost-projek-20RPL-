-- ====================================================================
-- Database Schema: TKJ Smart Service
-- Nama Database: tkj_smart_service
-- Arsitektur: Native PHP MVC (Unit Bisnis & Teaching Factory TKJ)
-- ====================================================================

-- 1. Buat Database
CREATE DATABASE IF NOT EXISTS `tkj_smart_service` 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `tkj_smart_service`;

-- Matikan cek foreign key sementara untuk reset tabel
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `email_otp`;
DROP TABLE IF EXISTS `faq`;
DROP TABLE IF EXISTS `notifikasi`;
DROP TABLE IF EXISTS `review`;
DROP TABLE IF EXISTS `pembayaran`;
DROP TABLE IF EXISTS `pekerjaan`;
DROP TABLE IF EXISTS `pesanan`;
DROP TABLE IF EXISTS `jasa`;
DROP TABLE IF EXISTS `users`;

SET FOREIGN_KEY_CHECKS = 1;

-- ====================================================================
-- 1. TABEL USERS
-- Menyimpan data pengguna dengan 4 Role: customer, teknisi, operator, kepala_sekolah
-- ====================================================================
CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(150) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('customer', 'teknisi', 'operator', 'kepala_sekolah', 'admin') NOT NULL DEFAULT 'customer',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_users_role` (`role`),
    INDEX `idx_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 2. TABEL JASA
-- Menyimpan katalog layanan jasa IT unit bisnis siswa TKJ
-- ====================================================================
CREATE TABLE `jasa` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama_jasa` VARCHAR(150) NOT NULL,
    `slug` VARCHAR(150) NULL,
    `deskripsi` TEXT NOT NULL,
    `harga_mulai` DECIMAL(12, 2) NOT NULL,
    `estimasi_pengerjaan` VARCHAR(100) NOT NULL,
    `status` ENUM('aktif', 'nonaktif') NOT NULL DEFAULT 'aktif',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_jasa_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 3. TABEL PESANAN
-- Menyimpan data pemesanan jasa oleh customer
-- ====================================================================
CREATE TABLE `pesanan` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `kode_pesanan` VARCHAR(50) NOT NULL UNIQUE,
    `customer_id` INT NOT NULL,
    `jasa_id` INT NOT NULL,
    `alamat` TEXT NOT NULL,
    `no_telepon` VARCHAR(30) NOT NULL,
    `deskripsi_masalah` TEXT NOT NULL,
    `tanggal_pemesanan` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `tanggal_pengerjaan` DATETIME NULL,
    `status` ENUM('pending', 'dikonfirmasi', 'diproses', 'selesai', 'dibatalkan') NOT NULL DEFAULT 'pending',
    `teknisi_id` INT NULL,
    `total_harga` DECIMAL(12, 2) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_pesanan_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_pesanan_jasa` FOREIGN KEY (`jasa_id`) REFERENCES `jasa` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_pesanan_teknisi` FOREIGN KEY (`teknisi_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX `idx_pesanan_status` (`status`),
    INDEX `idx_pesanan_kode` (`kode_pesanan`),
    INDEX `idx_pesanan_customer` (`customer_id`),
    INDEX `idx_pesanan_teknisi` (`teknisi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 4. TABEL PEKERJAAN
-- Menyimpan data progress pengerjaan oleh teknisi siswa TKJ
-- ====================================================================
CREATE TABLE `pekerjaan` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `pesanan_id` INT NOT NULL,
    `teknisi_id` INT NOT NULL,
    `catatan_teknisi` TEXT NULL,
    `hasil_pekerjaan` TEXT NULL,
    `foto_pekerjaan` VARCHAR(255) NULL,
    `status` ENUM('dalam_proses', 'selesai', 'tertunda') NOT NULL DEFAULT 'dalam_proses',
    `tanggal_mulai` DATETIME NULL,
    `tanggal_selesai` DATETIME NULL,
    CONSTRAINT `fk_pekerjaan_pesanan` FOREIGN KEY (`pesanan_id`) REFERENCES `pesanan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_pekerjaan_teknisi` FOREIGN KEY (`teknisi_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX `idx_pekerjaan_status` (`status`),
    INDEX `idx_pekerjaan_pesanan` (`pesanan_id`),
    INDEX `idx_pekerjaan_teknisi` (`teknisi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 5. TABEL PEMBAYARAN
-- Menyimpan data transaksi pembayaran pesanan
-- ====================================================================
CREATE TABLE `pembayaran` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `pesanan_id` INT NOT NULL,
    `metode_pembayaran` VARCHAR(50) NOT NULL DEFAULT 'transfer',
    `jumlah` DECIMAL(12, 2) NOT NULL,
    `status` VARCHAR(50) NOT NULL DEFAULT 'belum_dibayar',
    `tanggal_pembayaran` DATETIME NULL,
    `bukti_pembayaran` VARCHAR(255) NULL,
    `catatan_operator` TEXT NULL,
    CONSTRAINT `fk_pembayaran_pesanan` FOREIGN KEY (`pesanan_id`) REFERENCES `pesanan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX `idx_pembayaran_status` (`status`),
    INDEX `idx_pembayaran_pesanan` (`pesanan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 6. TABEL REVIEW
-- Menyimpan rating dan komentar dari customer
-- ====================================================================
CREATE TABLE `review` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `pesanan_id` INT NOT NULL,
    `customer_id` INT NOT NULL,
    `teknisi_id` INT NOT NULL,
    `rating` INT NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
    `komentar` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_review_pesanan` FOREIGN KEY (`pesanan_id`) REFERENCES `pesanan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_review_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_review_teknisi` FOREIGN KEY (`teknisi_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX `idx_review_rating` (`rating`),
    INDEX `idx_review_pesanan` (`pesanan_id`),
    INDEX `idx_review_teknisi` (`teknisi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 7. TABEL NOTIFIKASI
-- Menyimpan pemberitahuan sistem untuk pengguna
-- ====================================================================
CREATE TABLE `notifikasi` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `judul` VARCHAR(150) NOT NULL,
    `pesan` TEXT NOT NULL,
    `status` ENUM('belum_dibaca', 'dibaca') NOT NULL DEFAULT 'belum_dibaca',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_notifikasi_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX `idx_notifikasi_status` (`status`),
    INDEX `idx_notifikasi_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 8. TABEL FAQ
-- Menyimpan daftar pertanyaan umum (Frequently Asked Questions)
-- ====================================================================
CREATE TABLE `faq` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `pertanyaan` TEXT NOT NULL,
    `jawaban` TEXT NOT NULL,
    `status` ENUM('aktif', 'nonaktif') NOT NULL DEFAULT 'aktif',
    INDEX `idx_faq_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- 9. TABEL EMAIL OTP
-- Menyimpan kode OTP verifikasi registrasi dan autentikasi email
-- ====================================================================
CREATE TABLE `email_otp` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(150) NOT NULL,
    `otp` VARCHAR(10) NOT NULL,
    `type` VARCHAR(50) NOT NULL DEFAULT 'register',
    `is_used` TINYINT(1) NOT NULL DEFAULT 0,
    `expires_at` DATETIME NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_email_otp` (`email`, `otp`, `is_used`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ====================================================================
-- SEED DATA DUMMY
-- Password default untuk semua akun dummy: password123
-- Hash Bcrypt: $2y$10$4.aKk6uC9M0fTf/W0l0T7.0i0M5bXyG8R7bS7N.8/c5d1e2f3g4h
-- ====================================================================

-- 1. Dummy Users (5 Roles: Admin, Operator, Kepala Sekolah, Teknisi, Customer)
INSERT INTO `users` (`id`, `nama`, `email`, `password`, `role`) VALUES
(1, 'Pak Bambang Hartono, S.Kom', 'operator@tkj.sch.id', '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC', 'operator'),
(2, 'Drs. H. Supriyadi, M.Pd', 'kepsek@tkj.sch.id', '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC', 'kepala_sekolah'),
(3, 'Ahmad Dani (Siswa XI TKJ 1)', 'ahmad.teknisi@tkj.sch.id', '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC', 'teknisi'),
(4, 'Rizky Pratama (Siswa XII TKJ 2)', 'rizky.teknisi@tkj.sch.id', '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC', 'teknisi'),
(5, 'Budi Santoso', 'budi.customer@gmail.com', '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC', 'customer'),
(6, 'Siti Rahmawati', 'siti.customer@gmail.com', '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC', 'customer'),
(7, 'Administrator Sistem', 'admin@tkj.sch.id', '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC', 'admin');

-- 2. Dummy Jasa (6 Layanan Utama TKJ)
INSERT INTO `jasa` (`id`, `nama_jasa`, `deskripsi`, `harga_mulai`, `estimasi_pengerjaan`, `status`) VALUES
(1, 'Instalasi CCTV', 'Pemasangan kamera CCTV IP / Analog untuk rumah, toko, dan sekolah dengan integrasi monitoring via Smartphone.', 250000.00, '1 Hari', 'aktif'),
(2, 'Instalasi Jaringan', 'Perancangan dan penarikan kabel jaringan LAN (UTP/FTP), crimping RJ45, serta konfigurasi Mikrotik / Router.', 150000.00, '1 Hari', 'aktif'),
(3, 'Instalasi Wi-Fi', 'Pemasangan Access Point, perluasan jangkauan Wi-Fi (Range Extender/Mesh), dan pembuatan sistem Hotspot Voucher.', 100000.00, '4 - 6 Jam', 'aktif'),
(4, 'Service Komputer/Laptop', 'Perbaikan hardware & software komputer/laptop, install ulang OS, upgrade SSD/RAM, serta pembersihan thermal paste.', 75000.00, '1 - 2 Hari', 'aktif'),
(5, 'Maintenance Perangkat IT', 'Perawatan berkala untuk lab komputer sekolah, kantor, maupun UMKM agar perangkat IT selalu prima.', 300000.00, 'Berkala (1 Bulan)', 'aktif'),
(6, 'Jasa IT Lainnya', 'Konsultasi IT, perakitan PC custom (Gaming/Office), instalasi printer jaringan, dan solusi kendala IT spesifik.', 100000.00, 'Fleksibel', 'aktif');

-- 3. Dummy Pesanan
INSERT INTO `pesanan` (`id`, `kode_pesanan`, `customer_id`, `jasa_id`, `alamat`, `no_telepon`, `deskripsi_masalah`, `tanggal_pemesanan`, `tanggal_pengerjaan`, `status`, `teknisi_id`, `total_harga`) VALUES
(1, 'ORD-20260901-001', 5, 1, 'Jl. Mawar No. 12, RT 02/05, Kelurahan Permai', '081234567890', 'Pemasangan 4 titik kamera CCTV IP outdoor dan setting aplikasi HP', '2026-09-01 09:00:00', '2026-09-02 10:00:00', 'selesai', 3, 1000000.00),
(2, 'ORD-20260902-002', 6, 4, 'Jl. Melati No. 45, Kecamatan Sukamaju', '085712345678', 'Laptop Asus booting lemot dan panas, minta install Windows 11 & upgrade SSD 512GB', '2026-09-02 11:30:00', '2026-09-03 09:00:00', 'diproses', 4, 650000.00),
(3, 'ORD-20260903-003', 5, 3, 'Toko Kelontong Budi, Jl. Raya Merdeka No. 8', '081234567890', 'Ingin pasang Wi-Fi Hotspot voucheran untuk pelanggan toko', '2026-09-03 08:15:00', NULL, 'pending', NULL, 350000.00);

-- 4. Dummy Pekerjaan
INSERT INTO `pekerjaan` (`id`, `pesanan_id`, `teknisi_id`, `catatan_teknisi`, `hasil_pekerjaan`, `foto_pekerjaan`, `status`, `tanggal_mulai`, `tanggal_selesai`) VALUES
(1, 1, 3, 'Kabel UTP ditarik rapi melalui conduit pipa PVC. DVR terkoneksi ke jaringan internet lokal.', 'Instalasi 4 unit CCTV IP Dahua selesai, gambar jernih dan aplikasi HP terhubung lancar.', 'uploads/pekerjaan/cctv_ord001.jpg', 'selesai', '2026-09-02 10:00:00', '2026-09-02 16:30:00'),
(2, 2, 4, 'Bongkar laptop, pembersihan debu kipas, ganti pasta thermal Arctic MX-4. Clone OS ke SSD NVMe 512GB.', 'Laptop selesai di-upgrade, booting hanya 8 detik. Pengujian stress test suhu normal.', 'uploads/pekerjaan/laptop_ord002.jpg', 'dalam_proses', '2026-09-03 09:00:00', NULL);

-- 5. Dummy Pembayaran
INSERT INTO `pembayaran` (`id`, `pesanan_id`, `metode_pembayaran`, `jumlah`, `status`, `tanggal_pembayaran`) VALUES
(1, 1, 'qris', 1000000.00, 'lunas', '2026-09-02 17:00:00'),
(2, 2, 'transfer_bank', 650000.00, 'pending', NULL);

-- 6. Dummy Review
INSERT INTO `review` (`id`, `pesanan_id`, `customer_id`, `teknisi_id`, `rating`, `komentar`, `created_at`) VALUES
(1, 1, 5, 3, 5, 'Pemasangan CCTV sangat rapi dan ramah. Teknisi siswa TKJ pengerjaannya profesional banget didampingi gurunya. Mantap!', '2026-09-02 18:00:00');

-- 7. Dummy Notifikasi
INSERT INTO `notifikasi` (`id`, `user_id`, `judul`, `pesan`, `status`, `created_at`) VALUES
(1, 5, 'Pesanan Selesai', 'Pesanan ORD-20260901-001 (Instalasi CCTV) telah selesai dikerjakan oleh teknisi Ahmad Dani.', 'dibaca', '2026-09-02 16:35:00'),
(2, 3, 'Tugas Pekerjaan Baru', 'Anda ditugaskan mengerjakan pesanan ORD-20260901-001 oleh Operator.', 'dibaca', '2026-09-01 10:00:00'),
(3, 1, 'Pesanan Baru Masuk', 'Pesanan baru ORD-20260903-003 dari customer Budi Santoso perlu dikonfirmasi.', 'belum_dibaca', '2026-09-03 08:15:00');

-- 8. Dummy FAQ
INSERT INTO `faq` (`id`, `pertanyaan`, `jawaban`, `status`) VALUES
(1, 'Bagaimana cara memesan jasa?', 'Silakan login sebagai customer, pilih layanan, kemudian isi formulir pemesanan.', 'aktif'),
(2, 'Apa saja layanan TKJ Smart Service?', 'Kami menyediakan Instalasi CCTV, Instalasi Jaringan LAN, Instalasi Wi-Fi Hotspot, Service Komputer/Laptop, Maintenance Perangkat IT, dan Jasa IT Lainnya.', 'aktif'),
(3, 'Berapa lama pengerjaan?', 'Estimasi pengerjaan bervariasi: Instalasi Wi-Fi (4-6 jam), Instalasi CCTV & Jaringan (1 hari), Service Komputer (1-2 hari tergantung tingkat kerusakan).', 'aktif'),
(4, 'Bagaimana cara melihat status pesanan?', 'Anda dapat memantau status pesanan (Pending, Dikonfirmasi, Diproses, Selesai) secara real-time di Dashboard Customer atau menu Pesanan Saya.', 'aktif'),
(5, 'Bagaimana cara menghubungi teknisi?', 'Nama teknisi penanggung jawab akan tertera pada pesanan Anda setelah dikonfirmasi oleh Operator. Komunikasi dapat dilakukan melalui catatan pesanan atau layanan kontak unit bisnis.', 'aktif'),
(6, 'Bagaimana cara memberikan review?', 'Setelah pesanan berstatus Selesai, Anda dapat menekan tombol Beri Review pada detail pesanan untuk memberikan rating bintang dan ulasan.', 'aktif'),
(7, 'Apakah layanan jasa TKJ Smart Service bergaransi?', 'Ya! Semua layanan instalasi CCTV, jaringan, dan service komputer dilengkapi garansi pengerjaan ulang gratis jika terjadi kendala pasca pengerjaan.', 'aktif'),
(8, 'Metode pembayaran apa saja yang didukung?', 'Kami menerima pembayaran secara Tunai (Cash), Transfer Bank, dan QRIS.', 'aktif');

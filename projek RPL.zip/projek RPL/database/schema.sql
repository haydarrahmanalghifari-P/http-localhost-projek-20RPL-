-- ====================================================================
-- Database Schema: TKJ Smart Service
-- Unit Bisnis & Teaching Factory Layanan Jasa IT Siswa TKJ
-- Compatible with MySQL / MariaDB (XAMPP & Laragon)
-- ====================================================================

-- 1. Buat Database jika belum ada
CREATE DATABASE IF NOT EXISTS `tkj_smart_service` 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `tkj_smart_service`;

-- 2. Tabel Services (6 Layanan Utama TKJ)
DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(150) NOT NULL,
    `slug` VARCHAR(150) NOT NULL UNIQUE,
    `icon` VARCHAR(100) NOT NULL DEFAULT 'fa-screwdriver-wrench',
    `badge` VARCHAR(100) DEFAULT 'Layanan TKJ',
    `badge_color` VARCHAR(100) DEFAULT 'bg-cyan text-dark',
    `description` TEXT NOT NULL,
    `features` TEXT,
    `price` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert 6 Data Layanan Utama TKJ
INSERT INTO `services` (`id`, `title`, `slug`, `icon`, `badge`, `badge_color`, `description`, `features`, `price`) VALUES
(1, 'Instalasi CCTV', 'instalasi-cctv', 'fa-video', 'Terpopuler', 'bg-danger', 'Pemasangan kamera CCTV IP / Analog untuk rumah, toko, dan sekolah dengan integrasi monitoring via Smartphone.', 'Kamera HD & Night Vision, Akses Monitoring via Android/iOS, Penataan Kabel Rapi & Garansi Unit', 'Mulai Rp 250.000 / Titik'),
(2, 'Instalasi Jaringan', 'instalasi-jaringan', 'fa-network-wired', 'Rekomendasi', 'bg-info', 'Perancangan dan penarikan kabel jaringan LAN (UTP/FTP), crimping RJ45, serta konfigurasi Mikrotik / Router.', 'Penarikan Kabel UTP Cat5e / Cat6, Manajemen Bandwidth & Mikrotik, Testing Konektivitas & Labeling', 'Mulai Rp 150.000 / Node'),
(3, 'Instalasi Wi-Fi', 'instalasi-wifi', 'fa-wifi', 'Favorit', 'bg-primary', 'Pemasangan Access Point, perluasan jangkauan Wi-Fi (Range Extender/Mesh), dan pembuatan sistem Hotspot Voucher.', 'Setting Access Point & Router Wi-Fi, Perluasan Sinyal Bebas Deadzone, Sistem Hotspot Login Page', 'Mulai Rp 100.000 / Unit'),
(4, 'Service Komputer/Laptop', 'service-komputer-laptop', 'fa-laptop-code', 'Cepat & Bergaransi', 'bg-warning text-dark', 'Perbaikan hardware & software komputer/laptop, install ulang OS, upgrade SSD/RAM, serta pembersihan thermal paste.', 'Install Windows 10/11 & Software Standar, Ganti Pasta Thermal & Cleaning Fan, Upgrade SSD, RAM, & Diagnostic Error', 'Mulai Rp 75.000'),
(5, 'Maintenance Perangkat IT', 'maintenance-perangkat-it', 'fa-server', 'Paket Hemat', 'bg-success', 'Perawatan berkala untuk lab komputer sekolah, kantor, maupun UMKM agar perangkat IT selalu prima.', 'Pembersihan Debu & Perangkat Rutin, Backup Data & Optimization System, Pemeriksaan Kesehatan Hardware', 'Mulai Rp 300.000 / Bulan'),
(6, 'Jasa IT Lainnya', 'jasa-it-lainnya', 'fa-microchip', 'Custom Request', 'bg-secondary', 'Konsultasi IT, perakitan PC custom (Gaming/Office), instalasi printer jaringan, dan solusi kendala IT spesifik.', 'Perakitan PC Sesuai Budget, Sharing Printer & File Server Local, Pendampingan & Solusi Problem IT', 'Negosiasi Sesuai Kebutuhan');

-- 3. Tabel Orders (Persiapan untuk Tahap Selanjutnya)
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_code` VARCHAR(50) NOT NULL UNIQUE,
    `customer_name` VARCHAR(150) NOT NULL,
    `customer_phone` VARCHAR(50) NOT NULL,
    `customer_address` TEXT NOT NULL,
    `service_id` INT NOT NULL,
    `status` ENUM('pending', 'processed', 'completed', 'cancelled') DEFAULT 'pending',
    `notes` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`service_id`) REFERENCES `services`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

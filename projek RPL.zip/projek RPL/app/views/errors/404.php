<section class="py-5 text-center text-white my-5">
    <div class="container py-5">
        <div class="glass-card max-w-600 mx-auto p-5 rounded-4 border border-cyan border-opacity-25 shadow-lg">
            <i class="fa-solid fa-triangle-exclamation text-cyan display-1 mb-4"></i>
            <h1 class="display-3 fw-extrabold text-white">404</h1>
            <h3 class="fw-bold text-white mb-3">Halaman Tidak Ditemukan</h3>
            <p class="text-white-50 mb-4">
                Maaf, halaman atau rute URL yang Anda cari tidak tersedia di sistem <strong>TKJ Smart Service</strong>.
            </p>
            <a href="<?= BASE_URL ?>" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 py-2">
                <i class="fa-solid fa-house me-2"></i> Kembali ke Halaman Utama
            </a>
        </div>
    </div>
</section>

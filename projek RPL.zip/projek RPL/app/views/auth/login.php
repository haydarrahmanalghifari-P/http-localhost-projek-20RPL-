<div class="auth-minimal-wrapper">
    <!-- Subtle Ambient Glows -->
    <div class="auth-bg-orb auth-bg-orb-1"></div>
    <div class="auth-bg-orb auth-bg-orb-2"></div>

    <!-- Top Bar: Logo & Back Link -->
    <div class="auth-top-bar">
        <a href="<?= BASE_URL ?>" class="auth-brand-logo">
            <span class="brand-icon-mini">
                <i class="fa-solid fa-server"></i>
            </span>
            <span>TKJ <span style="color: #0284c7;">Smart Service</span></span>
        </a>
        <a href="<?= BASE_URL ?>" class="auth-back-btn">
            <i class="fa-solid fa-arrow-left me-1"></i> Beranda
        </a>
    </div>

    <!-- Minimalist Auth Card -->
    <div class="auth-minimal-card">
        
        <!-- Header -->
        <h1 class="auth-title-serif">Welcome Back</h1>
        <p class="auth-subtitle">Enter your credentials to access your account</p>

        <!-- Flash Alert Messages -->
        <?php 
        $flashLogin = AuthHelper::getFlash('login_error');
        $flashSuccess = AuthHelper::getFlash('login_success');
        $flashInfo = AuthHelper::getFlash('login_info');
        $flashAuth = AuthHelper::getFlash('auth_error');
        $flashTgError = AuthHelper::getFlash('login_telegram_error');
        ?>

        <?php if ($flashLogin): ?>
            <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashLogin['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($flashTgError): ?>
            <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                <i class="fa-brands fa-telegram text-primary me-1"></i> <?= $flashTgError['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($flashInfo): ?>
            <div class="alert alert-info alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-info-circle me-1"></i> <?= htmlspecialchars($flashInfo['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($flashAuth): ?>
            <div class="alert alert-warning alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= htmlspecialchars($flashAuth['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Segmented Tab: Password vs WhatsApp Cepat -->
        <div class="auth-tabs">
            <button type="button" class="auth-tab-btn active" id="tabBtnPassword" onclick="switchLoginTab('password')">
                <i class="fa-solid fa-lock me-1.5"></i> Password
            </button>
            <button type="button" class="auth-tab-btn" id="tabBtnWa" onclick="switchLoginTab('wa')">
                <i class="fa-brands fa-whatsapp text-success me-1.5"></i> WhatsApp Cepat
            </button>
        </div>

        <!-- Form 1: Login dengan Password -->
        <form action="<?= BASE_URL ?>/login" method="POST" id="loginForm">
            <?= SecurityHelper::csrfField() ?>

            <!-- Remember Me Checkbox -->
            <label class="auth-checkbox-group">
                <input type="checkbox" name="remember_me" class="auth-checkbox-input" checked>
                <span class="auth-checkbox-text">Remember me on this device</span>
            </label>

            <!-- Email -->
            <div class="auth-field">
                <label for="email" class="auth-label">Email</label>
                <input type="email" class="auth-input" id="email" name="email" placeholder="Enter your email" required autocomplete="email" autofocus>
            </div>

            <!-- Password -->
            <div class="auth-field">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <label for="password" class="auth-label mb-0">Password</label>
                    <a href="<?= BASE_URL ?>/lupa-password" class="extra-small text-decoration-none" style="font-size: 0.775rem; color: #64748b; font-weight: 500;">
                        Forgot password?
                    </a>
                </div>
                <div class="auth-password-wrapper">
                    <input type="password" class="auth-input" id="password" name="password" placeholder="••••••••••••" required>
                    <button type="button" class="auth-password-toggle" onclick="togglePasswordVisibility('password', this)" title="Show/Hide Password">
                        <i class="fa-regular fa-eye-slash"></i>
                    </button>
                </div>
            </div>

            <!-- WhatsApp OTP Security Info Banner -->
            <div class="auth-security-badge">
                <i class="fa-brands fa-whatsapp"></i>
                <div>
                    <strong>Two-Factor OTP:</strong> Kode verifikasi masuk akan dikirimkan otomatis ke WhatsApp Anda.
                </div>
            </div>

            <!-- Primary Black Submit Button -->
            <button type="submit" class="btn-auth-primary">
                Sign in
            </button>

            <!-- Tombol Cepat Pindah ke WhatsApp Login -->
            <div class="auth-divider">
                <span>atau masuk tanpa password</span>
            </div>
            <button type="button" class="btn-auth-wa" onclick="switchLoginTab('wa')">
                <i class="fa-brands fa-whatsapp fs-5 text-success me-1.5"></i> Masuk Cepat dengan WhatsApp
            </button>
        </form>

        <!-- Form 2: Login Cepat via WhatsApp (OTP Langsung) -->
        <form action="<?= BASE_URL ?>/login-wa" method="POST" id="waLoginForm" class="d-none">
            <?= SecurityHelper::csrfField() ?>

            <div class="p-3 mb-3 rounded-3 bg-light border border-success border-opacity-25 text-start">
                <div class="d-flex align-items-center gap-2 mb-1">
                    <i class="fa-brands fa-whatsapp text-success fs-5"></i>
                    <strong class="text-dark small">Login Instan Tanpa Password</strong>
                </div>
                <p class="text-muted extra-small mb-0 leading-relaxed">
                    Masukkan nomor WhatsApp atau email akun Anda. Kami akan mengirimkan 6 digit kode OTP langsung ke WhatsApp Anda untuk masuk seketika.
                </p>
            </div>

            <!-- Input Nomor WhatsApp / Email -->
            <div class="auth-field">
                <label for="wa_identifier" class="auth-label">Nomor WhatsApp atau Email Akun</label>
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0 text-success">
                        <i class="fa-brands fa-whatsapp fs-5"></i>
                    </span>
                    <input type="text" class="auth-input border-start-0 ps-0" id="wa_identifier" name="identifier" placeholder="Contoh: 08123456789 atau email akun" required autocomplete="tel">
                </div>
                <small class="text-muted extra-small mt-1 d-block">
                    Format: 08xxxxxxxxxx atau email yang telah terdaftar di sistem TKJ.
                </small>
            </div>

            <!-- Submit Button WhatsApp -->
            <button type="submit" class="btn-auth-wa-submit mb-3">
                <i class="fa-brands fa-whatsapp fs-5 me-1.5"></i> Kirim Kode OTP Masuk
            </button>

            <button type="button" class="btn btn-link text-secondary text-decoration-none w-100 extra-small" onclick="switchLoginTab('password')">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Login Password
            </button>
        </form>


        <!-- Footer Link -->
        <p class="auth-footer-link">
            Don't have an account? <a href="<?= BASE_URL ?>/register">Sign up</a>
        </p>

        <!-- Quick Testing Helper Accordion -->
        <div class="mt-4 pt-2">
            <div class="accordion" id="accordionTesting">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTesting">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTesting">
                            <i class="fa-solid fa-key me-2 text-primary"></i> Akun Testing (Password: password123)
                        </button>
                    </h2>
                    <div id="collapseTesting" class="accordion-collapse collapse" data-bs-parent="#accordionTesting">
                        <div class="accordion-body">
                            <ul class="list-unstyled mb-0 vstack gap-1">
                                <li><strong class="text-danger">Admin:</strong> admin@tkj.sch.id</li>
                                <li><strong class="text-dark">Customer:</strong> budi.customer@gmail.com</li>
                                <li><strong class="text-dark">Teknisi:</strong> ahmad.teknisi@tkj.sch.id</li>
                                <li><strong class="text-dark">Operator:</strong> operator@tkj.sch.id</li>
                                <li><strong class="text-dark">Kepala Sekolah:</strong> kepsek@tkj.sch.id</li>
                                <li class="mt-2 pt-2 border-top extra-small text-muted">
                                    <i class="fa-brands fa-whatsapp text-success me-1"></i> <strong>Tips Login Cepat:</strong> Klik tab <em>WhatsApp Cepat</em>, masukkan nomor WA atau email di atas untuk menerima OTP instan.
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
function switchLoginTab(tab) {
    const tabBtnPassword = document.getElementById('tabBtnPassword');
    const tabBtnWa = document.getElementById('tabBtnWa');
    const loginForm = document.getElementById('loginForm');
    const waLoginForm = document.getElementById('waLoginForm');

    if (tab === 'wa') {
        tabBtnWa.classList.add('active');
        tabBtnPassword.classList.remove('active');
        loginForm.classList.add('d-none');
        waLoginForm.classList.remove('d-none');
        const waInput = document.getElementById('wa_identifier');
        if (waInput) waInput.focus();
    } else {
        tabBtnPassword.classList.add('active');
        tabBtnWa.classList.remove('active');
        waLoginForm.classList.add('d-none');
        loginForm.classList.remove('d-none');
        const emailInput = document.getElementById('email');
        if (emailInput) emailInput.focus();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('tab') === 'wa') {
        switchLoginTab('wa');
    }
});

function togglePasswordVisibility(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    }
}
</script>

<div class="auth-minimal-wrapper">
    <!-- Subtle Ambient Glows -->
    <div class="auth-bg-orb auth-bg-orb-1"></div>
    <div class="auth-bg-orb auth-bg-orb-2"></div>

    <!-- Top Bar: Logo & Back Link -->
    <div class="auth-top-bar">
        <a href="<?= BASE_URL ?>" class="auth-brand-logo">
            <span class="brand-icon-mini">
                <i class="fa-solid fa-server"></i>
            </span>
            <span>TKJ <span style="color: #0284c7;">Smart Service</span></span>
        </a>
        <a href="<?= BASE_URL ?>/cancel-otp" class="auth-back-btn" onclick="return confirm('Batalkan verifikasi dan ulangi pendaftaran?')">
            <i class="fa-solid fa-arrow-left me-1"></i> Batal
        </a>
    </div>

    <!-- Minimalist Auth Card -->
    <div class="auth-minimal-card text-center">
        
        <h1 class="auth-title-serif">Verify Registration</h1>
        <p class="auth-subtitle mb-3">Enter the 6-digit OTP code sent to your WhatsApp</p>

        <!-- Phone & Email Badges -->
        <div class="d-flex flex-wrap justify-content-center gap-2 mb-4">
            <?php if (!empty($no_telepon)): ?>
                <div class="d-inline-flex align-items-center gap-2 bg-light border border-success border-opacity-50 px-3 py-1 rounded-pill shadow-sm">
                    <i class="fa-brands fa-whatsapp text-success"></i>
                    <span class="text-dark fw-semibold small"><?= htmlspecialchars($no_telepon) ?></span>
                </div>
            <?php endif; ?>
            <?php if (!empty($email)): ?>
                <div class="d-inline-flex align-items-center gap-2 bg-light border border-secondary border-opacity-30 px-3 py-1 rounded-pill shadow-sm">
                    <i class="fa-solid fa-envelope text-muted small"></i>
                    <span class="text-muted small"><?= htmlspecialchars($email) ?></span>
                </div>
            <?php endif; ?>
        </div>

        <!-- Flash Alert Messages -->
        <?php 
        $flashError   = AuthHelper::getFlash('otp_error');
        $flashSuccess = AuthHelper::getFlash('otp_success');
        ?>

        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show small text-start mb-4" role="alert">
                <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashError['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show small text-start mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-1"></i> <?= $flashSuccess['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Form Verifikasi OTP -->
        <form action="<?= BASE_URL ?>/verify-otp" method="POST" id="form-verify-otp">
            <?= SecurityHelper::csrfField() ?>
            
            <!-- Hidden OTP combined field -->
            <input type="hidden" name="otp_code" id="otp_code_hidden">

            <!-- 6 Digit OTP Input Boxes -->
            <div class="otp-inputs-wrapper d-flex justify-content-center gap-2 gap-sm-3 mb-3">
                <?php for ($i = 1; $i <= 6; $i++): ?>
                    <input type="text" 
                           class="otp-box form-control text-center fw-bold" 
                           name="otp_<?= $i ?>" 
                           id="otp_box_<?= $i ?>" 
                           maxlength="1" 
                           inputmode="numeric" 
                           pattern="[0-9]" 
                           autocomplete="one-time-code"
                           required>
                <?php endfor; ?>
            </div>

            <!-- Timer Kedaluwarsa -->
            <div class="d-flex align-items-center justify-content-center gap-2 text-muted small mb-4">
                <i class="fa-regular fa-clock text-primary"></i>
                <span>Kode berlaku dalam:</span>
                <span id="otp-timer" class="fw-bold text-dark font-monospace fs-6">05:00</span>
            </div>

            <!-- Tombol Verifikasi Akun -->
            <button type="submit" id="btn-submit-otp" class="btn-auth-primary mb-3">
                <i class="fa-solid fa-shield-check me-2"></i> Verifikasi & Aktifkan Akun
            </button>
        </form>

        <!-- Aksi Kirim Ulang OTP -->
        <div class="pt-3 border-top" style="border-color: #e2e8f0 !important;">
            <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-2 small">
                <span class="text-muted">Belum menerima pesan di WhatsApp?</span>
                <div id="resend-container">
                    <a href="<?= BASE_URL ?>/resend-otp" id="btn-resend" class="text-dark text-decoration-none fw-semibold d-none">
                        <i class="fa-solid fa-rotate-right me-1"></i> Kirim Ulang Kode OTP
                    </a>
                    <span id="resend-countdown" class="text-muted">
                        Kirim ulang dalam (<span id="resend-seconds" class="text-dark font-monospace fw-bold">60</span>s)
                    </span>
                </div>
            </div>

            <div class="mt-3 text-center">
                <a href="<?= BASE_URL ?>/cancel-otp" class="text-muted small text-decoration-none" onclick="return confirm('Batalkan verifikasi dan ulangi pendaftaran?')">
                    <i class="fa-solid fa-arrow-left me-1"></i> Ubah Data / Daftar Ulang
                </a>
            </div>
        </div>

    </div>
</div>

<!-- Script Interaktif OTP Boxes & Live Countdowns -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const otpBoxes = Array.from(document.querySelectorAll('.otp-box'));
    const hiddenOtp = document.getElementById('otp_code_hidden');
    const formOtp = document.getElementById('form-verify-otp');

    // Auto Focus kotak pertama
    if (otpBoxes[0]) {
        otpBoxes[0].focus();
    }

    function updateHiddenValue() {
        const fullCode = otpBoxes.map(box => box.value).join('');
        if (hiddenOtp) hiddenOtp.value = fullCode;
        return fullCode;
    }

    // Auto Advance & Backspace Logic
    otpBoxes.forEach((box, index) => {
        box.addEventListener('input', function(e) {
            this.value = this.value.replace(/\D/g, '');

            if (this.value.length >= 1) {
                this.value = this.value.charAt(0);
                if (index < otpBoxes.length - 1) {
                    otpBoxes[index + 1].focus();
                }
            }
            updateHiddenValue();
        });

        box.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && this.value === '' && index > 0) {
                otpBoxes[index - 1].focus();
                otpBoxes[index - 1].value = '';
                updateHiddenValue();
            } else if (e.key === 'ArrowLeft' && index > 0) {
                otpBoxes[index - 1].focus();
            } else if (e.key === 'ArrowRight' && index < otpBoxes.length - 1) {
                otpBoxes[index + 1].focus();
            }
        });

        // Paste support: paste 6 digit langsung terisi semua kotak
        box.addEventListener('paste', function(e) {
            e.preventDefault();
            const pasteData = (e.clipboardData || window.clipboardData).getData('text');
            const cleanDigits = pasteData.replace(/\D/g, '').slice(0, 6);

            if (cleanDigits.length > 0) {
                cleanDigits.split('').forEach((digit, i) => {
                    if (otpBoxes[i]) {
                        otpBoxes[i].value = digit;
                    }
                });
                updateHiddenValue();
                
                const targetIndex = Math.min(cleanDigits.length, otpBoxes.length - 1);
                otpBoxes[targetIndex].focus();

                if (cleanDigits.length === 6) {
                    setTimeout(() => formOtp.submit(), 250);
                }
            }
        });
    });

    // Validasi saat submit form
    formOtp.addEventListener('submit', function(e) {
        const fullCode = updateHiddenValue();
        if (fullCode.length !== 6) {
            e.preventDefault();
            alert('Silakan masukkan 6 digit kode OTP secara lengkap.');
            return false;
        }
    });


    // Countdown Waktu Kedaluwarsa OTP
    let totalSecondsLeft = <?= isset($timeLeft) ? (int)$timeLeft : 300 ?>;
    const timerElem = document.getElementById('otp-timer');

    function updateOtpTimer() {
        if (totalSecondsLeft <= 0) {
            if (timerElem) {
                timerElem.textContent = 'Kedaluwarsa';
                timerElem.classList.remove('text-cyan');
                timerElem.classList.add('text-danger');
            }
            return;
        }

        const mins = Math.floor(totalSecondsLeft / 60);
        const secs = totalSecondsLeft % 60;
        if (timerElem) {
            timerElem.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        }
        totalSecondsLeft--;
    }
    updateOtpTimer();
    setInterval(updateOtpTimer, 1000);

    // Countdown Cooldown Tombol Kirim Ulang (Resend)
    let resendSecondsLeft = <?= isset($resendLeft) ? (int)$resendLeft : 60 ?>;
    const resendCountdownElem = document.getElementById('resend-countdown');
    const resendSecondsElem = document.getElementById('resend-seconds');
    const btnResend = document.getElementById('btn-resend');

    function updateResendTimer() {
        if (resendSecondsLeft <= 0) {
            if (resendCountdownElem) resendCountdownElem.classList.add('d-none');
            if (btnResend) btnResend.classList.remove('d-none');
            return;
        }

        if (resendSecondsElem) {
            resendSecondsElem.textContent = resendSecondsLeft;
        }
        resendSecondsLeft--;
        setTimeout(updateResendTimer, 1000);
    }
    updateResendTimer();
});
</script>

<div class="auth-minimal-wrapper">
    <!-- Subtle Ambient Glows -->
    <div class="auth-bg-orb auth-bg-orb-1"></div>
    <div class="auth-bg-orb auth-bg-orb-2"></div>

    <!-- Top Bar: Logo & Back Link -->
    <div class="auth-top-bar">
        <a href="<?= BASE_URL ?>" class="auth-brand-logo">
            <span class="brand-icon-mini">
                <i class="fa-solid fa-server"></i>
            </span>
            <span>TKJ <span style="color: #0284c7;">Smart Service</span></span>
        </a>
        <a href="<?= BASE_URL ?>/login" class="auth-back-btn">
            <i class="fa-solid fa-arrow-left me-1"></i> Ke Login
        </a>
    </div>

    <!-- Minimalist Auth Card -->
    <div class="auth-minimal-card">
        
        <!-- Header -->
        <h1 class="auth-title-serif">Reset Password</h1>
        <p class="auth-subtitle">Create a new secure password for your account.</p>

        <!-- Verified Account Badge -->
        <div class="auth-security-badge mb-3">
            <i class="fa-solid fa-circle-check text-success"></i>
            <div>
                <strong><?= htmlspecialchars($nama) ?></strong>
                <div class="text-muted" style="font-size: 0.725rem;"><?= htmlspecialchars($email) ?></div>
            </div>
        </div>

        <!-- Flash Alert Messages -->
        <?php 
        $flashReset = AuthHelper::getFlash('reset_error');
        $flashInfo = AuthHelper::getFlash('reset_info');
        ?>

        <?php if ($flashReset): ?>
            <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashReset['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($flashInfo): ?>
            <div class="alert alert-info alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-circle-info me-1"></i> <?= htmlspecialchars($flashInfo['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Form Reset Password Baru -->
        <form action="<?= BASE_URL ?>/reset-password" method="POST">
            <?= SecurityHelper::csrfField() ?>
            
            <div class="auth-field">
                <label for="new_password" class="auth-label">New Password</label>
                <div class="auth-password-wrapper">
                    <input type="password" class="auth-input" id="new_password" name="new_password" placeholder="Min. 6 characters" required minlength="6" autofocus>
                    <button type="button" class="auth-password-toggle" onclick="togglePasswordVisibility('new_password', this)" title="Show/Hide Password">
                        <i class="fa-regular fa-eye-slash"></i>
                    </button>
                </div>
            </div>

            <div class="auth-field">
                <label for="confirm_password" class="auth-label">Confirm New Password</label>
                <div class="auth-password-wrapper">
                    <input type="password" class="auth-input" id="confirm_password" name="confirm_password" placeholder="Repeat new password" required minlength="6">
                    <button type="button" class="auth-password-toggle" onclick="togglePasswordVisibility('confirm_password', this)" title="Show/Hide Password">
                        <i class="fa-regular fa-eye-slash"></i>
                    </button>
                </div>
            </div>

            <!-- Primary Black Submit Button -->
            <button type="submit" class="btn-auth-primary mt-3">
                Save New Password
            </button>
        </form>

        <!-- Footer Link -->
        <p class="auth-footer-link">
            Cancel reset? <a href="<?= BASE_URL ?>/login">Return to Log In</a>
        </p>

    </div>
</div>

<script>
function togglePasswordVisibility(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    }
}
</script>

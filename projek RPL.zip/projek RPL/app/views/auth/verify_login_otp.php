<div class="auth-minimal-wrapper">
    <!-- Subtle Ambient Glows -->
    <div class="auth-bg-orb auth-bg-orb-1"></div>
    <div class="auth-bg-orb auth-bg-orb-2"></div>

    <!-- Top Bar: Logo & Back Link -->
    <div class="auth-top-bar">
        <a href="<?= BASE_URL ?>" class="auth-brand-logo">
            <span class="brand-icon-mini">
                <i class="fa-solid fa-server"></i>
            </span>
            <span>TKJ <span style="color: #0284c7;">Smart Service</span></span>
        </a>
        <a href="<?= BASE_URL ?>/cancel-login-otp" class="auth-back-btn" onclick="return confirm('Batalkan verifikasi login dan ganti akun?')">
            <i class="fa-solid fa-arrow-left me-1"></i> Batal
        </a>
    </div>

    <!-- Minimalist Auth Card -->
    <div class="auth-minimal-card text-center">
        
        <h1 class="auth-title-serif">Verify OTP</h1>
        <p class="auth-subtitle mb-3">Enter the 6-digit security code sent to your WhatsApp</p>

        <!-- User & Phone Info Badges -->
        <div class="d-flex flex-wrap justify-content-center gap-2 mb-3">
            <?php if (!empty($nama)): ?>
                <div class="d-inline-flex align-items-center gap-2 bg-light border border-secondary border-opacity-25 px-3 py-1 rounded-pill shadow-sm">
                    <i class="fa-solid fa-user-circle text-primary small"></i>
                    <span class="text-dark small fw-semibold"><?= htmlspecialchars($nama) ?></span>
                    <?php if (!empty($email)): ?>
                        <span class="text-muted small">(<?= htmlspecialchars($email) ?>)</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($no_telepon)): ?>
                <div class="d-inline-flex align-items-center gap-2 bg-light border border-success border-opacity-40 px-3 py-1 rounded-pill shadow-sm">
                    <i class="fa-brands fa-whatsapp text-success"></i>
                    <span class="text-dark small fw-semibold"><?= htmlspecialchars($masked_phone ?: $no_telepon) ?></span>
                </div>
            <?php endif; ?>
        </div>

                    <!-- Flash Alert Messages -->
                    <?php 
                    $flashError   = AuthHelper::getFlash('otp_login_error');
                    $flashSuccess = AuthHelper::getFlash('otp_login_success');
                    $flashWarning = AuthHelper::getFlash('otp_login_warning');
                    $flashInfo    = AuthHelper::getFlash('otp_login_info');
                    ?>

                    <?php if ($flashError): ?>
                        <div class="alert alert-danger alert-dismissible fade show small text-start mb-3" role="alert">
                            <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashError['message']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($flashSuccess): ?>
                        <div class="alert alert-success alert-dismissible fade show small text-start mb-3" role="alert">
                            <i class="fa-solid fa-circle-check me-1"></i> <?= $flashSuccess['message'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($flashWarning): ?>
                        <div class="alert alert-warning alert-dismissible fade show small text-start mb-3" role="alert">
                            <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= $flashWarning['message'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($flashInfo): ?>
                        <div class="alert alert-info alert-dismissible fade show small text-start mb-3" role="alert">
                            <i class="fa-solid fa-info-circle me-1"></i> <?= $flashInfo['message'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Form Hubungkan WhatsApp Jika Belum Ada Nomor -->
                    <?php if (empty($no_telepon)): ?>
                        <div class="p-3 mb-4 rounded-3 bg-light border border-success border-opacity-40 text-start shadow-sm">
                            <div class="d-flex align-items-center gap-2 mb-1.5">
                                <i class="fa-brands fa-whatsapp text-success fs-5"></i>
                                <strong class="text-dark small">Kirim OTP ke Nomor WhatsApp Anda</strong>
                            </div>
                            <p class="extra-small text-secondary mb-2 leading-relaxed">
                                Akun Anda belum terhubung nomor WhatsApp. Masukkan nomor WhatsApp aktif Anda untuk langsung menerima 6 digit kode OTP masuk:
                            </p>
                            <form action="<?= BASE_URL ?>/login-otp" method="POST" class="d-flex gap-2">
                                <?= SecurityHelper::csrfField() ?>
                                <input type="hidden" name="action" value="link_phone">
                                <input type="tel" name="new_phone" class="form-control form-control-sm bg-white border-secondary border-opacity-25 text-dark font-monospace" placeholder="Contoh: 081234567890" required autofocus>
                                <button type="submit" class="btn btn-sm btn-success text-white fw-bold text-nowrap px-3 shadow-sm">
                                    <i class="fa-solid fa-paper-plane me-1"></i> Kirim OTP
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>

                    <!-- Form Verifikasi OTP Login -->
                    <form action="<?= BASE_URL ?>/login-otp" method="POST" id="form-verify-login-otp">
                        <?= SecurityHelper::csrfField() ?>
                        
                        <!-- Hidden OTP combined field -->
                        <input type="hidden" name="otp_code" id="otp_code_hidden">

                        <!-- 6 Digit OTP Input Boxes -->
                        <div class="otp-inputs-wrapper d-flex justify-content-center gap-2 gap-sm-3 mb-3">
                            <?php for ($i = 1; $i <= 6; $i++): ?>
                                <input type="text" 
                                       class="form-control otp-box text-center fw-bold" 
                                       name="otp_<?= $i ?>" 
                                       id="otp_box_<?= $i ?>" 
                                       maxlength="1" 
                                       inputmode="numeric" 
                                       pattern="[0-9]" 
                                       autocomplete="one-time-code"
                                       required>
                            <?php endfor; ?>
                        </div>


            <!-- Timer Kedaluwarsa -->
            <div class="d-flex align-items-center justify-content-center gap-2 text-muted small mb-4">
                <i class="fa-regular fa-clock text-primary"></i>
                <span>Kode berlaku dalam:</span>
                <span id="otp-timer" class="fw-bold text-dark font-monospace fs-6">05:00</span>
            </div>

            <!-- Tombol Verifikasi Akun -->
            <button type="submit" id="btn-submit-otp" class="btn-auth-primary mb-3">
                <i class="fa-solid fa-right-to-bracket me-2"></i> Verifikasi & Masuk Dashboard
            </button>
        </form>

        <!-- Aksi Kirim Ulang OTP -->
        <div class="pt-3 border-top" style="border-color: #e2e8f0 !important;">
            <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-2 small">
                <span class="text-muted">Belum menerima kode OTP di WhatsApp?</span>
                <div id="resend-container">
                    <a href="<?= BASE_URL ?>/resend-login-otp" id="btn-resend" class="text-dark text-decoration-none fw-semibold d-none">
                        <i class="fa-solid fa-rotate-right me-1"></i> Kirim Ulang Kode OTP
                    </a>
                    <span id="resend-countdown" class="text-muted">
                        Kirim ulang dalam (<span id="resend-seconds" class="text-dark font-monospace fw-bold">60</span>s)
                    </span>
                </div>
            </div>

            <div class="mt-3 text-center">
                <a href="<?= BASE_URL ?>/cancel-login-otp" class="text-muted small text-decoration-none" onclick="return confirm('Batalkan verifikasi login dan ganti akun?')">
                    <i class="fa-solid fa-arrow-left me-1"></i> Ganti Akun / Batalkan
                </a>
            </div>
        </div>

    </div>
</div>

<!-- Script Interaktif OTP Boxes & Auto-Submit -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const otpBoxes = Array.from(document.querySelectorAll('.otp-box'));
    const hiddenOtp = document.getElementById('otp_code_hidden');
    const formOtp = document.getElementById('form-verify-login-otp');

    // Auto Focus kotak pertama
    if (otpBoxes[0]) {
        otpBoxes[0].focus();
    }

    function updateHiddenOtp() {
        const fullCode = otpBoxes.map(b => b.value).join('');
        if (hiddenOtp) hiddenOtp.value = fullCode;
        return fullCode;
    }

    // Tangani Input, Navigasi Panah, dan Backspace
    otpBoxes.forEach((box, index) => {
        box.addEventListener('input', function(e) {
            const val = this.value.replace(/\D/g, '');
            this.value = val ? val[val.length - 1] : '';

            const currentCode = updateHiddenOtp();

            if (this.value && index < otpBoxes.length - 1) {
                otpBoxes[index + 1].focus();
                otpBoxes[index + 1].select();
            }

            // Auto Submit jika 6 digit telah terisi lengkap
            if (currentCode.length === 6) {
                setTimeout(() => {
                    formOtp.submit();
                }, 150);
            }
        });

        box.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace') {
                if (!this.value && index > 0) {
                    otpBoxes[index - 1].focus();
                    otpBoxes[index - 1].value = '';
                    updateHiddenOtp();
                }
            } else if (e.key === 'ArrowLeft' && index > 0) {
                otpBoxes[index - 1].focus();
            } else if (e.key === 'ArrowRight' && index < otpBoxes.length - 1) {
                otpBoxes[index + 1].focus();
            }
        });

        // Dukungan Paste (Menempelkan 6 digit sekaligus)
        box.addEventListener('paste', function(e) {
            e.preventDefault();
            const pastedData = (e.clipboardData || window.clipboardData).getData('text').trim();
            const digits = pastedData.replace(/\D/g, '').slice(0, 6);

            if (digits.length > 0) {
                digits.split('').forEach((digit, i) => {
                    if (otpBoxes[i]) {
                        otpBoxes[i].value = digit;
                    }
                });

                const lastFilled = Math.min(digits.length, otpBoxes.length) - 1;
                if (otpBoxes[lastFilled]) {
                    otpBoxes[lastFilled].focus();
                }

                const finalCode = updateHiddenOtp();
                if (finalCode.length === 6) {
                    setTimeout(() => {
                        formOtp.submit();
                    }, 150);
                }
            }
        });
    });


    // Submit Validation Guard
    formOtp.addEventListener('submit', function(e) {
        const code = updateHiddenOtp();
        if (code.length !== 6) {
            e.preventDefault();
            alert('Harap masukkan 6 digit kode OTP login.');
            if (otpBoxes[0]) otpBoxes[0].focus();
        }
    });

    // ==========================================
    // Countdown Timer Kedaluwarsa OTP (5 Menit)
    // ==========================================
    const timerElem = document.getElementById('otp-timer');
    let totalSeconds = 300; // 5 Menit

    const timerInterval = setInterval(function() {
        totalSeconds--;
        if (totalSeconds <= 0) {
            clearInterval(timerInterval);
            if (timerElem) {
                timerElem.textContent = '00:00 (Kedaluwarsa)';
                timerElem.classList.remove('text-cyan');
                timerElem.classList.add('text-danger');
            }
        } else {
            const minutes = Math.floor(totalSeconds / 60);
            const seconds = totalSeconds % 60;
            if (timerElem) {
                timerElem.textContent = String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
            }
        }
    }, 1000);

    // ==========================================
    // Countdown Tombol Kirim Ulang (60 Detik)
    // ==========================================
    const btnResend = document.getElementById('btn-resend');
    const resendCountdown = document.getElementById('resend-countdown');
    const resendSecondsElem = document.getElementById('resend-seconds');
    let resendRemaining = 60;

    const resendTimer = setInterval(function() {
        resendRemaining--;
        if (resendSecondsElem) {
            resendSecondsElem.textContent = resendRemaining;
        }

        if (resendRemaining <= 0) {
            clearInterval(resendTimer);
            if (resendCountdown) resendCountdown.classList.add('d-none');
            if (btnResend) btnResend.classList.remove('d-none');
        }
    }, 1000);
});
</script>

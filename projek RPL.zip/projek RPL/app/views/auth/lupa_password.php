<div class="auth-minimal-wrapper">
    <!-- Subtle Ambient Glows -->
    <div class="auth-bg-orb auth-bg-orb-1"></div>
    <div class="auth-bg-orb auth-bg-orb-2"></div>

    <!-- Top Bar: Logo & Back Link -->
    <div class="auth-top-bar">
        <a href="<?= BASE_URL ?>" class="auth-brand-logo">
            <span class="brand-icon-mini">
                <i class="fa-solid fa-server"></i>
            </span>
            <span>TKJ <span style="color: #0284c7;">Smart Service</span></span>
        </a>
        <a href="<?= BASE_URL ?>/login" class="auth-back-btn">
            <i class="fa-solid fa-arrow-left me-1"></i> Ke Login
        </a>
    </div>

    <!-- Minimalist Auth Card -->
    <div class="auth-minimal-card">
        
        <!-- Header -->
        <h1 class="auth-title-serif">Forgot Password</h1>
        <p class="auth-subtitle">Enter your registered email address to receive password reset instructions.</p>

        <!-- Flash Alert Messages -->
        <?php 
        $flashLupa = AuthHelper::getFlash('lupa_error');
        $flashInfo = AuthHelper::getFlash('lupa_info');
        ?>

        <?php if ($flashLupa): ?>
            <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashLupa['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if ($flashInfo): ?>
            <div class="alert alert-info alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-circle-info me-1"></i> <?= htmlspecialchars($flashInfo['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Form Lupa Password -->
        <form action="<?= BASE_URL ?>/lupa-password" method="POST">
            <?= SecurityHelper::csrfField() ?>
            
            <div class="auth-field">
                <label for="email" class="auth-label">Registered Email</label>
                <input type="email" class="auth-input" id="email" name="email" placeholder="Enter your registered email" required autocomplete="email" autofocus>
                <div class="text-muted extra-small mt-1" style="font-size: 0.75rem;">
                    <i class="fa-solid fa-shield-halved text-primary me-1"></i> We'll verify your account credentials safely.
                </div>
            </div>

            <!-- Primary Black Submit Button -->
            <button type="submit" class="btn-auth-primary mt-3">
                Continue Reset
            </button>
        </form>

        <!-- Footer Link -->
        <p class="auth-footer-link">
            Remember your password? <a href="<?= BASE_URL ?>/login">Log In</a>
        </p>

    </div>
</div>

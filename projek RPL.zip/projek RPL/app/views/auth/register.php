<div class="auth-minimal-wrapper">
    <!-- Subtle Ambient Glows -->
    <div class="auth-bg-orb auth-bg-orb-1"></div>
    <div class="auth-bg-orb auth-bg-orb-2"></div>

    <!-- Top Bar: Logo & Back Link -->
    <div class="auth-top-bar">
        <a href="<?= BASE_URL ?>" class="auth-brand-logo">
            <span class="brand-icon-mini">
                <i class="fa-solid fa-server"></i>
            </span>
            <span>TKJ <span style="color: #0284c7;">Smart Service</span></span>
        </a>
        <a href="<?= BASE_URL ?>" class="auth-back-btn">
            <i class="fa-solid fa-arrow-left me-1"></i> Beranda
        </a>
    </div>

    <!-- Minimalist Auth Card -->
    <div class="auth-minimal-card">
        
        <!-- Header -->
        <h1 class="auth-title-serif">Create an Account</h1>
        <p class="auth-subtitle">You are few moments away from getting started!</p>

        <!-- Flash Alert Messages -->
        <?php $flashRegister = AuthHelper::getFlash('register_error'); ?>
        <?php if ($flashRegister): ?>
            <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashRegister['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Form Register -->
        <form action="<?= BASE_URL ?>/register" method="POST" id="registerForm">
            <?= SecurityHelper::csrfField() ?>

            <!-- Tips & Updates Checkbox (as in reference image) -->
            <label class="auth-checkbox-group">
                <input type="checkbox" name="subscribe_tips" class="auth-checkbox-input" checked>
                <span class="auth-checkbox-text">Send me tips, updates and offers</span>
            </label>

            <!-- Nama Lengkap -->
            <div class="auth-field">
                <label for="nama" class="auth-label">Full Name</label>
                <input type="text" class="auth-input" id="nama" name="nama" placeholder="Enter your full name" required autocomplete="name">
            </div>

            <!-- Email -->
            <div class="auth-field">
                <label for="email" class="auth-label">Email</label>
                <input type="email" class="auth-input" id="email" name="email" placeholder="Enter your email" required autocomplete="email">
            </div>

            <!-- WhatsApp Number -->
            <div class="auth-field">
                <label for="no_telepon" class="auth-label">
                    WhatsApp Number
                </label>
                <input type="tel" class="auth-input" id="no_telepon" name="no_telepon" placeholder="08xxxxxxxxxx" required autocomplete="tel">
                <div class="text-muted extra-small mt-1" style="font-size: 0.75rem;">
                    <i class="fa-brands fa-whatsapp text-success me-1"></i> 6-digit OTP verification code will be sent to this WhatsApp number.
                </div>
            </div>

            <!-- Password -->
            <div class="auth-field">
                <label for="password" class="auth-label">Password</label>
                <div class="auth-password-wrapper">
                    <input type="password" class="auth-input" id="password" name="password" placeholder="••••••••••••" required minlength="6">
                    <button type="button" class="auth-password-toggle" onclick="togglePasswordVisibility('password', this)" title="Show/Hide Password">
                        <i class="fa-regular fa-eye-slash"></i>
                    </button>
                </div>
            </div>

            <!-- Confirm Password -->
            <div class="auth-field">
                <label for="confirm_password" class="auth-label">Confirm Password</label>
                <div class="auth-password-wrapper">
                    <input type="password" class="auth-input" id="confirm_password" name="confirm_password" placeholder="••••••••••••" required minlength="6">
                    <button type="button" class="auth-password-toggle" onclick="togglePasswordVisibility('confirm_password', this)" title="Show/Hide Password">
                        <i class="fa-regular fa-eye-slash"></i>
                    </button>
                </div>
            </div>

            <!-- Terms & Privacy Note -->
            <p class="auth-terms-note">
                By signing up, you accept TKJ Smart Service <a href="javascript:void(0)" onclick="alert('Kebijakan Privasi: Data Anda dilindungi dengan standar enkripsi tinggi.')">privacy policy</a> and <a href="javascript:void(0)" onclick="alert('Syarat Layanan: Akun digunakan untuk pemesanan layanan IT & Jaringan.')">terms of service</a>.
            </p>

            <!-- Primary Black Submit Button -->
            <button type="submit" class="btn-auth-primary">
                Sign up
            </button>
        </form>


        <!-- Footer Link -->
        <p class="auth-footer-link">
            Already have an account? <a href="<?= BASE_URL ?>/login">Log In</a>
        </p>

    </div>
</div>

<script>
function togglePasswordVisibility(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    }
}
</script>

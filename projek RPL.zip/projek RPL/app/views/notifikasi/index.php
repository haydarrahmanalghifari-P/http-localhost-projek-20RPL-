<section class="py-5">
    <div class="container">
        
        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">INTERNAL WEBSITE NOTIFICATION</span>
                <h2 class="fw-bold text-white mb-0">Daftar Notifikasi Saya</h2>
            </div>
            <a href="<?= BASE_URL ?>/notifikasi/readAll" class="btn btn-outline-cyan rounded-pill btn-sm fw-bold">
                <i class="fa-solid fa-check-double me-1"></i> Tandai Semua Sudah Dibaca
            </a>
        </div>

        <!-- Flash Message -->
        <?php $flashNotif = AuthHelper::getFlash('notif_success'); ?>
        <?php if ($flashNotif): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashNotif['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- List Notifikasi -->
        <?php if (!empty($notifications)): ?>
            <div class="vstack gap-3">
                <?php foreach ($notifications as $n): ?>
                    <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 <?= ($n['status'] === 'belum_dibaca') ? 'border-start border-start-cyan border-start-4 bg-dark-card' : 'opacity-75' ?>">
                        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
                            <div class="d-flex align-items-center gap-2">
                                <i class="fa-solid fa-bell <?= ($n['status'] === 'belum_dibaca') ? 'text-cyan' : 'text-white-50' ?> fs-5"></i>
                                <h6 class="fw-bold text-white mb-0"><?= htmlspecialchars($n['judul']) ?></h6>
                                <?php if ($n['status'] === 'belum_dibaca'): ?>
                                    <span class="badge bg-danger rounded-pill extra-small">Baru</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary rounded-pill extra-small">Dibaca</span>
                                <?php endif; ?>
                            </div>
                            <small class="text-white-50 extra-small">
                                <i class="fa-regular fa-clock me-1"></i> <?= date('d M Y H:i', strtotime($n['created_at'])) ?>
                            </small>
                        </div>
                        <p class="text-white-50 small mb-3">
                            <?= htmlspecialchars($n['pesan']) ?>
                        </p>
                        <?php if ($n['status'] === 'belum_dibaca'): ?>
                            <a href="<?= BASE_URL ?>/notifikasi/read/<?= $n['id'] ?>" class="btn btn-cyan btn-sm rounded-pill py-0 px-3 extra-small fw-bold text-dark">
                                <i class="fa-solid fa-check me-1"></i> Tandai Dibaca
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="glass-card p-5 rounded-4 border border-secondary border-opacity-25 text-center my-4">
                <i class="fa-solid fa-bell-slash text-cyan display-3 mb-3"></i>
                <h4 class="fw-bold text-white">Belum Ada Notifikasi</h4>
                <p class="text-white-50 max-w-600 mx-auto mb-0">
                    Pemberitahuan aktivitas pesanan dan tugas pengerjaan Anda akan ditampilkan di halaman ini.
                </p>
            </div>
        <?php endif; ?>

    </div>
</section>

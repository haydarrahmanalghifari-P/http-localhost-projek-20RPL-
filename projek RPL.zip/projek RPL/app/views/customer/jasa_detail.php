<section class="py-5">
    <div class="container">
        
        <a href="<?= BASE_URL ?>/customer/jasa" class="btn btn-outline-secondary rounded-pill text-white mb-4 extra-small">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Katalog Layanan
        </a>

        <div class="row g-5">
            <!-- Left Info Card -->
            <div class="col-lg-7">
                <div class="glass-card p-4 p-md-5 rounded-4 border border-cyan border-opacity-25 shadow-lg">
                    <div class="d-flex align-items-center gap-3 mb-4">
                        <div class="service-icon-box" style="width: 64px; height: 64px;">
                            <i class="fa-solid <?= htmlspecialchars($service['icon'] ?? 'fa-screwdriver-wrench') ?> fs-2 text-cyan"></i>
                        </div>
                        <div>
                            <span class="badge <?= htmlspecialchars($service['badge_color'] ?? 'bg-cyan text-dark') ?> rounded-pill px-3 py-1 extra-small fw-bold">
                                <?= htmlspecialchars($service['badge'] ?? 'Layanan TKJ') ?>
                            </span>
                            <h2 class="fw-bold text-white mb-0 mt-1"><?= htmlspecialchars($service['title']) ?></h2>
                        </div>
                    </div>

                    <h5 class="fw-bold text-cyan mb-2">Deskripsi Layanan</h5>
                    <p class="text-white-50 lead fs-6 mb-4">
                        <?= htmlspecialchars($service['description']) ?>
                    </p>

                    <h5 class="fw-bold text-cyan mb-3">Cakupan Pengerjaan & Fitur Layanan</h5>
                    <?php if (!empty($service['features']) && is_array($service['features'])): ?>
                        <div class="vstack gap-2 mb-4">
                            <?php foreach ($service['features'] as $feat): ?>
                                <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25 d-flex align-items-center gap-3">
                                    <i class="fa-solid fa-circle-check text-cyan fs-5"></i>
                                    <span class="text-white small fw-medium"><?= htmlspecialchars($feat) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <div class="p-4 rounded-4 bg-dark-card border border-cyan border-opacity-25 mt-4">
                        <h6 class="fw-bold text-white mb-2"><i class="fa-solid fa-shield-halved text-cyan me-2"></i> Jaminan Kualitas TEFA TKJ</h6>
                        <p class="text-white-50 extra-small mb-0">
                            Setiap pengerjaan unit bisnis didampingi secara langsung oleh instruktur teknis/guru pengajar keahlian TKJ. Hasil pekerjaan rapi, diuji ketat, dan bergaransi.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Right Booking Action Card -->
            <div class="col-lg-5">
                <div class="p-4 p-md-5 rounded-4 glass-card border border-secondary border-opacity-25 sticky-top" style="top: 100px;">
                    <div class="text-center mb-4">
                        <span class="text-white-50 small">Estimasi Biaya Pengerjaan</span>
                        <div class="fs-2 fw-extrabold text-cyan mt-1"><?= htmlspecialchars($service['price']) ?></div>
                        <small class="text-white-50 extra-small d-block mt-1">*Biaya akhir disesuaikan dengan volume/titik pengerjaan</small>
                    </div>

                    <a href="<?= BASE_URL ?>/customer/pesanan/create?jasa_id=<?= $service['id'] ?>" class="btn btn-cyan text-dark w-100 rounded-pill fw-bold py-3 btn-shadow fs-6 mb-3">
                        <i class="fa-solid fa-paper-plane me-2"></i> Pesan Jasa Ini Sekarang
                    </a>

                    <div class="vstack gap-2 border-top border-secondary border-opacity-25 pt-3 extra-small text-white-50">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fa-solid fa-check text-cyan"></i> Pembayaran Fleksibel (Cash/Transfer/QRIS)
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <i class="fa-solid fa-check text-cyan"></i> Kunjungan Teknisi Langsung ke Lokasi
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <i class="fa-solid fa-check text-cyan"></i> Garansi Pengerjaan Ulang Gratis
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="py-5">
    <div class="container">
        
        <a href="<?= BASE_URL ?>/customer/pesanan" class="btn btn-outline-secondary rounded-pill text-white mb-4 extra-small">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Daftar Pesanan
        </a>

        <div class="row g-4">
            <!-- Left Info Panel -->
            <div class="col-lg-8">
                <div class="glass-card p-4 p-md-5 rounded-4 border border-cyan border-opacity-25 shadow-lg mb-4">
                    
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 border-bottom border-secondary border-opacity-25 pb-3 mb-4">
                        <div>
                            <span class="text-white-50 extra-small d-block">Kode Pesanan</span>
                            <h3 class="fw-bold text-white mb-0"><?= htmlspecialchars($order['kode_pesanan']) ?></h3>
                        </div>
                        <div>
                            <?php if ($order['status'] === 'pending'): ?>
                                <span class="badge bg-warning text-dark px-3 py-2 fs-6 rounded-pill">Status: Pending</span>
                            <?php elseif ($order['status'] === 'dikonfirmasi'): ?>
                                <span class="badge bg-info text-dark px-3 py-2 fs-6 rounded-pill">Status: Dikonfirmasi</span>
                            <?php elseif ($order['status'] === 'diproses'): ?>
                                <span class="badge bg-primary px-3 py-2 fs-6 rounded-pill">Status: Diproses Teknisi</span>
                            <?php elseif ($order['status'] === 'selesai'): ?>
                                <span class="badge bg-success px-3 py-2 fs-6 rounded-pill">Status: Selesai</span>
                            <?php else: ?>
                                <span class="badge bg-danger px-3 py-2 fs-6 rounded-pill">Status: Dibatalkan</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Progress Status Timeline -->
                    <h6 class="fw-bold text-cyan mb-3"><i class="fa-solid fa-bars-progress me-2"></i> Timeline Status Pengerjaan</h6>
                    <div class="row g-2 text-center mb-4">
                        <div class="col-3">
                            <div class="p-2 rounded-3 bg-dark-card border border-cyan">
                                <i class="fa-solid fa-circle-check text-cyan mb-1"></i>
                                <div class="extra-small text-white fw-bold">1. Order Dibuat</div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="p-2 rounded-3 bg-dark-card <?= in_array($order['status'], ['dikonfirmasi', 'diproses', 'selesai']) ? 'border border-cyan' : 'opacity-50' ?>">
                                <i class="fa-solid fa-user-check text-cyan mb-1"></i>
                                <div class="extra-small text-white fw-bold">2. Dikonfirmasi</div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="p-2 rounded-3 bg-dark-card <?= in_array($order['status'], ['diproses', 'selesai']) ? 'border border-cyan' : 'opacity-50' ?>">
                                <i class="fa-solid fa-screwdriver-wrench text-cyan mb-1"></i>
                                <div class="extra-small text-white fw-bold">3. Diproses</div>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="p-2 rounded-3 bg-dark-card <?= ($order['status'] === 'selesai') ? 'border border-cyan' : 'opacity-50' ?>">
                                <i class="fa-solid fa-flag-checkered text-cyan mb-1"></i>
                                <div class="extra-small text-white fw-bold">4. Selesai</div>
                            </div>
                        </div>
                    </div>

                    <!-- Details Grid -->
                    <div class="row g-4 mb-4">
                        <div class="col-md-6">
                            <h6 class="fw-bold text-cyan mb-2">Layanan Jasa Diorder</h6>
                            <p class="text-white fw-bold fs-5 mb-1"><?= htmlspecialchars($order['nama_jasa']) ?></p>
                            <p class="text-white-50 small mb-0"><?= htmlspecialchars($order['deskripsi_jasa'] ?? '') ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="fw-bold text-cyan mb-2">Teknisi Siswa Ditugaskan</h6>
                            <?php if (!empty($order['nama_teknisi'])): ?>
                                <p class="text-white fw-bold fs-6 mb-1">
                                    <i class="fa-solid fa-user-gear text-cyan me-1"></i> <?= htmlspecialchars($order['nama_teknisi']) ?>
                                </p>
                                <span class="badge bg-cyan-subtle text-cyan extra-small">Supervisi Guru TKJ</span>
                            <?php else: ?>
                                <p class="text-warning small mb-0"><i class="fa-solid fa-clock me-1"></i> Menunggu penugasan oleh Operator TEFA</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Problem Description -->
                    <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25 mb-4">
                        <h6 class="fw-bold text-cyan mb-2">Deskripsi Masalah / Alamat Kunjungan</h6>
                        <p class="text-white small mb-2">
                            <strong>Alamat:</strong> <?= htmlspecialchars($order['alamat']) ?> <br>
                            <strong>No. Telp / WA:</strong> <?= htmlspecialchars($order['no_telepon']) ?>
                        </p>
                        <p class="text-white-50 small mb-0">
                            <strong>Masalah:</strong> <?= htmlspecialchars($order['deskripsi_masalah']) ?>
                        </p>
                    </div>

                    <!-- Review Status if Completed -->
                    <?php if ($order['status'] === 'selesai'): ?>
                        <div class="p-3 rounded-3 bg-success bg-opacity-10 border border-success border-opacity-25 d-flex align-items-center justify-content-between">
                            <div>
                                <h6 class="fw-bold text-success mb-1"><i class="fa-solid fa-star text-warning me-1"></i> Ulasan Pelanggan</h6>
                                <p class="text-white-50 extra-small mb-0">
                                    <?= !empty($order['rating']) ? "Rating: {$order['rating']}/5 bintang. Ulasan: \"{$order['review_komentar']}\"" : "Pesanan ini sudah selesai. Berikan rating dan ulasan Anda." ?>
                                </p>
                            </div>
                            <?php if (empty($order['rating'])): ?>
                                <a href="<?= BASE_URL ?>/customer/review/<?= $order['id'] ?>" class="btn btn-warning text-dark btn-sm rounded-pill fw-bold">
                                    <i class="fa-solid fa-star me-1"></i> Beri Rating
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

            <!-- Right Price & Summary Card & Modul Pembayaran -->
            <div class="col-lg-4">
                <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 sticky-top" style="top: 100px;">
                    
                    <!-- Flash Messages -->
                    <?php $flashSuccess = AuthHelper::getFlash('order_success'); ?>
                    <?php if ($flashSuccess): ?>
                        <div class="alert alert-success alert-dismissible fade show extra-small mb-3" role="alert">
                            <i class="fa-solid fa-circle-check me-1"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php $flashError = AuthHelper::getFlash('order_error'); ?>
                    <?php if ($flashError): ?>
                        <div class="alert alert-danger alert-dismissible fade show extra-small mb-3" role="alert">
                            <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= htmlspecialchars($flashError['message']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <h6 class="fw-bold text-white mb-3"><i class="fa-solid fa-wallet text-cyan me-2"></i> Informasi Pembayaran</h6>
                    
                    <div class="d-flex justify-content-between text-white-50 small mb-2">
                        <span>Harga Layanan Jasa:</span>
                        <span class="text-white">Rp <?= number_format($order['harga_mulai'] ?? 150000, 0, ',', '.') ?></span>
                    </div>
                    <div class="d-flex justify-content-between text-white-50 small mb-3">
                        <span>Garansi Pengerjaan:</span>
                        <span class="text-success fw-bold">GRATIS</span>
                    </div>

                    <hr class="border-secondary border-opacity-25">

                    <div class="d-flex justify-content-between text-white fw-bold mb-3">
                        <span>Total Tagihan:</span>
                        <span class="text-cyan fs-5">Rp <?= number_format($order['total_harga'] ?? 150000, 0, ',', '.') ?></span>
                    </div>

                    <!-- Status Badge Pembayaran -->
                    <?php 
                    $payStatus = $payment['status'] ?? 'belum_dibayar';
                    $payMethod = strtolower($payment['metode_pembayaran'] ?? 'transfer');
                    ?>
                    <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25 mb-3 text-center">
                        <div class="text-white-50 extra-small mb-1">Status Pembayaran:</div>
                        <?php if ($payStatus === 'dibayar' || $payStatus === 'lunas'): ?>
                            <span class="badge bg-success px-3 py-2 fs-6 rounded-pill">
                                <i class="fa-solid fa-check-circle me-1"></i> Dibayar (Lunas)
                            </span>
                        <?php elseif ($payStatus === 'menunggu_verifikasi' || $payStatus === 'pending'): ?>
                            <span class="badge bg-info text-dark px-3 py-2 fs-6 rounded-pill">
                                <i class="fa-solid fa-clock me-1"></i> Menunggu Verifikasi Operator
                            </span>
                        <?php elseif ($payStatus === 'ditolak'): ?>
                            <span class="badge bg-danger px-3 py-2 fs-6 rounded-pill">
                                <i class="fa-solid fa-circle-xmark me-1"></i> Ditolak
                            </span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark px-3 py-2 fs-6 rounded-pill">
                                <i class="fa-solid fa-circle-exclamation me-1"></i> Belum Dibayar
                            </span>
                        <?php endif; ?>
                    </div>

                    <!-- Catatan Operator jika ditolak -->
                    <?php if ($payStatus === 'ditolak' && !empty($payment['catatan_operator'])): ?>
                        <div class="alert alert-danger extra-small mb-3">
                            <strong><i class="fa-solid fa-circle-info me-1"></i> Alasan Penolakan:</strong> <br>
                            <?= htmlspecialchars($payment['catatan_operator']) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Form / Pratinjau Pembayaran -->
                    <?php if (in_array($payStatus, ['belum_dibayar', 'ditolak'])): ?>
                        
                        <!-- Form Pembayaran / Upload Bukti -->
                        <form action="<?= BASE_URL ?>/customer/bayar/<?= $order['id'] ?>" method="POST" enctype="multipart/form-data" class="p-3 rounded-3 bg-dark bg-opacity-75 border border-cyan border-opacity-25">
                            <?= SecurityHelper::csrfField() ?>
                            <h6 class="fw-bold text-cyan small mb-3"><i class="fa-solid fa-credit-card me-1"></i> Konfirmasi Pembayaran</h6>
                            
                            <div class="mb-3">
                                <label class="form-label text-white extra-small fw-bold">Pilih Metode Pembayaran</label>
                                <div class="d-flex gap-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="metode_pembayaran" id="payTransfer" value="transfer" checked>
                                        <label class="form-check-input-label text-white extra-small" for="payTransfer">
                                            Transfer Bank
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="metode_pembayaran" id="payCash" value="cash">
                                        <label class="form-check-input-label text-white extra-small" for="payCash">
                                            Cash (Tunai)
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- Info Rekening Bank -->
                            <div id="bankInfoBox" class="p-2 rounded-2 bg-dark border border-secondary border-opacity-25 mb-3 extra-small text-white-50">
                                <div class="fw-bold text-cyan mb-1">Rekening Tujuan Transfer:</div>
                                <div>• <strong>Bank BCA:</strong> 123-456-7890 (a.n TKJ Smart Service)</div>
                                <div>• <strong>Bank Mandiri:</strong> 098-765-4321 (a.n TKJ Smart Service)</div>
                            </div>

                            <div class="mb-3" id="proofUploadGroup">
                                <label class="form-label text-white extra-small fw-bold">Unggah Bukti Pembayaran (JPG/PNG/PDF)</label>
                                <input type="file" name="bukti_pembayaran" class="form-control form-control-sm bg-dark text-white border-secondary" accept="image/*,.pdf" required>
                            </div>

                            <button type="submit" class="btn btn-cyan text-dark fw-bold w-100 btn-sm rounded-pill btn-shadow">
                                <i class="fa-solid fa-paper-plane me-1"></i> Kirim Konfirmasi Pembayaran
                            </button>
                        </form>

                    <?php else: ?>
                        
                        <!-- Pratinjau Bukti Pembayaran -->
                        <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25 extra-small text-white-50 mb-3">
                            <div class="fw-bold text-white mb-1">Metode: <span class="text-cyan text-uppercase"><?= htmlspecialchars($payMethod) ?></span></div>
                            <?php if (!empty($payment['bukti_pembayaran'])): ?>
                                <div class="mt-2">
                                    <span class="d-block mb-1 text-white-50">Bukti Transfer:</span>
                                    <a href="<?= BASE_URL ?>/<?= htmlspecialchars($payment['bukti_pembayaran']) ?>" target="_blank" class="btn btn-outline-cyan btn-sm py-1 px-2 w-100 extra-small">
                                        <i class="fa-solid fa-image me-1"></i> Lihat Bukti Transfer
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>

                    <?php endif; ?>

                </div>
            </div>
        </div>


    </div>
</section>

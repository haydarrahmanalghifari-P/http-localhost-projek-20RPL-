<section class="py-5">
    <div class="container">
        
        <!-- Flash Alert Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('auth_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Welcome Banner Customer -->
        <div class="p-4 p-md-5 rounded-4 glass-card border border-cyan border-opacity-25 mb-4 position-relative overflow-hidden">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <span class="badge bg-primary text-white rounded-pill px-3 py-1 mb-2">
                        <i class="fa-solid fa-user me-1"></i> Dashboard Customer
                    </span>
                    <h2 class="fw-bold text-white mb-2">
                        Selamat Datang, <span class="text-cyan"><?= htmlspecialchars($user['nama']) ?></span>!
                    </h2>
                    <p class="text-white-50 mb-3">
                        Kelola dan pantau pengajuan layanan instalasi CCTV, jaringan LAN, Wi-Fi, dan service komputer Anda secara real-time di sini.
                    </p>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?= BASE_URL ?>/customer/pesanan/create" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow btn-sm">
                            <i class="fa-solid fa-plus me-1"></i> Buat Pesanan Jasa Baru
                        </a>
                        <a href="<?= BASE_URL ?>/customer/ai-assistant" class="btn btn-warning text-dark rounded-pill fw-bold px-3 btn-sm">
                            <i class="fa-solid fa-robot me-1"></i> Tanya AI Assistant
                        </a>
                        <a href="<?= BASE_URL ?>/customer/jasa" class="btn btn-outline-cyan rounded-pill fw-semibold px-3 btn-sm">
                            <i class="fa-solid fa-screwdriver-wrench me-1"></i> Lihat Katalog Layanan
                        </a>
                        <a href="<?= BASE_URL ?>/customer/profile" class="btn btn-outline-light rounded-pill fw-semibold px-3 btn-sm">
                            <i class="fa-solid fa-user-gear me-1"></i> Ubah Profil
                        </a>
                    </div>

                </div>
                <div class="col-lg-4 text-center text-lg-end mt-4 mt-lg-0">
                    <i class="fa-solid fa-user-gear display-1 text-cyan opacity-50"></i>
                </div>
            </div>
        </div>

        <!-- 4 Metric Widgets Mandatory Requirement -->
        <div class="row g-4 mb-4">
            <!-- Widget 1: Total Pesanan -->
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-white-50 extra-small fw-semibold text-uppercase">Jumlah Pesanan</div>
                            <div class="fs-2 fw-extrabold text-white"><?= $counts['total'] ?? 0 ?></div>
                        </div>
                        <div class="icon-square bg-cyan-subtle text-cyan p-3 rounded-3 fs-3">
                            <i class="fa-solid fa-receipt"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Widget 2: Pesanan Menunggu -->
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-white-50 extra-small fw-semibold text-uppercase">Pesanan Menunggu</div>
                            <div class="fs-2 fw-extrabold text-warning"><?= $counts['pending'] ?? 0 ?></div>
                        </div>
                        <div class="icon-square bg-warning bg-opacity-10 text-warning p-3 rounded-3 fs-3">
                            <i class="fa-solid fa-clock-rotate-left"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Widget 3: Pesanan Diproses -->
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-white-50 extra-small fw-semibold text-uppercase">Pesanan Diproses</div>
                            <div class="fs-2 fw-extrabold text-info"><?= $counts['diproses'] ?? 0 ?></div>
                        </div>
                        <div class="icon-square bg-info bg-opacity-10 text-info p-3 rounded-3 fs-3">
                            <i class="fa-solid fa-spinner"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Widget 4: Pesanan Selesai -->
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-white-50 extra-small fw-semibold text-uppercase">Pesanan Selesai</div>
                            <div class="fs-2 fw-extrabold text-success"><?= $counts['selesai'] ?? 0 ?></div>
                        </div>
                        <div class="icon-square bg-success bg-opacity-10 text-success p-3 rounded-3 fs-3">
                            <i class="fa-solid fa-circle-check"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Shortcut Menu Buttons -->
        <div class="row g-3 mb-4">
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/customer/jasa" class="btn btn-outline-cyan w-100 py-3 rounded-4 d-flex align-items-center justify-content-center gap-2 text-decoration-none fw-bold">
                    <i class="fa-solid fa-list-check fs-5"></i> Katalog Layanan
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/customer/pesanan" class="btn btn-outline-cyan w-100 py-3 rounded-4 d-flex align-items-center justify-content-center gap-2 text-decoration-none fw-bold">
                    <i class="fa-solid fa-box-open fs-5"></i> Pesanan Saya
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/customer/riwayat" class="btn btn-outline-cyan w-100 py-3 rounded-4 d-flex align-items-center justify-content-center gap-2 text-decoration-none fw-bold">
                    <i class="fa-solid fa-star fs-5"></i> Riwayat & Review
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/customer/profile" class="btn btn-outline-cyan w-100 py-3 rounded-4 d-flex align-items-center justify-content-center gap-2 text-decoration-none fw-bold">
                    <i class="fa-solid fa-user-pen fs-5"></i> Pengaturan Profil
                </a>
            </div>
        </div>

        <!-- Recent Active Orders Table -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <h5 class="fw-bold text-white mb-0">
                    <i class="fa-solid fa-clock-rotate-left text-cyan me-2"></i> Pesanan Aktif Terbaru
                </h5>
                <a href="<?= BASE_URL ?>/customer/pesanan" class="btn btn-outline-cyan btn-sm rounded-pill extra-small fw-bold">
                    Lihat Semua Pesanan
                </a>
            </div>

            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>Kode Pesanan</th>
                            <th>Layanan Jasa</th>
                            <th>Tanggal Pengerjaan</th>
                            <th>Teknisi Siswa</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recentOrders)): ?>
                            <?php foreach ($recentOrders as $ord): ?>
                                <tr>
                                    <td><strong class="text-white"><?= htmlspecialchars($ord['kode_pesanan']) ?></strong></td>
                                    <td><?= htmlspecialchars($ord['nama_jasa']) ?></td>
                                    <td><?= date('d M Y', strtotime($ord['tanggal_pengerjaan'] ?? $ord['tanggal_pemesanan'])) ?></td>
                                    <td>
                                        <?= !empty($ord['nama_teknisi']) ? htmlspecialchars($ord['nama_teknisi']) : '<span class="text-white-50">Menunggu Penugasan</span>' ?>
                                    </td>
                                    <td>
                                        <?php if ($ord['status'] === 'pending'): ?>
                                            <span class="badge bg-warning text-dark">Pending</span>
                                        <?php elseif ($ord['status'] === 'dikonfirmasi'): ?>
                                            <span class="badge bg-info text-dark">Dikonfirmasi</span>
                                        <?php elseif ($ord['status'] === 'diproses'): ?>
                                            <span class="badge bg-primary">Diproses</span>
                                        <?php elseif ($ord['status'] === 'selesai'): ?>
                                            <span class="badge bg-success">Selesai</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Dibatalkan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?= BASE_URL ?>/customer/pesanan/detail/<?= $ord['id'] ?>" class="btn btn-cyan btn-sm py-0 px-2 extra-small text-dark fw-bold">
                                            Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-white-50 py-3">
                                    Belum ada pesanan aktif. <a href="<?= BASE_URL ?>/customer/pesanan/create" class="text-cyan fw-bold">Buat pesanan pertama Anda sekarang</a>.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

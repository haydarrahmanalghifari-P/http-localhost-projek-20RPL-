<section class="py-5">
    <div class="container">
        
        <a href="<?= BASE_URL ?>/customer/riwayat" class="btn btn-outline-secondary rounded-pill text-white mb-4 extra-small">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Riwayat
        </a>

        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="glass-card p-4 p-md-5 rounded-4 shadow-lg border border-cyan border-opacity-25">
                    
                    <div class="text-center mb-4">
                        <div class="brand-icon-box mx-auto mb-3" style="width: 56px; height: 56px;">
                            <i class="fa-solid fa-star text-warning fs-3"></i>
                        </div>
                        <h3 class="fw-bold text-white mb-1">Beri Ulasan & Rating</h3>
                        <p class="text-white-50 small">
                            Bagikan pengalaman Anda menggunakan jasa teknisi siswa TKJ untuk pesanan <strong>#<?= htmlspecialchars($order['kode_pesanan']) ?></strong>
                        </p>
                    </div>

                    <!-- Flash Error -->
                    <?php $flashError = AuthHelper::getFlash('review_error'); ?>
                    <?php if ($flashError): ?>
                        <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                            <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashError['message']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?= BASE_URL ?>/customer/review/<?= $order['id'] ?>" method="POST">
                        <?= SecurityHelper::csrfField() ?>
                        <input type="hidden" name="pesanan_id" value="<?= $order['id'] ?>">

                        <!-- Rating Selection (1-5 Stars) -->
                        <div class="mb-4 text-center">
                            <label class="form-label text-white small fw-semibold d-block mb-2">Pilih Rating Kepuasan (1 - 5 Bintang)</label>
                            <div class="d-flex justify-content-center gap-3">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <div class="form-check form-check-inline m-0">
                                        <input class="btn-check" type="radio" name="rating" id="rating<?= $i ?>" value="<?= $i ?>" <?= $i === 5 ? 'checked' : '' ?>>
                                        <label class="btn btn-outline-warning rounded-circle p-3 d-flex align-items-center justify-content-center" style="width: 48px; height: 48px;" for="rating<?= $i ?>">
                                            <i class="fa-solid fa-star fs-5"></i>
                                        </label>
                                    </div>
                                <?php endfor; ?>
                            </div>
                        </div>

                        <!-- Komentar Review -->
                        <div class="mb-4">
                            <label for="komentar" class="form-label text-white small fw-semibold">Ulasan & Catatan Pelanggan</label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-comment-dots"></i>
                                </span>
                                <textarea class="form-control bg-dark-card border-secondary text-white" id="komentar" name="komentar" rows="4" placeholder="Tuliskan ulasan Anda mengenai kerapian kabel, kecepatan pengerjaan, atau sikap teknisi siswa TKJ..." required></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-cyan text-dark w-100 rounded-pill fw-bold py-3 btn-shadow fs-6">
                            <i class="fa-solid fa-paper-plane me-2"></i> Kirim Ulasan Sekarang
                        </button>
                    </form>

                </div>
            </div>
        </div>

    </div>
</section>

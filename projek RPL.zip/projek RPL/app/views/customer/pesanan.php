<section class="py-5">
    <div class="container">
        
        <!-- Flash Alert Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('order_success'); ?>
        <?php $flashError = AuthHelper::getFlash('order_error'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i> <?= htmlspecialchars($flashError['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Page Title & Actions -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">PESANAN AKTIF</span>
                <h2 class="fw-bold text-white mb-0">Daftar Pesanan Saya</h2>
            </div>
            <a href="<?= BASE_URL ?>/customer/pesanan/create" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow">
                <i class="fa-solid fa-plus me-1"></i> Buat Pesanan Baru
            </a>
        </div>

        <!-- List Pesanan Aktif Cards -->
        <?php if (!empty($orders)): ?>
            <div class="vstack gap-3">
                <?php foreach ($orders as $ord): ?>
                    <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
                        <div class="row align-items-center g-3">
                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Kode Pesanan</small>
                                <strong class="text-white fs-6"><?= htmlspecialchars($ord['kode_pesanan']) ?></strong>
                                <small class="d-block text-cyan extra-small mt-1">
                                    <i class="fa-solid fa-calendar me-1"></i> <?= date('d M Y', strtotime($ord['tanggal_pemesanan'])) ?>
                                </small>
                            </div>

                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Layanan Jasa</small>
                                <h6 class="fw-bold text-white mb-1"><?= htmlspecialchars($ord['nama_jasa']) ?></h6>
                                <small class="text-white-50 extra-small">
                                    <i class="fa-solid fa-location-dot me-1 text-cyan"></i> <?= htmlspecialchars(substr($ord['alamat'], 0, 35)) ?>...
                                </small>
                            </div>

                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Teknisi Siswa TKJ</small>
                                <div class="small fw-semibold text-white">
                                    <?= !empty($ord['nama_teknisi']) ? htmlspecialchars($ord['nama_teknisi']) : '<span class="text-warning"><i class="fa-solid fa-clock me-1"></i> Belum DPlot</span>' ?>
                                </div>
                                <small class="text-white-50 extra-small d-block">
                                    Jadwal: <?= date('d M Y', strtotime($ord['tanggal_pengerjaan'] ?? $ord['tanggal_pemesanan'])) ?>
                                </small>
                            </div>

                            <div class="col-md-3 text-md-end">
                                <div class="mb-2">
                                    <?php if ($ord['status'] === 'pending'): ?>
                                        <span class="badge bg-warning text-dark px-3 py-1">Menunggu Konfirmasi</span>
                                    <?php elseif ($ord['status'] === 'dikonfirmasi'): ?>
                                        <span class="badge bg-info text-dark px-3 py-1">Dikonfirmasi</span>
                                    <?php elseif ($ord['status'] === 'diproses'): ?>
                                        <span class="badge bg-primary px-3 py-1">Teknisi Di Jalan / Pengerjaan</span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?= BASE_URL ?>/customer/pesanan/detail/<?= $ord['id'] ?>" class="btn btn-outline-cyan btn-sm rounded-pill px-3 fw-bold">
                                    <i class="fa-solid fa-eye me-1"></i> Detail Pesanan
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="glass-card p-5 rounded-4 border border-secondary border-opacity-25 text-center my-4">
                <i class="fa-solid fa-box-open text-cyan display-3 mb-3"></i>
                <h4 class="fw-bold text-white">Belum Ada Pesanan Aktif</h4>
                <p class="text-white-50 max-w-600 mx-auto mb-4">
                    Anda tidak memiliki pesanan yang sedang diproses saat ini. Pilih layanan IT yang Anda butuhkan dan ajukan pemesanan.
                </p>
                <a href="<?= BASE_URL ?>/customer/pesanan/create" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 py-2">
                    <i class="fa-solid fa-plus me-1"></i> Buat Pesanan Baru Sekarang
                </a>
            </div>
        <?php endif; ?>

    </div>
</section>

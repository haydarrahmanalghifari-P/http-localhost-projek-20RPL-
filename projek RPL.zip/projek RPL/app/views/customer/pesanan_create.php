<section class="py-5">
    <div class="container">
        
        <a href="<?= BASE_URL ?>/customer/pesanan" class="btn btn-outline-secondary rounded-pill text-white mb-4 extra-small">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Pesanan Saya
        </a>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="glass-card p-4 p-md-5 rounded-4 shadow-lg border border-cyan border-opacity-25">
                    
                    <div class="text-center mb-4">
                        <div class="brand-icon-box mx-auto mb-3" style="width: 56px; height: 56px;">
                            <i class="fa-solid fa-cart-plus text-cyan fs-3"></i>
                        </div>
                        <h3 class="fw-bold text-white mb-1">Form Pemesanan Jasa IT</h3>
                        <p class="text-white-50 small">Lengkapi formulir berikut untuk mengajukan pemesanan ke unit bisnis TKJ</p>
                    </div>

                    <!-- Flash Alert Error -->
                    <?php $flashError = AuthHelper::getFlash('order_error'); ?>
                    <?php if ($flashError): ?>
                        <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                            <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashError['message']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?= BASE_URL ?>/customer/pesanan/create" method="POST" enctype="multipart/form-data">
                        <?= SecurityHelper::csrfField() ?>
                        
                        <!-- 1. Nama Pelanggan (Readonly/Prefilled) -->
                        <div class="mb-3">
                            <label for="nama" class="form-label text-white small fw-semibold">Nama Pemesan <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-user"></i>
                                </span>
                                <input type="text" class="form-control bg-dark-card border-secondary text-white" id="nama" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" required readonly>
                            </div>
                        </div>

                        <!-- 2. Nomor Telepon -->
                        <div class="mb-3">
                            <label for="no_telepon" class="form-label text-white small fw-semibold">Nomor Telepon / WhatsApp <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-phone"></i>
                                </span>
                                <input type="text" class="form-control bg-dark-card border-secondary text-white" id="no_telepon" name="no_telepon" placeholder="Contoh: 081234567890" required pattern="[0-9]{9,15}">
                            </div>
                            <small class="text-white-50 extra-small">Nomor yang aktif untuk dikonfirmasi oleh teknisi/operator.</small>
                        </div>

                        <!-- 3. Alamat Lengkap Pengerjaan -->
                        <div class="mb-3">
                            <label for="alamat" class="form-label text-white small fw-semibold">Alamat Lengkap Kunjungan <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-location-dot"></i>
                                </span>
                                <textarea class="form-control bg-dark-card border-secondary text-white" id="alamat" name="alamat" rows="2" placeholder="Nama Jalan, No. Rumah, RT/RW, Patokan Lokasi..." required></textarea>
                            </div>
                        </div>

                        <!-- 4. Jenis Jasa -->
                        <div class="mb-3">
                            <label for="jasa_id" class="form-label text-white small fw-semibold">Pilihan Jenis Jasa IT <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-list"></i>
                                </span>
                                <select class="form-select bg-dark-card border-secondary text-white" id="jasa_id" name="jasa_id" required>
                                    <option value="" disabled <?= empty($selectedJasaId) ? 'selected' : '' ?>>-- Pilih Layanan Jasa --</option>
                                    <?php if (!empty($services)): ?>
                                        <?php foreach ($services as $svc): ?>
                                            <option value="<?= $svc['id'] ?>" <?= ($selectedJasaId == $svc['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($svc['title']) ?> (<?= htmlspecialchars($svc['price']) ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <!-- 5. Deskripsi Masalah / Detail Kebutuhan -->
                        <div class="mb-3">
                            <label for="deskripsi_masalah" class="form-label text-white small fw-semibold">Deskripsi Masalah / Kebutuhan IT <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-comment-dots"></i>
                                </span>
                                <textarea class="form-control bg-dark-card border-secondary text-white" id="deskripsi_masalah" name="deskripsi_masalah" rows="3" placeholder="Jelaskan detail kendala perangkat atau rencana titik pemasangan CCTV/Jaringan..." required minlength="10"></textarea>
                            </div>
                        </div>

                        <!-- 6. Tanggal Pengerjaan yang Diinginkan -->
                        <div class="mb-3">
                            <label for="tanggal_pengerjaan" class="form-label text-white small fw-semibold">Tanggal & Waktu Kunjungan Diinginkan <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-calendar-days"></i>
                                </span>
                                <input type="date" class="form-control bg-dark-card border-secondary text-white" id="tanggal_pengerjaan" name="tanggal_pengerjaan" value="<?= date('Y-m-d', strtotime('+1 day')) ?>" min="<?= date('Y-m-d') ?>" required>
                            </div>
                        </div>

                        <!-- 7. Foto Masalah (Opsional) -->
                        <div class="mb-4">
                            <label for="foto_masalah" class="form-label text-white small fw-semibold">Foto Perangkat / Lokasi Masalah (Opsional)</label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-camera"></i>
                                </span>
                                <input type="file" class="form-control bg-dark-card border-secondary text-white" id="foto_masalah" name="foto_masalah" accept="image/png, image/jpeg, image/jpg, image/webp">
                            </div>
                            <small class="text-white-50 extra-small">Format foto: JPG, PNG, WEBP. Maksimal 2MB.</small>
                        </div>

                        <!-- Button Submit -->
                        <button type="submit" class="btn btn-cyan text-dark w-100 rounded-pill fw-bold py-3 btn-shadow fs-6">
                            <i class="fa-solid fa-paper-plane me-2"></i> Kirim Pesanan Sekarang
                        </button>
                    </form>

                </div>
            </div>
        </div>

    </div>
</section>

<section class="py-5">
    <div class="container">
        
        <!-- Header Page -->
        <div class="text-center max-w-700 mx-auto mb-5">
            <span class="badge bg-cyan text-dark fw-bold px-3 py-2 rounded-pill mb-2">KATALOG LAYANAN CUSTOMER</span>
            <h2 class="fw-bold text-white fs-1">Layanan Jasa IT Unit Bisnis TKJ</h2>
            <p class="text-white-50">
                Pilih layanan jasa IT yang Anda butuhkan. Setiap pengerjaan dilakukan langsung oleh siswa berbakat TKJ di bawah bimbingan teknisi pengajar berpengalaman.
            </p>
        </div>

        <!-- Grid 6 Layanan -->
        <div class="row g-4">
            <?php if (!empty($services)): ?>
                <?php foreach ($services as $svc): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="service-card h-100 p-4 rounded-4 d-flex flex-column justify-content-between position-relative">
                            <div>
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <div class="service-icon-box">
                                        <i class="fa-solid <?= htmlspecialchars($svc['icon']) ?> fs-3 text-cyan"></i>
                                    </div>
                                    <span class="badge <?= htmlspecialchars($svc['badge_color'] ?? 'bg-cyan text-dark') ?> rounded-pill px-3 py-1 small fw-bold">
                                        <?= htmlspecialchars($svc['badge'] ?? 'TKJ Service') ?>
                                    </span>
                                </div>

                                <h4 class="fw-bold text-white mb-2"><?= htmlspecialchars($svc['title']) ?></h4>
                                <p class="text-white-50 small mb-4">
                                    <?= htmlspecialchars($svc['description']) ?>
                                </p>

                                <?php if (!empty($svc['features']) && is_array($svc['features'])): ?>
                                    <ul class="list-unstyled service-feature-list mb-4">
                                        <?php foreach ($svc['features'] as $feat): ?>
                                            <li class="small text-white-50 mb-2 d-flex align-items-start gap-2">
                                                <i class="fa-solid fa-check text-cyan mt-1"></i>
                                                <span><?= htmlspecialchars($feat) ?></span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>

                            <div class="pt-3 border-top border-secondary border-opacity-25 mt-auto">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <span class="text-white-50 extra-small">Estimasi Biaya:</span>
                                    <span class="fw-bold text-cyan small"><?= htmlspecialchars($svc['price']) ?></span>
                                </div>
                                <div class="d-flex gap-2">
                                    <a href="<?= BASE_URL ?>/customer/jasa/detail/<?= $svc['id'] ?>" class="btn btn-outline-light w-50 rounded-pill btn-sm fw-semibold">
                                        <i class="fa-solid fa-circle-info me-1"></i> Detail
                                    </a>
                                    <a href="<?= BASE_URL ?>/customer/pesanan/create?jasa_id=<?= $svc['id'] ?>" class="btn btn-cyan w-50 rounded-pill btn-sm fw-bold text-dark">
                                        <i class="fa-solid fa-cart-plus me-1"></i> Pesan Jasa
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>
</section>

<section class="py-4 py-md-5">
    <div class="container">
        
        <!-- Breadcrumb / Header Page -->
        <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-4">
            <div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/customer/dashboard" class="text-cyan text-decoration-none"><i class="fa-solid fa-house me-1"></i> Dashboard</a></li>
                        <li class="breadcrumb-item active text-white-50" aria-current="page">AI Assistant</li>
                    </ol>
                </nav>
                <h3 class="fw-bold text-white mb-0 d-flex align-items-center gap-2">
                    <i class="fa-solid fa-robot text-cyan"></i> AI Assistant TKJ Smart Service
                </h3>
            </div>
            <div class="d-flex align-items-center gap-2">
                <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup(); }" class="btn btn-outline-cyan rounded-pill btn-sm px-3" title="Buka Pop-up Chatbot di pojok kanan bawah">
                    <i class="fa-solid fa-window-restore me-1"></i> Mode Pop-up
                </button>
                <a href="<?= BASE_URL ?>/customer/dashboard" class="btn btn-outline-light rounded-pill btn-sm px-3">
                    <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Dashboard
                </a>
            </div>
        </div>

        <!-- Chat Container Card -->
        <div class="card bg-white border border-light-subtle rounded-4 shadow-sm overflow-hidden">
            
            <!-- Chat Header -->
            <div class="card-header bg-white border-bottom border-light-subtle p-3 p-md-4">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center gap-3">
                        <div class="position-relative">
                            <div class="rounded-circle bg-cyan-subtle p-2 text-cyan d-flex align-items-center justify-content-center shadow-sm" style="width: 48px; height: 48px;">
                                <i class="fa-solid fa-robot fs-4"></i>
                            </div>
                            <span class="position-absolute bottom-0 end-0 p-1 bg-success border border-white rounded-circle" title="AI System Online">
                                <span class="visually-hidden">Online</span>
                            </span>
                        </div>
                        <div>
                            <h5 class="fw-bold text-dark mb-0">TKJ Smart Bot</h5>
                            <small class="text-secondary d-flex align-items-center gap-1">
                                <i class="fa-solid fa-circle text-success extra-small"></i> Siap membantu 24/7 (Unit Bisnis TKJ)
                            </small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center flex-wrap gap-2">
                        <!-- Pill Engine Group -->
                        <div class="btn-group btn-group-sm p-1 rounded-pill bg-light border border-light-subtle" role="group" aria-label="Ganti Model AI">
                            <button type="button" class="btn btn-engine-pill-page active" data-page-engine="gemini" id="pagePillGemini" title="Gunakan Google Gemini">
                                <i class="fa-brands fa-google text-primary me-1"></i> Gemini
                            </button>
                            <button type="button" class="btn btn-engine-pill-page" data-page-engine="deepseek" id="pagePillDeepseek" title="Gunakan DeepSeek AI">
                                <i class="fa-solid fa-brain text-info me-1"></i> DeepSeek
                            </button>
                            <button type="button" class="btn btn-engine-pill-page" data-page-engine="grok" id="pagePillGrok" title="Gunakan Groq/xAI">
                                <i class="fa-solid fa-bolt text-warning me-1"></i> Groq AI
                            </button>
                            <button type="button" class="btn btn-engine-pill-page" data-page-engine="database" id="pagePillDb" title="Gunakan Smart DB AI Lokal">
                                <i class="fa-solid fa-database text-success me-1"></i> DB Lokal
                            </button>
                        </div>
                        <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#globalAiSettingsModal" title="Pengaturan Model AI & API Keys (Di Luar Chatbot)">
                            <i class="fa-solid fa-sliders me-1"></i> Model &amp; API Keys
                        </button>
                        <button type="button" id="btnClearChat" class="btn btn-outline-danger btn-sm rounded-pill px-3" title="Bersihkan Percakapan">
                            <i class="fa-solid fa-trash-can me-1"></i> Reset Chat
                        </button>
                    </div>
                </div>
            </div>

            <!-- Area Percakapan (Chat Body) -->
            <div class="card-body p-3 p-md-4 chat-conversation-area" id="chatContainer" style="height: 480px; overflow-y: auto; background: #f8fafc;">
                
                <!-- Welcome AI Message -->
                <div class="d-flex gap-3 mb-4 chat-bubble-wrapper ai-msg">
                    <div class="flex-shrink-0">
                        <div class="rounded-circle bg-cyan-subtle text-cyan p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                            <i class="fa-solid fa-robot"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1" style="max-width: 85%;">
                        <div class="bg-white border border-light-subtle rounded-4 p-3 text-dark shadow-sm chat-bubble">
                            <div class="fw-bold text-cyan mb-1 small d-flex align-items-center gap-2">
                                <span>TKJ Smart Bot</span>
                                <small class="text-secondary extra-small font-normal"><?= date('H:i') ?></small>
                            </div>
                            <p class="mb-2 leading-relaxed text-dark">
                                Halo <strong><?= htmlspecialchars($user['nama']) ?></strong>! 👋 Saya adalah <strong>AI Assistant TKJ Smart Service</strong>. Ada yang bisa saya bantu hari ini?
                            </p>
                            <p class="mb-0 text-secondary small">
                                Anda dapat menanyakan rekomendasi layanan jasa IT, melacak status pesanan, mengetahui alur pemesanan, atau info garansi & pembayaran.
                            </p>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Quick Suggestion Chips -->
            <div class="px-3 px-md-4 py-2 bg-white border-top border-light-subtle overflow-x-auto">
                <div class="d-flex align-items-center gap-2 text-nowrap pb-1" id="suggestionChips">
                    <span class="text-secondary extra-small fw-semibold me-1"><i class="fa-solid fa-lightbulb text-warning me-1"></i> Rekomendasi:</span>
                    <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small chip-btn" data-query="Komputer saya sering mati sendiri, saya harus memilih jasa apa?">
                        💻 Komputer sering mati sendiri
                    </button>
                    <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small chip-btn" data-query="Bagaimana status pesanan saya saat ini?">
                        📦 Status Pesanan Saya
                    </button>
                    <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small chip-btn" data-query="Bagaimana cara memesan layanan jasa IT di sini?">
                        📋 Cara Pemesanan Jasa
                    </button>
                    <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small chip-btn" data-query="Ingin pasang kamera CCTV untuk toko dan pemantauan via HP">
                        📹 Pasang Kamera CCTV
                    </button>
                    <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small chip-btn" data-query="Apakah layanan jasa TKJ Smart Service bergaransi?">
                        🛡️ Garansi & Pembayaran
                    </button>
                </div>
            </div>

            <!-- Input Pertanyaan & Tombol Kirim (Footer) -->
            <div class="card-footer bg-white border-top border-light-subtle p-3">
                <form id="chatForm" class="d-flex align-items-center gap-2">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-light-subtle text-cyan">
                            <i class="fa-solid fa-comment-dots"></i>
                        </span>
                        <input type="text" id="userInput" class="form-control bg-light text-dark border-light-subtle focus-ring-cyan py-2" placeholder="Ketik pertanyaan Anda tentang layanan, rekomendasi, atau pesanan..." autocomplete="off" required>
                    </div>
                    <button type="submit" id="btnSend" class="btn btn-primary text-white fw-bold rounded-3 px-4 py-2 d-flex align-items-center gap-2 shadow-sm flex-shrink-0" style="background: linear-gradient(135deg, #06b6d4, #0284c7); border: none;">
                        <span>Kirim</span>
                        <i class="fa-solid fa-paper-plane"></i>
                    </button>
                </form>
            </div>

        </div>

    </div>
</section>

<!-- Inline Style Custom Chat UI -->
<style>
.btn-engine-pill-page {
    font-size: 0.75rem;
    font-weight: 700;
    color: rgba(255, 255, 255, 0.65);
    padding: 3px 12px;
    border-radius: 50rem !important;
    border: none;
    background: transparent;
    transition: all 0.2s ease;
}
.btn-engine-pill-page:hover {
    color: #fff;
    background: rgba(255, 255, 255, 0.1);
}
.btn-engine-pill-page.active {
    color: #070b14;
    background: #22d3ee;
    box-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
}
.btn-engine-pill-page[data-page-engine="grok"].active {
    background: linear-gradient(135deg, #f59e0b, #eab308);
    color: #000;
    box-shadow: 0 0 12px rgba(245, 158, 11, 0.6);
}
.btn-engine-pill-page[data-page-engine="gemini"].active {
    background: linear-gradient(135deg, #06b6d4, #3b82f6);
    color: #fff;
    box-shadow: 0 0 12px rgba(59, 130, 246, 0.6);
}
.btn-engine-pill-page[data-page-engine="database"].active {
    background: linear-gradient(135deg, #10b981, #059669);
    color: #fff;
    box-shadow: 0 0 12px rgba(16, 185, 129, 0.6);
}

.page-ai-card {
    background: #ffffff;
    transition: all 0.25s ease;
}
.page-ai-card:hover {
    background: #f8fafc;
    border-color: rgba(6, 182, 212, 0.5) !important;
}
.page-ai-card.active {
    background: #ecfeff;
    border-color: rgba(6, 182, 212, 0.85) !important;
    box-shadow: 0 0 18px rgba(6, 182, 212, 0.15);
}

.chat-conversation-area::-webkit-scrollbar {
    width: 6px;
}
.chat-conversation-area::-webkit-scrollbar-track {
    background: #f1f5f9;
}
.chat-conversation-area::-webkit-scrollbar-thumb {
    background: rgba(6, 182, 212, 0.4);
    border-radius: 4px;
}
.chat-bubble-wrapper {
    animation: fadeIn 0.3s ease-in-out;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}
.user-bubble {
    background: linear-gradient(135deg, #0e7490 0%, #06b6d4 100%) !important;
    border: none !important;
}
.typing-dots span {
    display: inline-block;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background-color: #06b6d4;
    animation: typing 1.4s infinite ease-in-out both;
    margin: 0 2px;
}
.typing-dots span:nth-child(1) { animation-delay: -0.32s; }
.typing-dots span:nth-child(2) { animation-delay: -0.16s; }
@keyframes typing {
    0%, 80%, 100% { transform: scale(0); }
    40% { transform: scale(1); }
}
</style>

<!-- Script AJAX Chatbot Logic -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const chatContainer = document.getElementById('chatContainer');
    const chatForm = document.getElementById('chatForm');
    const userInput = document.getElementById('userInput');
    const btnSend = document.getElementById('btnSend');
    const btnClearChat = document.getElementById('btnClearChat');
    const chipBtns = document.querySelectorAll('.chip-btn');

    // Engine Controls & Modal Elements
    const pagePillGrok = document.getElementById('pagePillGrok');
    const pagePillGemini = document.getElementById('pagePillGemini');
    const pagePillDb = document.getElementById('pagePillDb');
    const pageCardGrok = document.getElementById('pageCardGrok');
    const pageCardGemini = document.getElementById('pageCardGemini');
    const pageCardDb = document.getElementById('pageCardDb');
    const pageInputGrokKey = document.getElementById('pageInputGrokKey');
    const pageInputGeminiKey = document.getElementById('pageInputGeminiKey');
    const btnPageSaveSettings = document.getElementById('btnPageSaveSettings');
    const btnPageResetSettings = document.getElementById('btnPageResetSettings');
    const pageSettingsAlert = document.getElementById('pageSettingsAlert');

    const BASE_URL = '<?= BASE_URL ?>';
    const DEFAULT_GROK_KEY = 'grok_a30478f696dc794318cbe8a182a0c65e_1a23970ce7441c2d221d98d25e91c40c0bf4c80f27c32145a9a9a193be61626a';
    const DEFAULT_GEMINI_KEY = 'AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw';

    let currentEngine = localStorage.getItem('tkj_chat_provider') || 'grok';
    let customGrokKey = localStorage.getItem('tkj_grok_key') || DEFAULT_GROK_KEY;
    let customGeminiKey = localStorage.getItem('tkj_gemini_key') || DEFAULT_GEMINI_KEY;

    // Terapkan Pilihan Engine di Halaman
    function setPageEngine(engine, showToast = false) {
        currentEngine = engine;
        localStorage.setItem('tkj_chat_provider', engine);

        // Update Pills
        [pagePillGrok, pagePillGemini, pagePillDb].forEach(btn => {
            if (btn) btn.classList.remove('active');
        });
        if (engine === 'grok' && pagePillGrok) pagePillGrok.classList.add('active');
        if (engine === 'gemini' && pagePillGemini) pagePillGemini.classList.add('active');
        if (engine === 'database' && pagePillDb) pagePillDb.classList.add('active');

        // Update Modal Cards
        [pageCardGrok, pageCardGemini, pageCardDb].forEach(card => {
            if (card) card.classList.remove('active');
        });
        if (engine === 'grok' && pageCardGrok) pageCardGrok.classList.add('active');
        if (engine === 'gemini' && pageCardGemini) pageCardGemini.classList.add('active');
        if (engine === 'database' && pageCardDb) pageCardDb.classList.add('active');

        if (showToast) {
            const labels = {
                grok: 'Grok AI (xAI)',
                gemini: 'Google Gemini',
                database: 'Smart DB Engine (Lokal)'
            };
            const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const toastHtml = `
                <div class="d-flex justify-content-center my-3">
                    <div class="badge bg-white border border-light-subtle text-secondary extra-small px-3 py-1.5 rounded-pill shadow-sm">
                        ⚡ Model AI dialihkan ke <strong class="text-dark">${labels[engine] || engine}</strong> <span class="text-muted ms-1">${timeStr}</span>
                    </div>
                </div>
            `;
            chatContainer.insertAdjacentHTML('beforeend', toastHtml);
            scrollToBottom();
        }
    }

    // Auto Scroll ke Paling Bawah
    function scrollToBottom() {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // Formatter Markdown Sederhana untuk Teks Respons AI
    function parseMarkdown(text) {
        if (!text) return '';
        let formatted = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/`(.*?)`/g, '<code class="bg-light px-1.5 py-0.5 rounded text-cyan border border-light-subtle">$1</code>')
            .replace(/(Rp\s*[\d\.]+)/g, '<span class="badge badge-subtle-cyan"><i class="fa-solid fa-tag me-1"></i>$1</span>')
            .replace(/\n/g, '<br>');
        return formatted;
    }

    // Tambah Bubble Chat User
    function appendUserMessage(text) {
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const html = `
            <div class="d-flex gap-3 mb-4 chat-bubble-wrapper user-msg justify-content-end">
                <div class="flex-grow-1 text-end" style="max-width: 85%;">
                    <div class="bg-primary rounded-4 p-3 text-white shadow-sm user-bubble d-inline-block text-start">
                        <div class="fw-semibold text-white-50 mb-1 extra-small opacity-75">Anda • ${timeStr}</div>
                        <div class="mb-0 text-white">${parseMarkdown(text)}</div>
                    </div>
                </div>
                <div class="flex-shrink-0">
                    <div class="rounded-circle bg-primary text-white p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                        <i class="fa-solid fa-user"></i>
                    </div>
                </div>
            </div>
        `;
        chatContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
    }

    // Tampilkan Typing Indicator
    function showTypingIndicator() {
        const html = `
            <div class="d-flex gap-3 mb-4 chat-bubble-wrapper ai-typing-wrapper" id="typingIndicator">
                <div class="flex-shrink-0">
                    <div class="rounded-circle bg-cyan-subtle text-cyan p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                </div>
                <div class="flex-grow-1" style="max-width: 85%;">
                    <div class="bg-white border border-light-subtle rounded-4 p-3 text-dark shadow-sm">
                        <div class="fw-bold text-cyan mb-1 small d-flex align-items-center gap-1.5">
                            <span>TKJ Smart Bot</span>
                            <span class="badge bg-light text-secondary border border-light-subtle extra-small">${currentEngine.toUpperCase()}</span>
                        </div>
                        <div class="typing-dots d-flex align-items-center py-1">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        chatContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
    }

    // Hapus Typing Indicator
    function removeTypingIndicator() {
        const typingEl = document.getElementById('typingIndicator');
        if (typingEl) {
            typingEl.remove();
        }
    }

    // Tambah Bubble Chat AI
    function appendAIMessage(text, timestamp) {
        removeTypingIndicator();
        const timeStr = timestamp || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        const html = `
            <div class="d-flex gap-3 mb-4 chat-bubble-wrapper ai-msg">
                <div class="flex-shrink-0">
                    <div class="rounded-circle bg-cyan-subtle text-cyan p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                </div>
                <div class="flex-grow-1" style="max-width: 85%;">
                    <div class="bg-white border border-light-subtle rounded-4 p-3 text-dark shadow-sm chat-bubble">
                        <div class="fw-bold text-cyan mb-1 small d-flex align-items-center justify-content-between">
                            <span class="d-flex align-items-center gap-1.5"><i class="fa-solid fa-robot"></i> TKJ Smart Bot</span>
                            <small class="text-secondary extra-small font-normal">${timeStr}</small>
                        </div>
                        <div class="mb-0 text-dark leading-relaxed">${parseMarkdown(text)}</div>
                    </div>
                </div>
            </div>
        `;
        chatContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
    }

    // Kirim Pesan via AJAX ke AIController
    async function sendMessage(messageText) {
        if (!messageText.trim()) return;

        appendUserMessage(messageText);
        userInput.value = '';
        userInput.disabled = true;
        btnSend.disabled = true;

        showTypingIndicator();

        const activeApiKey = currentEngine === 'grok' 
            ? (customGrokKey || DEFAULT_GROK_KEY) 
            : (currentEngine === 'gemini' ? (customGeminiKey || DEFAULT_GEMINI_KEY) : '');

        try {
            const response = await fetch(`${BASE_URL}/ai/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    message: messageText,
                    provider: currentEngine,
                    apiKey: activeApiKey
                })
            });

            const data = await response.json();

            if (data.status === 'success') {
                appendAIMessage(data.response, data.timestamp);
            } else {
                appendAIMessage('Mohon maaf, terjadi kendala saat memproses pertanyaan Anda: ' + (data.message || 'Terjadi kesalahan sistem.'));
            }
        } catch (error) {
            console.error('AI Chat Error:', error);
            appendAIMessage('Mohon maaf, koneksi ke server terputus. Silakan coba lagi beberapa saat lagi.');
        } finally {
            userInput.disabled = false;
            btnSend.disabled = false;
            userInput.focus();
        }
    }

    // Submit Event Listener
    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        sendMessage(userInput.value);
    });

    // Chip Suggestion Click Handler
    chipBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const query = this.getAttribute('data-query');
            if (query) {
                sendMessage(query);
            }
        });
    });

    // Engine Switcher Pill Listeners
    if (pagePillGrok) pagePillGrok.addEventListener('click', () => setPageEngine('grok', true));
    if (pagePillGemini) pagePillGemini.addEventListener('click', () => setPageEngine('gemini', true));
    if (pagePillDb) pagePillDb.addEventListener('click', () => setPageEngine('database', true));

    // Cards in Modal
    if (pageCardGrok) pageCardGrok.addEventListener('click', () => setPageEngine('grok', false));
    if (pageCardGemini) pageCardGemini.addEventListener('click', () => setPageEngine('gemini', false));
    if (pageCardDb) pageCardDb.addEventListener('click', () => setPageEngine('database', false));

    // Toggle PW in Modal
    document.querySelectorAll('.btn-page-toggle-pw').forEach(btn => {
        btn.addEventListener('click', function() {
            const targetId = this.getAttribute('data-input');
            const targetInput = document.getElementById(targetId);
            if (targetInput) {
                const isPw = targetInput.type === 'password';
                targetInput.type = isPw ? 'text' : 'password';
                this.innerHTML = isPw ? '<i class="fa-solid fa-eye-slash text-cyan"></i>' : '<i class="fa-solid fa-eye"></i>';
            }
        });
    });

    // Save Settings from Modal
    if (btnPageSaveSettings) {
        btnPageSaveSettings.addEventListener('click', function() {
            if (pageInputGrokKey) {
                customGrokKey = pageInputGrokKey.value.trim() || DEFAULT_GROK_KEY;
                localStorage.setItem('tkj_grok_key', customGrokKey);
            }
            if (pageInputGeminiKey) {
                customGeminiKey = pageInputGeminiKey.value.trim() || DEFAULT_GEMINI_KEY;
                localStorage.setItem('tkj_gemini_key', customGeminiKey);
            }
            setPageEngine(currentEngine, false);

            if (pageSettingsAlert) {
                pageSettingsAlert.classList.remove('d-none');
                setTimeout(() => {
                    pageSettingsAlert.classList.add('d-none');
                    const modalEl = document.getElementById('pageAiSettingsModal');
                    const modalInst = bootstrap.Modal.getInstance(modalEl);
                    if (modalInst) modalInst.hide();
                }, 1000);
            }
        });
    }

    // Reset Settings in Modal
    if (btnPageResetSettings) {
        btnPageResetSettings.addEventListener('click', function() {
            if (confirm('Kembalikan konfigurasi API Key & Model AI ke default sistem?')) {
                customGrokKey = DEFAULT_GROK_KEY;
                customGeminiKey = DEFAULT_GEMINI_KEY;
                localStorage.removeItem('tkj_grok_key');
                localStorage.removeItem('tkj_gemini_key');
                if (pageInputGrokKey) pageInputGrokKey.value = DEFAULT_GROK_KEY;
                if (pageInputGeminiKey) pageInputGeminiKey.value = DEFAULT_GEMINI_KEY;
                setPageEngine('grok', true);
            }
        });
    }

    // Reset Percakapan
    btnClearChat.addEventListener('click', function() {
        if (confirm('Apakah Anda yakin ingin mengosongkan percakapan chat ini?')) {
            const initialHTML = `
                <div class="d-flex gap-3 mb-4 chat-bubble-wrapper ai-msg">
                    <div class="flex-shrink-0">
                        <div class="rounded-circle bg-cyan-subtle text-cyan p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                            <i class="fa-solid fa-robot"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1" style="max-width: 85%;">
                        <div class="bg-dark bg-opacity-75 border border-cyan border-opacity-25 rounded-4 p-3 text-white shadow-sm chat-bubble">
                            <div class="fw-bold text-cyan mb-1 small d-flex align-items-center gap-2">
                                <span>TKJ Smart Bot</span>
                                <small class="text-white-50 opacity-75 extra-small font-normal"><?= date('H:i') ?></small>
                            </div>
                            <p class="mb-2 leading-relaxed">
                                Percakapan telah direset. Halo <strong><?= htmlspecialchars($user['nama']) ?></strong>! 👋 Ada yang bisa saya bantu kembali?
                            </p>
                        </div>
                    </div>
                </div>
            `;
            chatContainer.innerHTML = initialHTML;
            scrollToBottom();
        }
    });

    // Populate modal inputs if already stored
    if (pageInputGrokKey) pageInputGrokKey.value = customGrokKey;
    if (pageInputGeminiKey) pageInputGeminiKey.value = customGeminiKey;

    // Listen to Global AI Settings Changes (when updated from navbar or global modal outside)
    window.addEventListener('tkj-ai-settings-changed', function(e) {
        if (e.detail && e.detail.provider) {
            currentEngine = e.detail.provider;
            customGrokKey = e.detail.grokKey || customGrokKey;
            customGeminiKey = e.detail.geminiKey || customGeminiKey;
            setPageEngine(currentEngine, true);
        }
    });

    // Initial Engine Setup & Scroll
    setPageEngine(currentEngine, false);
    scrollToBottom();
});
</script>

<section class="py-5">
    <div class="container">
        
        <!-- Flash Alert Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('review_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="mb-4">
            <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">RIWAYAT LAYANAN</span>
            <h2 class="fw-bold text-white mb-0">Riwayat Pesanan Selesai & Review</h2>
        </div>

        <?php if (!empty($orders)): ?>
            <div class="vstack gap-3">
                <?php foreach ($orders as $ord): ?>
                    <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
                        <div class="row align-items-center g-3">
                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Kode Pesanan</small>
                                <strong class="text-white fs-6"><?= htmlspecialchars($ord['kode_pesanan']) ?></strong>
                                <small class="d-block text-cyan extra-small mt-1">
                                    <i class="fa-solid fa-calendar-check me-1"></i> <?= date('d M Y', strtotime($ord['tanggal_pemesanan'])) ?>
                                </small>
                            </div>

                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Layanan Jasa</small>
                                <h6 class="fw-bold text-white mb-1"><?= htmlspecialchars($ord['nama_jasa']) ?></h6>
                                <small class="text-white-50 extra-small">Teknisi: <?= htmlspecialchars($ord['nama_teknisi'] ?? 'Siswa TKJ') ?></small>
                            </div>

                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Status & Rating</small>
                                <div>
                                    <?php if ($ord['status'] === 'selesai'): ?>
                                        <span class="badge bg-success me-1">Selesai</span>
                                        <?php if (!empty($ord['rating'])): ?>
                                            <span class="text-warning extra-small"><i class="fa-solid fa-star"></i> <?= $ord['rating'] ?>/5</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Dibatalkan</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-3 text-md-end">
                                <?php if ($ord['status'] === 'selesai' && empty($ord['rating'])): ?>
                                    <a href="<?= BASE_URL ?>/customer/review/<?= $ord['id'] ?>" class="btn btn-warning text-dark btn-sm rounded-pill fw-bold me-1">
                                        <i class="fa-solid fa-star me-1"></i> Beri Review
                                    </a>
                                <?php endif; ?>
                                <a href="<?= BASE_URL ?>/customer/pesanan/detail/<?= $ord['id'] ?>" class="btn btn-outline-cyan btn-sm rounded-pill px-3 fw-bold">
                                    Detail
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="glass-card p-5 rounded-4 border border-secondary border-opacity-25 text-center my-4">
                <i class="fa-solid fa-clock-rotate-left text-cyan display-3 mb-3"></i>
                <h4 class="fw-bold text-white">Belum Ada Riwayat Pesanan</h4>
                <p class="text-white-50 max-w-600 mx-auto mb-4">
                    Riwayat pesanan yang telah selesai dikerjakan akan ditampilkan di sini.
                </p>
                <a href="<?= BASE_URL ?>/customer/pesanan/create" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 py-2">
                    <i class="fa-solid fa-plus me-1"></i> Pesan Jasa IT Sekarang
                </a>
            </div>
        <?php endif; ?>

    </div>
</section>

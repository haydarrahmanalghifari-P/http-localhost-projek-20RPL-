<!-- ==========================================================================
     HERO SECTION (High Impact Modern Tech UI)
     ========================================================================== -->
<section class="hero-section position-relative overflow-hidden">
    <div class="hero-bg-glow"></div>
    <div class="container position-relative z-1 py-4 py-lg-5">
        <div class="row align-items-center g-5">
            
            <!-- Left Column: Value Proposition & CTAs -->
            <div class="col-lg-7">
                <div class="d-inline-flex align-items-center gap-2 px-3 py-1.5 rounded-pill hero-badge mb-3">
                    <span class="badge-dot"></span>
                    <span class="text-cyan small fw-semibold">
                        <i class="fa-solid fa-graduation-cap me-1"></i> Unit Bisnis &amp; Teaching Factory Siswa TKJ SMK
                    </span>
                </div>

                <h1 class="display-4 fw-extrabold text-white hero-title mb-3 lh-sm">
                    Solusi Layanan IT Terpercaya <br>
                    <span class="text-gradient-cyan">Cepat, Rapi &amp; Bergaransi Resmi</span>
                </h1>

                <p class="lead text-white-50 mb-4 me-lg-4 hero-subtitle">
                    Layanan profesional instalasi CCTV, jaringan LAN, Wi-Fi Hotspot, perbaikan laptop &amp; komputer, serta maintenance berkala oleh siswa berbakat TKJ didampingi teknisi pengajar berpengalaman.
                </p>

                <!-- Action Button Group -->
                <div class="d-flex flex-wrap align-items-center gap-3 mb-4">
                    <a href="#layanan" class="btn btn-cyan btn-lg rounded-pill fw-bold px-4 btn-shadow">
                        <i class="fa-solid fa-screwdriver-wrench me-2"></i> Lihat Layanan Jasa
                    </a>
                    <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup('Halo, saya ingin konsultasi layanan IT yang cocok untuk kebutuhan saya'); }" class="btn btn-outline-cyan btn-lg rounded-pill fw-semibold px-4" title="Konsultasi Cepat AI (Node.js)">
                        <i class="fa-solid fa-comments me-2"></i> Chat AI Bot
                    </button>
                    <a href="<?= BASE_URL ?>/customer/pesanan/create" class="btn btn-outline-light btn-lg rounded-pill fw-semibold px-3">
                        <i class="fa-solid fa-calendar-plus text-cyan me-2"></i> Pesan Sekarang
                    </a>
                </div>
                
                <!-- Quick Trust Badges -->
                <div class="d-flex flex-wrap gap-4 pt-3 text-white-50 border-top border-secondary border-opacity-25 small">
                    <div class="d-flex align-items-center gap-2">
                        <i class="fa-solid fa-circle-check text-cyan fs-5"></i>
                        <span>Teknisi Terlatih &amp; Bersertifikat</span>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <i class="fa-solid fa-shield-halved text-cyan fs-5"></i>
                        <span>Pengerjaan Bergaransi</span>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <i class="fa-solid fa-hand-holding-dollar text-cyan fs-5"></i>
                        <span>Tarif Ramah Pelajar &amp; UMKM</span>
                    </div>
                </div>
            </div>

            <!-- Right Column: High-Impact Visual Showcase & Live Terminal -->
            <div class="col-lg-5">
                <div class="hero-card-wrapper">
                    <div class="hero-showcase-box shadow-2xl">
                        <!-- High-Res Photorealistic Lab Workshop Image -->
                        <div class="position-relative overflow-hidden">
                            <img src="<?= BASE_URL ?>/public/img/hero_lab.jpg" alt="Bengkel IT &amp; Lab Jaringan Siswa TKJ" class="hero-main-img">
                            <div class="hero-overlay-gradient"></div>
                            
                            <!-- Floating Glass Badge: Live Status (Top-Left) -->
                            <div class="position-absolute top-0 start-0 m-3">
                                <div class="floating-glass-pill">
                                    <span class="badge-dot"></span>
                                    <span class="fw-bold extra-small text-white">Lab Produksi TEFA Aktif</span>
                                </div>
                            </div>

                            <!-- Floating Glass Badge: 4K CCTV (Top-Right) -->
                            <div class="position-absolute top-0 end-0 m-3">
                                <div class="floating-glass-pill pill-alt">
                                    <i class="fa-solid fa-video text-success extra-small"></i>
                                    <span class="extra-small text-white-50">4K Live Monitoring</span>
                                </div>
                            </div>

                            <!-- Floating Bottom Station Card Over Image -->
                            <div class="position-absolute bottom-0 start-0 end-0 p-3 z-2">
                                <div class="p-3 rounded-4 bg-dark bg-opacity-80 border border-cyan border-opacity-35 backdrop-blur shadow-lg">
                                    <div class="d-flex align-items-center justify-content-between mb-2">
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="brand-icon-box" style="width: 32px; height: 32px;">
                                                <i class="fa-solid fa-server text-cyan small"></i>
                                            </div>
                                            <div>
                                                <div class="fw-bold text-white extra-small">Mikrotik &amp; Server Station</div>
                                                <small class="text-cyan opacity-80" style="font-size: 0.68rem;">100 Mbps Throughput • 0% Loss</small>
                                            </div>
                                        </div>
                                        <span class="badge bg-cyan text-dark extra-small fw-bold">ONLINE</span>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between pt-2 border-top border-white border-opacity-10">
                                        <div class="d-flex align-items-center gap-1.5">
                                            <span class="text-warning extra-small"><i class="fa-solid fa-star"></i> 5.0</span>
                                            <span class="text-white-50" style="font-size: 0.72rem;">(48+ Ulasan Pelanggan)</span>
                                        </div>
                                        <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup(); }" class="btn btn-outline-cyan btn-sm rounded-pill extra-small py-1 px-2.5" title="Chat dengan AI Assistant">
                                            <i class="fa-solid fa-comments me-1"></i> Chat AI
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ==========================================================================
     STATS COUNTER BANNER (Trust Metrics)
     ========================================================================== -->
<section class="py-4 text-white">
    <div class="container">
        <div class="p-4 p-md-5 rounded-4 stats-banner position-relative overflow-hidden">
            <div class="row text-center g-4 position-relative z-1">
                <div class="col-6 col-md-3">
                    <div class="display-5 fw-extrabold text-cyan mb-1">150+</div>
                    <div class="text-white-50 small fw-semibold">Komputer/Laptop Service</div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="display-5 fw-extrabold text-cyan mb-1">50+</div>
                    <div class="text-white-50 small fw-semibold">Titik CCTV Terpasang</div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="display-5 fw-extrabold text-cyan mb-1">35+</div>
                    <div class="text-white-50 small fw-semibold">Jaringan LAN &amp; Wi-Fi</div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="display-5 fw-extrabold text-cyan mb-1">100%</div>
                    <div class="text-white-50 small fw-semibold">Supervisi Pengajar Ahli</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     LAYANAN SECTION (Master Cards with Rich Visuals & AI Link)
     ========================================================================== -->
<section class="py-5" id="layanan">
    <div class="container py-4">
        
        <div class="text-center max-w-700 mx-auto mb-5">
            <span class="badge bg-cyan text-dark fw-bold px-3 py-1.5 rounded-pill mb-2">KATALOG LAYANAN IT</span>
            <h2 class="fw-bold text-white fs-1 mb-2">6 Layanan Jasa Unggulan TKJ</h2>
            <p class="text-white-50 mb-0">
                Dikerjakan secara profesional oleh siswa terlatih di bawah pendampingan guru teknis bersertifikasi.
            </p>
        </div>

        <div class="row g-4 align-items-stretch">
            <?php if (!empty($services)): ?>
                <?php foreach ($services as $svc): ?>
                    <div class="col-lg-4 col-md-6 d-flex">
                        <div class="service-card w-100 p-4 rounded-4 d-flex flex-column justify-content-between position-relative">
                            
                            <div>
                                <!-- Top Bar: Icon Box & Category Badge -->
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <div class="service-icon-box">
                                        <i class="fa-solid <?= htmlspecialchars($svc['icon']) ?> fs-4 text-cyan"></i>
                                    </div>
                                    <span class="badge <?= htmlspecialchars($svc['badge_color'] ?? 'bg-cyan text-dark') ?> rounded-pill px-3 py-1.5 extra-small fw-bold">
                                        <?= htmlspecialchars($svc['badge'] ?? 'Layanan TKJ') ?>
                                    </span>
                                </div>

                                <!-- Title & Description -->
                                <h4 class="fw-bold text-white mb-2"><?= htmlspecialchars($svc['title']) ?></h4>
                                <p class="text-white-50 small mb-3 leading-relaxed">
                                    <?= htmlspecialchars($svc['description']) ?>
                                </p>

                                <!-- Features List -->
                                <?php if (!empty($svc['features']) && is_array($svc['features'])): ?>
                                    <ul class="list-unstyled mb-4">
                                        <?php foreach ($svc['features'] as $feat): ?>
                                            <li class="service-feature-item mb-2 d-flex align-items-start gap-2">
                                                <i class="fa-solid fa-circle-check text-cyan mt-1 extra-small"></i>
                                                <span><?= htmlspecialchars($feat) ?></span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>

                            <!-- Card Footer / Price & Actions (Pinned at Bottom) -->
                            <div class="pt-3 border-top border-secondary border-opacity-25 mt-auto">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <span class="text-white-50 extra-small fw-medium">Biaya Layanan:</span>
                                    <span class="price-pill-glow"><?= htmlspecialchars($svc['price']) ?></span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <a href="<?= BASE_URL ?>/customer/pesanan/create?jasa_id=<?= $svc['id'] ?>" class="btn btn-cyan flex-grow-1 rounded-pill fw-bold btn-sm py-2">
                                        <i class="fa-solid fa-cart-plus me-1"></i> Pesan Jasa
                                    </a>
                                    <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup('Jelaskan rincian biaya dan prosedur layanan <?= addslashes($svc['title']) ?>'); }" class="btn btn-outline-cyan rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px; min-width: 36px;" title="Chat AI tentang <?= htmlspecialchars($svc['title']) ?>">
                                        <i class="fa-solid fa-comment-dots"></i>
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center text-white-50">
                    Belum ada layanan yang ditambahkan.
                </div>
            <?php endif; ?>
        </div>

    </div>
</section>

<!-- ==========================================================================
     ALUR PEMESANAN (4 Simple Steps Workflow)
     ========================================================================== -->
<section class="py-5 bg-dark-element bg-opacity-40">
    <div class="container py-4">
        <div class="text-center max-w-700 mx-auto mb-5">
            <span class="badge bg-cyan-subtle text-cyan border border-cyan px-3 py-1 rounded-pill mb-2">PROSES MUDAH</span>
            <h2 class="fw-bold text-white fs-1 mb-2">Alur Pemesanan Jasa Kami</h2>
            <p class="text-white-50 mb-0">Hanya 4 langkah mudah untuk mendapatkan penanganan teknis terbaik.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="step-card">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="step-number-badge">1</div>
                        <i class="fa-solid fa-comments text-cyan fs-4"></i>
                    </div>
                    <h5 class="fw-bold text-white mb-2">Pilih / Tanya AI</h5>
                    <p class="text-white-50 small mb-0">
                        Tentukan layanan yang Anda butuhkan atau tanyakan rekomendasi terbaik melalui chatbot AI pintar kami.
                    </p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="step-card">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="step-number-badge">2</div>
                        <i class="fa-solid fa-calendar-check text-cyan fs-4"></i>
                    </div>
                    <h5 class="fw-bold text-white mb-2">Konfirmasi &amp; Jadwal</h5>
                    <p class="text-white-50 small mb-0">
                        Operator &amp; teknisi menyepakati jadwal pengerjaan atau diagnosa perangkat di bengkel / lokasi Anda.
                    </p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="step-card">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="step-number-badge">3</div>
                        <i class="fa-solid fa-screwdriver-wrench text-cyan fs-4"></i>
                    </div>
                    <h5 class="fw-bold text-white mb-2">Pengerjaan Ahli</h5>
                    <p class="text-white-50 small mb-0">
                        Pengerjaan teliti menggunakan peralatan standar industri dan didampingi langsung oleh guru teknisi pengajar.
                    </p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="step-card">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="step-number-badge">4</div>
                        <i class="fa-solid fa-shield-check text-cyan fs-4"></i>
                    </div>
                    <h5 class="fw-bold text-white mb-2">Selesai &amp; Garansi</h5>
                    <p class="text-white-50 small mb-0">
                        Pemeriksaan hasil kerja secara menyeluruh bersama pelanggan dilengkapi jaminan garansi pengerjaan.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     KEUNGGULAN SECTION (Teaching Factory)
     ========================================================================== -->
<section class="py-5" id="keunggulan">
    <div class="container py-4">
        <div class="row align-items-center g-5">
            
            <div class="col-lg-5">
                <span class="badge bg-cyan-subtle text-cyan border border-cyan px-3 py-1 rounded-pill mb-2">MENGAPA KAMI?</span>
                <h2 class="fw-bold text-white fs-1 mb-3">
                    Keuntungan Menggunakan Jasa Unit Bisnis TKJ
                </h2>
                <p class="text-white-50 mb-4">
                    TKJ Smart Service memadukan standar industri dengan pembelajaran nyata siswa (Teaching Factory). Anda mendapatkan jasa IT berkualitas sekaligus mendukung kemandirian siswa.
                </p>
                <div class="p-4 rounded-4 glass-card border border-cyan border-opacity-35">
                    <div class="d-flex align-items-center gap-3">
                        <div class="badge-icon bg-cyan text-dark rounded-circle p-3 fs-3 fw-bold flex-shrink-0">
                            <i class="fa-solid fa-user-shield"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-white mb-1">Supervisi Guru &amp; Teknisi Senior</h6>
                            <p class="text-white-50 extra-small mb-0">Setiap tahapan pekerjaan diperiksa langsung oleh instruktur teknis ahli bersertifikat.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="row g-4">
                    <div class="col-sm-6">
                        <div class="p-4 rounded-4 feature-box h-100">
                            <div class="feature-icon-orb mb-3">
                                <i class="fa-solid fa-graduation-cap text-cyan fs-3"></i>
                            </div>
                            <h5 class="fw-bold text-white">Siswa Berkompeten</h5>
                            <p class="text-white-50 small mb-0">
                                Ditangani siswa pilihan yang telah lulus sertifikasi internal uji kompetensi keahlian jaringan &amp; hardware.
                            </p>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="p-4 rounded-4 feature-box h-100">
                            <div class="feature-icon-orb mb-3">
                                <i class="fa-solid fa-hand-holding-dollar text-cyan fs-3"></i>
                            </div>
                            <h5 class="fw-bold text-white">Tarif Bersahabat</h5>
                            <p class="text-white-50 small mb-0">
                                Biaya jasa terjangkau dan transparan, sangat cocok untuk anggaran masyarakat, sekolah, &amp; UMKM.
                            </p>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="p-4 rounded-4 feature-box h-100">
                            <div class="feature-icon-orb mb-3">
                                <i class="fa-solid fa-toolbox text-cyan fs-3"></i>
                            </div>
                            <h5 class="fw-bold text-white">Peralatan Standar Industri</h5>
                            <p class="text-white-50 small mb-0">
                                Didukung alat lengkap: LAN tester digital, crimper profesional, optical power meter, &amp; diagnostic software.
                            </p>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="p-4 rounded-4 feature-box h-100">
                            <div class="feature-icon-orb mb-3">
                                <i class="fa-solid fa-award text-cyan fs-3"></i>
                            </div>
                            <h5 class="fw-bold text-white">Garansi Pengerjaan</h5>
                            <p class="text-white-50 small mb-0">
                                Jaminan pengerjaan ulang bebas biaya jika ditemukan kendala teknis setelah perbaikan atau instalasi.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ==========================================================================
     TESTIMONIALS SECTION (Pelanggan Nyata)
     ========================================================================== -->
<section class="py-5 bg-dark-element bg-opacity-30">
    <div class="container py-4">
        <div class="text-center max-w-700 mx-auto mb-5">
            <span class="badge bg-cyan text-dark fw-bold px-3 py-1.5 rounded-pill mb-2">TESTIMONI</span>
            <h2 class="fw-bold text-white fs-1 mb-2">Apa Kata Pelanggan Kami?</h2>
            <p class="text-white-50 mb-0">Kepuasan dan kepercayaan pelanggan adalah prioritas utama unit kami.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="testimonial-card h-100 d-flex flex-column justify-content-between">
                    <div>
                        <div class="text-warning mb-2">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p class="text-white-50 small fst-italic mb-3">
                            "Pasang 4 kamera CCTV di toko kelontong saya. Pengerjaan kabel sangat rapi dan diajari cara setting pantau lewat HP. Sangat puas dengan kerja siswa TKJ!"
                        </p>
                    </div>
                    <div class="d-flex align-items-center gap-3 pt-3 border-top border-secondary border-opacity-25">
                        <div class="chat-mini-avatar rounded-circle bg-cyan text-dark fw-bold d-flex align-items-center justify-content-center">
                            BS
                        </div>
                        <div>
                            <div class="fw-bold text-white small">Bpk. Budi Santoso</div>
                            <small class="text-cyan extra-small">Pemilik Toko Grosir</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="testimonial-card h-100 d-flex flex-column justify-content-between">
                    <div>
                        <div class="text-warning mb-2">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p class="text-white-50 small fst-italic mb-3">
                            "Laptop kantor sering blue screen dan lemot. Setelah diupgrade SSD dan instal ulang oleh siswa TKJ, performanya jadi kencang kembali seperti baru. Biayanya sangat hemat."
                        </p>
                    </div>
                    <div class="d-flex align-items-center gap-3 pt-3 border-top border-secondary border-opacity-25">
                        <div class="chat-mini-avatar rounded-circle bg-primary text-white fw-bold d-flex align-items-center justify-content-center">
                            DW
                        </div>
                        <div>
                            <div class="fw-bold text-white small">Ibu Dewi Wardani</div>
                            <small class="text-cyan extra-small">Staf Administrasi Sekolah</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="testimonial-card h-100 d-flex flex-column justify-content-between">
                    <div>
                        <div class="text-warning mb-2">
                            <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                        </div>
                        <p class="text-white-50 small fst-italic mb-3">
                            "Penarikan kabel LAN 12 titik untuk ruang lab komputer. Sambungan kabel kencang dan manajemen bandwidth Mikrotik berjalan sangat lancar. Teknisi sangat sopan."
                        </p>
                    </div>
                    <div class="d-flex align-items-center gap-3 pt-3 border-top border-secondary border-opacity-25">
                        <div class="chat-mini-avatar rounded-circle bg-success text-white fw-bold d-flex align-items-center justify-content-center">
                            AH
                        </div>
                        <div>
                            <div class="fw-bold text-white small">Ahmad Hidayat</div>
                            <small class="text-cyan extra-small">Pengelola Lembaga Kursus</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     INTERACTIVE CHATBOT SECTION (Node.js AI Assistant - Gemini Powered)
     ========================================================================== -->
<section class="py-5 position-relative" id="chatbot-section" style="background: radial-gradient(circle at 50% 0%, rgba(6, 182, 212, 0.08) 0%, transparent 70%);">
    <div class="container py-2">
        <div class="text-center max-w-700 mx-auto mb-4">
            <div class="d-inline-flex align-items-center gap-2 px-3 py-1.5 rounded-pill bg-cyan-subtle border border-cyan border-opacity-35 mb-3 shadow-sm">
                <i class="fa-brands fa-node-js text-success fs-5"></i>
                <span class="text-cyan small fw-bold tracking-wide">NODE.JS AI CHATBOT ENGINE</span>
                <span class="badge bg-success text-dark extra-small fw-bold">ONLINE</span>
            </div>
            <h2 class="display-6 fw-bold text-white mb-2 d-flex align-items-center justify-content-center gap-2">
                <i class="fa-solid fa-comments text-cyan"></i> Tanya AI Assistant TKJ
            </h2>
            <p class="text-white-50 mb-0">
                Konsultasikan kendala komputer, perakitan PC, instalasi CCTV, atau jaringan secara instan 24/7 didukung Google Gemini AI &amp; Node.js.
            </p>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-9 col-xl-8">
                <!-- Chatbot In-Page Card -->
                <div class="card glass-card border border-cyan border-opacity-35 rounded-4 shadow-2xl overflow-hidden">
                    
                    <!-- Card Header -->
                    <div class="card-header bg-dark bg-opacity-90 border-bottom border-cyan border-opacity-20 p-3 p-md-3.5 d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center gap-3">
                            <div class="position-relative">
                                <div class="rounded-circle bg-cyan-subtle p-2 text-cyan d-flex align-items-center justify-content-center shadow-sm" style="width: 44px; height: 44px;">
                                    <i class="fa-solid fa-comments fs-5"></i>
                                </div>
                                <span class="position-absolute bottom-0 end-0 p-1 bg-success border border-dark rounded-circle"></span>
                            </div>
                            <div>
                                <div class="d-flex align-items-center gap-2">
                                    <h6 class="fw-bold text-white mb-0">TKJ Smart Bot</h6>
                                    <span class="badge badge-subtle-success extra-small">
                                        <i class="fa-brands fa-node-js me-1"></i>Node.js Live
                                    </span>
                                </div>
                                <small class="text-cyan-light extra-small opacity-80" id="inpageBotStatus">
                                    Port 5000 • Google Gemini 3.5 Flash
                                </small>
                            </div>
                        </div>
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <!-- Engine Switcher Pills -->
                            <div class="btn-group btn-group-sm p-1 rounded-pill bg-dark border border-secondary border-opacity-35" role="group">
                                <button type="button" class="btn btn-engine-pill-inpage active" data-home-engine="grok" id="homePillGrok" title="Beralih ke Grok AI">
                                    <i class="fa-solid fa-bolt text-warning me-0.5"></i> Grok
                                </button>
                                <button type="button" class="btn btn-engine-pill-inpage" data-home-engine="gemini" id="homePillGemini" title="Beralih ke Gemini">
                                    <i class="fa-brands fa-google text-info me-0.5"></i> Gemini
                                </button>
                                <button type="button" class="btn btn-engine-pill-inpage" data-home-engine="database" id="homePillDb" title="Beralih ke DB Lokal">
                                    <i class="fa-solid fa-database text-success me-0.5"></i> DB
                                </button>
                            </div>
                            <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup(); }" class="btn btn-outline-cyan btn-sm rounded-pill px-3" title="Buka dalam mode Pop-up floating">
                                <i class="fa-solid fa-up-right-from-square me-1"></i> Mode Pop-up
                            </button>
                            <button type="button" id="btnInpageReset" class="btn btn-outline-danger btn-sm rounded-pill px-2.5" title="Reset percakapan">
                                <i class="fa-solid fa-rotate-right"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Chat Conversation Body -->
                    <div class="card-body p-3 p-md-4" id="inpageChatBody" style="height: 380px; overflow-y: auto; background: rgba(11, 17, 32, 0.75);">
                        <!-- AI Welcome Bubble -->
                        <div class="d-flex gap-2.5 mb-3 chat-bubble-item ai-msg-item">
                            <div class="flex-shrink-0">
                                <div class="chat-mini-avatar bg-cyan-subtle text-cyan rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="fa-solid fa-comments"></i>
                                </div>
                            </div>
                            <div class="chat-content-wrap flex-grow-1" style="max-width: 85%;">
                                <div class="chat-bubble ai-bubble shadow-sm p-3">
                                    <div class="d-flex align-items-center justify-content-between mb-1.5 pb-1 border-bottom border-secondary border-opacity-25">
                                        <span class="fw-bold text-cyan extra-small d-flex align-items-center gap-1">
                                            <i class="fa-brands fa-node-js text-success"></i> TKJ Smart Bot (Node.js)
                                        </span>
                                        <span class="extra-small text-white-50 opacity-75"><?= date('H:i') ?></span>
                                    </div>
                                    <p class="mb-2 text-white small leading-relaxed">
                                        Halo! 👋 Saya <strong>TKJ Smart Bot</strong>, asisten virtual resmi <strong>TKJ Smart Service</strong> yang berjalan di server <strong>Node.js</strong>.
                                    </p>
                                    <p class="mb-0 text-white-50 extra-small">
                                        Ada kebutuhan perbaikan laptop, pemasangan kamera CCTV, setting jaringan Wi-Fi/LAN, atau konsultasi tarif yang bisa saya bantu?
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Suggestion Chips Bar -->
                    <div class="px-3 px-md-4 py-2 bg-dark bg-opacity-60 border-top border-secondary border-opacity-25 overflow-x-auto">
                        <div class="d-flex align-items-center gap-1.5 text-nowrap pb-1" id="inpageChips">
                            <span class="text-white-50 extra-small fw-semibold me-1"><i class="fa-solid fa-lightbulb text-warning"></i> Saran:</span>
                            <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small inpage-chip-btn" data-query="Komputer saya sering mati sendiri dan lemot, solusinya apa?">
                                💻 PC Sering Mati Sendiri
                            </button>
                            <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small inpage-chip-btn" data-query="Berapa biaya pasang kamera CCTV untuk toko dan setting pantau dari HP?">
                                📹 Pasang CCTV Toko
                            </button>
                            <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small inpage-chip-btn" data-query="Berapa biaya instalasi jaringan LAN dan setting Wi-Fi Mikrotik?">
                                🌐 Jaringan LAN &amp; Wi-Fi
                            </button>
                            <button type="button" class="btn btn-outline-cyan btn-sm rounded-pill extra-small inpage-chip-btn" data-query="Bagaimana alur pemesanan dan apakah layanannya bergaransi?">
                                🛡️ Alur &amp; Garansi Resmi
                            </button>
                        </div>
                    </div>

                    <!-- Input Form & Send Button -->
                    <div class="card-footer bg-dark bg-opacity-95 border-top border-cyan border-opacity-20 p-3">
                        <form id="inpageChatForm" class="d-flex align-items-center gap-2">
                            <div class="input-group">
                                <span class="input-group-text bg-dark border-cyan border-opacity-35 text-cyan">
                                    <i class="fa-solid fa-comments"></i>
                                </span>
                                <input type="text" id="inpageChatInput" class="form-control bg-dark text-white border-cyan border-opacity-35 py-2" placeholder="Ketik pertanyaan seputar layanan IT, tarif, atau konsultasi kendala..." autocomplete="off" required>
                            </div>
                            <button type="submit" id="btnInpageSend" class="btn btn-cyan text-dark fw-bold rounded-3 px-4 py-2 d-flex align-items-center gap-2 btn-shadow flex-shrink-0">
                                <span>Kirim</span>
                                <i class="fa-solid fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<script>
// Script Khusus In-Page Chatbot Section (Node.js & Gemini)
(function() {
    const inpageChatBody = document.getElementById('inpageChatBody');
    const inpageChatForm = document.getElementById('inpageChatForm');
    const inpageChatInput = document.getElementById('inpageChatInput');
    const btnInpageSend = document.getElementById('btnInpageSend');
    const btnInpageReset = document.getElementById('btnInpageReset');
    const inpageChips = document.getElementById('inpageChips');
    const inpageBotStatus = document.getElementById('inpageBotStatus');

    const NODE_URL = 'http://localhost:5000';
    const PHP_URL = '<?= BASE_URL ?>/ai/chat';

    function scrollInpageBottom() {
        if (inpageChatBody) {
            inpageChatBody.scrollTop = inpageChatBody.scrollHeight;
        }
    }

    function formatText(t) {
        if (!t) return '';
        return t
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-cyan text-decoration-underline fw-semibold">$1</a>')
            .replace(/(Rp\s*[\d\.]+)/g, '<span class="ai-price-pill"><i class="fa-solid fa-tag me-1"></i>$1</span>')
            .replace(/\n/g, '<br>');
    }

    function appendUserBubble(text) {
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const html = `
            <div class="d-flex gap-2.5 mb-3 chat-bubble-item user-msg-item justify-content-end">
                <div class="chat-content-wrap text-end" style="max-width: 85%;">
                    <div class="chat-bubble user-bubble-pop text-start shadow-sm d-inline-block">
                        <div class="extra-small text-white-50 opacity-75 mb-1 text-end">Anda • ${timeStr}</div>
                        <div class="small mb-0 text-white">${formatText(text)}</div>
                    </div>
                </div>
                <div class="flex-shrink-0">
                    <div class="chat-mini-avatar bg-cyan text-dark rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm">
                        <i class="fa-solid fa-user"></i>
                    </div>
                </div>
            </div>
        `;
        inpageChatBody.insertAdjacentHTML('beforeend', html);
        scrollInpageBottom();
    }

    function showInpageTyping() {
        const html = `
            <div class="d-flex gap-2.5 mb-3 chat-bubble-item ai-typing-item" id="inpageTyping">
                <div class="flex-shrink-0">
                    <div class="chat-mini-avatar bg-cyan-subtle text-cyan rounded-circle d-flex align-items-center justify-content-center">
                        <i class="fa-solid fa-comments"></i>
                    </div>
                </div>
                <div class="chat-content-wrap">
                    <div class="chat-bubble ai-bubble shadow-sm p-3">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="fw-bold text-cyan extra-small">TKJ Smart Bot</span>
                            <span class="text-white-50 extra-small opacity-75">mengetik...</span>
                        </div>
                        <div class="typing-dots-pop py-1">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        inpageChatBody.insertAdjacentHTML('beforeend', html);
        scrollInpageBottom();
    }

    function removeInpageTyping() {
        const el = document.getElementById('inpageTyping');
        if (el) el.remove();
    }

    function appendAIBubble(text, time = null) {
        removeInpageTyping();
        const timeStr = time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const html = `
            <div class="d-flex gap-2.5 mb-3 chat-bubble-item ai-msg-item">
                <div class="flex-shrink-0">
                    <div class="chat-mini-avatar bg-cyan-subtle text-cyan rounded-circle d-flex align-items-center justify-content-center">
                        <i class="fa-solid fa-comments"></i>
                    </div>
                </div>
                <div class="chat-content-wrap" style="max-width: 85%;">
                    <div class="chat-bubble ai-bubble shadow-sm p-3">
                        <div class="d-flex align-items-center justify-content-between mb-1.5 pb-1 border-bottom border-secondary border-opacity-25">
                            <span class="fw-bold text-cyan extra-small d-flex align-items-center gap-1">
                                <i class="fa-brands fa-node-js text-success"></i> TKJ Smart Bot
                            </span>
                            <span class="extra-small text-white-50 opacity-75">${timeStr}</span>
                        </div>
                        <div class="small text-white mb-0 leading-relaxed">${formatText(text)}</div>
                    </div>
                </div>
            </div>
        `;
        inpageChatBody.insertAdjacentHTML('beforeend', html);
        scrollInpageBottom();
    }

    async function sendChat(text) {
        const msg = (text || '').trim();
        if (!msg) return;

        appendUserBubble(msg);
        inpageChatInput.value = '';
        inpageChatInput.disabled = true;
        btnInpageSend.disabled = true;

        showInpageTyping();

        let received = false;
        const currentHomeEngine = localStorage.getItem('tkj_chat_provider') || 'grok';
        const homeGrokKey = localStorage.getItem('tkj_grok_key') || 'grok_a30478f696dc794318cbe8a182a0c65e_1a23970ce7441c2d221d98d25e91c40c0bf4c80f27c32145a9a9a193be61626a';
        const homeGeminiKey = localStorage.getItem('tkj_gemini_key') || 'AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw';
        const activeKey = currentHomeEngine === 'grok' ? homeGrokKey : (currentHomeEngine === 'gemini' ? homeGeminiKey : '');

        // Prioritas 1: Node.js server (Port 5000)
        try {
            const res = await fetch(`${NODE_URL}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    message: msg, 
                    user: { nama: 'Pengunjung Beranda' },
                    provider: currentHomeEngine,
                    apiKey: activeKey
                }),
                signal: AbortSignal.timeout(16000)
            });
            if (res.ok) {
                const data = await res.json();
                if (data.status === 'success' && data.response) {
                    appendAIBubble(data.response, data.timestamp);
                    received = true;
                }
            }
        } catch (e) {
            console.warn('[In-Page Chat] Node.js server timeout/offline, trying PHP fallback:', e.message);
        }

        // Prioritas 2: PHP fallback (/ai/chat)
        if (!received) {
            try {
                const res = await fetch(PHP_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        message: msg,
                        provider: currentHomeEngine,
                        apiKey: activeKey
                    })
                });
                const data = await res.json();
                if (data.status === 'success' && data.response) {
                    appendAIBubble(data.response, data.timestamp);
                    received = true;
                }
            } catch (err) {
                console.error('[In-Page Chat] PHP error:', err);
            }
        }

        if (!received) {
            appendAIBubble('Mohon maaf, terjadi kendala koneksi ke server AI. Silakan coba kembali sesaat lagi.');
        }

        inpageChatInput.disabled = false;
        btnInpageSend.disabled = false;
        inpageChatInput.focus();
    }

    window.sendInpageChat = sendChat;

    if (inpageChatForm) {
        inpageChatForm.addEventListener('submit', function(e) {
            e.preventDefault();
            sendChat(inpageChatInput.value);
        });
    }

    if (inpageChips) {
        inpageChips.addEventListener('click', function(e) {
            const btn = e.target.closest('.inpage-chip-btn');
            if (btn) {
                const query = btn.getAttribute('data-query');
                if (query) sendChat(query);
            }
        });
    }

    if (btnInpageReset) {
        btnInpageReset.addEventListener('click', function() {
            const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            inpageChatBody.innerHTML = `
                <div class="d-flex gap-2.5 mb-3 chat-bubble-item ai-msg-item">
                    <div class="flex-shrink-0">
                        <div class="chat-mini-avatar bg-cyan-subtle text-cyan rounded-circle d-flex align-items-center justify-content-center">
                            <i class="fa-solid fa-comments"></i>
                        </div>
                    </div>
                    <div class="chat-content-wrap flex-grow-1" style="max-width: 85%;">
                        <div class="chat-bubble ai-bubble shadow-sm p-3">
                            <div class="d-flex align-items-center justify-content-between mb-1.5 pb-1 border-bottom border-secondary border-opacity-25">
                                <span class="fw-bold text-cyan extra-small d-flex align-items-center gap-1">
                                    <i class="fa-brands fa-node-js text-success"></i> TKJ Smart Bot (Node.js)
                                </span>
                                <span class="extra-small text-white-50 opacity-75">${timeStr}</span>
                            </div>
                            <p class="mb-2 text-white small leading-relaxed">
                                Percakapan telah direset. Halo! 👋 Ada yang bisa saya bantu hari ini?
                            </p>
                        </div>
                    </div>
                </div>
            `;
            scrollInpageBottom();
        });
    }

    // Engine Switcher Pill Logic for Homepage
    const homePillGrok = document.getElementById('homePillGrok');
    const homePillGemini = document.getElementById('homePillGemini');
    const homePillDb = document.getElementById('homePillDb');

    function syncHomeEngineUI(eng) {
        [homePillGrok, homePillGemini, homePillDb].forEach(b => { if (b) b.classList.remove('active'); });
        if (eng === 'grok' && homePillGrok) homePillGrok.classList.add('active');
        if (eng === 'gemini' && homePillGemini) homePillGemini.classList.add('active');
        if (eng === 'database' && homePillDb) homePillDb.classList.add('active');
    }

    if (homePillGrok) homePillGrok.addEventListener('click', () => {
        localStorage.setItem('tkj_chat_provider', 'grok');
        syncHomeEngineUI('grok');
    });
    if (homePillGemini) homePillGemini.addEventListener('click', () => {
        localStorage.setItem('tkj_chat_provider', 'gemini');
        syncHomeEngineUI('gemini');
    });
    if (homePillDb) homePillDb.addEventListener('click', () => {
        localStorage.setItem('tkj_chat_provider', 'database');
        syncHomeEngineUI('database');
    });

    syncHomeEngineUI(localStorage.getItem('tkj_chat_provider') || 'grok');

    // Check status port 5000
    fetch(`${NODE_URL}/api/status`, { signal: AbortSignal.timeout(2000) })
        .then(r => r.json())
        .then(d => {
            if (inpageBotStatus) {
                const provName = d.defaultProvider ? d.defaultProvider.toUpperCase() : 'MULTI-AI';
                inpageBotStatus.innerHTML = `<span class="text-success"><i class="fa-solid fa-circle small me-1"></i>Node.js Live</span> • ${provName} Engine Ready`;
            }
        })
        .catch(() => {
            if (inpageBotStatus) {
                inpageBotStatus.innerHTML = `Port 5000 • PHP Fallback Ready`;
            }
        });
})();
</script>

<style>
.btn-engine-pill-inpage {
    font-size: 0.68rem;
    font-weight: 700;
    color: rgba(255, 255, 255, 0.65);
    padding: 2px 8px;
    border-radius: 50rem !important;
    border: none;
    background: transparent;
    transition: all 0.2s ease;
}
.btn-engine-pill-inpage:hover {
    color: #fff;
    background: rgba(255, 255, 255, 0.1);
}
.btn-engine-pill-inpage.active {
    color: #070b14;
    background: #22d3ee;
    box-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
}
.btn-engine-pill-inpage[data-home-engine="grok"].active {
    background: linear-gradient(135deg, #f59e0b, #eab308);
    color: #000;
    box-shadow: 0 0 10px rgba(245, 158, 11, 0.6);
}
.btn-engine-pill-inpage[data-home-engine="gemini"].active {
    background: linear-gradient(135deg, #06b6d4, #3b82f6);
    color: #fff;
    box-shadow: 0 0 10px rgba(59, 130, 246, 0.6);
}
.btn-engine-pill-inpage[data-home-engine="database"].active {
    background: linear-gradient(135deg, #10b981, #059669);
    color: #fff;
    box-shadow: 0 0 10px rgba(16, 185, 129, 0.6);
}
</style>

<!-- ==========================================================================
     FAQ SECTION (Accordion Interaktif)
     ========================================================================== -->
<section class="py-5" id="faq">
    <div class="container py-4">
        <div class="row align-items-center g-5">
            <div class="col-lg-5">
                <span class="badge bg-cyan-subtle text-cyan border border-cyan px-3 py-1 rounded-pill mb-2">TANYA JAWAB</span>
                <h2 class="fw-bold text-white fs-1 mb-3">Pertanyaan yang Sering Diajukan</h2>
                <p class="text-white-50 mb-4">
                    Punya pertanyaan seputar cara kerja, metode pembayaran, atau garansi? Temukan jawabannya di sini atau tanyakan langsung pada AI Assistant kami.
                </p>
                <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup(); }" class="btn btn-outline-cyan rounded-pill fw-bold px-4" title="Konsultasi dengan AI Assistant">
                    <i class="fa-solid fa-comments me-2"></i> Chat AI Assistant Sekarang
                </button>
            </div>

            <div class="col-lg-7">
                <div class="accordion accordion-dark" id="homeFaqAccordion">
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <i class="fa-solid fa-circle-question text-cyan me-2"></i> Bagaimana cara memesan layanan jasa IT di sini?
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#homeFaqAccordion">
                            <div class="accordion-body">
                                Anda dapat mengklik tombol <strong>Pesan Jasa</strong> pada katalog untuk mengisi formulir pemesanan secara langsung di website. Pesanan Anda akan tercatat di sistem dan diverifikasi langsung oleh Admin &amp; Operator unit bisnis TKJ tanpa melalui WhatsApp.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <i class="fa-solid fa-circle-question text-cyan me-2"></i> Apakah layanan jasa bergaransi?
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#homeFaqAccordion">
                            <div class="accordion-body">
                                Ya, seluruh layanan perbaikan dan instalasi kami bergaransi resmi. Jika terjadi kendala pasca pengerjaan dalam masa garansi, teknisi kami akan menanganinya kembali tanpa biaya tambahan.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                <i class="fa-solid fa-circle-question text-cyan me-2"></i> Berapa lama estimasi pengerjaan service?
                            </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#homeFaqAccordion">
                            <div class="accordion-body">
                                Service software/instalasi rata-rata memakan waktu 1-2 hari kerja. Untuk instalasi CCTV dan penarikan kabel LAN disesuaikan dengan luas lokasi pengerjaan (umumnya 1 hari pengerjaan).
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingFour">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                <i class="fa-solid fa-circle-question text-cyan me-2"></i> Apakah teknisi siswa bisa datang ke rumah atau kantor?
                            </button>
                        </h2>
                        <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#homeFaqAccordion">
                            <div class="accordion-body">
                                Ya, kami melayani kunjungan ke lokasi (*on-site visit*) untuk wilayah sekitar sekolah didampingi teknisi pengajar pembimbing.
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     TENTANG SECTION (Teaching Factory Lab Showcase)
     ========================================================================== -->
<section class="py-5" id="tentang">
    <div class="container py-4">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <div class="position-relative">
                    <div class="hero-showcase-box rounded-4 overflow-hidden border border-cyan border-opacity-35 shadow-2xl">
                        <img src="<?= BASE_URL ?>/public/img/hero_lab.jpg" alt="Bengkel IT &amp; Teaching Factory TKJ" class="w-100 object-fit-cover" style="height: 360px;">
                        <div class="hero-overlay-gradient"></div>
                        <div class="position-absolute bottom-0 start-0 m-4 z-2">
                            <span class="badge bg-cyan text-dark fw-bold px-3 py-1.5 rounded-pill mb-2 shadow">TEACHING FACTORY (TEFA)</span>
                            <h4 class="fw-bold text-white mb-1">Bengkel &amp; Lab Komputer Terpadu</h4>
                            <p class="text-white-50 extra-small mb-0">Standar industri dengan supervisi guru pembimbing kejuruan.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <span class="badge bg-cyan-subtle text-cyan border border-cyan px-3 py-1.5 rounded-pill mb-2">TENTANG UNIT BISNIS</span>
                <h2 class="fw-bold text-white fs-1 mb-3">Membangun Keahlian Nyata Melalui Layanan IT Profesional</h2>
                <p class="text-white-50 mb-3">
                    <strong>TKJ Smart Service</strong> adalah unit usaha dan Teaching Factory yang dikelola oleh siswa Jurusan Teknik Komputer &amp; Jaringan SMK di bawah bimbingan para guru dan teknisi bersertifikat.
                </p>
                <p class="text-white-50 mb-4">
                    Melalui unit bisnis ini, siswa mengasah keterampilan kerja nyata melayani kebutuhan masyarakat sekitar — mulai dari perbaikan komputer, instalasi CCTV, hingga konfigurasi jaringan internet sekolah dan kantor.
                </p>
                
                <div class="row g-3 mb-4">
                    <div class="col-6">
                        <div class="p-3 rounded-3 bg-dark bg-opacity-60 border border-secondary border-opacity-25">
                            <div class="d-flex align-items-center gap-2 mb-1">
                                <i class="fa-solid fa-certificate text-cyan"></i>
                                <span class="fw-bold text-white small">Uji Kompetensi</span>
                            </div>
                            <small class="text-white-50 extra-small">Siswa telah tersertifikasi uji keahlian internal.</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 rounded-3 bg-dark bg-opacity-60 border border-secondary border-opacity-25">
                            <div class="d-flex align-items-center gap-2 mb-1">
                                <i class="fa-solid fa-microchip text-cyan"></i>
                                <span class="fw-bold text-white small">Alat Industri</span>
                            </div>
                            <small class="text-white-50 extra-small">Peralatan diagnostik dan fiber optic standar industri.</small>
                        </div>
                    </div>
                </div>

                <div class="d-flex align-items-center gap-3">
                    <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup('Ceritakan tentang unit bisnis TKJ Smart Service'); }" class="btn btn-outline-cyan rounded-pill fw-bold px-4" title="Tanya AI tentang TKJ">
                        <i class="fa-solid fa-comments me-2"></i> Chat AI Tentang TKJ
                    </button>
                    <a href="#kontak" class="btn btn-cyan rounded-pill fw-bold px-4">
                        <i class="fa-solid fa-headset me-2"></i> Hubungi Kami
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     CALL TO ACTION (CTA) BANNER
     ========================================================================== -->
<section class="py-5">
    <div class="container">
        <div class="p-4 p-md-5 rounded-4 cta-card text-center text-lg-start d-lg-flex align-items-center justify-content-between">
            <div class="mb-4 mb-lg-0 me-lg-4">
                <span class="badge bg-cyan text-dark fw-bold mb-2">KONSULTASI GRATIS</span>
                <h3 class="fw-bold text-white mb-2 fs-2">Punya Masalah IT Atau Ingin Pasang CCTV &amp; Jaringan?</h3>
                <p class="text-white-50 mb-0">Hubungi kami hari ini untuk konsultasi kebutuhan teknis dan mendapatkan estimasi biaya terbaik.</p>
            </div>
            <div class="d-flex flex-wrap align-items-center gap-3 justify-content-center flex-shrink-0">
                <button type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup('Saya butuh bantuan konsultasi jasa IT'); }" class="btn btn-outline-cyan rounded-pill fw-bold px-4 py-2.5" title="Chat dengan AI Assistant">
                    <i class="fa-solid fa-comments me-2"></i> Chat AI Bot
                </button>
                <a href="<?= BASE_URL ?>/customer/pesanan/create" class="btn btn-cyan btn-lg text-dark rounded-pill fw-bold px-4 py-2.5 btn-shadow">
                    <i class="fa-solid fa-cart-plus fs-5 me-2"></i> Pesan Layanan Sekarang
                </a>
            </div>
        </div>
    </div>
</section>

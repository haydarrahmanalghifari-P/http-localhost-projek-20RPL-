<section class="py-5">
    <div class="container">
        
        <a href="<?= BASE_URL ?>/teknisi/dashboard" class="btn btn-outline-secondary rounded-pill text-white mb-4 extra-small">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Dashboard
        </a>

        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="glass-card p-4 p-md-5 rounded-4 shadow-lg border border-cyan border-opacity-25">
                    
                    <div class="text-center mb-4">
                        <div class="brand-icon-box mx-auto mb-3" style="width: 56px; height: 56px;">
                            <i class="fa-solid fa-user-gear text-cyan fs-3"></i>
                        </div>
                        <h3 class="fw-bold text-white mb-1">Pengaturan Profil Teknisi</h3>
                        <p class="text-white-50 small">Perbarui data diri dan kata sandi akun Teknisi Siswa TKJ Anda</p>
                    </div>

                    <!-- Flash Alert Messages -->
                    <?php $flashSuccess = AuthHelper::getFlash('teknisi_success'); ?>
                    <?php $flashError = AuthHelper::getFlash('teknisi_error'); ?>

                    <?php if ($flashSuccess): ?>
                        <div class="alert alert-success alert-dismissible fade show small" role="alert">
                            <i class="fa-solid fa-circle-check me-1"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($flashError): ?>
                        <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                            <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashError['message']) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?= BASE_URL ?>/teknisi/profile" method="POST">
                        <?= SecurityHelper::csrfField() ?>
                        
                        <div class="mb-3">
                            <label for="nama" class="form-label text-white small fw-semibold">Nama Lengkap & Kelas Siswa</label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-user"></i>
                                </span>
                                <input type="text" class="form-control bg-dark-card border-secondary text-white" id="nama" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="email" class="form-label text-white small fw-semibold">Alamat Email Sekolah</label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-envelope"></i>
                                </span>
                                <input type="email" class="form-control bg-dark-card border-secondary text-white" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                            </div>
                        </div>

                        <hr class="border-secondary border-opacity-25 my-4">
                        <h6 class="fw-bold text-cyan mb-3">Ubah Password (Kosongkan jika tidak diubah)</h6>

                        <div class="mb-3">
                            <label for="new_password" class="form-label text-white small fw-semibold">Password Baru</label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-lock"></i>
                                </span>
                                <input type="password" class="form-control bg-dark-card border-secondary text-white" id="new_password" name="new_password" placeholder="Minimal 6 karakter" minlength="6">
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="confirm_password" class="form-label text-white small fw-semibold">Konfirmasi Password Baru</label>
                            <div class="input-group">
                                <span class="input-group-text bg-dark-card border-secondary text-cyan">
                                    <i class="fa-solid fa-shield-check"></i>
                                </span>
                                <input type="password" class="form-control bg-dark-card border-secondary text-white" id="confirm_password" name="confirm_password" placeholder="Ulangi password baru" minlength="6">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-cyan text-dark w-100 rounded-pill fw-bold py-3 btn-shadow fs-6">
                            <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Perubahan Profil
                        </button>
                    </form>

                </div>
            </div>
        </div>

    </div>
</section>

<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('teknisi_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="mb-4">
            <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">WORKSTATION TEKNISI</span>
            <h2 class="fw-bold text-white mb-0">Pekerjaan Ditugaskan Kepada Anda</h2>
        </div>

        <?php if (!empty($jobs)): ?>
            <div class="vstack gap-3">
                <?php foreach ($jobs as $j): ?>
                    <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
                        <div class="row align-items-center g-3">
                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Kode Pesanan</small>
                                <strong class="text-white fs-6"><?= htmlspecialchars($j['kode_pesanan']) ?></strong>
                                <small class="d-block text-cyan extra-small mt-1">
                                    <i class="fa-solid fa-calendar me-1"></i> Tgl: <?= date('d M Y', strtotime($j['tanggal_pengerjaan'] ?? $j['tanggal_pemesanan'])) ?>
                                </small>
                            </div>

                            <div class="col-md-4">
                                <small class="text-white-50 d-block extra-small">Layanan & Customer</small>
                                <h6 class="fw-bold text-white mb-1"><?= htmlspecialchars($j['nama_jasa']) ?></h6>
                                <small class="text-white-50 extra-small d-block">
                                    <i class="fa-solid fa-user me-1 text-cyan"></i> <?= htmlspecialchars($j['nama_customer']) ?> (<?= htmlspecialchars($j['no_telepon']) ?>)
                                </small>
                                <small class="text-white-50 extra-small d-block">
                                    <i class="fa-solid fa-location-dot me-1 text-cyan"></i> <?= htmlspecialchars(substr($j['alamat'], 0, 35)) ?>...
                                </small>
                            </div>

                            <div class="col-md-2">
                                <small class="text-white-50 d-block extra-small">Status Tugas</small>
                                <?php if ($j['status'] === 'diproses'): ?>
                                    <span class="badge bg-primary px-3 py-1">Dikerjakan</span>
                                <?php elseif ($j['status'] === 'dikonfirmasi'): ?>
                                    <span class="badge bg-warning text-dark px-3 py-1">Menunggu</span>
                                <?php else: ?>
                                    <span class="badge bg-success px-3 py-1">Selesai</span>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-3 text-md-end">
                                <a href="<?= BASE_URL ?>/teknisi/pekerjaan/detail/<?= $j['id'] ?>" class="btn btn-cyan btn-sm rounded-pill px-4 fw-bold text-dark btn-shadow">
                                    <i class="fa-solid fa-pen-to-square me-1"></i> Detail & Progress
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="glass-card p-5 rounded-4 border border-secondary border-opacity-25 text-center my-4">
                <i class="fa-solid fa-circle-check text-cyan display-3 mb-3"></i>
                <h4 class="fw-bold text-white">Tidak Ada Tugas Aktif</h4>
                <p class="text-white-50 max-w-600 mx-auto mb-0">
                    Saat ini tidak ada pekerjaan aktif yang ditugaskan kepada Anda. Seluruh tugas telah selesai dikerjakan.
                </p>
            </div>
        <?php endif; ?>

    </div>
</section>

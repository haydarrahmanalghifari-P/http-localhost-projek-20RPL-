<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('teknisi_success'); ?>
        <?php $flashError = AuthHelper::getFlash('teknisi_error'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i> <?= htmlspecialchars($flashError['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Banner Teknisi -->
        <div class="p-4 p-md-5 rounded-4 glass-card border border-cyan border-opacity-25 mb-4">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <span class="badge bg-info text-dark fw-bold rounded-pill px-3 py-1 mb-2">
                        <i class="fa-solid fa-screwdriver-wrench me-1"></i> Dashboard Teknisi Siswa TKJ
                    </span>
                    <h2 class="fw-bold text-white mb-2">
                        Halo Teknisi, <span class="text-cyan"><?= htmlspecialchars($user['nama']) ?></span>!
                    </h2>
                    <p class="text-white-50 mb-3">
                        Workstation pengerjaan servis IT. Perbarui status pekerjaan, tambahkan catatan & hasil servis, serta ungah foto bukti pengerjaan.
                    </p>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?= BASE_URL ?>/teknisi/pekerjaan" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow btn-sm">
                            <i class="fa-solid fa-list-check me-1"></i> Lihat Tugas Pekerjaan
                        </a>
                        <a href="<?= BASE_URL ?>/teknisi/profile" class="btn btn-outline-light rounded-pill fw-semibold px-3 btn-sm">
                            <i class="fa-solid fa-user-gear me-1"></i> Edit Profil
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 text-center text-lg-end mt-4 mt-lg-0">
                    <i class="fa-solid fa-headset display-1 text-cyan opacity-50"></i>
                </div>
            </div>
        </div>

        <!-- Metric Widgets -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-white-50 small fw-semibold text-uppercase">Tugas Pengerjaan Aktif</div>
                            <div class="fs-2 fw-extrabold text-warning"><?= $counts['active'] ?? 0 ?></div>
                        </div>
                        <div class="icon-square bg-warning bg-opacity-10 text-warning p-3 rounded-3 fs-3">
                            <i class="fa-solid fa-screwdriver-wrench"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-white-50 small fw-semibold text-uppercase">Tugas Selesai</div>
                            <div class="fs-2 fw-extrabold text-success"><?= $counts['completed'] ?? 0 ?></div>
                        </div>
                        <div class="icon-square bg-success bg-opacity-10 text-success p-3 rounded-3 fs-3">
                            <i class="fa-solid fa-circle-check"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-white-50 small fw-semibold text-uppercase">Rating Pelanggan</div>
                            <div class="fs-2 fw-extrabold text-cyan"><?= $counts['rating'] ?? '4.9' ?> / 5.0</div>
                        </div>
                        <div class="icon-square bg-cyan-subtle text-cyan p-3 rounded-3 fs-3">
                            <i class="fa-solid fa-star"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Daftar Tugas Pekerjaan Aktif Teknisi -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <h5 class="fw-bold text-white mb-0">
                    <i class="fa-solid fa-list-check text-cyan me-2"></i> Tugas Pekerjaan Ditugaskan kepada Anda
                </h5>
                <a href="<?= BASE_URL ?>/teknisi/pekerjaan" class="btn btn-outline-cyan btn-sm rounded-pill extra-small fw-bold">
                    Lihat Semua Tugas
                </a>
            </div>

            <?php if (!empty($jobs)): ?>
                <div class="vstack gap-3">
                    <?php foreach ($jobs as $j): ?>
                        <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25">
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
                                <div>
                                    <span class="badge bg-warning text-dark me-2"><?= strtoupper(htmlspecialchars($j['status'])) ?></span>
                                    <strong class="text-white"><?= htmlspecialchars($j['kode_pesanan']) ?></strong> - <?= htmlspecialchars($j['nama_jasa']) ?>
                                </div>
                                <small class="text-white-50 extra-small">Tgl Kunjungan: <?= date('d M Y', strtotime($j['tanggal_pengerjaan'] ?? $j['tanggal_pemesanan'])) ?></small>
                            </div>
                            <p class="text-white-50 small mb-2">
                                <strong>Pelanggan:</strong> <?= htmlspecialchars($j['nama_customer']) ?> (<?= htmlspecialchars($j['no_telepon']) ?>)<br>
                                <strong>Alamat:</strong> <?= htmlspecialchars($j['alamat']) ?><br>
                                <strong>Kendala:</strong> <?= htmlspecialchars($j['deskripsi_masalah']) ?>
                            </p>
                            <div class="d-flex gap-2">
                                <a href="<?= BASE_URL ?>/teknisi/pekerjaan/detail/<?= $j['id'] ?>" class="btn btn-cyan btn-sm rounded-pill px-3 fw-bold text-dark">
                                    <i class="fa-solid fa-pen-to-square me-1"></i> Update Status & Catatan
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center text-white-50 py-4">
                    Belum ada tugas pengerjaan aktif yang ditugaskan kepada Anda.
                </div>
            <?php endif; ?>
        </div>

    </div>
</section>

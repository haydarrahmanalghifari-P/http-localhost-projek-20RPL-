<section class="py-5">
    <div class="container">
        
        <a href="<?= BASE_URL ?>/teknisi/pekerjaan" class="btn btn-outline-secondary rounded-pill text-white mb-4 extra-small">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Daftar Pekerjaan
        </a>

        <!-- Flash Alert Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('teknisi_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <!-- Left Info Panel -->
            <div class="col-lg-5">
                <div class="glass-card p-4 rounded-4 border border-cyan border-opacity-25 shadow-lg mb-4">
                    <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-2">RINCIAN TUGAS</span>
                    <h3 class="fw-bold text-white mb-1">#<?= htmlspecialchars($job['kode_pesanan']) ?></h3>
                    <p class="text-cyan fw-bold mb-3"><?= htmlspecialchars($job['nama_jasa']) ?></p>

                    <div class="vstack gap-3 text-white-50 extra-small">
                        <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25">
                            <strong class="text-white d-block mb-1"><i class="fa-solid fa-user text-cyan me-1"></i> Pelanggan:</strong>
                            <div class="text-white fs-6 fw-bold"><?= htmlspecialchars($job['nama_customer']) ?></div>
                            <div>Telp / WA: <a href="https://wa.me/<?= str_replace(['-', ' '], '', $job['no_telepon']) ?>" target="_blank" class="text-cyan fw-bold"><?= htmlspecialchars($job['no_telepon']) ?></a></div>
                        </div>

                        <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25">
                            <strong class="text-white d-block mb-1"><i class="fa-solid fa-location-dot text-cyan me-1"></i> Alamat Pengerjaan:</strong>
                            <div class="text-white"><?= htmlspecialchars($job['alamat']) ?></div>
                        </div>

                        <div class="p-3 rounded-3 bg-dark-card border border-secondary border-opacity-25">
                            <strong class="text-white d-block mb-1"><i class="fa-solid fa-triangle-exclamation text-warning me-1"></i> Kendala Pelanggan:</strong>
                            <div class="text-white-50"><?= htmlspecialchars($job['deskripsi_masalah']) ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Progress Form Panel -->
            <div class="col-lg-7">
                <div class="glass-card p-4 p-md-5 rounded-4 border border-secondary border-opacity-25 shadow-lg">
                    <h4 class="fw-bold text-white mb-1"><i class="fa-solid fa-pen-to-square text-cyan me-2"></i> Update Progress & Hasil Pekerjaan</h4>
                    <p class="text-white-50 extra-small mb-4">Lengkapi catatan teknisi, hasil pengerjaan, dan foto dokumentasi bukti pengerjaan.</p>

                    <form action="<?= BASE_URL ?>/teknisi/pekerjaan/update/<?= $job['id'] ?>" method="POST" enctype="multipart/form-data">
                        <?= SecurityHelper::csrfField() ?>
                        <input type="hidden" name="order_id" value="<?= $job['id'] ?>">

                        <!-- 1. Ubah Status Pekerjaan -->
                        <div class="mb-3">
                            <label for="status" class="form-label text-white small fw-semibold">Status Pekerjaan <span class="text-danger">*</span></label>
                            <select class="form-select bg-dark-card border-secondary text-white" id="status" name="status" required>
                                <option value="Menunggu" <?= ($job['status'] === 'dikonfirmasi' || $job['status_pekerjaan'] === 'tertunda') ? 'selected' : '' ?>>Menunggu</option>
                                <option value="Dikerjakan" <?= ($job['status'] === 'diproses' || $job['status_pekerjaan'] === 'dalam_proses') ? 'selected' : '' ?>>Dikerjakan</option>
                                <option value="Selesai" <?= ($job['status'] === 'selesai' || $job['status_pekerjaan'] === 'selesai') ? 'selected' : '' ?>>Selesai</option>
                            </select>
                        </div>

                        <!-- 2. Catatan Pekerjaan -->
                        <div class="mb-3">
                            <label for="catatan_teknisi" class="form-label text-white small fw-semibold">Catatan Pengerjaan Teknisi</label>
                            <textarea class="form-control bg-dark-card border-secondary text-white" id="catatan_teknisi" name="catatan_teknisi" rows="3" placeholder="Tuliskan catatan analisis kendala, spesifikasi komponen diganti, atau rincian penarikan kabel..."><?= htmlspecialchars($job['catatan_teknisi'] ?? '') ?></textarea>
                        </div>

                        <!-- 3. Hasil Pekerjaan -->
                        <div class="mb-3">
                            <label for="hasil_pekerjaan" class="form-label text-white small fw-semibold">Hasil Pekerjaan Servis</label>
                            <textarea class="form-control bg-dark-card border-secondary text-white" id="hasil_pekerjaan" name="hasil_pekerjaan" rows="3" placeholder="Jelaskan ringkasan hasil pengerjaan (misal: 4 CCTV aktif & terkoneksi HP, booting laptop 8 detik)..."><?= htmlspecialchars($job['hasil_pekerjaan'] ?? '') ?></textarea>
                        </div>

                        <!-- 4. Mengunggah Foto Dokumentasi -->
                        <div class="mb-4">
                            <label for="foto_pekerjaan" class="form-label text-white small fw-semibold">Unggah Foto Dokumentasi Pekerjaan</label>
                            <input type="file" class="form-control bg-dark-card border-secondary text-white" id="foto_pekerjaan" name="foto_pekerjaan" accept="image/png, image/jpeg, image/jpg, image/webp">
                            <?php if (!empty($job['foto_pekerjaan'])): ?>
                                <small class="text-cyan extra-small d-block mt-1">
                                    <i class="fa-solid fa-image me-1"></i> Foto tersimpan: <?= htmlspecialchars($job['foto_pekerjaan']) ?>
                                </small>
                            <?php endif; ?>
                        </div>

                        <!-- Info Banner Otomatisasi -->
                        <div class="p-3 rounded-3 bg-cyan bg-opacity-10 border border-cyan border-opacity-25 mb-4 text-white-50 extra-small">
                            <i class="fa-solid fa-circle-info text-cyan me-1"></i> <strong>Sistem Otomatisasi Selesai:</strong> Ketika status diubah menjadi <strong>Selesai</strong>, hasil pekerjaan & tanggal selesai akan disimpan, status pesanan diubah menjadi <strong>Selesai</strong>, dan notifikasi dikirimkan otomatis ke Customer.
                        </div>

                        <button type="submit" class="btn btn-cyan text-dark w-100 rounded-pill fw-bold py-3 btn-shadow fs-6">
                            <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Progress & Update Pekerjaan
                        </button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</section>

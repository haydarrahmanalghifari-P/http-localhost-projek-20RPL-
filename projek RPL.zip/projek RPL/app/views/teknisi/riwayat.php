<section class="py-5">
    <div class="container">
        
        <!-- Header -->
        <div class="mb-4">
            <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">DOKUMENTASI TEKNISI</span>
            <h2 class="fw-bold text-white mb-0">Riwayat Pekerjaan Selesai</h2>
        </div>

        <?php if (!empty($jobs)): ?>
            <div class="vstack gap-3">
                <?php foreach ($jobs as $j): ?>
                    <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
                        <div class="row align-items-center g-3">
                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Kode Pesanan</small>
                                <strong class="text-white fs-6"><?= htmlspecialchars($j['kode_pesanan']) ?></strong>
                                <span class="badge bg-success d-block mt-1 w-fit">Selesai</span>
                            </div>

                            <div class="col-md-4">
                                <small class="text-white-50 d-block extra-small">Layanan & Customer</small>
                                <h6 class="fw-bold text-white mb-1"><?= htmlspecialchars($j['nama_jasa']) ?></h6>
                                <small class="text-white-50 extra-small">Pelanggan: <?= htmlspecialchars($j['nama_customer']) ?></small>
                            </div>

                            <div class="col-md-3">
                                <small class="text-white-50 d-block extra-small">Hasil Pekerjaan</small>
                                <div class="text-white extra-small fw-semibold"><?= htmlspecialchars(substr($j['hasil_pekerjaan'] ?? 'Pekerjaan selesai', 0, 45)) ?>...</div>
                            </div>

                            <div class="col-md-2 text-md-end">
                                <a href="<?= BASE_URL ?>/teknisi/pekerjaan/detail/<?= $j['id'] ?>" class="btn btn-outline-cyan btn-sm rounded-pill px-3 fw-bold">
                                    Detail
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="glass-card p-5 rounded-4 border border-secondary border-opacity-25 text-center my-4">
                <i class="fa-solid fa-clock-rotate-left text-cyan display-3 mb-3"></i>
                <h4 class="fw-bold text-white">Belum Ada Riwayat Pekerjaan Selesai</h4>
                <p class="text-white-50 max-w-600 mx-auto mb-0">
                    Riwayat tugas servis yang telah selesai Anda kerjakan akan otomatis tampil di halaman ini.
                </p>
            </div>
        <?php endif; ?>

    </div>
</section>

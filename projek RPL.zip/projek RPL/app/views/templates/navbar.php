<!-- Navbar Utama -->
<nav class="navbar navbar-expand-lg sticky-top custom-navbar shadow-sm">
    <div class="container">
        <!-- Brand Logo -->
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?= BASE_URL ?>">
            <div class="brand-icon-box">
                <i class="fa-solid fa-server text-cyan fs-5"></i>
            </div>
            <div class="brand-text">
                <span class="fw-bold text-white fs-5">TKJ</span>
                <span class="fw-bold text-cyan fs-5">Smart Service</span>
                <small class="d-block brand-subtext">Unit Bisnis Siswa TKJ</small>
            </div>
        </a>

        <!-- Mobile Toggler -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTKJ" aria-controls="navbarTKJ" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fa-solid fa-bars-staggered text-white fs-4"></i>
        </button>

        <!-- Menu Navigation -->
        <div class="collapse navbar-collapse" id="navbarTKJ">
            <ul class="navbar-nav ms-auto me-lg-3 mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (isset($active_nav) && $active_nav == 'home') ? 'active' : '' ?>" href="<?= BASE_URL ?>">
                        <i class="fa-solid fa-house me-1"></i> Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>#layanan">
                        <i class="fa-solid fa-screwdriver-wrench me-1"></i> Layanan Jasa
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>#keunggulan">
                        <i class="fa-solid fa-shield-halved me-1"></i> Keunggulan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>#tentang">
                        <i class="fa-solid fa-graduation-cap me-1"></i> Tentang TKJ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= BASE_URL ?>#kontak">
                        <i class="fa-solid fa-headset me-1"></i> Kontak
                    </a>
                </li>
            </ul>

            <!-- Button Auth & Internal Notification Dropdown -->
            <div class="d-flex align-items-center gap-2 mt-3 mt-lg-0">
                <?php if (AuthHelper::isLoggedIn()): ?>
                    <?php 
                    $user = AuthHelper::user();
                    
                    // Fetch Unread Notifications for Navbar Bell Dropdown
                    $notifModel = new NotificationModel();
                    $unreadCount = $notifModel->getUnreadCountByUser($user['id']);
                    $unreadList = $notifModel->getUnreadNotificationsByUser($user['id']);
                    ?>

                    <!-- Tombol Ikon Chatbot AI (Icon Only) -->
                    <button class="btn btn-outline-cyan rounded-circle p-2 d-flex align-items-center justify-content-center me-1" style="width: 38px; height: 38px;" type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup(); }" title="Chat AI Assistant">
                        <i class="fa-solid fa-robot fs-6"></i>
                    </button>

                    <!-- Tombol Pengaturan AI & API Keys (Di Luar Chatbot) -->
                    <button class="btn btn-outline-cyan rounded-circle p-2 d-flex align-items-center justify-content-center me-1" style="width: 38px; height: 38px;" type="button" data-bs-toggle="modal" data-bs-target="#globalAiSettingsModal" title="Pengaturan Model AI & API Keys">
                        <i class="fa-solid fa-sliders fs-6"></i>
                    </button>

                    <!-- Bell Icon Notification Dropdown -->
                    <div class="dropdown me-1">
                        <button class="btn btn-outline-cyan rounded-circle position-relative p-2 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;" type="button" id="notifDropdown" data-bs-toggle="dropdown" aria-expanded="false" title="Notifikasi Internal">
                            <i class="fa-solid fa-bell fs-6"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger extra-small">
                                    <?= $unreadCount ?>
                                </span>
                            <?php endif; ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end shadow-lg border-secondary border-opacity-25 p-3" style="width: 320px;" aria-labelledby="notifDropdown">
                            <li class="d-flex align-items-center justify-content-between pb-2 border-bottom border-secondary border-opacity-25 mb-2">
                                <span class="fw-bold text-white small"><i class="fa-solid fa-bell text-cyan me-1"></i> Notifikasi</span>
                                <?php if ($unreadCount > 0): ?>
                                    <a href="<?= BASE_URL ?>/notifikasi/readAll" class="extra-small text-cyan text-decoration-none">Tandai Dibaca</a>
                                <?php endif; ?>
                            </li>

                            <?php if (!empty($unreadList)): ?>
                                <?php foreach ($unreadList as $un): ?>
                                    <li class="mb-2">
                                        <div class="p-2 rounded-3 bg-dark bg-opacity-50">
                                            <div class="d-flex align-items-center justify-content-between mb-1">
                                                <strong class="text-cyan extra-small"><?= htmlspecialchars($un['judul']) ?></strong>
                                                <a href="<?= BASE_URL ?>/notifikasi/read/<?= $un['id'] ?>" class="text-white-50 extra-small" title="Tandai Dibaca">
                                                    <i class="fa-solid fa-check"></i>
                                                </a>
                                            </div>
                                            <p class="text-white-50 extra-small mb-1 leading-tight">
                                                <?= htmlspecialchars(substr($un['pesan'], 0, 70)) ?>...
                                            </p>
                                            <small class="text-white-50 opacity-50" style="font-size: 0.65rem;">
                                                <?= date('d M H:i', strtotime($un['created_at'])) ?>
                                            </small>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li class="text-center text-white-50 py-3 extra-small">
                                    Tidak ada notifikasi baru.
                                </li>
                            <?php endif; ?>

                            <li class="pt-2 border-top border-secondary border-opacity-25 text-center">
                                <a href="<?= BASE_URL ?>/notifikasi" class="text-cyan fw-bold extra-small text-decoration-none">
                                    Lihat Semua Notifikasi <i class="fa-solid fa-arrow-right ms-1"></i>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <!-- User Profile Dropdown -->
                    <div class="dropdown">
                        <button class="btn btn-outline-cyan rounded-pill dropdown-toggle extra-small fw-bold px-3 py-2 d-inline-flex align-items-center" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-solid fa-circle-user me-1 fs-6"></i>
                            <span class="d-inline-block text-truncate align-middle" style="max-width: 120px;"><?= htmlspecialchars($user['nama']) ?></span>
                            <?php
                                $roleBadgeColor = 'bg-cyan text-dark';
                                if ($user['role'] === 'admin') $roleBadgeColor = 'bg-danger text-white';
                                elseif ($user['role'] === 'operator') $roleBadgeColor = 'bg-warning text-dark';
                                elseif ($user['role'] === 'teknisi') $roleBadgeColor = 'bg-info text-dark';
                                elseif ($user['role'] === 'kepala_sekolah') $roleBadgeColor = 'bg-primary text-white';
                            ?>
                            <span class="badge <?= $roleBadgeColor ?> ms-1 extra-small"><?= strtoupper(str_replace('_', ' ', $user['role'])) ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end shadow-lg border-secondary border-opacity-25">
                            <li>
                                <a class="dropdown-item text-cyan fw-semibold small" href="<?= AuthHelper::getDashboardUrl() ?>">
                                    <i class="fa-solid fa-gauge me-2"></i> Dashboard Saya
                                </a>
                            </li>
                            <?php if ($user['role'] === 'admin'): ?>
                                <li>
                                    <a class="dropdown-item text-danger fw-semibold small" href="<?= BASE_URL ?>/admin/users">
                                        <i class="fa-solid fa-users-gear me-2"></i> Kelola Pengguna
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-warning fw-semibold small" href="<?= BASE_URL ?>/admin/pesanan">
                                        <i class="fa-solid fa-clipboard-check me-2"></i> Verifikasi Pesanan
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-info fw-semibold small" href="<?= BASE_URL ?>/operator/jasa">
                                        <i class="fa-solid fa-screwdriver-wrench me-2"></i> Katalog Jasa
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-success fw-semibold small" href="<?= BASE_URL ?>/operator/laporan">
                                        <i class="fa-solid fa-chart-line me-2"></i> Laporan TEFA
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-cyan fw-semibold small" href="<?= BASE_URL ?>/admin/ai-config">
                                        <i class="fa-solid fa-microchip me-2 text-cyan"></i> Konfigurasi AI &amp; Multi API Key
                                    </a>
                                </li>
                            <?php elseif ($user['role'] === 'operator'): ?>
                                <li>
                                    <a class="dropdown-item text-warning fw-semibold small" href="<?= BASE_URL ?>/operator/faq">
                                        <i class="fa-solid fa-circle-question me-2"></i> Kelola FAQ AI
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <a class="dropdown-item text-cyan fw-semibold small" href="#" data-bs-toggle="modal" data-bs-target="#globalAiSettingsModal">
                                    <i class="fa-solid fa-sliders me-2"></i> Pengaturan Model &amp; API Keys
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item text-white small" href="<?= BASE_URL ?>/notifikasi">
                                    <i class="fa-solid fa-bell me-2"></i> Notifikasi Saya
                                </a>
                            </li>

                            <li><hr class="dropdown-divider border-secondary opacity-25"></li>
                            <li>
                                <a class="dropdown-item text-danger small" href="<?= BASE_URL ?>/logout">
                                    <i class="fa-solid fa-right-from-bracket me-2"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <!-- Tombol Ikon Chatbot AI (Icon Only) -->
                    <button class="btn btn-outline-cyan rounded-circle p-2 d-flex align-items-center justify-content-center me-1" style="width: 38px; height: 38px;" type="button" onclick="if(window.openChatbotPopup){ window.openChatbotPopup(); }" title="Chat AI Assistant">
                        <i class="fa-solid fa-robot fs-6"></i>
                    </button>
                    <!-- Tombol Pengaturan AI & API Keys (Di Luar Chatbot) -->
                    <button class="btn btn-outline-cyan rounded-circle p-2 d-flex align-items-center justify-content-center me-1" style="width: 38px; height: 38px;" type="button" data-bs-toggle="modal" data-bs-target="#globalAiSettingsModal" title="Pengaturan Model AI & API Keys">
                        <i class="fa-solid fa-sliders fs-6"></i>
                    </button>
                    <a href="<?= BASE_URL ?>/login" class="btn btn-outline-light rounded-pill px-3 py-1 text-decoration-none small fw-semibold">
                        <i class="fa-solid fa-right-to-bracket me-1"></i> Login
                    </a>
                    <a href="<?= BASE_URL ?>/register" class="btn btn-cyan text-dark fw-bold rounded-pill px-3 py-1 btn-shadow text-decoration-none small">
                        <i class="fa-solid fa-user-plus me-1"></i> Daftar
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

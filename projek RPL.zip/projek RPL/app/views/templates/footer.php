<!-- Footer Section -->
<footer class="custom-footer pt-5 pb-4 mt-5 text-white">
    <div class="container">
        <div class="row g-4 mb-4">
            <!-- Col 1: App Info -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-box">
                        <i class="fa-solid fa-server text-cyan fs-5"></i>
                    </div>
                    <div>
                        <span class="fw-bold text-white fs-5">TKJ</span>
                        <span class="fw-bold text-cyan fs-5">Smart Service</span>
                    </div>
                </div>
                <p class="text-white-50 small mb-3">
                    Unit bisnis praktek kerja siswa Teknik Komputer & Jaringan. Menyediakan layanan perbaikan & instalasi perangkat IT profesional, terjangkau, dan didampingi teknisi pengajar berpengalaman.
                </p>
                <div class="d-flex gap-2">
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>

            <!-- Col 2: Quick Links -->
            <div class="col-lg-2 col-md-6">
                <h6 class="fw-bold text-cyan mb-3">Navigasi</h6>
                <ul class="list-unstyled footer-links small">
                    <li class="mb-2"><a href="<?= BASE_URL ?>"><i class="fa-solid fa-angle-right me-1 text-cyan"></i> Home</a></li>
                    <li class="mb-2"><a href="<?= BASE_URL ?>#layanan"><i class="fa-solid fa-angle-right me-1 text-cyan"></i> Layanan Jasa</a></li>
                    <li class="mb-2"><a href="<?= BASE_URL ?>#keunggulan"><i class="fa-solid fa-angle-right me-1 text-cyan"></i> Keunggulan</a></li>
                    <li class="mb-2"><a href="<?= BASE_URL ?>#tentang"><i class="fa-solid fa-angle-right me-1 text-cyan"></i> Tentang TKJ</a></li>
                    <li class="mb-2"><a href="<?= BASE_URL ?>#kontak"><i class="fa-solid fa-angle-right me-1 text-cyan"></i> Kontak Kami</a></li>
                </ul>
            </div>

            <!-- Col 3: Services List -->
            <div class="col-lg-3 col-md-6">
                <h6 class="fw-bold text-cyan mb-3">Layanan Kami</h6>
                <ul class="list-unstyled footer-links small">
                    <li class="mb-2"><i class="fa-solid fa-video me-2 text-cyan"></i> Instalasi CCTV</li>
                    <li class="mb-2"><i class="fa-solid fa-network-wired me-2 text-cyan"></i> Instalasi Jaringan LAN</li>
                    <li class="mb-2"><i class="fa-solid fa-wifi me-2 text-cyan"></i> Setting Wi-Fi & Hotspot</li>
                    <li class="mb-2"><i class="fa-solid fa-laptop-code me-2 text-cyan"></i> Service Komputer/Laptop</li>
                    <li class="mb-2"><i class="fa-solid fa-server me-2 text-cyan"></i> Maintenance Perangkat IT</li>
                    <li class="mb-2"><i class="fa-solid fa-microchip me-2 text-cyan"></i> Perakitan PC & Custom IT</li>
                </ul>
            </div>

            <!-- Col 4: Contact & Location -->
            <div class="col-lg-3 col-md-6" id="kontak">
                <h6 class="fw-bold text-cyan mb-3">Hubungi Kami</h6>
                <ul class="list-unstyled text-white-50 small mb-0">
                    <li class="mb-2 d-flex align-items-start gap-2">
                        <i class="fa-solid fa-location-dot text-cyan mt-1"></i>
                        <span>Bengkel & Lab TKJ SMK Negeri 1, Gedung Unit Produksi IT.</span>
                    </li>
                    <li class="mb-2 d-flex align-items-center gap-2">
                        <i class="fa-solid fa-phone text-cyan"></i>
                        <span><?= APP_PHONE ?></span>
                    </li>
                    <li class="mb-2 d-flex align-items-center gap-2">
                        <i class="fa-solid fa-envelope text-cyan"></i>
                        <span><?= APP_EMAIL ?></span>
                    </li>
                    <li class="d-flex align-items-center gap-2">
                        <i class="fa-solid fa-clock text-cyan"></i>
                        <span>Senin - Sabtu: 08.00 - 16.00 WIB</span>
                    </li>
                </ul>
            </div>
        </div>

        <hr class="border-secondary my-4">

        <!-- Copyright -->
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                <p class="small text-white-50 mb-0">
                    &copy; <?= date('Y') ?> <strong class="text-white"><?= APP_NAME ?></strong>. Powered by Siswa & Guru TKJ.
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <small class="text-white-50">Arsitektur MVC Native PHP | Tugas Project RPL</small>
            </div>
        </div>
    </div>
</footer>

<!-- Chatbot AI Pop-up Widget -->
<?php require_once APPROOT . '/app/views/templates/chatbot_widget.php'; ?>

<!-- Bootstrap 5 JS Bundle CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS -->
<script src="<?= BASE_URL ?>/public/js/main.js"></script>
</body>
</html>

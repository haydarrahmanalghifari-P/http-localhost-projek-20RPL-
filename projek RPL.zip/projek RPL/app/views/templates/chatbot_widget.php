<?php
/**
 * TKJ Smart Service - AI Chatbot Pop-up Widget (Ultra Visual Edition)
 * Modern floating glassmorphic AI widget with rich visual cards, audio waves, sound chimes, and expand mode.
 */
$isUserLoggedIn = AuthHelper::isLoggedIn();
$currentUser = $isUserLoggedIn ? AuthHelper::user() : null;
$clientUserName = $currentUser ? htmlspecialchars($currentUser['nama']) : 'Kak';
$userRoleBadge = $currentUser ? strtoupper(str_replace('_', ' ', $currentUser['role'])) : 'GUEST';
?>

<!-- ==========================================================================
     AI CHATBOT POP-UP WIDGET (ULTRA VISUAL)
     ========================================================================== -->

<!-- Floating Greeting Bubble -->
<div id="chatbotGreetingBubble" class="chatbot-greeting-bubble shadow-xl">
    <button type="button" class="bubble-close-btn" id="btnCloseGreetingBubble" aria-label="Tutup sapaan">&times;</button>
    <div class="d-flex align-items-center gap-2.5 cursor-pointer" id="btnGreetingOpenChat">
        <div class="greeting-avatar-orb">
            <i class="fa-solid fa-comments text-cyan"></i>
            <span class="greeting-ping"></span>
        </div>
        <div class="greeting-text">
            <div class="d-flex align-items-center gap-1 mb-0.5">
                <span class="badge-bot-mini"><i class="fa-brands fa-node-js me-1 text-success"></i> NODE.JS AI</span>
                <span class="text-success extra-small">● Online</span>
            </div>
            <div class="fw-bold text-dark small leading-tight">Butuh Konsultasi Jasa IT?</div>
            <div class="text-primary extra-small fw-semibold">Klik ikon chat untuk konsultasi instan &raquo;</div>
        </div>
    </div>
</div>

<!-- Floating Action Button (FAB Launcher with Rotating Cyber Orbit) -->
<button type="button" id="chatbotFabBtn" class="chatbot-fab-btn shadow-2xl" aria-label="Buka AI Chatbot Assistant" title="Chat dengan AI Assistant TKJ (Node.js & Gemini)">
    <div class="fab-orbit-ring"></div>
    <div class="fab-glow-core"></div>
    <div class="fab-icon-container">
        <i class="fa-solid fa-comments fab-icon-open"></i>
        <i class="fa-solid fa-xmark fab-icon-close"></i>
    </div>
    <span class="fab-online-badge" title="AI Assistant Siap 24/7 (Node.js)"></span>
    <span class="fab-sparkle-dot"></span>
</button>

<!-- Chatbot Pop-up Window -->
<div id="chatbotPopupModal" class="chatbot-popup-modal shadow-2xl" role="dialog" aria-labelledby="chatbotTitle" aria-hidden="true">
    
    <!-- Modal Header with Tech Background & Audio Spectrum Wave -->
    <div class="chatbot-header p-3 position-relative overflow-hidden">
        <div class="header-cyber-glow"></div>
        <div class="d-flex align-items-center justify-content-between position-relative z-2">
            
            <!-- Bot Profile & Status -->
            <div class="d-flex align-items-center gap-2.5">
                <div class="position-relative">
                    <div class="chatbot-avatar-frame d-flex align-items-center justify-content-center">
                        <i class="fa-solid fa-comments text-cyan fs-5"></i>
                    </div>
                    <span class="avatar-live-pulse"></span>
                </div>
                <div>
                    <div class="d-flex align-items-center gap-2">
                        <h6 class="fw-bold text-dark mb-0" id="chatbotTitle">TKJ Smart Bot</h6>
                        <span class="badge-ai-gradient badge-engine-dynamic gemini" id="botBadgeRuntime"><i class="fa-brands fa-google text-info me-1"></i> Gemini AI</span>
                    </div>
                    <div class="d-flex align-items-center gap-2 mt-0.5">
                        <div class="ai-audio-wave" id="aiAudioWave" title="AI Spectrum">
                            <span></span><span></span><span></span><span></span>
                        </div>
                        <small class="text-secondary extra-small fw-semibold" id="botSubtitleRuntime">Google Gemini • Flash 3.5 / 3.8</small>
                    </div>
                </div>
            </div>
            
            <!-- Header Controls -->
            <div class="d-flex align-items-center gap-1.5">
                <button type="button" class="btn btn-icon-glass" data-bs-toggle="modal" data-bs-target="#globalAiSettingsModal" title="Pengaturan Model AI & API Keys (Di Luar Chatbot)">
                    <i class="fa-solid fa-sliders text-cyan" id="settingsIcon"></i>
                </button>
                <button type="button" id="btnToggleSound" class="btn btn-icon-glass" title="Toggle Suara AI (Aktif/Mute)">
                    <i class="fa-solid fa-volume-high text-cyan" id="soundIcon"></i>
                </button>
                <button type="button" id="btnExpandPopup" class="btn btn-icon-glass d-none d-sm-flex" title="Perbesar / Perkecil Tampilan">
                    <i class="fa-solid fa-up-right-and-down-left-from-center" id="expandIcon"></i>
                </button>
                <button type="button" id="btnResetPopupChat" class="btn btn-icon-glass" title="Mulai Ulang Percakapan">
                    <i class="fa-solid fa-rotate-right"></i>
                </button>
                <button type="button" id="btnClosePopupChat" class="btn btn-icon-glass btn-close-modal" title="Tutup Chat">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Quick Engine Switcher & Status Bar -->
    <div class="chatbot-engine-bar px-3 py-1.5 d-flex align-items-center justify-content-between border-bottom border-light-subtle position-relative z-2">
        <div class="d-flex align-items-center gap-2">
            <span class="text-secondary extra-small fw-semibold"><i class="fa-solid fa-microchip text-cyan me-1"></i> Engine:</span>
            <div class="btn-group btn-group-sm engine-toggle-group" role="group" aria-label="Ganti Model AI">
                <button type="button" class="btn btn-engine-pill active" data-engine="gemini" id="pillGemini" title="Beralih ke Google Gemini">
                    <i class="fa-brands fa-google text-primary me-0.5"></i> Gemini
                </button>
                <button type="button" class="btn btn-engine-pill" data-engine="deepseek" id="pillDeepseek" title="Beralih ke DeepSeek AI">
                    <i class="fa-solid fa-brain text-info me-0.5"></i> DeepSeek
                </button>
                <button type="button" class="btn btn-engine-pill" data-engine="grok" id="pillGrok" title="Beralih ke xAI Grok">
                    <i class="fa-solid fa-bolt text-warning me-0.5"></i> Groq
                </button>
                <button type="button" class="btn btn-engine-pill" data-engine="database" id="pillDb" title="Beralih ke Smart DB AI Lokal">
                    <i class="fa-solid fa-database text-success me-0.5"></i> DB Lokal
                </button>
            </div>
        </div>
        <div class="d-flex align-items-center gap-2">
            <button type="button" class="btn btn-link text-cyan extra-small p-0 text-decoration-none fw-semibold" data-bs-toggle="modal" data-bs-target="#globalAiSettingsModal" title="Pengaturan Model & API Keys di Luar Chatbot">
                <i class="fa-solid fa-sliders me-0.5"></i> Atur Keys
            </button>
            <?php if ($isUserLoggedIn && $currentUser['role'] === 'customer'): ?>
                <a href="<?= BASE_URL ?>/customer/ai-assistant" class="extra-small text-cyan text-decoration-none fw-semibold" title="Buka Halaman Lengkap">
                    Full <i class="fa-solid fa-arrow-up-right-from-square ms-0.5"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Chat Messages Scroll Area -->
    <div class="chatbot-body p-3" id="chatbotMessageContainer">
    </div>

    <!-- Chat Footer Input Form -->
    <div class="chatbot-footer p-2.5 border-top border-light-subtle">
        <form id="chatbotInputForm" class="d-flex align-items-center gap-2">
            <div class="input-wrapper flex-grow-1 position-relative">
                <input type="text" id="chatbotInputText" class="form-control chatbot-input py-2 ps-3 pe-4 text-dark" placeholder="Ketik pertanyaan seputar layanan IT..." autocomplete="off" required>
                <span class="input-sparkle"><i class="fa-solid fa-wand-magic-sparkles text-cyan"></i></span>
            </div>
            <button type="submit" id="btnChatbotSend" class="btn btn-send-pop d-flex align-items-center justify-content-center" title="Kirim Pesan">
                <i class="fa-solid fa-paper-plane"></i>
            </button>
        </form>
        <div class="d-flex align-items-center justify-content-between mt-1.5 px-1">
            <small class="chatbot-attribution text-secondary">
                ⚡ Unit Bisnis Siswa TKJ SMK • Respon Cepat AI
            </small>
            <small class="text-secondary extra-small">
                Tekan <kbd class="bg-light text-dark border px-1 py-0.5 rounded extra-small">Enter ↵</kbd>
            </small>
        </div>
    </div>

</div>

<!-- ==========================================================================
     GLOBAL MODAL: PENGATURAN MODEL AI & API KEYS (DI LUAR CHATBOT)
     ========================================================================== -->
<div class="modal fade" id="globalAiSettingsModal" tabindex="-1" aria-labelledby="globalAiSettingsModalLabel" aria-hidden="true" style="z-index: 1065;">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border border-cyan border-opacity-35 shadow-2xl rounded-4 overflow-hidden" style="background: #ffffff; color: #0f172a;">
            
            <!-- Modal Header -->
            <div class="modal-header border-bottom border-light-subtle px-4 py-3 bg-white">
                <div class="d-flex align-items-center gap-3">
                    <div class="modal-icon-badge rounded-circle d-flex align-items-center justify-content-center" style="width: 44px; height: 44px; background: rgba(8, 145, 178, 0.12); color: #0891b2; border: 1.5px solid rgba(8, 145, 178, 0.3);">
                        <i class="fa-solid fa-sliders fs-5"></i>
                    </div>
                    <div>
                        <h5 class="modal-title fw-bold text-dark mb-0" id="globalAiSettingsModalLabel">Pengaturan Model &amp; API Keys AI</h5>
                        <small class="text-muted extra-small">Kustomisasi penyedia kecerdasan buatan &amp; manajemen kunci API di luar chatbot</small>
                    </div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <a href="<?= BASE_URL ?>/admin/ai-config" class="btn btn-outline-cyan btn-sm rounded-pill extra-small d-none d-md-inline-flex align-items-center gap-1" title="Buka Halaman Penuh Dashboard Konfigurasi AI">
                        <i class="fa-solid fa-expand"></i> Dashboard Lengkap
                    </a>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                </div>
            </div>

            <!-- Modal Body -->
            <div class="modal-body p-4" style="background-color: #f8fafc;">
                
                <!-- Status Bar Integrasi -->
                <div class="d-flex flex-wrap align-items-center justify-content-between p-2.5 rounded-3 bg-white border border-light-subtle mb-4 gap-2 shadow-sm">
                    <div class="d-flex align-items-center gap-2">
                        <span class="extra-small text-muted fw-semibold">Status Sistem AI:</span>
                        <span class="badge bg-success bg-opacity-10 text-success extra-small fw-semibold py-1 px-2 rounded-pill" id="globalServerNodeBadge">
                            <i class="fa-brands fa-node-js me-1"></i> Node.js Server: Online
                        </span>
                        <span class="badge bg-info bg-opacity-10 text-info extra-small fw-semibold py-1 px-2 rounded-pill">
                            <i class="fa-brands fa-php me-1"></i> PHP Fallback: Siap
                        </span>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <span class="extra-small text-muted">Model Aktif:</span>
                        <span class="badge bg-primary bg-opacity-10 text-primary extra-small fw-bold py-1 px-2 rounded-pill" id="globalActiveEngineBadge">
                            <i class="fa-solid fa-bolt me-1"></i> Grok AI
                        </span>
                    </div>
                </div>

                <!-- Bagian 1: Pilih Engine / Model Kecerdasan -->
                <div class="mb-4">
                    <label class="form-label text-dark small fw-bold text-uppercase d-flex align-items-center gap-2 mb-2">
                        <i class="fa-solid fa-brain text-cyan"></i> 1. Pilih Model Kecerdasan Buatan (Active Engine)
                    </label>
                    <div class="row g-3">
                        <!-- Google Gemini Card -->
                        <div class="col-6 col-lg-3">
                            <div class="global-ai-provider-card h-100 p-3 rounded-4 cursor-pointer active d-flex flex-column justify-content-between" data-global-engine="gemini" id="globalCardGemini" role="button" tabindex="0" onclick="window.selectModalEngine && window.selectModalEngine('gemini')">
                                <div>
                                    <div class="d-flex align-items-center justify-content-between mb-2">
                                        <span class="fw-bold small d-flex align-items-center gap-1.5 card-provider-name">
                                            <i class="fa-brands fa-google text-primary fs-5"></i> Gemini
                                        </span>
                                        <span class="badge bg-info bg-opacity-10 text-info extra-small fw-bold">Rekomendasi Utama</span>
                                    </div>
                                    <div class="extra-small text-muted mb-2">Model: <strong class="text-dark">Gemini 1.5 / 2.0</strong></div>
                                    <p class="text-secondary extra-small mb-0 leading-relaxed" style="font-size: 11.5px;">
                                        Multimodal reasoning Google DeepMind, penalaran kontekstual data servis.
                                    </p>
                                </div>
                                <div class="mt-3 pt-2 border-top border-light-subtle d-flex align-items-center justify-content-between">
                                    <span class="extra-small text-muted">Status:</span>
                                    <span id="cardStatusGemini"><span class="badge bg-success bg-opacity-10 text-success extra-small"><i class="fa-solid fa-check me-1"></i>Aktif Digunakan</span></span>
                                </div>
                            </div>
                        </div>

                        <!-- DeepSeek AI Card -->
                        <div class="col-6 col-lg-3">
                            <div class="global-ai-provider-card h-100 p-3 rounded-4 cursor-pointer d-flex flex-column justify-content-between" data-global-engine="deepseek" id="globalCardDeepseek" role="button" tabindex="0" onclick="window.selectModalEngine && window.selectModalEngine('deepseek')">
                                <div>
                                    <div class="d-flex align-items-center justify-content-between mb-2">
                                        <span class="fw-bold small d-flex align-items-center gap-1.5 card-provider-name">
                                            <i class="fa-solid fa-brain text-info fs-5"></i> DeepSeek
                                        </span>
                                        <span class="badge bg-info bg-opacity-10 text-cyan extra-small fw-bold">V3 / R1</span>
                                    </div>
                                    <div class="extra-small text-muted mb-2">Model: <strong class="text-dark">deepseek-chat</strong></div>
                                    <p class="text-secondary extra-small mb-0 leading-relaxed" style="font-size: 11.5px;">
                                        Penalaran komprehensif mendalam &amp; analisis teknis cerdas.
                                    </p>
                                </div>
                                <div class="mt-3 pt-2 border-top border-light-subtle d-flex align-items-center justify-content-between">
                                    <span class="extra-small text-muted">Status:</span>
                                    <span id="cardStatusDeepseek"><span class="text-muted extra-small"><i class="fa-regular fa-circle me-1"></i>Pilih</span></span>
                                </div>
                            </div>
                        </div>

                        <!-- Grok AI Card -->
                        <div class="col-6 col-lg-3">
                            <div class="global-ai-provider-card h-100 p-3 rounded-4 cursor-pointer d-flex flex-column justify-content-between" data-global-engine="grok" id="globalCardGrok" role="button" tabindex="0" onclick="window.selectModalEngine && window.selectModalEngine('grok')">
                                <div>
                                    <div class="d-flex align-items-center justify-content-between mb-2">
                                        <span class="fw-bold small d-flex align-items-center gap-1.5 card-provider-name">
                                            <i class="fa-solid fa-bolt text-warning fs-5"></i> xAI Grok
                                        </span>
                                        <span class="badge bg-secondary bg-opacity-10 text-muted extra-small fw-bold">Opsional</span>
                                    </div>
                                    <div class="extra-small text-muted mb-2">Model: <strong class="text-dark">Grok-2 / Beta</strong></div>
                                    <p class="text-secondary extra-small mb-0 leading-relaxed" style="font-size: 11.5px;">
                                        Penalaran cepat, pemahaman teknis IT akurat, dan instruksi unit bisnis TKJ.
                                    </p>
                                </div>
                                <div class="mt-3 pt-2 border-top border-light-subtle d-flex align-items-center justify-content-between">
                                    <span class="extra-small text-muted">Status:</span>
                                    <span id="cardStatusGrok"><span class="text-muted extra-small"><i class="fa-regular fa-circle me-1"></i>Pilih</span></span>
                                </div>
                            </div>
                        </div>

                        <!-- Smart DB Engine Card -->
                        <div class="col-6 col-lg-3">
                            <div class="global-ai-provider-card h-100 p-3 rounded-4 cursor-pointer d-flex flex-column justify-content-between" data-global-engine="database" id="globalCardDb" role="button" tabindex="0" onclick="window.selectModalEngine && window.selectModalEngine('database')">
                                <div>
                                    <div class="d-flex align-items-center justify-content-between mb-2">
                                        <span class="fw-bold small d-flex align-items-center gap-1.5 card-provider-name">
                                            <i class="fa-solid fa-database text-success fs-5"></i> Smart DB
                                        </span>
                                        <span class="badge bg-success bg-opacity-10 text-success extra-small fw-bold">Lokal MySQL</span>
                                    </div>
                                    <div class="extra-small text-muted mb-2">Engine: <strong class="text-dark">Local Matcher</strong></div>
                                    <p class="text-secondary extra-small mb-0 leading-relaxed" style="font-size: 11.5px;">
                                        Pencocokan intent database MySQL langsung tanpa kuota eksternal (Offline).
                                    </p>
                                </div>
                                <div class="mt-3 pt-2 border-top border-light-subtle d-flex align-items-center justify-content-between">
                                    <span class="extra-small text-muted">Status:</span>
                                    <span id="cardStatusDb"><span class="text-muted extra-small"><i class="fa-regular fa-circle me-1"></i>Pilih</span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bagian 2: Kunci API (API Keys) -->
                <div class="mb-3">
                    <label class="form-label text-dark small fw-bold text-uppercase d-flex align-items-center gap-2 mb-2">
                        <i class="fa-solid fa-key text-cyan"></i> 2. Kunci API Penyedia (API Keys Configuration)
                    </label>

                    <!-- Grok API Key Field -->
                    <div class="p-3 rounded-3 bg-white border border-light-subtle mb-3 shadow-sm global-ai-key-box">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <label class="form-label text-dark small fw-bold mb-0 d-flex align-items-center gap-2">
                                <i class="fa-solid fa-bolt text-warning"></i> Groq / xAI API Key
                            </label>
                            <span class="badge bg-secondary bg-opacity-10 text-muted extra-small fw-semibold py-1 px-2 rounded-pill"><i class="fa-solid fa-bolt me-1"></i>Opsional</span>
                        </div>
                        <div class="input-group mb-1.5">
                            <span class="input-group-text bg-light text-cyan extra-small"><i class="fa-solid fa-shield-halved"></i></span>
                            <input type="password" id="globalInputGrokKey" class="form-control bg-white text-dark font-monospace extra-small py-2" placeholder="gsk_... / xai-..." value="">
                            <button class="btn btn-light border border-start-0 btn-global-toggle-pw text-muted" type="button" data-input="globalInputGrokKey" title="Tampilkan / Sembunyikan Key">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <small class="text-muted extra-small">Opsional: Masukkan jika Anda memiliki API key Groq (gsk_...) atau xAI resmi.</small>
                            <button type="button" class="btn btn-link text-primary extra-small p-0 text-decoration-none fw-semibold" onclick="document.getElementById('globalInputGrokKey').value = '';">
                                <i class="fa-solid fa-eraser me-1"></i>Kosongkan
                            </button>
                        </div>
                    </div>

                    <!-- Gemini API Key Field -->
                    <div class="p-3 rounded-3 bg-white border border-light-subtle mb-3 shadow-sm global-ai-key-box">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <label class="form-label text-dark small fw-bold mb-0 d-flex align-items-center gap-2">
                                <i class="fa-brands fa-google text-primary"></i> Google Gemini API Key
                            </label>
                            <span class="badge bg-info bg-opacity-10 text-info extra-small fw-semibold py-1 px-2 rounded-pill"><i class="fa-solid fa-circle-info me-1"></i>Tersedia</span>
                        </div>
                        <div class="input-group mb-1.5">
                            <span class="input-group-text bg-light text-cyan extra-small"><i class="fa-solid fa-shield-halved"></i></span>
                            <input type="password" id="globalInputGeminiKey" class="form-control bg-white text-dark font-monospace extra-small py-2" placeholder="AQ.Ab8... / AIzaSy..." value="AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw">
                            <button class="btn btn-light border border-start-0 btn-global-toggle-pw text-muted" type="button" data-input="globalInputGeminiKey" title="Tampilkan / Sembunyikan Key">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <small class="text-muted extra-small">Kunci resmi Google Cloud / Google AI Studio untuk Gemini Flash.</small>
                            <button type="button" class="btn btn-link text-primary extra-small p-0 text-decoration-none fw-semibold" onclick="document.getElementById('globalInputGeminiKey').value = 'AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw';">
                                <i class="fa-solid fa-rotate-left me-1"></i>Isi Default
                            </button>
                        </div>
                    </div>

                    <!-- DeepSeek API Key Field -->
                    <div class="p-3 rounded-3 bg-white border border-light-subtle shadow-sm global-ai-key-box">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <label class="form-label text-dark small fw-bold mb-0 d-flex align-items-center gap-2">
                                <i class="fa-solid fa-brain text-info"></i> DeepSeek AI API Key
                            </label>
                            <span class="badge bg-success bg-opacity-10 text-success extra-small fw-semibold py-1 px-2 rounded-pill"><i class="fa-solid fa-circle-check me-1"></i>Tersedia</span>
                        </div>
                        <div class="input-group mb-1.5">
                            <span class="input-group-text bg-light text-cyan extra-small"><i class="fa-solid fa-shield-halved"></i></span>
                            <input type="password" id="globalInputDeepseekKey" class="form-control bg-white text-dark font-monospace extra-small py-2" placeholder="sk-..." value="sk-70e0eb2e9efe49fa967af6da72b5cda9">
                            <button class="btn btn-light border border-start-0 btn-global-toggle-pw text-muted" type="button" data-input="globalInputDeepseekKey" title="Tampilkan / Sembunyikan Key">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <small class="text-muted extra-small">Kunci resmi DeepSeek (api.deepseek.com) untuk model deepseek-chat &amp; deepseek-reasoner.</small>
                            <button type="button" class="btn btn-link text-primary extra-small p-0 text-decoration-none fw-semibold" onclick="document.getElementById('globalInputDeepseekKey').value = 'sk-70e0eb2e9efe49fa967af6da72b5cda9';">
                                <i class="fa-solid fa-rotate-left me-1"></i>Isi Default
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Toast / Alert Feedback inside modal -->
                <div id="globalSettingsToast" class="alert alert-success extra-small py-2.5 px-3 mb-0 rounded-3 shadow-sm d-none">
                    <i class="fa-solid fa-circle-check me-1.5"></i>
                    <span class="fw-semibold">Pengaturan berhasil disimpan dan langsung disinkronkan ke chatbot!</span>
                </div>

            </div>

            <!-- Modal Footer -->
            <div class="modal-footer border-top border-light-subtle p-3 bg-white d-flex align-items-center justify-content-between">
                <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3" id="globalBtnResetSettings" title="Kembalikan ke setelan bawaan">
                    <i class="fa-solid fa-arrow-rotate-left me-1"></i> Reset ke Default
                </button>
                <div class="d-flex align-items-center gap-2">
                    <button type="button" class="btn btn-light border btn-sm rounded-pill px-3" data-bs-dismiss="modal">
                        Batal
                    </button>
                    <button type="button" class="btn btn-cyan btn-sm rounded-pill px-4 fw-bold shadow-sm" id="globalBtnSaveSettings">
                        <i class="fa-solid fa-check me-1"></i> Simpan &amp; Terapkan
                    </button>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- ==========================================================================
     CHATBOT WIDGET STYLES (ULTRA VISUAL)
     ========================================================================== -->
<style>
/* ==========================================================================
   GLOBAL AI SETTINGS MODAL (CLEAN MODERN WHITE THEME - 100% CONTRAST & POLISH)
   ========================================================================== */
#globalAiSettingsModal .modal-content {
    background-color: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.15) !important;
    border-radius: 20px !important;
    color: #0f172a !important;
}
#globalAiSettingsModal .modal-header {
    background-color: #ffffff !important;
    border-bottom: 1px solid #e2e8f0 !important;
}
#globalAiSettingsModal .modal-title {
    color: #0f172a !important;
    font-weight: 700 !important;
}
#globalAiSettingsModal .modal-body {
    background-color: #f8fafc !important;
}
#globalAiSettingsModal .global-ai-provider-card {
    background-color: #ffffff !important;
    border: 1.5px solid #e2e8f0 !important;
    color: #0f172a !important;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
    transition: all 0.25s ease;
}
#globalAiSettingsModal .global-ai-provider-card:hover {
    border-color: #0891b2 !important;
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(8, 145, 178, 0.12) !important;
}
#globalAiSettingsModal .global-ai-provider-card.active {
    background: #f0fdfa !important;
    border: 2px solid #0891b2 !important;
    box-shadow: 0 4px 15px rgba(8, 145, 178, 0.18) !important;
}
#globalAiSettingsModal .global-ai-provider-card .card-provider-name {
    color: #0f172a !important;
    font-weight: 700 !important;
}
#globalAiSettingsModal .global-ai-key-box {
    background-color: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 14px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
}
#globalAiSettingsModal .global-ai-key-box label {
    color: #0f172a !important;
    font-weight: 700 !important;
}
#globalAiSettingsModal .input-group-text {
    background-color: #f8fafc !important;
    border: 1px solid #cbd5e1 !important;
    border-right: none !important;
    border-radius: 12px 0 0 12px !important;
    color: #0891b2 !important;
}
#globalAiSettingsModal .form-control {
    background-color: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    border-left: none !important;
    border-right: none !important;
    border-radius: 0 !important;
    color: #0f172a !important;
    font-size: 13px !important;
}
#globalAiSettingsModal .form-control:focus {
    border-color: #0891b2 !important;
    box-shadow: none !important;
    background-color: #ffffff !important;
}
#globalAiSettingsModal .btn-global-toggle-pw {
    background-color: #f8fafc !important;
    border: 1px solid #cbd5e1 !important;
    border-left: none !important;
    border-radius: 0 12px 12px 0 !important;
    color: #64748b !important;
}
#globalAiSettingsModal .btn-global-toggle-pw:hover {
    background-color: #e2e8f0 !important;
    color: #0891b2 !important;
}
#globalAiSettingsModal .modal-footer {
    background-color: #ffffff !important;
    border-top: 1px solid #e2e8f0 !important;
}

/* Color Accents */
.text-emerald { color: #10b981 !important; }
.text-amber { color: #f59e0b !important; }

/* ==========================================================================
   CHATBOT WIDGET - CLEAN MODERN WHITE THEME (HIGH CONTRAST & ACCENTS)
   ========================================================================== */

/* Floating Greeting Bubble */
.chatbot-greeting-bubble {
    position: fixed;
    bottom: 96px;
    right: 28px;
    z-index: 1055;
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 18px;
    padding: 12px 16px;
    max-width: 285px;
    transform: translateY(0);
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    animation: bubbleFloat 4s ease-in-out infinite;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08), 0 0 20px rgba(6, 182, 212, 0.12) !important;
}
.chatbot-greeting-bubble.hide {
    opacity: 0;
    pointer-events: none;
    transform: translateY(12px) scale(0.92);
}
@keyframes bubbleFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-6px); }
}
.bubble-close-btn {
    position: absolute;
    top: 6px;
    right: 8px;
    background: transparent;
    border: none;
    color: #94a3b8;
    font-size: 16px;
    line-height: 1;
    cursor: pointer;
    padding: 0;
    transition: color 0.2s ease;
}
.bubble-close-btn:hover {
    color: #ef4444;
}
.greeting-avatar-orb {
    position: relative;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: #ecfeff;
    border: 1.5px solid #06b6d4;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}
.greeting-ping {
    position: absolute;
    top: -2px;
    right: -2px;
    width: 8px;
    height: 8px;
    background-color: #22c55e;
    border-radius: 50%;
    box-shadow: 0 0 8px #22c55e;
}
.badge-bot-mini {
    font-size: 0.65rem;
    font-weight: 700;
    padding: 1px 6px;
    border-radius: 50rem;
    background: #ecfdf5;
    color: #059669;
    border: 1px solid #a7f3d0;
}

/* Floating Action Button (FAB) */
.chatbot-fab-btn {
    position: fixed;
    bottom: 24px;
    right: 24px;
    width: 62px;
    height: 62px;
    border-radius: 50%;
    background: linear-gradient(135deg, #06b6d4 0%, #0284c7 100%);
    border: 2px solid #ffffff;
    color: #ffffff;
    cursor: pointer;
    z-index: 1060;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    box-shadow: 0 10px 30px rgba(6, 182, 212, 0.4), 0 0 20px rgba(2, 132, 199, 0.3);
}
.chatbot-fab-btn:hover {
    transform: scale(1.08) translateY(-3px);
    box-shadow: 0 14px 35px rgba(6, 182, 212, 0.55), 0 0 30px rgba(2, 132, 199, 0.4);
}
.fab-orbit-ring {
    position: absolute;
    width: 74px;
    height: 74px;
    border-radius: 50%;
    border: 1.5px dashed rgba(6, 182, 212, 0.6);
    animation: fabOrbitRotate 12s linear infinite;
    pointer-events: none;
}
@keyframes fabOrbitRotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.fab-icon-container {
    position: relative;
    width: 26px;
    height: 26px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    color: #ffffff;
    z-index: 2;
}
.fab-icon-open, .fab-icon-close {
    position: absolute;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    color: #ffffff;
}
.fab-icon-close {
    opacity: 0;
    transform: rotate(-90deg) scale(0.5);
}
.chatbot-fab-btn.is-active .fab-icon-open {
    opacity: 0;
    transform: rotate(90deg) scale(0.5);
}
.chatbot-fab-btn.is-active .fab-icon-close {
    opacity: 1;
    transform: rotate(0) scale(1);
    color: #ffffff;
}
.chatbot-fab-btn.is-active {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    box-shadow: 0 10px 30px rgba(239, 68, 68, 0.45);
}
.chatbot-fab-btn.is-active .fab-orbit-ring {
    border-color: rgba(239, 68, 68, 0.5);
}
.fab-online-badge {
    position: absolute;
    top: 2px;
    right: 2px;
    width: 14px;
    height: 14px;
    background-color: #22c55e;
    border: 2px solid #ffffff;
    border-radius: 50%;
    box-shadow: 0 0 8px #22c55e;
    z-index: 3;
}
.fab-sparkle-dot {
    position: absolute;
    bottom: 4px;
    left: 6px;
    width: 6px;
    height: 6px;
    background: #ffffff;
    border-radius: 50%;
    opacity: 0.8;
    animation: sparklePulse 2s ease-in-out infinite;
}

/* Chatbot Pop-up Window (White Modern Light Theme) */
.chatbot-popup-modal {
    position: fixed;
    bottom: 96px;
    right: 24px;
    width: 410px;
    max-width: calc(100vw - 32px);
    height: 600px;
    max-height: calc(100vh - 120px);
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 24px;
    display: flex;
    flex-direction: column;
    z-index: 1060;
    overflow: hidden;
    box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.16), 0 0 35px rgba(6, 182, 212, 0.14) !important;
    opacity: 0;
    pointer-events: none;
    transform: translateY(28px) scale(0.94);
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}
.chatbot-popup-modal.is-open {
    opacity: 1;
    pointer-events: all;
    transform: translateY(0) scale(1);
}
.chatbot-popup-modal.is-expanded {
    width: 540px;
    height: 680px;
}

/* Header */
.chatbot-header {
    background: linear-gradient(135deg, #ffffff 0%, #f0fdfa 60%, #e0f2fe 100%) !important;
    border-bottom: 1px solid #e2e8f0 !important;
}
.header-cyber-glow {
    position: absolute;
    top: -50px;
    left: -50px;
    width: 150px;
    height: 150px;
    background: radial-gradient(circle, rgba(6, 182, 212, 0.15) 0%, transparent 70%);
    pointer-events: none;
}
.chatbot-avatar-frame {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: #ecfeff;
    border: 1.5px solid #06b6d4;
    box-shadow: 0 2px 10px rgba(6, 182, 212, 0.2);
}
.avatar-live-pulse {
    position: absolute;
    bottom: -1px;
    right: -1px;
    width: 12px;
    height: 12px;
    background-color: #22c55e;
    border: 2px solid #ffffff;
    border-radius: 50%;
    box-shadow: 0 0 6px #22c55e;
}
.badge-ai-gradient {
    font-size: 0.68rem;
    font-weight: 800;
    padding: 2px 8px;
    border-radius: 50rem;
    background: linear-gradient(135deg, #06b6d4, #0284c7);
    color: #fff !important;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px rgba(6, 182, 212, 0.3);
}

/* Audio Wave Spectrum in Header */
.ai-audio-wave {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    height: 12px;
}
.ai-audio-wave span {
    width: 2.5px;
    background-color: #0891b2;
    border-radius: 2px;
    animation: waveBar 1.2s ease-in-out infinite;
}
.ai-audio-wave span:nth-child(1) { height: 4px; animation-delay: 0s; }
.ai-audio-wave span:nth-child(2) { height: 10px; animation-delay: 0.2s; }
.ai-audio-wave span:nth-child(3) { height: 7px; animation-delay: 0.4s; }
.ai-audio-wave span:nth-child(4) { height: 11px; animation-delay: 0.1s; }

/* Control Buttons in Header */
.btn-icon-glass {
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    color: #475569 !important;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    transition: all 0.2s ease;
    padding: 0;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}
.btn-icon-glass:hover {
    background: #ecfeff !important;
    color: #0891b2 !important;
    border-color: #06b6d4 !important;
    transform: translateY(-1px);
}
.btn-close-modal:hover {
    background: #fef2f2 !important;
    color: #ef4444 !important;
    border-color: #fca5a5 !important;
}

/* Engine Switcher Bar */
.chatbot-engine-bar {
    background: #f8fafc !important;
    border-bottom: 1px solid #e2e8f0 !important;
}
.engine-toggle-group {
    background: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    border-radius: 50rem;
    padding: 2px;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.03);
}
.btn-engine-pill {
    font-size: 0.68rem;
    font-weight: 700;
    color: #64748b !important;
    padding: 2px 9px;
    border-radius: 50rem !important;
    border: none;
    background: transparent;
    transition: all 0.2s ease;
}
.btn-engine-pill:hover {
    color: #0f172a !important;
    background: #f1f5f9;
}
.btn-engine-pill.active {
    color: #0284c7 !important;
    background: #e0f2fe !important;
    box-shadow: 0 1px 4px rgba(2, 132, 199, 0.2);
}
.btn-engine-pill[data-engine="grok"].active {
    background: #fef3c7 !important;
    color: #b45309 !important;
    box-shadow: 0 1px 4px rgba(245, 158, 11, 0.25);
}
.btn-engine-pill[data-engine="gemini"].active {
    background: #e0f2fe !important;
    color: #0369a1 !important;
    box-shadow: 0 1px 4px rgba(59, 130, 246, 0.25);
}
.btn-engine-pill[data-engine="deepseek"].active {
    background: #ecfeff !important;
    color: #0e7490 !important;
    box-shadow: 0 1px 4px rgba(6, 182, 212, 0.25);
}
.btn-engine-pill[data-engine="database"].active {
    background: #dcfce7 !important;
    color: #15803d !important;
    box-shadow: 0 1px 4px rgba(16, 185, 129, 0.25);
}

/* Chat Body */
.chatbot-body {
    flex: 1;
    overflow-y: auto;
    background: #f8fafc !important;
    scroll-behavior: smooth;
}
.chatbot-body::-webkit-scrollbar {
    width: 6px;
}
.chatbot-body::-webkit-scrollbar-track {
    background: #f1f5f9;
}
.chatbot-body::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
}
.chatbot-body::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
}

/* Mini Avatar */
.chat-mini-avatar {
    width: 34px;
    height: 34px;
    font-size: 14px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
}
.chat-bubble-item {
    animation: chatMsgFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}
.chat-content-wrap {
    max-width: 86%;
}
.chat-bubble {
    border-radius: 18px;
    padding: 12px 15px;
    line-height: 1.55;
    word-break: break-word;
}

/* AI Message Bubble (White Card) */
.ai-bubble {
    background: #ffffff !important;
    border: 1px solid #e2e8f0 !important;
    border-top-left-radius: 4px;
    color: #1e293b !important;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.05) !important;
}
.ai-bubble .small,
.ai-bubble p,
.ai-bubble div {
    color: #1e293b;
}
.ai-bubble strong {
    color: #0f172a !important;
    font-weight: 700;
}
.ai-bubble code {
    background: #f1f5f9 !important;
    color: #0284c7 !important;
    border: 1px solid #e2e8f0;
}

/* User Message Bubble */
.user-bubble-pop {
    background: linear-gradient(135deg, #0284c7 0%, #06b6d4 100%) !important;
    border: none !important;
    border-top-right-radius: 4px;
    color: #ffffff !important;
    box-shadow: 0 4px 14px rgba(6, 182, 212, 0.3) !important;
}
.user-bubble-pop * {
    color: #ffffff !important;
}

/* Interactive Visual Service Cards (Inside Chat) */
.visual-service-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 9px 10px;
    cursor: pointer;
    transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    display: flex;
    flex-direction: column;
    height: 100%;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
}
.visual-service-card:hover {
    background: #f0fdfa;
    border-color: #06b6d4;
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(6, 182, 212, 0.15);
}
.vcard-title {
    font-size: 0.74rem;
    font-weight: 700;
    color: #0f172a;
    line-height: 1.25;
    margin-bottom: 4px;
}
.vcard-badge {
    font-size: 0.65rem;
    font-weight: 600;
    color: #0891b2;
    background: #ecfeff;
    padding: 1px 6px;
    border-radius: 50rem;
    border: 1px solid #a5f3fc;
    align-self: flex-start;
}

/* Visual Card in AI Response (Markdown Enhancement) */
.ai-rich-card {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    padding: 12px;
    margin: 10px 0;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
.ai-card-title {
    font-weight: 700;
    color: #0284c7;
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 6px;
}
.ai-price-pill {
    display: inline-flex;
    align-items: center;
    background: #ecfeff;
    border: 1px solid #a5f3fc;
    color: #0891b2;
    padding: 2px 8px;
    border-radius: 50rem;
    font-weight: 700;
    font-size: 0.75rem;
    margin-bottom: 6px;
}
.ai-action-btns {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-top: 10px;
}
.btn-ai-action {
    font-size: 0.72rem;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 50rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    transition: all 0.2s ease;
}
.btn-ai-action.primary {
    background: #0284c7;
    color: #ffffff !important;
}
.btn-ai-action.primary:hover {
    background: #0369a1;
    transform: translateY(-1px);
}
.btn-ai-action.secondary {
    background: #f1f5f9;
    border: 1px solid #cbd5e1;
    color: #334155 !important;
}
.btn-ai-action.secondary:hover {
    background: #e2e8f0;
    transform: translateY(-1px);
}

/* Footer & Input */
.chatbot-footer {
    background: #ffffff !important;
    border-top: 1px solid #e2e8f0 !important;
}
.input-wrapper {
    position: relative;
}
.chatbot-input {
    background-color: #f8fafc !important;
    border: 1.5px solid #cbd5e1 !important;
    border-radius: 14px !important;
    color: #0f172a !important;
    font-size: 0.86rem;
    transition: all 0.25s ease;
}
.chatbot-input:focus {
    border-color: #0891b2 !important;
    box-shadow: 0 0 0 3px rgba(8, 145, 178, 0.15) !important;
    outline: none;
    background-color: #ffffff !important;
}
.chatbot-input::placeholder {
    color: #94a3b8 !important;
}
.input-sparkle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
    font-size: 13px;
    color: #0891b2;
    opacity: 0.7;
}
.btn-send-pop {
    width: 42px;
    height: 42px;
    border-radius: 14px;
    background: linear-gradient(135deg, #06b6d4, #0284c7) !important;
    border: none;
    color: #ffffff !important;
    font-size: 15px;
    flex-shrink: 0;
    transition: all 0.25s ease;
    box-shadow: 0 4px 12px rgba(6, 182, 212, 0.35);
}
.btn-send-pop:hover {
    transform: scale(1.05) translateY(-1px);
    box-shadow: 0 6px 18px rgba(6, 182, 212, 0.5);
    color: #ffffff !important;
}
.btn-send-pop:disabled {
    opacity: 0.5;
    transform: none;
}
.chatbot-attribution {
    font-size: 0.68rem;
    color: #64748b !important;
}

/* Typing Indicator Animation with Visual Glow */
.typing-dots-pop span {
    display: inline-block;
    width: 6.5px;
    height: 6.5px;
    border-radius: 50%;
    background-color: #0891b2;
    animation: popTyping 1.3s infinite ease-in-out both;
    margin: 0 2px;
    box-shadow: 0 0 6px rgba(8, 145, 178, 0.4);
}
.typing-dots-pop span:nth-child(1) { animation-delay: -0.32s; }
.typing-dots-pop span:nth-child(2) { animation-delay: -0.16s; }
@keyframes popTyping {
    0%, 80%, 100% { transform: scale(0); }
    40% { transform: scale(1); }
}

/* Mobile Screens (< 576px) */
@media (max-width: 575.98px) {
    .chatbot-popup-modal {
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        max-width: 100%;
        height: 100%;
        max-height: 100%;
        border-radius: 0;
        border: none;
    }
    .chatbot-greeting-bubble {
        right: 16px;
        bottom: 84px;
        max-width: 240px;
    }
    .chatbot-fab-btn {
        bottom: 16px;
        right: 16px;
        width: 56px;
        height: 56px;
    }
    .fab-orbit-ring {
        width: 66px;
        height: 66px;
    }
}
</style>

<!-- ==========================================================================
     CHATBOT WIDGET CLIENT SCRIPT (AUDIO SYNTH & RICH CARD RENDERING)
     ========================================================================== -->
<script>
(function() {
    const BASE_URL = '<?= BASE_URL ?>';
    const clientName = '<?= $clientUserName ?>';
    const isUserLoggedIn = <?= $isUserLoggedIn ? 'true' : 'false' ?>;
    const userRole = '<?= $currentUser['role'] ?? 'guest' ?>';
    const userEmail = '<?= $currentUser['email'] ?? '' ?>';
    const userId = '<?= $currentUser['id'] ?? '' ?>';

    const fabBtn = document.getElementById('chatbotFabBtn');
    const popupModal = document.getElementById('chatbotPopupModal');
    const closeBtn = document.getElementById('btnClosePopupChat');
    const resetBtn = document.getElementById('btnResetPopupChat');
    const expandBtn = document.getElementById('btnExpandPopup');
    const expandIcon = document.getElementById('expandIcon');
    const soundBtn = document.getElementById('btnToggleSound');
    const soundIcon = document.getElementById('soundIcon');
    const greetingBubble = document.getElementById('chatbotGreetingBubble');
    const btnCloseGreeting = document.getElementById('btnCloseGreetingBubble');
    const btnGreetingOpen = document.getElementById('btnGreetingOpenChat');
    
    // Global AI Settings Controls (Outside Chatbot)
    const globalModalEl = document.getElementById('globalAiSettingsModal');
    const pillGrok = document.getElementById('pillGrok');
    const pillGemini = document.getElementById('pillGemini');
    const pillDeepseek = document.getElementById('pillDeepseek');
    const pillDb = document.getElementById('pillDb');
    const globalCardGrok = document.getElementById('globalCardGrok');
    const globalCardGemini = document.getElementById('globalCardGemini');
    const globalCardDeepseek = document.getElementById('globalCardDeepseek');
    const globalCardDb = document.getElementById('globalCardDb');
    const globalInputGrokKey = document.getElementById('globalInputGrokKey');
    const globalInputGeminiKey = document.getElementById('globalInputGeminiKey');
    const globalInputDeepseekKey = document.getElementById('globalInputDeepseekKey');
    const globalBtnSaveSettings = document.getElementById('globalBtnSaveSettings');
    const globalBtnResetSettings = document.getElementById('globalBtnResetSettings');
    const globalSettingsToast = document.getElementById('globalSettingsToast');
    const globalActiveEngineBadge = document.getElementById('globalActiveEngineBadge');
    const globalServerNodeBadge = document.getElementById('globalServerNodeBadge');

    const messageContainer = document.getElementById('chatbotMessageContainer');
    const inputForm = document.getElementById('chatbotInputForm');
    const inputText = document.getElementById('chatbotInputText');
    const sendBtn = document.getElementById('btnChatbotSend');

    const STORAGE_KEY = 'tkj_chatbot_history_v2';
    const NODE_API_URL = 'http://localhost:5000';
    
    // Default API Keys & Active Engine
    const DEFAULT_GROK_KEY = '';
    const DEFAULT_GEMINI_KEY = 'AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw';
    const DEFAULT_DEEPSEEK_KEY = 'sk-70e0eb2e9efe49fa967af6da72b5cda9';
    
    let currentEngine = localStorage.getItem('tkj_chat_provider') || 'gemini';
    let customGrokKey = localStorage.getItem('tkj_grok_key') || '';
    let customGeminiKey = localStorage.getItem('tkj_gemini_key') || DEFAULT_GEMINI_KEY;
    let customDeepseekKey = localStorage.getItem('tkj_deepseek_key') || DEFAULT_DEEPSEEK_KEY;

    let chatHistory = [];
    let isSoundOn = localStorage.getItem('tkj_chat_sound') !== 'muted';
    let isNodeServerActive = false;

    // Terapkan Pilihan Engine ke UI
    function setEngine(engine, showToastMsg = false) {
        currentEngine = engine;
        localStorage.setItem('tkj_chat_provider', engine);

        // Update Pill Buttons
        [pillGrok, pillGemini, pillDeepseek, pillDb].forEach(btn => {
            if (btn) btn.classList.remove('active');
        });
        if (engine === 'grok' && pillGrok) pillGrok.classList.add('active');
        if (engine === 'gemini' && pillGemini) pillGemini.classList.add('active');
        if (engine === 'deepseek' && pillDeepseek) pillDeepseek.classList.add('active');
        if (engine === 'database' && pillDb) pillDb.classList.add('active');

        // Update Cards in Global Modal
        [globalCardGrok, globalCardGemini, globalCardDeepseek, globalCardDb].forEach(card => {
            if (card) card.classList.remove('active');
        });
        if (engine === 'grok' && globalCardGrok) globalCardGrok.classList.add('active');
        if (engine === 'gemini' && globalCardGemini) globalCardGemini.classList.add('active');
        if (engine === 'deepseek' && globalCardDeepseek) globalCardDeepseek.classList.add('active');
        if (engine === 'database' && globalCardDb) globalCardDb.classList.add('active');

        if (globalActiveEngineBadge) {
            const mapBadge = {
                grok: '<i class="fa-solid fa-bolt me-1"></i> Grok AI',
                gemini: '<i class="fa-brands fa-google me-1"></i> Gemini AI',
                deepseek: '<i class="fa-solid fa-brain me-1"></i> DeepSeek AI',
                database: '<i class="fa-solid fa-database me-1"></i> Smart DB'
            };
            const mapClass = {
                grok: 'badge badge-subtle-warning extra-small fw-bold',
                gemini: 'badge badge-subtle-info extra-small fw-bold',
                deepseek: 'badge badge-subtle-cyan extra-small fw-bold',
                database: 'badge badge-subtle-success extra-small fw-bold'
            };
            globalActiveEngineBadge.className = mapClass[engine] || 'badge badge-subtle-cyan extra-small fw-bold';
            globalActiveEngineBadge.innerHTML = mapBadge[engine] || engine;
        }

        // Update Header Badge & Subtitle
        const badgeEl = document.getElementById('botBadgeRuntime');
        const subtitleEl = document.getElementById('botSubtitleRuntime');

        if (engine === 'grok') {
            if (badgeEl) {
                badgeEl.className = 'badge-ai-gradient badge-engine-dynamic grok';
                badgeEl.innerHTML = '<i class="fa-solid fa-bolt text-warning me-1"></i> Grok AI';
            }
            if (subtitleEl) {
                subtitleEl.innerHTML = '<span class="text-warning">xAI Grok</span> • Grok-2 / Grok Beta';
            }
        } else if (engine === 'gemini') {
            if (badgeEl) {
                badgeEl.className = 'badge-ai-gradient badge-engine-dynamic gemini';
                badgeEl.innerHTML = '<i class="fa-brands fa-google text-info me-1"></i> Gemini AI';
            }
            if (subtitleEl) {
                subtitleEl.innerHTML = '<span class="text-cyan">Google Gemini</span> • Flash 3.5 / 3.8';
            }
        } else if (engine === 'deepseek') {
            if (badgeEl) {
                badgeEl.className = 'badge-ai-gradient badge-engine-dynamic deepseek';
                badgeEl.innerHTML = '<i class="fa-solid fa-brain text-info me-1"></i> DeepSeek AI';
            }
            if (subtitleEl) {
                subtitleEl.innerHTML = '<span class="text-info">DeepSeek AI</span> • V3 / R1 Penalaran';
            }
        } else {
            if (badgeEl) {
                badgeEl.className = 'badge-ai-gradient badge-engine-dynamic database';
                badgeEl.innerHTML = '<i class="fa-solid fa-database text-success me-1"></i> Smart DB';
            }
            if (subtitleEl) {
                subtitleEl.innerHTML = '<span class="text-success">MySQL Database</span> • Offline & Cepat';
            }
        }

        if (showToastMsg) {
            const labels = {
                grok: 'Grok AI (xAI)',
                gemini: 'Google Gemini',
                deepseek: 'DeepSeek AI (V3/R1)',
                database: 'Smart DB Engine (Lokal)'
            };
            showSystemNotification(`⚡ Engine AI dialihkan ke <strong>${labels[engine] || engine}</strong>.`);
        }
    }

    // System Notification Bubble di Chat
    function showSystemNotification(msgText) {
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const html = `
            <div class="d-flex justify-content-center my-2">
                <div class="badge bg-white border border-light-subtle text-secondary extra-small px-3 py-1.5 rounded-pill shadow-sm">
                    ${msgText} <span class="text-muted ms-1 opacity-75">${timeStr}</span>
                </div>
            </div>
        `;
        messageContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
    }

    // Deteksi Status Server Node.js Chatbot
    async function checkNodeStatus() {
        try {
            const res = await fetch(`${NODE_API_URL}/api/status`, {
                method: 'GET',
                signal: AbortSignal.timeout(2500)
            });
            if (res.ok) {
                isNodeServerActive = true;
                if (globalServerNodeBadge) {
                    globalServerNodeBadge.className = 'badge badge-subtle-success extra-small';
                    globalServerNodeBadge.innerHTML = '<i class="fa-brands fa-node-js me-1"></i> Node.js Server: Online';
                }
                return;
            }
        } catch (e) {
            isNodeServerActive = false;
            if (globalServerNodeBadge) {
                globalServerNodeBadge.className = 'badge badge-subtle-secondary extra-small';
                globalServerNodeBadge.innerHTML = '<i class="fa-brands fa-node-js me-1"></i> Node.js Server: Offline (PHP Fallback)';
            }
        }
    }

    // Update Sound Button UI
    function updateSoundUI() {
        if (soundIcon) {
            if (isSoundOn) {
                soundIcon.className = 'fa-solid fa-volume-high text-cyan';
                soundBtn.setAttribute('title', 'Suara AI: Aktif (Klik untuk bisukan)');
            } else {
                soundIcon.className = 'fa-solid fa-volume-xmark text-white-50';
                soundBtn.setAttribute('title', 'Suara AI: Bisu (Klik untuk aktifkan)');
            }
        }
    }
    updateSoundUI();

    // Play Gentle Audio Chime using Web Audio API (No external file needed)
    function playChime(type = 'receive') {
        if (!isSoundOn) return;
        try {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            const ctx = new AudioCtx();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();

            if (type === 'receive') {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
                osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.12); // G5
                gain.gain.setValueAtTime(0.06, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start();
                osc.stop(ctx.currentTime + 0.22);
            } else {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(440, ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(554.37, ctx.currentTime + 0.08);
                gain.gain.setValueAtTime(0.04, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start();
                osc.stop(ctx.currentTime + 0.12);
            }
        } catch (e) {
            // Audio error ignored safely
        }
    }

    // Scroll to Bottom
    function scrollToBottom() {
        if (messageContainer) {
            messageContainer.scrollTop = messageContainer.scrollHeight;
        }
    }

    // Rich Markdown Parser & Visual Card Formatter
    function parseMarkdown(text) {
        if (!text) return '';
        let formatted = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-cyan text-decoration-underline fw-semibold" target="_self">$1</a>')
            .replace(/`(.*?)`/g, '<code class="bg-light px-1.5 py-0.5 rounded text-primary border">$1</code>')
            .replace(/\n/g, '<br>');

        // Enhance Service Price highlights: misal Rp 75.000 atau Rp 250.000
        formatted = formatted.replace(/(Rp\s*[\d\.]+)/g, '<span class="ai-price-pill"><i class="fa-solid fa-tag me-1"></i>$1</span>');

        return formatted;
    }

    // Load History from SessionStorage
    function loadHistory() {
        try {
            const saved = sessionStorage.getItem(STORAGE_KEY);
            if (saved) {
                chatHistory = JSON.parse(saved);
                if (Array.isArray(chatHistory) && chatHistory.length > 0) {
                    messageContainer.innerHTML = '';
                    chatHistory.forEach(item => {
                        if (item.sender === 'user') {
                            renderUserBubble(item.text, item.time, false);
                        } else {
                            renderAIBubble(item.text, item.time, false);
                        }
                    });
                    scrollToBottom();
                }
            }
        } catch (e) {
            console.warn('Chat history parsing error:', e);
        }
    }

    // Save History
    function saveHistory() {
        try {
            const trimmed = chatHistory.slice(-30);
            sessionStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
        } catch (e) {
            console.warn('Chat history save error:', e);
        }
    }

    // Render User Message Bubble
    function renderUserBubble(text, time = null, save = true) {
        const timeStr = time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const html = `
            <div class="d-flex gap-2.5 mb-3 chat-bubble-item user-msg-item justify-content-end">
                <div class="chat-content-wrap text-end">
                    <div class="chat-bubble user-bubble-pop text-start shadow-sm d-inline-block">
                        <div class="extra-small text-white-50 opacity-75 mb-1 text-end">Anda • ${timeStr}</div>
                        <div class="small mb-0 text-white">${parseMarkdown(text)}</div>
                    </div>
                </div>
                <div class="flex-shrink-0">
                    <div class="chat-mini-avatar bg-cyan text-dark rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm">
                        <i class="fa-solid fa-user"></i>
                    </div>
                </div>
            </div>
        `;
        messageContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();

        if (save) {
            chatHistory.push({ sender: 'user', text: text, time: timeStr });
            saveHistory();
            playChime('send');
        }
    }

    // Typing Indicator
    function showTyping() {
        const html = `
            <div class="d-flex gap-2.5 mb-3 chat-bubble-item ai-typing-item" id="popTypingIndicator">
                <div class="flex-shrink-0">
                    <div class="chat-mini-avatar bg-cyan-subtle text-cyan rounded-circle d-flex align-items-center justify-content-center">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                </div>
                <div class="chat-content-wrap">
                    <div class="chat-bubble ai-bubble shadow-sm">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="fw-bold text-cyan extra-small">TKJ Smart Bot</span>
                            <span class="text-muted extra-small">menganalisis...</span>
                        </div>
                        <div class="typing-dots-pop py-1">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        messageContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
    }

    function removeTyping() {
        const el = document.getElementById('popTypingIndicator');
        if (el) el.remove();
    }

    // Render AI Bubble with Rich CTAs if relevant
    function renderAIBubble(text, time = null, save = true) {
        removeTyping();
        const timeStr = time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        // Add smart quick actions depending on answer context
        let actionButtons = '';
        const lower = text.toLowerCase();
        if (lower.includes('login') || lower.includes('status pesanan')) {
            if (!isUserLoggedIn) {
                actionButtons = `
                    <div class="ai-action-btns">
                        <a href="${BASE_URL}/login" class="btn-ai-action primary">
                            <i class="fa-solid fa-right-to-bracket"></i> Halaman Login
                        </a>
                    </div>
                `;
            } else if (userRole === 'admin') {
                actionButtons = `
                    <div class="ai-action-btns">
                        <a href="${BASE_URL}/admin/dashboard" class="btn-ai-action primary">
                            <i class="fa-solid fa-gauge-high"></i> Dashboard Admin
                        </a>
                    </div>
                `;
            } else if (userRole === 'teknisi') {
                actionButtons = `
                    <div class="ai-action-btns">
                        <a href="${BASE_URL}/teknisi/dashboard" class="btn-ai-action primary">
                            <i class="fa-solid fa-wrench"></i> Dashboard Teknisi
                        </a>
                    </div>
                `;
            } else {
                actionButtons = `
                    <div class="ai-action-btns">
                        <a href="${BASE_URL}/customer/dashboard" class="btn-ai-action primary">
                            <i class="fa-solid fa-user"></i> Dashboard
                        </a>
                        <a href="${BASE_URL}/customer/pesanan" class="btn-ai-action secondary">
                            <i class="fa-solid fa-box-archive"></i> Pesanan Saya
                        </a>
                    </div>
                `;
            }
        }

        const html = `
            <div class="d-flex gap-2.5 mb-3 chat-bubble-item ai-msg-item">
                <div class="flex-shrink-0">
                    <div class="chat-mini-avatar bg-cyan-subtle text-cyan rounded-circle d-flex align-items-center justify-content-center">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                </div>
                <div class="chat-content-wrap">
                    <div class="chat-bubble ai-bubble shadow-sm">
                        <div class="d-flex align-items-center justify-content-between mb-1">
                            <span class="fw-bold text-cyan extra-small d-flex align-items-center">
                                <i class="fa-solid fa-robot me-1.5"></i> TKJ Smart Bot
                            </span>
                            <span class="extra-small text-muted chat-timestamp">${timeStr}</span>
                        </div>
                        <div class="small text-dark mb-0 leading-relaxed">${parseMarkdown(text)}</div>
                        ${actionButtons}
                    </div>
                </div>
            </div>
        `;
        messageContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();

        if (save) {
            chatHistory.push({ sender: 'ai', text: text, time: timeStr });
            saveHistory();
            playChime('receive');
        }
    }

    // Send Message AJAX Handler - Prioritaskan Server Node.js
    async function sendMessage(text) {
        const query = (text || '').trim();
        if (!query) return;

        renderUserBubble(query);
        inputText.value = '';
        inputText.disabled = true;
        sendBtn.disabled = true;

        showTyping();

        let isDelivered = false;

        const userPayload = {
            isLoggedIn: isUserLoggedIn,
            id: userId,
            nama: clientName,
            email: userEmail,
            role: userRole
        };

        const activeApiKey = currentEngine === 'grok' 
            ? (customGrokKey || DEFAULT_GROK_KEY) 
            : (currentEngine === 'gemini' 
                ? (customGeminiKey || DEFAULT_GEMINI_KEY) 
                : (currentEngine === 'deepseek' ? (customDeepseekKey || DEFAULT_DEEPSEEK_KEY) : ''));

        // 1. Coba hubungi Node.js Server langsung (Port 5000)
        try {
            const nodeRes = await fetch(`${NODE_API_URL}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: query,
                    user: userPayload,
                    provider: currentEngine,
                    apiKey: activeApiKey
                }),
                signal: AbortSignal.timeout(16000)
            });

            if (nodeRes.ok) {
                const nodeData = await nodeRes.json();
                if (nodeData.status === 'success' && nodeData.response) {
                    renderAIBubble(nodeData.response, nodeData.timestamp);
                    isDelivered = true;
                    checkNodeStatus(); // Refresh status indicator
                }
            }
        } catch (nodeErr) {
            console.warn('[Chatbot Widget] Node.js server tidak merespons, mencoba fallback PHP...', nodeErr.message);
        }

        // 2. Jika Node.js offline/gagal, fallback ke endpoint PHP /ai/chat
        if (!isDelivered) {
            try {
                const phpRes = await fetch(`${BASE_URL}/ai/chat`, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        message: query,
                        user: userPayload,
                        provider: currentEngine,
                        apiKey: activeApiKey
                    })
                });

                const phpData = await phpRes.json();
                if (phpData.status === 'success') {
                    renderAIBubble(phpData.response, phpData.timestamp);
                    isDelivered = true;
                } else {
                    renderAIBubble('Mohon maaf, terjadi kendala: ' + (phpData.message || 'Terjadi kesalahan sistem.'));
                    isDelivered = true;
                }
            } catch (phpErr) {
                console.error('[Chatbot Widget] PHP Endpoint Error:', phpErr);
            }
        }

        if (!isDelivered) {
            renderAIBubble('Mohon maaf, koneksi ke server AI terputus. Pastikan server Node.js aktif (`node server.js`).');
        }

        inputText.disabled = false;
        sendBtn.disabled = false;
        inputText.focus();
    }

    // Toggle Chatbot Popup
    function togglePopup() {
        const isOpen = popupModal.classList.contains('is-open');
        if (isOpen) {
            closePopup();
        } else {
            openPopup();
        }
    }

    function openPopup(initialQuery = null) {
        popupModal.classList.add('is-open');
        fabBtn.classList.add('is-active');
        popupModal.setAttribute('aria-hidden', 'false');
        
        // Hide greeting bubble
        if (greetingBubble) {
            greetingBubble.classList.add('hide');
        }

        scrollToBottom();
        setTimeout(() => {
            inputText.focus();
        }, 300);

        if (initialQuery) {
            sendMessage(initialQuery);
        }
    }

    function closePopup() {
        popupModal.classList.remove('is-open');
        fabBtn.classList.remove('is-active');
        popupModal.setAttribute('aria-hidden', 'true');
    }

    // Expand / Shrink Size
    function toggleExpand() {
        popupModal.classList.toggle('is-expanded');
        const isExp = popupModal.classList.contains('is-expanded');
        if (expandIcon) {
            expandIcon.className = isExp ? 'fa-solid fa-down-left-and-up-right-to-center' : 'fa-solid fa-up-right-and-down-left-from-center';
        }
    }

    // Toggle Sound
    function toggleSound() {
        isSoundOn = !isSoundOn;
        localStorage.setItem('tkj_chat_sound', isSoundOn ? 'active' : 'muted');
        updateSoundUI();
        if (isSoundOn) {
            playChime('receive');
        }
    }

    // Reset Chatbot
    function resetChat() {
        if (confirm('Mulai percakapan baru dengan TKJ Smart Bot?')) {
            sessionStorage.removeItem(STORAGE_KEY);
            chatHistory = [];
            messageContainer.innerHTML = '';
            scrollToBottom();
            inputText.focus();
        }
    }

    // Expose Global APIs
    window.toggleChatbotPopup = togglePopup;
    window.openChatbotPopup = openPopup;
    window.closeChatbotPopup = closePopup;
    window.sendChatbotQuery = function(q) {
        if (!popupModal.classList.contains('is-open')) {
            openPopup();
        }
        sendMessage(q);
    };

    // Event Listeners
    if (fabBtn) fabBtn.addEventListener('click', togglePopup);
    if (closeBtn) closeBtn.addEventListener('click', closePopup);
    if (resetBtn) resetBtn.addEventListener('click', resetChat);
    if (expandBtn) expandBtn.addEventListener('click', toggleExpand);
    if (soundBtn) soundBtn.addEventListener('click', toggleSound);

    // Engine Switcher Pill Listeners
    if (pillGrok) pillGrok.addEventListener('click', () => setEngine('grok', true));
    if (pillGemini) pillGemini.addEventListener('click', () => setEngine('gemini', true));
    if (pillDeepseek) pillDeepseek.addEventListener('click', () => setEngine('deepseek', true));
    if (pillDb) pillDb.addEventListener('click', () => setEngine('database', true));

    // Global Modal Sync & Setup
    let selectedModalEngine = currentEngine;

    function highlightModalCards(eng) {
        [globalCardGrok, globalCardGemini, globalCardDeepseek, globalCardDb].forEach(c => c && c.classList.remove('active'));
        if (eng === 'grok' && globalCardGrok) globalCardGrok.classList.add('active');
        if (eng === 'gemini' && globalCardGemini) globalCardGemini.classList.add('active');
        if (eng === 'deepseek' && globalCardDeepseek) globalCardDeepseek.classList.add('active');
        if (eng === 'database' && globalCardDb) globalCardDb.classList.add('active');

        const statusGrok = document.getElementById('cardStatusGrok');
        const statusGemini = document.getElementById('cardStatusGemini');
        const statusDeepseek = document.getElementById('cardStatusDeepseek');
        const statusDb = document.getElementById('cardStatusDb');

        if (statusGrok) statusGrok.innerHTML = eng === 'grok' 
            ? '<span class="badge badge-subtle-cyan"><i class="fa-solid fa-check me-1"></i>Aktif Digunakan</span>' 
            : '<span class="text-muted extra-small"><i class="fa-regular fa-circle me-1"></i>Klik untuk Memilih</span>';
        if (statusGemini) statusGemini.innerHTML = eng === 'gemini' 
            ? '<span class="badge badge-subtle-cyan"><i class="fa-solid fa-check me-1"></i>Aktif Digunakan</span>' 
            : '<span class="text-muted extra-small"><i class="fa-regular fa-circle me-1"></i>Klik untuk Memilih</span>';
        if (statusDeepseek) statusDeepseek.innerHTML = eng === 'deepseek' 
            ? '<span class="badge badge-subtle-cyan"><i class="fa-solid fa-check me-1"></i>Aktif Digunakan</span>' 
            : '<span class="text-muted extra-small"><i class="fa-regular fa-circle me-1"></i>Klik untuk Memilih</span>';
        if (statusDb) statusDb.innerHTML = eng === 'database' 
            ? '<span class="badge badge-subtle-cyan"><i class="fa-solid fa-check me-1"></i>Aktif Digunakan</span>' 
            : '<span class="text-muted extra-small"><i class="fa-regular fa-circle me-1"></i>Klik untuk Memilih</span>';
    }

    function selectModalEngine(eng) {
        selectedModalEngine = eng;
        setEngine(eng, true);
        highlightModalCards(eng);
    }
    window.selectModalEngine = selectModalEngine;

    if (globalModalEl) {
        globalModalEl.addEventListener('show.bs.modal', function() {
            if (globalInputGrokKey) globalInputGrokKey.value = customGrokKey;
            if (globalInputGeminiKey) globalInputGeminiKey.value = customGeminiKey;
            if (globalInputDeepseekKey) globalInputDeepseekKey.value = customDeepseekKey;
            selectedModalEngine = currentEngine;
            highlightModalCards(currentEngine);
            checkNodeStatus();
        });
    }

    // Modal Provider Card Click Selection
    if (globalCardGrok) {
        globalCardGrok.addEventListener('click', () => selectModalEngine('grok'));
        globalCardGrok.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') selectModalEngine('grok'); });
    }
    if (globalCardGemini) {
        globalCardGemini.addEventListener('click', () => selectModalEngine('gemini'));
        globalCardGemini.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') selectModalEngine('gemini'); });
    }
    if (globalCardDeepseek) {
        globalCardDeepseek.addEventListener('click', () => selectModalEngine('deepseek'));
        globalCardDeepseek.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') selectModalEngine('deepseek'); });
    }
    if (globalCardDb) {
        globalCardDb.addEventListener('click', () => selectModalEngine('database'));
        globalCardDb.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') selectModalEngine('database'); });
    }

    // Toggle Password Visibility in Global Modal
    document.querySelectorAll('.btn-global-toggle-pw').forEach(btn => {
        btn.addEventListener('click', function() {
            const targetId = this.getAttribute('data-input');
            const targetInput = document.getElementById(targetId);
            if (targetInput) {
                const isPw = targetInput.type === 'password';
                targetInput.type = isPw ? 'text' : 'password';
                this.innerHTML = isPw ? '<i class="fa-solid fa-eye-slash text-cyan"></i>' : '<i class="fa-solid fa-eye"></i>';
            }
        });
    });

    // Save Settings from Global Modal
    if (globalBtnSaveSettings) {
        globalBtnSaveSettings.addEventListener('click', () => {
            if (globalInputGrokKey) {
                customGrokKey = globalInputGrokKey.value.trim() || DEFAULT_GROK_KEY;
                localStorage.setItem('tkj_grok_key', customGrokKey);
            }
            if (globalInputGeminiKey) {
                customGeminiKey = globalInputGeminiKey.value.trim() || DEFAULT_GEMINI_KEY;
                localStorage.setItem('tkj_gemini_key', customGeminiKey);
            }
            if (globalInputDeepseekKey) {
                customDeepseekKey = globalInputDeepseekKey.value.trim() || DEFAULT_DEEPSEEK_KEY;
                localStorage.setItem('tkj_deepseek_key', customDeepseekKey);
            }
            setEngine(selectedModalEngine || currentEngine, false);

            // Broadcast change to other pages
            window.dispatchEvent(new CustomEvent('tkj-ai-settings-changed', {
                detail: {
                    provider: currentEngine,
                    grokKey: customGrokKey,
                    geminiKey: customGeminiKey,
                    deepseekKey: customDeepseekKey
                }
            }));

            if (globalSettingsToast) {
                globalSettingsToast.classList.remove('d-none');
                setTimeout(() => {
                    globalSettingsToast.classList.add('d-none');
                    const modalInst = bootstrap.Modal.getInstance(globalModalEl);
                    if (modalInst) modalInst.hide();
                }, 900);
            } else {
                const modalInst = bootstrap.Modal.getInstance(globalModalEl);
                if (modalInst) modalInst.hide();
            }

            showSystemNotification(`✅ Pengaturan model AI <strong>${currentEngine.toUpperCase()}</strong> &amp; API Key berhasil diterapkan.`);
        });
    }

    // Reset Settings in Global Modal
    if (globalBtnResetSettings) {
        globalBtnResetSettings.addEventListener('click', () => {
            if (confirm('Kembalikan konfigurasi API Key & Model AI ke default sistem?')) {
                customGrokKey = DEFAULT_GROK_KEY;
                customGeminiKey = DEFAULT_GEMINI_KEY;
                customDeepseekKey = DEFAULT_DEEPSEEK_KEY;
                localStorage.removeItem('tkj_grok_key');
                localStorage.removeItem('tkj_gemini_key');
                localStorage.removeItem('tkj_deepseek_key');
                if (globalInputGrokKey) globalInputGrokKey.value = DEFAULT_GROK_KEY;
                if (globalInputGeminiKey) globalInputGeminiKey.value = DEFAULT_GEMINI_KEY;
                if (globalInputDeepseekKey) globalInputDeepseekKey.value = DEFAULT_DEEPSEEK_KEY;
                selectedModalEngine = 'grok';
                highlightModalCards('grok');
                setEngine('grok', true);
            }
        });
    }

    if (btnCloseGreeting) {
        btnCloseGreeting.addEventListener('click', (e) => {
            e.stopPropagation();
            greetingBubble.classList.add('hide');
        });
    }
    if (btnGreetingOpen) {
        btnGreetingOpen.addEventListener('click', () => {
            openPopup();
        });
    }

    // Form Submit
    if (inputForm) {
        inputForm.addEventListener('submit', (e) => {
            e.preventDefault();
            sendMessage(inputText.value);
        });
    }

    // Auto-hide greeting bubble after 12 seconds
    setTimeout(() => {
        if (greetingBubble && !popupModal.classList.contains('is-open')) {
            greetingBubble.classList.add('hide');
        }
    }, 12000);

    // Initial Engine Setup & Status Check
    setEngine(currentEngine, false);
    loadHistory();
    checkNodeStatus();
    setInterval(checkNodeStatus, 15000);

})();
</script>

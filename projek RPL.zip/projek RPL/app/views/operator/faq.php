<section class="py-5">
    <div class="container">
        
        <!-- Flash Alert Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('op_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php $flashError = AuthHelper::getFlash('op_error'); ?>
        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= htmlspecialchars($flashError['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header Halaman Operator FAQ -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">PANGKALAN DATA FAQ</span>
                <h2 class="fw-bold text-white mb-0 d-flex align-items-center gap-2">
                    <i class="fa-solid fa-circle-question text-cyan"></i> Kelola FAQ AI Assistant
                </h2>
                <small class="text-white-50">Kelola daftar pertanyaan dan jawaban umum yang digunakan AI Assistant untuk melayani customer.</small>
            </div>
            <button type="button" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow" data-bs-toggle="modal" data-bs-target="#modalTambahFaq">
                <i class="fa-solid fa-plus me-1"></i> Tambah FAQ Baru
            </button>
        </div>

        <!-- Tabel Pengelolaan FAQ -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 shadow-lg">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th style="width: 5%;">ID</th>
                            <th style="width: 30%;">Pertanyaan</th>
                            <th style="width: 40%;">Jawaban AI Assistant</th>
                            <th style="width: 10%;">Status</th>
                            <th style="width: 15%;" class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($faqs)): ?>
                            <?php foreach ($faqs as $faq): ?>
                                <tr>
                                    <td>#<?= $faq['id'] ?></td>
                                    <td>
                                        <strong class="text-white d-block leading-snug"><?= htmlspecialchars($faq['pertanyaan']) ?></strong>
                                    </td>
                                    <td class="text-white-50">
                                        <div class="leading-relaxed" style="max-height: 80px; overflow-y: auto;">
                                            <?= nl2br(htmlspecialchars($faq['jawaban'])) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (($faq['status'] ?? 'aktif') === 'aktif'): ?>
                                            <span class="badge bg-success bg-opacity-75 text-white px-2 py-1 rounded-pill">
                                                <i class="fa-solid fa-check-circle me-1"></i> Aktif
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary bg-opacity-75 text-white px-2 py-1 rounded-pill">
                                                <i class="fa-solid fa-eye-slash me-1"></i> Nonaktif
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <!-- Form Toggle Status -->
                                        <form action="<?= BASE_URL ?>/operator/faq/toggle/<?= $faq['id'] ?>" method="POST" class="d-inline">
                                            <?= SecurityHelper::csrfField() ?>
                                            <?php if (($faq['status'] ?? 'aktif') === 'aktif'): ?>
                                                <button type="submit" class="btn btn-outline-warning btn-sm py-1 px-2 me-1" title="Nonaktifkan FAQ">
                                                    <i class="fa-solid fa-toggle-on"></i> Matikan
                                                </button>
                                            <?php else: ?>
                                                <button type="submit" class="btn btn-outline-success btn-sm py-1 px-2 me-1" title="Aktifkan FAQ">
                                                    <i class="fa-solid fa-toggle-off"></i> Aktifkan
                                                </button>
                                            <?php endif; ?>
                                        </form>

                                        <!-- Button Edit Modal -->
                                        <button type="button" class="btn btn-outline-cyan btn-sm py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#modalEditFaq<?= $faq['id'] ?>" title="Edit FAQ">
                                            <i class="fa-solid fa-pen-to-square"></i> Edit
                                        </button>

                                        <!-- Form Hapus FAQ -->
                                        <form action="<?= BASE_URL ?>/operator/faq/delete/<?= $faq['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus FAQ ini?')">
                                            <?= SecurityHelper::csrfField() ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2" title="Hapus FAQ">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Modal Edit FAQ -->
                                <div class="modal fade" id="modalEditFaq<?= $faq['id'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content bg-dark-card border-secondary text-white">
                                            <div class="modal-header border-secondary">
                                                <h5 class="modal-title fw-bold text-white mb-0">
                                                    <i class="fa-solid fa-pen-to-square text-cyan me-2"></i> Edit FAQ #<?= $faq['id'] ?>
                                                </h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="<?= BASE_URL ?>/operator/faq/edit/<?= $faq['id'] ?>" method="POST">
                                                <?= SecurityHelper::csrfField() ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label text-cyan fw-bold">Pertanyaan Customer</label>
                                                        <input type="text" name="pertanyaan" class="form-control bg-dark text-white border-secondary" value="<?= htmlspecialchars($faq['pertanyaan']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label text-cyan fw-bold">Jawaban AI Assistant</label>
                                                        <textarea name="jawaban" class="form-control bg-dark text-white border-secondary" rows="4" required><?= htmlspecialchars($faq['jawaban']) ?></textarea>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label text-cyan fw-bold">Status FAQ</label>
                                                        <select name="status" class="form-select bg-dark text-white border-secondary">
                                                            <option value="aktif" <?= ($faq['status'] ?? 'aktif') === 'aktif' ? 'selected' : '' ?>>Aktif (Digunakan AI Assistant)</option>
                                                            <option value="nonaktif" <?= ($faq['status'] ?? 'aktif') === 'nonaktif' ? 'selected' : '' ?>>Nonaktif (Tidak Digunakan AI)</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer border-secondary">
                                                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm px-4 fw-bold">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-white-50 py-4">Belum ada data FAQ yang tersimpan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<!-- Modal Tambah FAQ Baru -->
<div class="modal fade" id="modalTambahFaq" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-dark-card border-secondary text-white">
            <div class="modal-header border-secondary">
                <h5 class="modal-title fw-bold text-white mb-0">
                    <i class="fa-solid fa-plus-circle text-cyan me-2"></i> Tambah FAQ Baru
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= BASE_URL ?>/operator/faq/create" method="POST">
                <?= SecurityHelper::csrfField() ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label text-cyan fw-bold">Pertanyaan Customer</label>
                        <input type="text" name="pertanyaan" class="form-control bg-dark text-white border-secondary" placeholder="Contoh: Bagaimana cara memesan jasa?" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-cyan fw-bold">Jawaban AI Assistant</label>
                        <textarea name="jawaban" class="form-control bg-dark text-white border-secondary" rows="4" placeholder="Contoh: Silakan login sebagai customer, pilih layanan, kemudian isi formulir pemesanan." required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-cyan fw-bold">Status FAQ</label>
                        <select name="status" class="form-select bg-dark text-white border-secondary">
                            <option value="aktif" selected>Aktif (Digunakan AI Assistant)</option>
                            <option value="nonaktif">Nonaktif (Tidak Digunakan AI)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm px-4 fw-bold">Tambah FAQ</button>
                </div>
            </form>
        </div>
    </div>
</div>

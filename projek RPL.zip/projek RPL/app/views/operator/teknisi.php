<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('op_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">MANAJEMEN SDM TEFA</span>
                <h2 class="fw-bold text-white mb-0">Kelola Data Teknisi Siswa TKJ</h2>
            </div>
            <button type="button" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow" data-bs-toggle="modal" data-bs-target="#modalTambahTeknisi">
                <i class="fa-solid fa-user-plus me-1"></i> Tambah Teknisi Siswa
            </button>
        </div>

        <!-- Table Teknisi -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>ID</th>
                            <th>Nama Teknisi Siswa</th>
                            <th>Email</th>
                            <th>Role & Kelas</th>
                            <th>Tanggal Registrasi</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($teknisiList)): ?>
                            <?php foreach ($teknisiList as $t): ?>
                                <tr>
                                    <td>#<?= $t['id'] ?></td>
                                    <td><strong class="text-white"><?= htmlspecialchars($t['nama']) ?></strong></td>
                                    <td><?= htmlspecialchars($t['email']) ?></td>
                                    <td><span class="badge bg-info text-dark">Teknisi Siswa TKJ</span></td>
                                    <td><?= date('d M Y', strtotime($t['created_at'] ?? 'now')) ?></td>
                                    <td class="text-end">
                                        <button class="btn btn-outline-cyan btn-sm py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#modalEditTeknisi<?= $t['id'] ?>">
                                            <i class="fa-solid fa-pen-to-square"></i> Edit
                                        </button>
                                        <form action="<?= BASE_URL ?>/operator/teknisi/delete/<?= $t['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data teknisi ini?')">
                                            <?= SecurityHelper::csrfField() ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2">
                                                <i class="fa-solid fa-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Modal Edit Teknisi -->
                                <div class="modal fade" id="modalEditTeknisi<?= $t['id'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content bg-dark-card border-secondary text-white">
                                            <div class="modal-header border-secondary">
                                                <h5 class="modal-header-title fw-bold text-white mb-0">Edit Data Teknisi Siswa</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="<?= BASE_URL ?>/operator/teknisi/edit/<?= $t['id'] ?>" method="POST">
                                                <?= SecurityHelper::csrfField() ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label text-white small fw-semibold">Nama Lengkap Siswa</label>
                                                        <input type="text" class="form-control bg-dark border-secondary text-white" name="nama" value="<?= htmlspecialchars($t['nama']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label text-white small fw-semibold">Alamat Email Sekolah</label>
                                                        <input type="email" class="form-control bg-dark border-secondary text-white" name="email" value="<?= htmlspecialchars($t['email']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label text-white small fw-semibold">Password Baru (Kosongkan jika tidak diubah)</label>
                                                        <input type="password" class="form-control bg-dark border-secondary text-white" name="password" placeholder="••••••••">
                                                    </div>
                                                </div>
                                                <div class="modal-footer border-secondary">
                                                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm fw-bold">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-white-50 py-3">Belum ada data teknisi siswa terdaftar.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<!-- Modal Tambah Teknisi Baru -->
<div class="modal fade" id="modalTambahTeknisi" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark-card border-secondary text-white">
            <div class="modal-header border-secondary">
                <h5 class="modal-header-title fw-bold text-white mb-0">Tambah Teknisi Siswa TKJ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= BASE_URL ?>/operator/teknisi/create" method="POST">
                <?= SecurityHelper::csrfField() ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label text-white small fw-semibold">Nama Lengkap Siswa & Kelas</label>
                        <input type="text" class="form-control bg-dark border-secondary text-white" name="nama" placeholder="Contoh: Ahmad Dani (XI TKJ 1)" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-white small fw-semibold">Alamat Email Sekolah</label>
                        <input type="email" class="form-control bg-dark border-secondary text-white" name="email" placeholder="ahmad.teknisi@tkj.sch.id" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-white small fw-semibold">Password Default</label>
                        <input type="password" class="form-control bg-dark border-secondary text-white" name="password" placeholder="password123" value="password123" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm fw-bold">Tambah Teknisi</button>
                </div>
            </form>
        </div>
    </div>
</div>

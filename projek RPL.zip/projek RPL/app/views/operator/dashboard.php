<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('op_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Banner Operator -->
        <div class="p-4 p-md-5 rounded-4 glass-card border border-cyan border-opacity-25 mb-4 position-relative overflow-hidden">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <span class="badge bg-warning text-dark fw-bold rounded-pill px-3 py-1 mb-2">
                        <i class="fa-solid fa-sliders me-1"></i> Control Panel Operator TEFA
                    </span>
                    <h2 class="fw-bold text-white mb-2">
                        Dashboard Operator, <span class="text-cyan"><?= htmlspecialchars($user['nama']) ?></span>!
                    </h2>
                    <p class="text-white-50 mb-3">
                        Pusat pengelolaan sistem unit bisnis TKJ Smart Service: kelola data customer, teknisi siswa, katalog jasa, plotting pesanan, pembayaran, dan laporan.
                    </p>
                </div>
                <div class="col-lg-4 text-center text-lg-end mt-4 mt-lg-0">
                    <i class="fa-solid fa-gauge-high display-1 text-cyan opacity-50"></i>
                </div>
            </div>
        </div>

        <!-- Metric Widgets -->
        <div class="row g-4 mb-4">
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Customer</div>
                    <div class="fs-2 fw-extrabold text-white"><?= $countCustomers ?></div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Teknisi Siswa</div>
                    <div class="fs-2 fw-extrabold text-cyan"><?= $countTeknisi ?></div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Pesanan</div>
                    <div class="fs-2 fw-extrabold text-warning"><?= $countOrders ?></div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Omset</div>
                    <div class="fs-2 fw-extrabold text-success">Rp <?= number_format($summary['total_revenue'] ?? 2000000, 0, ',', '.') ?></div>
                </div>
            </div>
        </div>

        <!-- Shortcut Modules Navigation -->
        <h5 class="fw-bold text-white mb-3"><i class="fa-solid fa-cubes text-cyan me-2"></i> Modul Pengelolaan Operator</h5>
        <div class="row g-3 mb-4">
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/customer" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-users fs-5"></i> Kelola Customer
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/teknisi" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-user-gear fs-5"></i> Kelola Teknisi
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/jasa" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-screwdriver-wrench fs-5"></i> Kelola Jasa
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/pesanan" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-list-check fs-5"></i> Kelola Pesanan
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/pembayaran" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-wallet fs-5"></i> Pembayaran
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/review" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-star fs-5"></i> Review
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/faq" class="btn btn-warning text-dark w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-circle-question fs-5"></i> Kelola FAQ AI
                </a>
            </div>
            <div class="col-md-3 col-6">
                <a href="<?= BASE_URL ?>/operator/laporan" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-chart-pie fs-5"></i> Laporan
                </a>
            </div>
        </div>


        <!-- Tabel Pesanan Terbaru Operator -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <h5 class="fw-bold text-white mb-0">
                    <i class="fa-solid fa-clock-rotate-left text-cyan me-2"></i> Pesanan Masuk Terbaru
                </h5>
                <a href="<?= BASE_URL ?>/operator/pesanan" class="btn btn-outline-cyan btn-sm rounded-pill extra-small fw-bold">
                    Kelola Semua Pesanan
                </a>
            </div>

            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>Kode</th>
                            <th>Customer</th>
                            <th>Jasa</th>
                            <th>Tgl Pemesanan</th>
                            <th>Teknisi Siswa</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recentOrders)): ?>
                            <?php foreach ($recentOrders as $ord): ?>
                                <tr>
                                    <td><strong class="text-white"><?= htmlspecialchars($ord['kode_pesanan']) ?></strong></td>
                                    <td><?= htmlspecialchars($ord['nama_customer'] ?? 'Customer') ?></td>
                                    <td><?= htmlspecialchars($ord['nama_jasa']) ?></td>
                                    <td><?= date('d M Y', strtotime($ord['tanggal_pemesanan'])) ?></td>
                                    <td>
                                        <?= !empty($ord['nama_teknisi']) ? htmlspecialchars($ord['nama_teknisi']) : '<span class="text-danger fw-bold">Belum Ada</span>' ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-info text-dark"><?= strtoupper(htmlspecialchars($ord['status'])) ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

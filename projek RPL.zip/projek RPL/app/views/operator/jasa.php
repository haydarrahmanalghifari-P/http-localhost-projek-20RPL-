<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('op_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">KATALOG KATALOG</span>
                <h2 class="fw-bold text-white mb-0">Kelola Layanan Jasa IT</h2>
            </div>
            <button type="button" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow" data-bs-toggle="modal" data-bs-target="#modalTambahJasa">
                <i class="fa-solid fa-plus me-1"></i> Tambah Layanan Jasa Baru
            </button>
        </div>

        <!-- Table Jasa -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>ID</th>
                            <th>Nama Jasa</th>
                            <th>Deskripsi Ringkas</th>
                            <th>Harga Mulai</th>
                            <th>Estimasi Pengerjaan</th>
                            <th>Status</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($services)): ?>
                            <?php foreach ($services as $s): ?>
                                <tr>
                                    <td>#<?= $s['id'] ?></td>
                                    <td><strong class="text-white"><?= htmlspecialchars($s['title']) ?></strong></td>
                                    <td><?= htmlspecialchars(substr($s['description'], 0, 45)) ?>...</td>
                                    <td><span class="text-cyan fw-bold"><?= htmlspecialchars($s['price']) ?></span></td>
                                    <td>1 Hari</td>
                                    <td>
                                        <span class="badge bg-success">Aktif</span>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-outline-cyan btn-sm py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#modalEditJasa<?= $s['id'] ?>">
                                            <i class="fa-solid fa-pen-to-square"></i> Edit
                                        </button>
                                        <form action="<?= BASE_URL ?>/operator/jasa/delete/<?= $s['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus layanan jasa ini?')">
                                            <?= SecurityHelper::csrfField() ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2">
                                                <i class="fa-solid fa-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Modal Edit Jasa -->
                                <div class="modal fade" id="modalEditJasa<?= $s['id'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content bg-dark-card border-secondary text-white">
                                            <div class="modal-header border-secondary">
                                                <h5 class="modal-header-title fw-bold text-white mb-0">Edit Layanan Jasa</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="<?= BASE_URL ?>/operator/jasa/edit/<?= $s['id'] ?>" method="POST">
                                                <?= SecurityHelper::csrfField() ?>
                                                <div class="modal-body">
                                                    <div class="row g-3 mb-3">
                                                        <div class="col-md-6">
                                                            <label class="form-label text-white small fw-semibold">Nama Jasa</label>
                                                            <input type="text" class="form-control bg-dark border-secondary text-white" name="nama_jasa" value="<?= htmlspecialchars($s['title']) ?>" required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label text-white small fw-semibold">Harga Mulai (Rp)</label>
                                                            <input type="number" class="form-control bg-dark border-secondary text-white" name="harga_mulai" value="150000" required>
                                                        </div>
                                                    </div>
                                                    <div class="row g-3 mb-3">
                                                        <div class="col-md-6">
                                                            <label class="form-label text-white small fw-semibold">Estimasi Pengerjaan</label>
                                                            <input type="text" class="form-control bg-dark border-secondary text-white" name="estimasi_pengerjaan" value="1 Hari" required>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label text-white small fw-semibold">Status Layanan</label>
                                                            <select class="form-select bg-dark border-secondary text-white" name="status">
                                                                <option value="aktif" selected>Aktif</option>
                                                                <option value="nonaktif">Nonaktif</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label text-white small fw-semibold">Deskripsi Layanan</label>
                                                        <textarea class="form-control bg-dark border-secondary text-white" name="deskripsi" rows="3" required><?= htmlspecialchars($s['description']) ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer border-secondary">
                                                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm fw-bold">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<!-- Modal Tambah Jasa Baru -->
<div class="modal fade" id="modalTambahJasa" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-dark-card border-secondary text-white">
            <div class="modal-header border-secondary">
                <h5 class="modal-header-title fw-bold text-white mb-0">Tambah Layanan Jasa IT Baru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= BASE_URL ?>/operator/jasa/create" method="POST">
                <?= SecurityHelper::csrfField() ?>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label text-white small fw-semibold">Nama Jasa</label>
                            <input type="text" class="form-control bg-dark border-secondary text-white" name="nama_jasa" placeholder="Contoh: Instalasi FO & Fiber Cable" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-white small fw-semibold">Harga Mulai (Rp)</label>
                            <input type="number" class="form-control bg-dark border-secondary text-white" name="harga_mulai" placeholder="200000" required>
                        </div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label text-white small fw-semibold">Estimasi Pengerjaan</label>
                            <input type="text" class="form-control bg-dark border-secondary text-white" name="estimasi_pengerjaan" placeholder="Contoh: 1 - 2 Hari" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-white small fw-semibold">Status Layanan</label>
                            <select class="form-select bg-dark border-secondary text-white" name="status">
                                <option value="aktif" selected>Aktif</option>
                                <option value="nonaktif">Nonaktif</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-white small fw-semibold">Deskripsi Layanan Jasa</label>
                        <textarea class="form-control bg-dark border-secondary text-white" name="deskripsi" rows="3" placeholder="Jelaskan cakupan pengerjaan layanan jasa..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn-outline-light rounded-pill btn-sm btn" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm fw-bold">Tambah Jasa Baru</button>
                </div>
            </form>
        </div>
    </div>
</div>

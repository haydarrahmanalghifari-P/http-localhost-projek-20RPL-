<section class="py-5">
    <div class="container">
        
        <?php
        $tipe = $reportData['tipe'] ?? 'pesanan';
        $periode = $reportData['periode'] ?? 'bulan';
        $summary = $reportData['summary'] ?? [];
        $rows = $reportData['rows'] ?? [];
        $chartData = $reportData['chartData'] ?? [];

        $tipeTitles = [
            'pesanan' => 'Laporan Pesanan Jasa',
            'layanan' => 'Laporan Layanan & Popularitas Jasa',
            'teknisi' => 'Laporan Kinerja Teknisi Siswa TKJ',
            'pendapatan' => 'Laporan Pendapatan & Pembayaran',
            'customer' => 'Laporan Aktivitas & Transaksi Customer'
        ];

        $periodeTitles = [
            'hari' => 'Hari Ini (' . date('d M Y') . ')',
            'minggu' => 'Minggu Ini',
            'bulan' => 'Bulan Ini (' . date('F Y') . ')',
            'tahun' => 'Tahun Ini (' . date('Y') . ')'
        ];
        ?>

        <!-- Area Header Laporan (Dengan Penanganan Print) -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4 no-print">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">PANGKALAN LAPORAN UNIT BISNIS</span>
                <h2 class="fw-bold text-white mb-0 d-flex align-items-center gap-2">
                    <i class="fa-solid fa-chart-pie text-cyan"></i> <?= $tipeTitles[$tipe] ?? 'Laporan TEFA' ?>
                </h2>
                <small class="text-white-50">Filter Periode: <strong><?= $periodeTitles[$periode] ?? 'Bulan Ini' ?></strong></small>
            </div>
            <div class="d-flex align-items-center gap-2">
                <button onclick="window.print()" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow">
                    <i class="fa-solid fa-print me-1"></i> Cetak Laporan
                </button>
            </div>
        </div>

        <!-- Official Header untuk Tampilan Cetak (Hanya Muncul Saat Print) -->
        <div class="print-header d-none text-center mb-4">
            <h3 class="fw-bold mb-1">SMK NEGERI TKJ - UNIT BISNIS & TEACHING FACTORY</h3>
            <h4 class="fw-bold text-cyan mb-1"><?= strtoupper($tipeTitles[$tipe] ?? 'LAPORAN TEFA') ?></h4>
            <p class="mb-0 small">Periode: <?= $periodeTitles[$periode] ?? 'Bulan Ini' ?> | Dicetak pada: <?= date('d M Y H:i') ?></p>
            <hr class="border-dark opacity-50 my-2">
        </div>

        <!-- 5 Tipe Laporan Nav Tabs (No Print) -->
        <div class="glass-card p-2 rounded-4 border border-secondary border-opacity-25 mb-4 no-print">
            <ul class="nav nav-pills nav-fill gap-1">
                <li class="nav-item">
                    <a class="nav-link rounded-3 text-white fw-bold extra-small <?= ($tipe === 'pesanan') ? 'active bg-cyan text-dark' : '' ?>" href="<?= BASE_URL ?>/operator/laporan?tipe=pesanan&periode=<?= $periode ?>">
                        <i class="fa-solid fa-list-check me-1"></i> 1. Pesanan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link rounded-3 text-white fw-bold extra-small <?= ($tipe === 'layanan') ? 'active bg-cyan text-dark' : '' ?>" href="<?= BASE_URL ?>/operator/laporan?tipe=layanan&periode=<?= $periode ?>">
                        <i class="fa-solid fa-screwdriver-wrench me-1"></i> 2. Layanan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link rounded-3 text-white fw-bold extra-small <?= ($tipe === 'teknisi') ? 'active bg-cyan text-dark' : '' ?>" href="<?= BASE_URL ?>/operator/laporan?tipe=teknisi&periode=<?= $periode ?>">
                        <i class="fa-solid fa-user-gear me-1"></i> 3. Teknisi
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link rounded-3 text-white fw-bold extra-small <?= ($tipe === 'pendapatan') ? 'active bg-cyan text-dark' : '' ?>" href="<?= BASE_URL ?>/operator/laporan?tipe=pendapatan&periode=<?= $periode ?>">
                        <i class="fa-solid fa-wallet me-1"></i> 4. Pendapatan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link rounded-3 text-white fw-bold extra-small <?= ($tipe === 'customer') ? 'active bg-cyan text-dark' : '' ?>" href="<?= BASE_URL ?>/operator/laporan?tipe=customer&periode=<?= $periode ?>">
                        <i class="fa-solid fa-users me-1"></i> 5. Customer
                    </a>
                </li>
            </ul>
        </div>

        <!-- 4 Filter Periode Waktu (No Print) -->
        <div class="d-flex align-items-center justify-content-between gap-2 mb-4 no-print flex-wrap">
            <div class="text-white-50 extra-small fw-semibold"><i class="fa-solid fa-filter text-cyan me-1"></i> Filter Periode Waktu:</div>
            <div class="btn-group rounded-pill p-1 bg-dark border border-secondary border-opacity-25" role="group">
                <a href="<?= BASE_URL ?>/operator/laporan?tipe=<?= $tipe ?>&periode=hari" class="btn btn-sm rounded-pill extra-small px-3 <?= ($periode === 'hari') ? 'btn-cyan text-dark fw-bold' : 'btn-dark text-white-50' ?>">
                    <i class="fa-solid fa-calendar-day me-1"></i> Hari Ini
                </a>
                <a href="<?= BASE_URL ?>/operator/laporan?tipe=<?= $tipe ?>&periode=minggu" class="btn btn-sm rounded-pill extra-small px-3 <?= ($periode === 'minggu') ? 'btn-cyan text-dark fw-bold' : 'btn-dark text-white-50' ?>">
                    <i class="fa-solid fa-calendar-week me-1"></i> Minggu Ini
                </a>
                <a href="<?= BASE_URL ?>/operator/laporan?tipe=<?= $tipe ?>&periode=bulan" class="btn btn-sm rounded-pill extra-small px-3 <?= ($periode === 'bulan') ? 'btn-cyan text-dark fw-bold' : 'btn-dark text-white-50' ?>">
                    <i class="fa-solid fa-calendar-days me-1"></i> Bulan Ini
                </a>
                <a href="<?= BASE_URL ?>/operator/laporan?tipe=<?= $tipe ?>&periode=tahun" class="btn btn-sm rounded-pill extra-small px-3 <?= ($periode === 'tahun') ? 'btn-cyan text-dark fw-bold' : 'btn-dark text-white-50' ?>">
                    <i class="fa-solid fa-calendar me-1"></i> Tahun Ini
                </a>
            </div>
        </div>

        <!-- 4 Summary Cards Total Data -->
        <div class="row g-3 mb-4">
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Rekap Data</div>
                    <div class="fs-3 fw-extrabold text-white"><?= $summary['total_data'] ?? 0 ?> Item</div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Omset Transaksi</div>
                    <div class="fs-3 fw-extrabold text-success">Rp <?= number_format($summary['total_omset'] ?? 0, 0, ',', '.') ?></div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Selesai / Terpenuhi</div>
                    <div class="fs-3 fw-extrabold text-cyan"><?= $summary['completed'] ?? 0 ?></div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">Dalam Progres / Pending</div>
                    <div class="fs-3 fw-extrabold text-warning"><?= $summary['pending'] ?? 0 ?></div>
                </div>
            </div>
        </div>

        <!-- Panel Grafik Chart.js Sederhana -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 mb-4 shadow-lg">
            <h5 class="fw-bold text-white mb-3 d-flex align-items-center gap-2">
                <i class="fa-solid fa-chart-column text-cyan"></i> Visualisasi Grafik Analytics (Chart.js)
            </h5>
            <div style="max-height: 320px; position: relative;">
                <canvas id="reportChart" style="max-height: 300px;"></canvas>
            </div>
        </div>

        <!-- Tabel Rekapitulasi Data Laporan -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 shadow-lg">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <h5 class="fw-bold text-white mb-0">
                    <i class="fa-solid fa-table text-cyan me-2"></i> Tabel Data Rekapitulasi - <?= $tipeTitles[$tipe] ?>
                </h5>
                <span class="badge bg-cyan text-dark extra-small font-normal">Periode: <?= $periodeTitles[$periode] ?></span>
            </div>

            <div class="table-responsive">
                <?php if ($tipe === 'pesanan'): ?>
                    <table class="table table-dark table-hover align-middle mb-0 extra-small">
                        <thead>
                            <tr class="text-cyan">
                                <th>Kode</th>
                                <th>Customer</th>
                                <th>Jasa IT</th>
                                <th>Tgl Pemesanan</th>
                                <th>Teknisi Siswa</th>
                                <th>Total Biaya (Rp)</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($rows)): ?>
                                <?php foreach ($rows as $r): ?>
                                    <tr>
                                        <td><strong class="text-white"><?= htmlspecialchars($r['kode_pesanan']) ?></strong></td>
                                        <td><?= htmlspecialchars($r['customer_name'] ?? 'Customer') ?></td>
                                        <td><?= htmlspecialchars($r['nama_jasa']) ?></td>
                                        <td><?= date('d M Y H:i', strtotime($r['tanggal_pemesanan'])) ?></td>
                                        <td><?= htmlspecialchars($r['nama_teknisi'] ?? 'Belum Ditugaskan') ?></td>
                                        <td><span class="text-cyan fw-bold">Rp <?= number_format($r['total_harga'] ?? 0, 0, ',', '.') ?></span></td>
                                        <td><span class="badge bg-info text-dark"><?= strtoupper($r['status']) ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="7" class="text-center text-white-50 py-3">Tidak ada data pesanan pada periode ini.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                <?php elseif ($tipe === 'layanan'): ?>
                    <table class="table table-dark table-hover align-middle mb-0 extra-small">
                        <thead>
                            <tr class="text-cyan">
                                <th>ID</th>
                                <th>Nama Layanan Jasa</th>
                                <th>Harga Mulai</th>
                                <th>Total Frekuensi Pemesanan</th>
                                <th>Total Perolehan Omset (Rp)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($rows)): ?>
                                <?php foreach ($rows as $r): ?>
                                    <tr>
                                        <td>#<?= $r['id'] ?></td>
                                        <td><strong class="text-white"><?= htmlspecialchars($r['nama_jasa']) ?></strong></td>
                                        <td>Rp <?= number_format($r['harga_mulai'], 0, ',', '.') ?></td>
                                        <td><span class="badge bg-cyan text-dark fw-bold fs-6"><?= $r['total_order'] ?> Order</span></td>
                                        <td><span class="text-success fw-bold fs-6">Rp <?= number_format($r['total_pendapatan'], 0, ',', '.') ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                <?php elseif ($tipe === 'teknisi'): ?>
                    <table class="table table-dark table-hover align-middle mb-0 extra-small">
                        <thead>
                            <tr class="text-cyan">
                                <th>ID</th>
                                <th>Nama Teknisi Siswa</th>
                                <th>Email</th>
                                <th>Total Tugas</th>
                                <th>Pekerjaan Selesai</th>
                                <th>Dalam Proses</th>
                                <th>Rating Performa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($rows)): ?>
                                <?php foreach ($rows as $r): ?>
                                    <tr>
                                        <td>#<?= $r['id'] ?></td>
                                        <td><strong class="text-white"><?= htmlspecialchars($r['nama_teknisi']) ?></strong></td>
                                        <td><?= htmlspecialchars($r['email']) ?></td>
                                        <td><span class="badge bg-secondary"><?= $r['total_tugas'] ?> Tugas</span></td>
                                        <td><span class="badge bg-success"><?= $r['tugas_selesai'] ?> Selesai</span></td>
                                        <td><span class="badge bg-warning text-dark"><?= $r['tugas_proses'] ?> Diproses</span></td>
                                        <td><span class="text-warning fw-bold"><i class="fa-solid fa-star me-1"></i> <?= number_format($r['avg_rating'], 1) ?> / 5.0</span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                <?php elseif ($tipe === 'pendapatan'): ?>
                    <table class="table table-dark table-hover align-middle mb-0 extra-small">
                        <thead>
                            <tr class="text-cyan">
                                <th>ID Transaksi</th>
                                <th>Kode Pesanan</th>
                                <th>Customer</th>
                                <th>Metode Pembayaran</th>
                                <th>Jumlah Tagihan</th>
                                <th>Status Verifikasi</th>
                                <th>Tanggal Pembayaran</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($rows)): ?>
                                <?php foreach ($rows as $r): ?>
                                    <tr>
                                        <td>#TRX-<?= $r['id'] ?></td>
                                        <td><strong class="text-white"><?= htmlspecialchars($r['kode_pesanan']) ?></strong></td>
                                        <td><?= htmlspecialchars($r['customer_name']) ?></td>
                                        <td><span class="badge bg-secondary text-uppercase"><?= htmlspecialchars($r['metode_pembayaran']) ?></span></td>
                                        <td><span class="text-cyan fw-bold">Rp <?= number_format($r['jumlah'], 0, ',', '.') ?></span></td>
                                        <td>
                                            <?php if (in_array($r['status'], ['dibayar', 'lunas'])): ?>
                                                <span class="badge bg-success">Dibayar (Lunas)</span>
                                            <?php elseif (in_array($r['status'], ['menunggu_verifikasi', 'pending'])): ?>
                                                <span class="badge bg-info text-dark">Menunggu Verifikasi</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Ditolak</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= !empty($r['tanggal_pembayaran']) ? date('d M Y H:i', strtotime($r['tanggal_pembayaran'])) : '-' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                <?php else: ?>
                    <table class="table table-dark table-hover align-middle mb-0 extra-small">
                        <thead>
                            <tr class="text-cyan">
                                <th>ID</th>
                                <th>Nama Customer</th>
                                <th>Email</th>
                                <th>Jumlah Pesanan Jasa</th>
                                <th>Total Pengeluaran (Rp)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($rows)): ?>
                                <?php foreach ($rows as $r): ?>
                                    <tr>
                                        <td>#<?= $r['id'] ?></td>
                                        <td><strong class="text-white"><?= htmlspecialchars($r['customer_name']) ?></strong></td>
                                        <td><?= htmlspecialchars($r['email']) ?></td>
                                        <td><span class="badge bg-cyan text-dark fw-bold"><?= $r['total_pesanan'] ?> Pesanan</span></td>
                                        <td><span class="text-success fw-bold fs-6">Rp <?= number_format($r['total_pengeluaran'], 0, ',', '.') ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

    </div>
</section>

<!-- Print CSS Styling -->
<style>
@media print {
    .no-print, header, nav, footer, .navbar {
        display: none !important;
    }
    body {
        background: #fff !important;
        color: #000 !important;
    }
    .print-header {
        display: block !important;
        color: #000 !important;
    }
    .glass-card, .bg-dark-card {
        background: none !important;
        border: 1px solid #ddd !important;
        color: #000 !important;
        box-shadow: none !important;
    }
    .table-dark {
        --bs-table-bg: #fff !important;
        --bs-table-color: #000 !important;
        border: 1px solid #ccc !important;
    }
    .table-dark th {
        color: #000 !important;
        border-bottom: 2px solid #000 !important;
    }
    .text-cyan, .text-success, .text-white, .text-white-50 {
        color: #000 !important;
    }
}
</style>

<!-- Chart.js Engine CDN & Initializer Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const rawChartData = <?= json_encode($chartData) ?>;
    const ctx = document.getElementById('reportChart');

    if (ctx && rawChartData && rawChartData.labels) {
        new Chart(ctx, {
            type: rawChartData.type || 'bar',
            data: {
                labels: rawChartData.labels,
                datasets: rawChartData.datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#94a3b8',
                            font: { family: 'Plus Jakarta Sans', size: 12 }
                        }
                    }
                },
                scales: (rawChartData.type === 'bar' || rawChartData.type === 'line') ? {
                    x: {
                        ticks: { color: '#94a3b8' },
                        grid: { color: 'rgba(255, 255, 255, 0.05)' }
                    },
                    y: {
                        ticks: { color: '#94a3b8' },
                        grid: { color: 'rgba(255, 255, 255, 0.05)' }
                    }
                } : {}
            }
        });
    }
});
</script>

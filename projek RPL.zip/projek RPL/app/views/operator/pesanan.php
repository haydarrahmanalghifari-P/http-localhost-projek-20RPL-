<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('op_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php $flashError = AuthHelper::getFlash('op_error'); ?>
        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i> <?= htmlspecialchars($flashError['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">MANAJEMEN PESANAN</span>
                <h2 class="fw-bold text-white mb-0">Kelola Pesanan Jasa & Plotting Teknisi</h2>
                <small class="text-white-50">Semua pesanan jasa dikelola langsung oleh Admin & Operator sistem.</small>
            </div>
            <div>
                <button class="btn btn-cyan text-dark fw-bold rounded-pill px-3 py-2 btn-sm btn-shadow d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#modalTambahPesananAdmin">
                    <i class="fa-solid fa-plus-circle fs-6"></i>
                    <span>Input Pesanan Baru</span>
                </button>
            </div>
        </div>

        <!-- Table Pesanan Operator -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>Kode</th>
                            <th>Customer & Kontak</th>
                            <th>Jasa & Alamat</th>
                            <th>Tgl Pemesanan</th>
                            <th>Teknisi Ditugaskan</th>
                            <th>Status Pesanan</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($orders)): ?>
                            <?php foreach ($orders as $ord): ?>
                                <tr>
                                    <td><strong class="text-white"><?= htmlspecialchars($ord['kode_pesanan']) ?></strong></td>
                                    <td>
                                        <div class="fw-bold text-white"><?= htmlspecialchars($ord['nama_customer'] ?? 'Customer') ?></div>
                                        <div class="text-white-50 extra-small"><?= htmlspecialchars($ord['no_telepon']) ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-white"><?= htmlspecialchars($ord['nama_jasa']) ?></div>
                                        <div class="text-white-50 extra-small"><?= htmlspecialchars(substr($ord['alamat'], 0, 30)) ?>...</div>
                                    </td>
                                    <td><?= date('d M Y', strtotime($ord['tanggal_pemesanan'])) ?></td>
                                    <td>
                                        <?php if (!empty($ord['nama_teknisi'])): ?>
                                            <span class="badge bg-info text-dark"><i class="fa-solid fa-user-gear me-1"></i> <?= htmlspecialchars($ord['nama_teknisi']) ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger text-white"><i class="fa-solid fa-triangle-exclamation me-1"></i> Belum Belum Ada</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $st = strtolower($ord['status']);
                                        if ($st === 'pending' || $st === 'menunggu'): ?>
                                            <span class="badge bg-warning text-dark">Menunggu</span>
                                        <?php elseif ($st === 'dikonfirmasi' || $st === 'diverifikasi'): ?>
                                            <span class="badge bg-info text-dark">Diverifikasi</span>
                                        <?php elseif ($st === 'diproses' || $st === 'dikerjakan'): ?>
                                            <span class="badge bg-primary">Diproses / Dikerjakan</span>
                                        <?php elseif ($st === 'selesai'): ?>
                                            <span class="badge bg-success">Selesai</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Dibatalkan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-cyan btn-sm py-1 px-2 text-dark fw-bold me-1" data-bs-toggle="modal" data-bs-target="#modalPlotTeknisi<?= $ord['id'] ?>">
                                            <i class="fa-solid fa-user-gear me-1"></i> Plot / Status
                                        </button>
                                        <form action="<?= BASE_URL ?>/operator/pesanan/delete/<?= $ord['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus pesanan ini?')">
                                            <?= SecurityHelper::csrfField() ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-white-50 py-3">Belum ada pesanan masuk.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Modals Plotting Teknisi Operator -->
        <?php if (!empty($orders)): ?>
            <?php foreach ($orders as $ord): ?>
                <div class="modal fade" id="modalPlotTeknisi<?= $ord['id'] ?>" tabindex="-1" aria-hidden="true" style="z-index: 1065;">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content bg-dark-card border-secondary text-white" style="background: #111a2e !important;">
                            <div class="modal-header border-secondary py-2.5">
                                <h6 class="modal-header-title fw-bold text-white mb-0">Plotting Teknisi &amp; Status #<?= htmlspecialchars($ord['kode_pesanan']) ?></h6>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?= BASE_URL ?>/operator/pesanan/update/<?= $ord['id'] ?>" method="POST">
                                <?= SecurityHelper::csrfField() ?>
                                <div class="modal-body py-3">
                                    <div class="mb-3">
                                        <label class="form-label text-white small fw-semibold">Pilih Teknisi Siswa TKJ Penanggung Jawab</label>
                                        <select class="form-select bg-dark border-secondary text-white" name="teknisi_id">
                                            <option value="" <?= empty($ord['teknisi_id']) ? 'selected' : '' ?>>-- Pilih Teknisi Siswa --</option>
                                            <?php if (!empty($teknisiList)): ?>
                                                <?php foreach ($teknisiList as $tek): ?>
                                                    <option value="<?= $tek['id'] ?>" <?= ($ord['teknisi_id'] == $tek['id']) ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($tek['nama']) ?> (<?= htmlspecialchars($tek['email']) ?>)
                                                    </option>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label text-white small fw-semibold">Ubah Status Pesanan</label>
                                        <select class="form-select bg-dark border-secondary text-white" name="status">
                                            <option value="Menunggu" <?= ($ord['status'] === 'pending') ? 'selected' : '' ?>>Menunggu</option>
                                            <option value="Diverifikasi" <?= ($ord['status'] === 'dikonfirmasi') ? 'selected' : '' ?>>Diverifikasi</option>
                                            <option value="Diproses" <?= ($ord['status'] === 'diproses') ? 'selected' : '' ?>>Diproses</option>
                                            <option value="Dikerjakan" <?= ($ord['status'] === 'dikerjakan') ? 'selected' : '' ?>>Dikerjakan</option>
                                            <option value="Selesai" <?= ($ord['status'] === 'selesai') ? 'selected' : '' ?>>Selesai</option>
                                            <option value="Dibatalkan" <?= ($ord['status'] === 'dibatalkan') ? 'selected' : '' ?>>Dibatalkan</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer border-secondary py-2.5">
                                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm px-4 fw-bold">Simpan Plotting</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Modal Input Pesanan Baru (Admin / Operator) -->
        <div class="modal fade" id="modalTambahPesananAdmin" tabindex="-1" aria-labelledby="modalTambahPesananLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content bg-dark-card border border-secondary border-opacity-50 text-white shadow-lg">
                    <div class="modal-header border-secondary border-opacity-25 pb-3">
                        <div class="d-flex align-items-center gap-2">
                            <div class="p-2 rounded-circle bg-cyan text-dark d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                                <i class="fa-solid fa-file-circle-plus fs-5"></i>
                            </div>
                            <div>
                                <h5 class="modal-title fw-bold text-white mb-0" id="modalTambahPesananLabel">Input Pesanan Jasa Baru (Admin & Operator)</h5>
                                <small class="text-white-50">Gunakan form ini untuk mencatat pesanan customer secara langsung di sistem.</small>
                            </div>
                        </div>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <form action="<?= BASE_URL ?>/operator/pesanan/create" method="POST">
                        <?= SecurityHelper::csrfField() ?>
                        <div class="modal-body py-4">
                            <div class="row g-3">
                                
                                <!-- Pilih Customer -->
                                <div class="col-md-6">
                                    <label class="form-label text-white small fw-semibold">Pilih Customer <span class="text-danger">*</span></label>
                                    <select name="customer_id" class="form-select bg-dark border-secondary text-white" required>
                                        <option value="">-- Pilih Customer Terdaftar --</option>
                                        <?php if (!empty($customerList)): ?>
                                            <?php foreach ($customerList as $cust): ?>
                                                <option value="<?= $cust['id'] ?>">
                                                    <?= htmlspecialchars($cust['nama']) ?> (<?= htmlspecialchars($cust['email']) ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <!-- Pilih Jasa IT -->
                                <div class="col-md-6">
                                    <label class="form-label text-white small fw-semibold">Layanan Jasa <span class="text-danger">*</span></label>
                                    <select name="jasa_id" class="form-select bg-dark border-secondary text-white" required>
                                        <option value="">-- Pilih Layanan Jasa --</option>
                                        <?php if (!empty($serviceList)): ?>
                                            <?php foreach ($serviceList as $s): ?>
                                                <option value="<?= $s['id'] ?>">
                                                    <?= htmlspecialchars($s['title'] ?? $s['nama_jasa']) ?> (<?= htmlspecialchars($s['price'] ?? 'Mulai Rp ' . number_format($s['harga_mulai'] ?? 0, 0, ',', '.')) ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <!-- No Telepon / Kontak -->
                                <div class="col-md-6">
                                    <label class="form-label text-white small fw-semibold">Nomor Telepon / Kontak <span class="text-danger">*</span></label>
                                    <input type="text" name="no_telepon" class="form-control bg-dark border-secondary text-white" placeholder="Contoh: 081234567890" required>
                                </div>

                                <!-- Tanggal Pengerjaan -->
                                <div class="col-md-6">
                                    <label class="form-label text-white small fw-semibold">Tanggal Rencana Pengerjaan <span class="text-danger">*</span></label>
                                    <input type="date" name="tanggal_pengerjaan" class="form-control bg-dark border-secondary text-white" value="<?= date('Y-m-d') ?>" required>
                                </div>

                                <!-- Alamat Lokasi Customer -->
                                <div class="col-12">
                                    <label class="form-label text-white small fw-semibold">Alamat Lengkap Lokasi Pengerjaan <span class="text-danger">*</span></label>
                                    <textarea name="alamat" rows="2" class="form-control bg-dark border-secondary text-white" placeholder="Alamat rumah, kantor, lab, atau lokasi instalasi..." required></textarea>
                                </div>

                                <!-- Deskripsi Masalah / Kebutuhan -->
                                <div class="col-12">
                                    <label class="form-label text-white small fw-semibold">Deskripsi Kerusakan / Kebutuhan IT <span class="text-danger">*</span></label>
                                    <textarea name="deskripsi_masalah" rows="3" class="form-control bg-dark border-secondary text-white" placeholder="Jelaskan kendala, tipe perangkat, jumlah titik pemasangan, atau spesifikasi pengerjaan..." required></textarea>
                                </div>

                                <!-- Plotting Teknisi (Opsional) -->
                                <div class="col-md-4">
                                    <label class="form-label text-white small fw-semibold">Teknisi Siswa Ditugaskan</label>
                                    <select name="teknisi_id" class="form-select bg-dark border-secondary text-white">
                                        <option value="">-- Tetapkan Nanti --</option>
                                        <?php if (!empty($teknisiList)): ?>
                                            <?php foreach ($teknisiList as $tek): ?>
                                                <option value="<?= $tek['id'] ?>"><?= htmlspecialchars($tek['nama']) ?></option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <!-- Status Awal -->
                                <div class="col-md-4">
                                    <label class="form-label text-white small fw-semibold">Status Awal Pesanan</label>
                                    <select name="status" class="form-select bg-dark border-secondary text-white">
                                        <option value="pending" selected>Menunggu Konfirmasi (Pending)</option>
                                        <option value="dikonfirmasi">Diverifikasi &amp; Dikonfirmasi</option>
                                        <option value="diproses">Langsung Diproses</option>
                                    </select>
                                </div>

                                <!-- Total Biaya / Estimasi -->
                                <div class="col-md-4">
                                    <label class="form-label text-white small fw-semibold">Estimasi Total Biaya (Rp)</label>
                                    <input type="number" name="total_harga" class="form-control bg-dark border-secondary text-white" placeholder="Biaya (Kosong = Otomatis Jasa)">
                                </div>

                            </div>
                        </div>

                        <div class="modal-footer border-secondary border-opacity-25 pt-3">
                            <button type="button" class="btn btn-outline-light rounded-pill btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm px-4 fw-bold">
                                <i class="fa-solid fa-save me-1"></i> Simpan Pesanan ke Sistem
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</section>

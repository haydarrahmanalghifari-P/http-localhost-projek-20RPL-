<section class="py-5">
    <div class="container">
        
        <!-- Flash Alert Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('op_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">TRANSAKSI & KEUANGAN</span>
                <h2 class="fw-bold text-white mb-0 d-flex align-items-center gap-2">
                    <i class="fa-solid fa-wallet text-cyan"></i> Melihat & Verifikasi Pembayaran
                </h2>
                <small class="text-white-50">Kelola dan verifikasi konfirmasi pembayaran Cash dan Transfer Bank dari customer.</small>
            </div>
        </div>

        <!-- Table Pembayaran -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 shadow-lg">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>ID Transaksi</th>
                            <th>Kode Pesanan</th>
                            <th>Customer</th>
                            <th>Metode</th>
                            <th>Jumlah (Rp)</th>
                            <th>Status Pembayaran</th>
                            <th>Bukti Pembayaran</th>
                            <th class="text-end">Aksi Operator</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($payments)): ?>
                            <?php foreach ($payments as $pb): ?>
                                <?php 
                                $status = strtolower($pb['status'] ?? 'belum_dibayar');
                                $metode = strtolower($pb['metode_pembayaran'] ?? 'transfer');
                                ?>
                                <tr>
                                    <td>#TRX-<?= $pb['id'] ?></td>
                                    <td><strong class="text-white"><?= htmlspecialchars($pb['kode_pesanan']) ?></strong></td>
                                    <td>
                                        <strong class="text-white d-block"><?= htmlspecialchars($pb['customer_name']) ?></strong>
                                        <small class="text-white-50 opacity-75"><?= htmlspecialchars($pb['customer_email'] ?? '') ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary text-uppercase px-2 py-1">
                                            <?= ($metode === 'cash') ? 'CASH (TUNAI)' : 'TRANSFER BANK' ?>
                                        </span>
                                    </td>
                                    <td><span class="text-cyan fw-bold fs-6">Rp <?= number_format($pb['jumlah'], 0, ',', '.') ?></span></td>
                                    <td>
                                        <?php if ($status === 'dibayar' || $status === 'lunas'): ?>
                                            <span class="badge bg-success px-2 py-1 rounded-pill">
                                                <i class="fa-solid fa-check-circle me-1"></i> Dibayar
                                            </span>
                                        <?php elseif ($status === 'menunggu_verifikasi' || $status === 'pending'): ?>
                                            <span class="badge bg-info text-dark px-2 py-1 rounded-pill">
                                                <i class="fa-solid fa-clock me-1"></i> Menunggu Verifikasi
                                            </span>
                                        <?php elseif ($status === 'ditolak'): ?>
                                            <span class="badge bg-danger px-2 py-1 rounded-pill">
                                                <i class="fa-solid fa-circle-xmark me-1"></i> Ditolak
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark px-2 py-1 rounded-pill">
                                                <i class="fa-solid fa-circle-exclamation me-1"></i> Belum Dibayar
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($pb['bukti_pembayaran'])): ?>
                                            <button type="button" class="btn btn-outline-cyan btn-sm py-1 px-2 extra-small" data-bs-toggle="modal" data-bs-target="#modalBukti<?= $pb['id'] ?>">
                                                <i class="fa-solid fa-image me-1"></i> Lihat Bukti
                                            </button>

                                            <!-- Modal Pratinjau Bukti Pembayaran -->
                                            <div class="modal fade" id="modalBukti<?= $pb['id'] ?>" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content bg-dark-card border-secondary text-white">
                                                        <div class="modal-header border-secondary">
                                                            <h5 class="modal-title fw-bold text-white mb-0">Bukti Transfer - Pesanan <?= htmlspecialchars($pb['kode_pesanan']) ?></h5>
                                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body text-center p-3">
                                                            <?php 
                                                            $ext = strtolower(pathinfo($pb['bukti_pembayaran'], PATHINFO_EXTENSION));
                                                            ?>
                                                            <?php if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'])): ?>
                                                                <img src="<?= BASE_URL ?>/<?= htmlspecialchars($pb['bukti_pembayaran']) ?>" class="img-fluid rounded-3 border border-secondary shadow" alt="Bukti Transfer">
                                                            <?php else: ?>
                                                                <div class="p-4 bg-dark rounded-3 border border-secondary mb-3">
                                                                    <i class="fa-solid fa-file-pdf display-4 text-cyan mb-2"></i>
                                                                    <p class="text-white small mb-0">Dokumen Bukti Transfer (PDF)</p>
                                                                </div>
                                                            <?php endif; ?>
                                                            <a href="<?= BASE_URL ?>/<?= htmlspecialchars($pb['bukti_pembayaran']) ?>" target="_blank" class="btn btn-cyan text-dark btn-sm rounded-pill mt-3 fw-bold">
                                                                <i class="fa-solid fa-up-right-from-square me-1"></i> Buka File Asli
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-white-50 extra-small">Tanpa Lampiran</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if (in_array($status, ['menunggu_verifikasi', 'pending', 'belum_dibayar'])): ?>
                                            <!-- Form Verifikasi -->
                                            <form action="<?= BASE_URL ?>/operator/pembayaran/verifikasi/<?= $pb['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Verifikasi bahwa pembayaran pesanan ini telah diterima?')">
                                                <?= SecurityHelper::csrfField() ?>
                                                <button type="submit" class="btn btn-success btn-sm py-1 px-2 me-1 fw-bold">
                                                    <i class="fa-solid fa-check me-1"></i> Verifikasi
                                                </button>
                                            </form>

                                            <!-- Tombol Modal Tolak -->
                                            <button type="button" class="btn btn-outline-danger btn-sm py-1 px-2" data-bs-toggle="modal" data-bs-target="#modalTolak<?= $pb['id'] ?>">
                                                <i class="fa-solid fa-xmark me-1"></i> Tolak
                                            </button>

                                            <!-- Modal Form Tolak Pembayaran -->
                                            <div class="modal fade" id="modalTolak<?= $pb['id'] ?>" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content bg-dark-card border-secondary text-white text-start">
                                                        <div class="modal-header border-secondary">
                                                            <h5 class="modal-title fw-bold text-white mb-0">Tolak Pembayaran #TRX-<?= $pb['id'] ?></h5>
                                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="<?= BASE_URL ?>/operator/pembayaran/tolak/<?= $pb['id'] ?>" method="POST">
                                                            <?= SecurityHelper::csrfField() ?>
                                                            <div class="modal-body">
                                                                <p class="text-white-50 small mb-3">Masukkan alasan penolakan agar customer dapat memperbaiki konfirmasi pembayaran.</p>
                                                                <div class="mb-3">
                                                                    <label class="form-label text-cyan fw-bold extra-small">Alasan Penolakan / Catatan Operator</label>
                                                                    <textarea name="catatan_operator" class="form-control bg-dark text-white border-secondary" rows="3" placeholder="Contoh: Nominal transfer tidak sesuai / file bukti tidak dapat terbaca." required></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer border-secondary">
                                                                <button type="button" class="btn btn-outline-light rounded-pill btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" class="btn btn-danger rounded-pill btn-sm px-4 fw-bold">Tolak Pembayaran</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-white-50 extra-small"><i class="fa-solid fa-lock me-1"></i> Sudah Diproses</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center text-white-50 py-4">Belum ada riwayat transaksi pembayaran.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

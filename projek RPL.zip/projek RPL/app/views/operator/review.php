<section class="py-5">
    <div class="container">
        
        <!-- Header -->
        <div class="mb-4">
            <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">EVALUASI PELANGGAN</span>
            <h2 class="fw-bold text-white mb-0">Melihat Rating & Review Customer</h2>
        </div>

        <!-- Table Review -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>Kode Pesanan</th>
                            <th>Customer</th>
                            <th>Teknisi Siswa TKJ</th>
                            <th>Rating</th>
                            <th>Komentar Ulasan</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($reviews)): ?>
                            <?php foreach ($reviews as $rev): ?>
                                <tr>
                                    <td><strong class="text-white"><?= htmlspecialchars($rev['kode_pesanan']) ?></strong></td>
                                    <td><?= htmlspecialchars($rev['nama_customer']) ?></td>
                                    <td><span class="text-cyan fw-bold"><?= htmlspecialchars($rev['nama_teknisi']) ?></span></td>
                                    <td>
                                        <div class="text-warning">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa-<?= $i <= $rev['rating'] ? 'solid' : 'regular' ?> fa-star"></i>
                                            <?php endfor; ?>
                                            <span class="ms-1 fw-bold text-white"><?= $rev['rating'] ?>/5</span>
                                        </div>
                                    </td>
                                    <td>"<?= htmlspecialchars($rev['komentar']) ?>"</td>
                                    <td><?= date('d M Y', strtotime($rev['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-white-50 py-3">Belum ada review dari customer.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

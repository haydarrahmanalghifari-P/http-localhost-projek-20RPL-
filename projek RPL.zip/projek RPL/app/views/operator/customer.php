<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('op_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-cyan text-dark fw-bold px-3 py-1 rounded-pill mb-1">MANAJEMEN USER</span>
                <h2 class="fw-bold text-white mb-0">Kelola Data Customer</h2>
            </div>
            <button type="button" class="btn btn-cyan text-dark rounded-pill fw-bold px-4 btn-shadow" data-bs-toggle="modal" data-bs-target="#modalTambahCustomer">
                <i class="fa-solid fa-plus me-1"></i> Tambah Customer Baru
            </button>
        </div>

        <!-- Table Customer -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>ID</th>
                            <th>Nama Lengkap</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Tanggal Terdaftar</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($customers)): ?>
                            <?php foreach ($customers as $c): ?>
                                <tr>
                                    <td>#<?= $c['id'] ?></td>
                                    <td><strong class="text-white"><?= htmlspecialchars($c['nama']) ?></strong></td>
                                    <td><?= htmlspecialchars($c['email']) ?></td>
                                    <td><span class="badge bg-primary">Customer</span></td>
                                    <td><?= date('d M Y', strtotime($c['created_at'] ?? 'now')) ?></td>
                                    <td class="text-end">
                                        <button class="btn btn-outline-cyan btn-sm py-1 px-2 me-1" data-bs-toggle="modal" data-bs-target="#modalEditCustomer<?= $c['id'] ?>">
                                            <i class="fa-solid fa-pen-to-square"></i> Edit
                                        </button>
                                        <form action="<?= BASE_URL ?>/operator/customer/delete/<?= $c['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus customer ini?')">
                                            <?= SecurityHelper::csrfField() ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2">
                                                <i class="fa-solid fa-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Modal Edit Customer -->
                                <div class="modal fade" id="modalEditCustomer<?= $c['id'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content bg-dark-card border-secondary text-white">
                                            <div class="modal-header border-secondary">
                                                <h5 class="modal-header-title fw-bold text-white mb-0">Edit Data Customer</h5>
                                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="<?= BASE_URL ?>/operator/customer/edit/<?= $c['id'] ?>" method="POST">
                                                <?= SecurityHelper::csrfField() ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label text-white small fw-semibold">Nama Lengkap</label>
                                                        <input type="text" class="form-control bg-dark border-secondary text-white" name="nama" value="<?= htmlspecialchars($c['nama']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label text-white small fw-semibold">Alamat Email</label>
                                                        <input type="email" class="form-control bg-dark border-secondary text-white" name="email" value="<?= htmlspecialchars($c['email']) ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label text-white small fw-semibold">Password Baru (Kosongkan jika tidak diubah)</label>
                                                        <input type="password" class="form-control bg-dark border-secondary text-white" name="password" placeholder="••••••••">
                                                    </div>
                                                </div>
                                                <div class="modal-footer border-secondary">
                                                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm fw-bold">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-white-50 py-3">Belum ada data customer terdaftar.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<!-- Modal Tambah Customer Baru -->
<div class="modal fade" id="modalTambahCustomer" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark-card border-secondary text-white">
            <div class="modal-header border-secondary">
                <h5 class="modal-header-title fw-bold text-white mb-0">Tambah Customer Baru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= BASE_URL ?>/operator/customer/create" method="POST">
                <?= SecurityHelper::csrfField() ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label text-white small fw-semibold">Nama Lengkap</label>
                        <input type="text" class="form-control bg-dark border-secondary text-white" name="nama" placeholder="Contoh: Budi Santoso" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-white small fw-semibold">Alamat Email</label>
                        <input type="email" class="form-control bg-dark border-secondary text-white" name="email" placeholder="budi@gmail.com" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-white small fw-semibold">Password</label>
                        <input type="password" class="form-control bg-dark border-secondary text-white" name="password" placeholder="Minimal 6 karakter" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-light rounded-pill btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-cyan text-dark rounded-pill btn-sm fw-bold">Tambah Customer</button>
                </div>
            </form>
        </div>
    </div>
</div>

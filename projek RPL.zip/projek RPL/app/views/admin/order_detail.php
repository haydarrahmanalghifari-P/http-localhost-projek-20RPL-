<?php
/**
 * Halaman Detail Pesanan Administrator (Sesuai Desain Rekan Pengguna)
 * Dilengkapi dengan Pembaruan Status Real-time & Notifikasi WhatsApp Otomatis (Fonnte)
 */
$st = strtolower($order['status'] ?? 'pending');

// Mapping Status Badge
$badgeClass = 'bg-primary';
$statusLabel = strtoupper($st);
if ($st === 'pending' || $st === 'menunggu') {
    $badgeClass = 'bg-warning text-dark';
    $statusLabel = 'PENDING';
} elseif ($st === 'dikonfirmasi' || $st === 'diverifikasi') {
    $badgeClass = 'bg-info text-dark';
    $statusLabel = 'CONFIRMED';
} elseif ($st === 'diproses' || $st === 'dikerjakan' || $st === 'processing') {
    $badgeClass = 'bg-primary text-white';
    $statusLabel = 'PROCESSING';
} elseif ($st === 'shipped') {
    $badgeClass = 'bg-primary text-white';
    $statusLabel = 'SHIPPED';
} elseif ($st === 'selesai' || $st === 'completed') {
    $badgeClass = 'bg-success text-white';
    $statusLabel = 'COMPLETED';
} elseif ($st === 'dibatalkan' || $st === 'cancelled') {
    $badgeClass = 'bg-danger text-white';
    $statusLabel = 'CANCELLED';
}

$kodeTrx = !empty($order['kode_pesanan']) ? $order['kode_pesanan'] : ('TRX-' . sprintf('%06d', $order['id']));
?>

<section class="py-4 py-lg-5" style="background-color: #f8fafc; min-height: 90vh;">
    <div class="container-fluid px-3 px-lg-5">

        <!-- Flash Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('admin_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 border-0 shadow-sm rounded-4 d-flex align-items-center gap-2" role="alert">
                <i class="fa-solid fa-circle-check fs-5 text-success"></i>
                <div class="fw-medium"><?= htmlspecialchars($flashSuccess['message']) ?></div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php $flashError = AuthHelper::getFlash('admin_error'); ?>
        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 border-0 shadow-sm rounded-4 d-flex align-items-center gap-2" role="alert">
                <i class="fa-solid fa-circle-exclamation fs-5 text-danger"></i>
                <div class="fw-medium"><?= htmlspecialchars($flashError['message']) ?></div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Navigasi Cepat Kembali -->
        <div class="mb-3 d-flex align-items-center justify-content-between">
            <a href="<?= BASE_URL ?>/admin/pesanan" class="text-decoration-none text-muted extra-small fw-semibold d-inline-flex align-items-center gap-1.5 hover-text-primary">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Pesanan
            </a>
            <span class="badge bg-danger bg-opacity-10 text-danger extra-small fw-bold px-3 py-1 rounded-pill">
                <i class="fa-solid fa-shield-halved me-1"></i> Otorisasi Administrator
            </span>
        </div>

        <div class="row g-4">
            
            <!-- ==========================================
                 KOLOM KIRI: DETAIL PESANAN & TABEL PRODUK
                 ========================================== -->
            <div class="col-lg-8">
                <div class="card border border-light-subtle rounded-4 shadow-sm p-4 p-md-5 bg-white mb-4">
                    
                    <!-- Header Kartu: Judul TRX & Status Pill Badge -->
                    <div class="d-flex align-items-center justify-content-between pb-3 border-bottom border-light-subtle mb-4">
                        <h4 class="fw-bold text-dark mb-0 font-heading">
                            Detail Pesanan <?= htmlspecialchars($kodeTrx) ?>
                        </h4>
                        <span class="badge <?= $badgeClass ?> px-3 py-2 rounded-3 fw-bold font-monospace" style="letter-spacing: 0.5px; font-size: 0.85rem;">
                            <?= $statusLabel ?>
                        </span>
                    </div>

                    <!-- Tabel Item / Layanan Jasa -->
                    <div class="table-responsive mb-4">
                        <table class="table align-middle mb-0" style="border-collapse: separate; border-spacing: 0;">
                            <thead>
                                <tr class="text-secondary extra-small fw-bold text-uppercase border-bottom border-light-subtle">
                                    <th class="ps-0 py-3" style="width: 50%;">Produk / Layanan</th>
                                    <th class="py-3 text-center" style="width: 20%;">Harga</th>
                                    <th class="py-3 text-center" style="width: 10%;">Qty</th>
                                    <th class="pe-0 py-3 text-end" style="width: 20%;">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-bottom border-light-subtle">
                                    <td class="ps-0 py-3">
                                        <div class="fw-bold text-dark" style="font-size: 0.95rem;">
                                            <?= htmlspecialchars($order['nama_jasa']) ?>
                                        </div>
                                        <?php if (!empty($order['deskripsi_masalah'])): ?>
                                            <div class="text-secondary extra-small mt-1 text-truncate" style="max-width: 380px;">
                                                <i class="fa-solid fa-wrench text-cyan me-1"></i> <?= htmlspecialchars($order['deskripsi_masalah']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 text-center text-dark fw-medium">
                                        Rp <?= number_format($order['total_harga'] ?? 0, 0, ',', '.') ?>
                                    </td>
                                    <td class="py-3 text-center text-dark fw-medium">
                                        1
                                    </td>
                                    <td class="pe-0 py-3 text-end fw-bold text-dark">
                                        Rp <?= number_format($order['total_harga'] ?? 0, 0, ',', '.') ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Total Pembayaran -->
                    <div class="d-flex align-items-center justify-content-end gap-3 pt-3 border-top border-light-subtle">
                        <span class="text-secondary fw-semibold">Total Pembayaran:</span>
                        <span class="fs-4 fw-extrabold text-success font-heading">
                            Rp <?= number_format($order['total_harga'] ?? 0, 0, ',', '.') ?>
                        </span>
                    </div>

                    <!-- Rincian Masalah & Catatan Pengerjaan -->
                    <?php if (!empty($order['deskripsi_masalah'])): ?>
                        <div class="mt-4 pt-3 border-top border-light-subtle">
                            <h6 class="fw-bold text-dark extra-small text-uppercase mb-2">
                                <i class="fa-solid fa-clipboard-list text-cyan me-1"></i> Keluhan &amp; Catatan Teknis:
                            </h6>
                            <div class="p-3 rounded-3 bg-light border border-light-subtle small text-dark leading-relaxed">
                                <?= nl2br(htmlspecialchars($order['deskripsi_masalah'])) ?>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

            <!-- ==========================================
                 KOLOM KANAN: UPDATE STATUS DENGAN WA AKTIF
                 ========================================== -->
            <div class="col-lg-4">
                
                <!-- 1. KARTU UPDATE STATUS PESANAN (PERSIS SEPERTI FOTO REKAN) -->
                <div class="card border-0 rounded-4 shadow-sm overflow-hidden mb-4">
                    
                    <!-- Blue Header with WA Aktif Badge -->
                    <div class="card-header border-0 px-4 py-3 d-flex align-items-center justify-content-between" style="background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);">
                        <h6 class="text-white fw-bold mb-0">Update Status Pesanan</h6>
                        <span class="badge bg-success bg-opacity-95 text-white extra-small fw-semibold px-2.5 py-1 rounded-pill d-inline-flex align-items-center gap-1 shadow-sm">
                            <i class="fa-brands fa-whatsapp"></i> WA Aktif
                        </span>
                    </div>

                    <!-- Card Body Form -->
                    <div class="card-body p-4 bg-white">
                        <form action="<?= BASE_URL ?>/admin/pesanan/update/<?= $order['id'] ?>" method="POST" id="formUpdateStatus">
                            <?= SecurityHelper::csrfField() ?>
                            <input type="hidden" name="from_detail" value="1">

                            <div class="mb-3">
                                <label for="selectStatus" class="form-label extra-small text-muted fw-bold text-uppercase mb-2">
                                    Pilih Status Baru:
                                </label>
                                <select name="status" id="selectStatus" class="form-select form-select-lg fw-semibold text-dark rounded-3" style="font-size: 0.92rem; border: 1.5px solid #cbd5e1;">
                                    <option value="pending" <?= ($st === 'pending' || $st === 'menunggu') ? 'selected' : '' ?>>
                                        ⏳ Pending (Menunggu Verifikasi)
                                    </option>
                                    <option value="dikonfirmasi" <?= ($st === 'dikonfirmasi' || $st === 'diverifikasi') ? 'selected' : '' ?>>
                                        📋 Confirmed (Terverifikasi Admin)
                                    </option>
                                    <option value="diproses" <?= ($st === 'diproses' || $st === 'dikerjakan') ? 'selected' : '' ?>>
                                        🛠️ Processing (Sedang Diproses)
                                    </option>
                                    <option value="shipped" <?= ($st === 'shipped') ? 'selected' : '' ?>>
                                        🚚 Shipped (Dalam Pengerjaan/Pengiriman)
                                    </option>
                                    <option value="selesai" <?= ($st === 'selesai' || $st === 'completed') ? 'selected' : '' ?>>
                                        ✅ Completed (Pesanan Selesai)
                                    </option>
                                    <option value="dibatalkan" <?= ($st === 'dibatalkan' || $st === 'cancelled') ? 'selected' : '' ?>>
                                        ❌ Cancelled (Batalkan Pesanan)
                                    </option>
                                </select>
                            </div>

                            <!-- Plotting Teknisi Siswa TEFA -->
                            <div class="mb-3">
                                <label for="selectTeknisi" class="form-label extra-small text-muted fw-bold text-uppercase mb-2">
                                    Teknisi Siswa (TEFA TKJ):
                                </label>
                                <select name="teknisi_id" id="selectTeknisi" class="form-select rounded-3" style="font-size: 0.875rem;">
                                    <option value="">-- Belum Ditugaskan --</option>
                                    <?php if (!empty($teknisiList)): ?>
                                        <?php foreach ($teknisiList as $tek): ?>
                                            <option value="<?= $tek['id'] ?>" <?= ($order['teknisi_id'] == $tek['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($tek['nama']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <!-- Catatan Tambahan Admin (Opsional dikirim via WhatsApp) -->
                            <div class="mb-3">
                                <label for="catatanAdmin" class="form-label extra-small text-muted fw-bold text-uppercase mb-1">
                                    Catatan Tambahan untuk Pelanggan (WA):
                                </label>
                                <textarea name="catatan_admin" id="catatanAdmin" rows="2" class="form-control rounded-3 extra-small" placeholder="Contoh: Teknisi kami akan datang ke lokasi pkl 10.00 WIB."></textarea>
                            </div>

                            <!-- WhatsApp Notification Alert Info -->
                            <div class="p-2.5 mb-3 rounded-3 bg-success bg-opacity-10 border border-success border-opacity-25 text-success extra-small d-flex align-items-center gap-2">
                                <i class="fa-brands fa-whatsapp fs-5 flex-shrink-0 text-success"></i>
                                <div>
                                    Notifikasi WhatsApp otomatis akan dikirim ke: <strong><?= htmlspecialchars($order['no_telepon'] ?? '-') ?></strong>
                                </div>
                            </div>

                            <!-- Submit Button -->
                            <button type="submit" class="btn btn-primary w-100 py-2.5 rounded-3 fw-bold d-flex align-items-center justify-content-center gap-2 shadow-sm" style="background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); border: none;">
                                <i class="fa-solid fa-floppy-disk"></i>
                                <span>Simpan &amp; Kirim Notifikasi WA</span>
                            </button>
                        </form>
                    </div>
                </div>

                <!-- 2. KARTU INFORMASI PENGIRIMAN / LOKASI -->
                <div class="card border border-light-subtle rounded-4 shadow-sm p-4 bg-white mb-3">
                    <h6 class="fw-bold text-dark mb-2">Informasi Pengiriman</h6>
                    <p class="text-secondary small mb-0 leading-relaxed">
                        <i class="fa-solid fa-location-dot text-danger me-1"></i>
                        <?= htmlspecialchars($order['alamat'] ?: 'Alamat tidak dicantumkan') ?>
                    </p>
                </div>

                <!-- 3. KARTU INFORMASI TRANSAKSI -->
                <div class="card border border-light-subtle rounded-4 shadow-sm p-4 bg-white mb-3">
                    <h6 class="fw-bold text-dark mb-3">Informasi Transaksi</h6>
                    <div class="vstack gap-2 extra-small">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted">Tanggal:</span>
                            <span class="fw-semibold text-dark">
                                <?= date('d M Y, H:i', strtotime($order['tanggal_pemesanan'])) ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted">No. Transaksi:</span>
                            <span class="fw-bold text-dark font-monospace">
                                <?= htmlspecialchars($kodeTrx) ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted">Pelanggan:</span>
                            <span class="fw-semibold text-dark">
                                <?= htmlspecialchars($order['nama_customer'] ?? 'Pelanggan') ?>
                            </span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="text-muted">No. WhatsApp:</span>
                            <span class="fw-semibold text-success font-monospace">
                                <?= htmlspecialchars($order['no_telepon'] ?? '-') ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Tombol Kembali ke Daftar Pesanan -->
                <a href="<?= BASE_URL ?>/admin/pesanan" class="btn btn-outline-secondary w-100 rounded-3 py-2 fw-semibold text-dark shadow-sm bg-white border-light-subtle">
                    Kembali ke Daftar Pesanan
                </a>

            </div>

        </div>

    </div>
</section>

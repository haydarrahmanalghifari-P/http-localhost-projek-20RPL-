<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfigurasi AI &amp; API Key | TKJ Smart Service Administrator</title>
    
    <!-- Google Fonts: Plus Jakarta Sans & Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- FontAwesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        :root {
            --sidebar-bg: #111827;
            --sidebar-active: #2563eb;
            --main-bg: #f8fafc;
            --card-border: #eef2f6;
            --text-dark: #0f172a;
            --text-muted: #64748b;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background-color: var(--main-bg);
            color: #1e293b;
            font-family: 'Plus Jakarta Sans', 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            font-size: 14px;
            -webkit-font-smoothing: antialiased;
        }

        .text-cyan {
            color: #06b6d4 !important;
        }

        /* ------------------ SIDEBAR ------------------ */
        .admin-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            background-color: var(--sidebar-bg);
            color: #dce6ef;
            padding: 20px 16px;
            display: flex;
            flex-direction: column;
            z-index: 1040;
            overflow-y: auto;
        }

        .sidebar-brand-wrapper {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 4px 6px 14px 6px;
        }

        .brand-logo-group {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: #ffffff;
        }

        .brand-shield-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: linear-gradient(135deg, #06b6d4 0%, #0284c7 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 19px;
            box-shadow: 0 4px 12px rgba(6, 182, 212, 0.4);
            flex-shrink: 0;
        }

        .brand-text-block strong {
            display: block;
            font-size: 15px;
            font-weight: 800;
            letter-spacing: -0.2px;
            color: #ffffff;
            line-height: 1.2;
        }

        .brand-text-block .badge-admin {
            display: inline-block;
            background: linear-gradient(135deg, #0891b2 0%, #0e7490 100%);
            color: #ffffff;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.8px;
            padding: 2px 8px;
            border-radius: 20px;
            text-transform: uppercase;
            margin-top: 3px;
        }

        .sidebar-close-btn {
            color: #64748b;
            font-size: 16px;
            cursor: pointer;
            transition: color 0.15s;
        }
        .sidebar-close-btn:hover { color: #ffffff; }

        /* User Pill Badge */
        .user-pill-container {
            margin: 10px 0 16px 0;
            background: #1f2937;
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 24px;
            padding: 7px 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .user-pill-icon {
            color: #f59e0b;
            font-size: 15px;
        }

        .user-pill-name {
            color: #f59e0b;
            font-size: 13.5px;
            font-weight: 700;
        }

        /* Sidebar Nav Links */
        .sidebar-nav {
            display: flex;
            flex-direction: column;
            gap: 3px;
            flex: 1;
        }

        .sidebar-nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: #94a3b8;
            padding: 11px 14px;
            border-radius: 10px;
            font-size: 13.5px;
            font-weight: 500;
            transition: all 0.15s ease;
        }

        .sidebar-nav-item i {
            font-size: 16px;
            width: 20px;
            text-align: center;
            color: #94a3b8;
            transition: color 0.15s ease;
        }

        .sidebar-nav-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
            color: #ffffff;
        }
        .sidebar-nav-item:hover i { color: #ffffff; }

        /* Active Nav Item: Blue Pill */
        .sidebar-nav-item.active {
            background-color: var(--sidebar-active);
            color: #ffffff;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.35);
        }
        .sidebar-nav-item.active i {
            color: #ffffff;
        }

        /* ------------------ MAIN CONTENT AREA ------------------ */
        .admin-main-wrapper {
            margin-left: 250px;
            min-height: 100vh;
            background-color: var(--main-bg);
            padding: 26px 32px;
            position: relative;
        }

        /* Top Header Card */
        .top-header-card {
            background: #ffffff;
            border: 1px solid var(--card-border);
            border-radius: 16px;
            padding: 16px 24px;
            box-shadow: 0 1px 3px rgba(15, 23, 42, 0.03);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }

        .header-icon-box {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: #ffffff;
            border: 1.5px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #1e293b;
            flex-shrink: 0;
        }

        .top-header-card h4 {
            font-size: 20px;
            font-weight: 800;
            color: var(--text-dark);
            margin: 0;
            letter-spacing: -0.3px;
        }

        .top-header-card .header-sub {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 2px;
        }

        .date-pill {
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            border-radius: 20px;
            padding: 6px 14px;
            font-size: 12.5px;
            color: #64748b;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-preview-customer {
            border: 1.5px solid #3b82f6;
            background: #ffffff;
            color: #2563eb;
            border-radius: 20px;
            padding: 6px 16px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.15s ease;
        }
        .btn-preview-customer:hover {
            background: #eff6ff;
            color: #1d4ed8;
        }

        /* Section Heading */
        .section-title-icon {
            font-size: 22px;
            color: #2563eb;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .section-main-title {
            font-size: 23px;
            font-weight: 800;
            color: var(--text-dark);
            margin: 0;
            letter-spacing: -0.4px;
        }

        .section-subtitle {
            font-size: 13.5px;
            color: var(--text-muted);
            margin-top: 4px;
            margin-bottom: 12px;
        }

        .btn-test-all {
            border: 1.5px solid #93c5fd;
            background: #ffffff;
            color: #2563eb;
            border-radius: 20px;
            padding: 7px 20px;
            font-weight: 600;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
            transition: all 0.15s ease;
        }
        .btn-test-all:hover {
            background: #eff6ff;
            border-color: #60a5fa;
            color: #1d4ed8;
        }

        /* 4 Stat Cards */
        .stat-widget-card {
            background: #ffffff;
            border: 1px solid var(--card-border);
            border-radius: 16px;
            padding: 20px 22px;
            box-shadow: 0 1px 3px rgba(15, 23, 42, 0.03);
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 100%;
        }

        .stat-widget-label {
            font-size: 13px;
            color: var(--text-muted);
            font-weight: 500;
            margin-bottom: 6px;
        }

        .stat-widget-val {
            font-size: 20px;
            font-weight: 800;
            color: var(--text-dark);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .stat-widget-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: grid;
            place-items: center;
            font-size: 20px;
            flex-shrink: 0;
        }

        .icon-mint { background: #ecfdf5; color: #10b981; }
        .icon-blue { background: #eff6ff; color: #3b82f6; }
        .icon-yellow { background: #fefce8; color: #eab308; }
        .icon-cyan { background: #ecfeff; color: #06b6d4; }

        /* Main Configuration Panels */
        .config-panel-card {
            background: #ffffff;
            border: 1px solid var(--card-border);
            border-radius: 16px;
            padding: 24px 26px;
            box-shadow: 0 1px 3px rgba(15, 23, 42, 0.03);
            height: 100%;
        }

        .config-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 6px;
        }

        .config-card-title {
            font-size: 17px;
            font-weight: 750;
            color: var(--text-dark);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .config-card-desc {
            font-size: 13px;
            color: var(--text-muted);
            line-height: 1.5;
            margin-bottom: 18px;
        }

        .badge-priority-1 {
            background-color: #2563eb;
            color: #ffffff;
            font-size: 11px;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 20px;
        }

        .badge-failover {
            background-color: #ecfdf5;
            color: #059669;
            font-size: 11px;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 20px;
        }

        /* Floating Action Button: Chatbot Customer (Bottom Right) */
        .floating-shield-btn {
            position: fixed;
            bottom: 28px;
            right: 28px;
            width: 54px;
            height: 54px;
            border-radius: 50%;
            background: linear-gradient(135deg, #06b6d4 0%, #0284c7 100%);
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            box-shadow: 0 10px 25px rgba(6, 182, 212, 0.45);
            border: none;
            cursor: pointer;
            z-index: 1050;
            text-decoration: none;
            transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.2s;
        }
        .floating-shield-btn:hover {
            transform: scale(1.08);
            box-shadow: 0 14px 30px rgba(6, 182, 212, 0.65);
            color: #ffffff;
        }

        @media (max-width: 992px) {
            .admin-sidebar { width: 76px; padding: 18px 8px; }
            .brand-text-block, .user-pill-container, .sidebar-nav-item span { display: none; }
            .sidebar-nav-item { justify-content: center; padding: 12px 0; }
            .admin-main-wrapper { margin-left: 76px; padding: 20px 16px; }
        }
    </style>
</head>
<body>

    <!-- ==================== LEFT SIDEBAR ==================== -->
    <aside class="admin-sidebar">
        
        <!-- Brand Header: TKJ Smart Service -->
        <div class="sidebar-brand-wrapper">
            <a href="<?= BASE_URL ?>/admin/dashboard" class="brand-logo-group">
                <div class="brand-shield-icon">
                    <i class="fa-solid fa-server"></i>
                </div>
                <div class="brand-text-block">
                    <strong>
                        <span>TKJ</span> <span class="text-cyan">Smart Service</span>
                    </strong>
                    <span class="badge-admin">ADMINISTRATOR</span>
                </div>
            </a>
            <div class="sidebar-close-btn d-none d-lg-block">
                <i class="fa-solid fa-xmark"></i>
            </div>
        </div>

        <!-- User Chip -->
        <div class="user-pill-container">
            <i class="fa-solid fa-circle-user user-pill-icon"></i>
            <span class="user-pill-name"><?= htmlspecialchars($user['nama'] ?? 'Admin') ?></span>
        </div>

        <!-- Sidebar Navigation Menu -->
        <nav class="sidebar-nav">
            <a href="<?= BASE_URL ?>/admin/dashboard" class="sidebar-nav-item">
                <i class="fa-solid fa-gauge-high"></i>
                <span>Dashboard Overview</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/users" class="sidebar-nav-item">
                <i class="fa-solid fa-users-gear"></i>
                <span>Kelola Pengguna</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/pesanan" class="sidebar-nav-item">
                <i class="fa-solid fa-clipboard-check"></i>
                <span>Verifikasi Pesanan</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/jasa" class="sidebar-nav-item">
                <i class="fa-solid fa-screwdriver-wrench"></i>
                <span>Katalog Layanan Jasa</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/pembayaran" class="sidebar-nav-item">
                <i class="fa-solid fa-credit-card"></i>
                <span>Transaksi Pembayaran</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/laporan" class="sidebar-nav-item">
                <i class="fa-solid fa-chart-line"></i>
                <span>Laporan TEFA</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/faq" class="sidebar-nav-item">
                <i class="fa-solid fa-circle-question"></i>
                <span>Basis Pengetahuan FAQ</span>
            </a>
            <!-- Active Item: Konfigurasi AI & API -->
            <a href="<?= BASE_URL ?>/admin/ai-config" class="sidebar-nav-item active">
                <i class="fa-solid fa-microchip"></i>
                <span>Konfigurasi AI &amp; API</span>
            </a>
        </nav>

        <!-- Sidebar Footer Links -->
        <div class="mt-auto pt-3 border-top border-secondary border-opacity-25 d-flex flex-column gap-1">
            <a href="<?= BASE_URL ?>/customer/ai-assistant" class="sidebar-nav-item text-cyan" title="Uji Coba AI Chatbot Langsung" target="_blank">
                <i class="fa-solid fa-robot"></i>
                <span>Chatbot Customer</span>
            </a>
            <a href="<?= BASE_URL ?>/logout" class="sidebar-nav-item text-danger" onclick="return confirm('Yakin ingin logout?')">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <!-- ==================== MAIN CONTENT AREA ==================== -->
    <main class="admin-main-wrapper">

        <!-- 1. Top Header Card: Title, Subtitle, Date, Pratinjau Customer -->
        <div class="top-header-card">
            <div class="d-flex align-items-center gap-3">
                <div class="header-icon-box">
                    <i class="fa-solid fa-server text-cyan fs-5"></i>
                </div>
                <div>
                    <h4>Konfigurasi AI &amp; API Key</h4>
                    <div class="header-sub">Panel Kontrol Manajemen Sistem TKJ Smart Service</div>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2">
                <div class="date-pill">
                    <i class="fa-regular fa-calendar"></i>
                    <span><?= date('d M Y') ?></span>
                </div>
                <a href="<?= BASE_URL ?>/customer/ai-assistant" class="btn-preview-customer" title="Buka Pratinjau AI Assistant Customer" target="_blank">
                    <i class="fa-regular fa-eye"></i>
                    <span>Pratinjau Chatbot Customer</span>
                </a>
            </div>
        </div>

        <!-- 2. Section Heading & Action Button -->
        <div class="mb-4">
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="section-title-icon">
                    <i class="fa-solid fa-microchip"></i>
                </span>
                <h3 class="section-main-title">Konfigurasi AI &amp; Multi API Key Cadangan</h3>
            </div>
            <p class="section-subtitle">
                Kelola API Key utama dan 3 cadangan otomatis agar Chatbot AI Layanan Jasa IT &amp; Asisten Konsultasi TKJ tidak pernah macet atau down saat kuota/limit habis.
            </p>
            <div>
                <button type="button" id="btnTestAllKeys" class="btn-test-all">
                    <i class="fa-solid fa-bolt text-primary"></i>
                    <span>Tes Semua API Key</span>
                </button>
            </div>
        </div>

        <!-- 3. 4 Stat Metric Cards -->
        <div class="row g-3 g-md-4 mb-4">
            <!-- Card 1: Status Kunci Utama -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-widget-card">
                    <div>
                        <div class="stat-widget-label">Status Kunci Utama</div>
                        <div class="stat-widget-val text-dark" id="statPrimaryKey">
                            <i class="fa-solid fa-circle-check text-success fs-5"></i>
                            <span>Terpasang</span>
                        </div>
                    </div>
                    <div class="stat-widget-icon icon-mint">
                        <i class="fa-solid fa-key"></i>
                    </div>
                </div>
            </div>

            <!-- Card 2: Cadangan Siaga -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-widget-card">
                    <div>
                        <div class="stat-widget-label">Cadangan Siaga</div>
                        <div class="stat-widget-val text-primary" id="statBackupCount">
                            3 dari 3 Cadangan
                        </div>
                    </div>
                    <div class="stat-widget-icon icon-blue">
                        <i class="fa-solid fa-layer-group"></i>
                    </div>
                </div>
            </div>

            <!-- Card 3: Auto-Failover -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-widget-card">
                    <div>
                        <div class="stat-widget-label">Auto-Failover</div>
                        <div class="stat-widget-val text-success" id="statAutoFailover">
                            <i class="fa-solid fa-circle-check text-success fs-5"></i>
                            <span>Aktif Otomatis</span>
                        </div>
                    </div>
                    <div class="stat-widget-icon icon-yellow">
                        <i class="fa-solid fa-arrows-rotate"></i>
                    </div>
                </div>
            </div>

            <!-- Card 4: Model AI Aktif -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-widget-card">
                    <div>
                        <div class="stat-widget-label">Model AI Aktif</div>
                        <div class="stat-widget-val text-dark font-monospace text-truncate" id="statModelName">
                            <?= htmlspecialchars($aiConfig['active_model'] ?? 'qwen/qwen3.8-27b') ?>
                        </div>
                    </div>
                    <div class="stat-widget-icon icon-cyan">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- 4. Form Konfigurasi: 2 Kolom (Kunci Utama & 3 API Key Cadangan) -->
        <form id="aiConfigForm" method="post" action="<?= BASE_URL ?>/admin/ai-config">
            <?= SecurityHelper::csrfField() ?>

            <div class="row g-4 mb-4">
                
                <!-- KOLOM KIRI: ⭐ Kunci Utama (Primary API Key) [Prioritas 1] -->
                <div class="col-lg-6">
                    <div class="config-panel-card">
                        
                        <!-- Header -->
                        <div class="config-card-header">
                            <h5 class="config-card-title">
                                <span class="text-warning">⭐</span>
                                <span>Kunci Utama (Primary API Key)</span>
                            </h5>
                            <span class="badge-priority-1">Prioritas 1</span>
                        </div>

                        <p class="config-card-desc">
                            Kunci ini akan selalu digunakan pertama kali oleh Chatbot AI Konsultasi dan Asisten Diagnosa Layanan Jasa IT TKJ Smart Service.
                        </p>

                        <!-- Pilihan Provider -->
                        <div class="mb-3">
                            <label class="form-label text-dark fw-bold small mb-1.5">Penyedia AI / Engine:</label>
                            <div class="d-flex flex-wrap gap-2">
                                <label class="btn btn-sm btn-outline-secondary rounded-pill px-3 provider-pill <?= ($aiConfig['primary_provider'] ?? 'gemini') === 'gemini' ? 'active' : '' ?>">
                                    <input type="radio" name="primary_provider" value="gemini" class="d-none" <?= ($aiConfig['primary_provider'] ?? 'gemini') === 'gemini' ? 'checked' : '' ?>>
                                    <i class="fa-brands fa-google text-primary me-1"></i> Google Gemini
                                </label>
                                <label class="btn btn-sm btn-outline-secondary rounded-pill px-3 provider-pill <?= ($aiConfig['primary_provider'] ?? '') === 'deepseek' ? 'active' : '' ?>">
                                    <input type="radio" name="primary_provider" value="deepseek" class="d-none" <?= ($aiConfig['primary_provider'] ?? '') === 'deepseek' ? 'checked' : '' ?>>
                                    <i class="fa-solid fa-brain text-info me-1"></i> DeepSeek AI
                                </label>
                                <label class="btn btn-sm btn-outline-secondary rounded-pill px-3 provider-pill <?= ($aiConfig['primary_provider'] ?? '') === 'grok' ? 'active' : '' ?>">
                                    <input type="radio" name="primary_provider" value="grok" class="d-none" <?= ($aiConfig['primary_provider'] ?? '') === 'grok' ? 'checked' : '' ?>>
                                    <i class="fa-solid fa-bolt text-warning me-1"></i> Groq / xAI
                                </label>
                                <label class="btn btn-sm btn-outline-secondary rounded-pill px-3 provider-pill <?= ($aiConfig['primary_provider'] ?? '') === 'database' ? 'active' : '' ?>">
                                    <input type="radio" name="primary_provider" value="database" class="d-none" <?= ($aiConfig['primary_provider'] ?? '') === 'database' ? 'checked' : '' ?>>
                                    <i class="fa-solid fa-database text-success me-1"></i> Smart DB (Lokal)
                                </label>
                            </div>
                        </div>

                        <!-- Model AI -->
                        <div class="mb-3">
                            <label class="form-label text-dark fw-bold small mb-1.5">Pilih Model AI:</label>
                            <select name="active_model" id="inputActiveModel" class="form-select form-select-sm rounded-3 py-2 font-monospace" style="font-size: 13px;">
                                <optgroup label="Google Gemini">
                                    <option value="gemini-3.5-flash-lite" <?= ($aiConfig['active_model'] ?? '') === 'gemini-3.5-flash-lite' ? 'selected' : '' ?>>gemini-3.5-flash-lite (Flash Cepat &amp; Akurat)</option>
                                    <option value="gemini-flash-latest" <?= ($aiConfig['active_model'] ?? '') === 'gemini-flash-latest' ? 'selected' : '' ?>>gemini-flash-latest</option>
                                    <option value="gemini-3.8-flash" <?= ($aiConfig['active_model'] ?? '') === 'gemini-3.8-flash' ? 'selected' : '' ?>>gemini-3.8-flash</option>
                                </optgroup>
                                <optgroup label="DeepSeek AI">
                                    <option value="deepseek-chat" <?= ($aiConfig['active_model'] ?? '') === 'deepseek-chat' ? 'selected' : '' ?>>deepseek-chat (DeepSeek-V3 Cepat)</option>
                                    <option value="deepseek-reasoner" <?= ($aiConfig['active_model'] ?? '') === 'deepseek-reasoner' ? 'selected' : '' ?>>deepseek-reasoner (DeepSeek-R1)</option>
                                </optgroup>
                                <optgroup label="Groq / xAI">
                                    <option value="qwen/qwen3.8-27b" <?= ($aiConfig['active_model'] ?? '') === 'qwen/qwen3.8-27b' ? 'selected' : '' ?>>qwen/qwen3.8-27b (Qwen Multitask)</option>
                                    <option value="grok-2-latest" <?= ($aiConfig['active_model'] ?? '') === 'grok-2-latest' ? 'selected' : '' ?>>grok-2-latest (xAI Grok)</option>
                                    <option value="grok-2" <?= ($aiConfig['active_model'] ?? '') === 'grok-2' ? 'selected' : '' ?>>grok-2</option>
                                </optgroup>
                                <optgroup label="Lokal / Offline">
                                    <option value="local-db-intent" <?= ($aiConfig['active_model'] ?? '') === 'local-db-intent' ? 'selected' : '' ?>>Smart DB Intent Matcher (MySQL Lokal)</option>
                                </optgroup>
                            </select>
                        </div>

                        <!-- Input Primary API Key -->
                        <div class="mb-3">
                            <div class="d-flex align-items-center justify-content-between mb-1.5">
                                <label class="form-label text-dark fw-bold small mb-0" id="primaryKeyLabel">
                                    <?= ($aiConfig['primary_provider'] ?? '') === 'deepseek' ? 'DeepSeek AI' : (($aiConfig['primary_provider'] ?? '') === 'grok' ? 'Groq / xAI' : 'Google Gemini') ?> API Key Utama:
                                </label>
                                <span class="badge bg-success bg-opacity-10 text-success extra-small fw-semibold py-1 px-2 rounded" id="primaryKeyStatusBadge">
                                    <i class="fa-solid fa-circle-check me-1"></i> Terhubung
                                </span>
                            </div>

                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted border-end-0">
                                    <i class="fa-solid fa-key"></i>
                                </span>
                                <input type="password" id="inputPrimaryKey" name="primary_key" class="form-control font-monospace border-start-0 border-end-0 py-2" style="font-size: 13px;" placeholder="Masukkan API Key utama (AQ.... / sk-...)" value="<?= htmlspecialchars($aiConfig['primary_key'] ?? '') ?>">
                                <button type="button" class="btn btn-light border border-start-0 text-muted btn-toggle-pw" data-target="inputPrimaryKey" title="Tampilkan / Sembunyikan">
                                    <i class="fa-regular fa-eye"></i>
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-copy-key" data-target="inputPrimaryKey" title="Salin Kunci">
                                    <i class="fa-regular fa-copy"></i>
                                </button>
                            </div>
                            <div class="d-flex align-items-center justify-content-between mt-1.5">
                                <small class="text-muted extra-small">Kunci tersinkronisasi langsung dengan engine AI chatbot layanan servis IT.</small>
                                <button type="button" class="btn btn-link extra-small text-decoration-none p-0 text-primary fw-semibold" id="btnFillDefaultPrimary">
                                    <i class="fa-solid fa-rotate-left me-1"></i>Isi Kunci Bawaan
                                </button>
                            </div>
                        </div>

                        <!-- Uji Kunci Utama Button -->
                        <div class="p-3 rounded-3 bg-light border mt-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                                <div>
                                    <span class="text-muted extra-small fw-semibold d-block">Uji Kecepatan Respon:</span>
                                    <span class="extra-small fw-bold text-dark" id="primaryPingResult">Response time: ~142ms (Aktif)</span>
                                </div>
                                <button type="button" class="btn btn-primary btn-sm rounded-pill px-3 fw-semibold btn-test-single" data-key-target="inputPrimaryKey" data-provider-name="auto" style="font-size: 12.5px;">
                                    <i class="fa-solid fa-play me-1"></i> Uji Kunci Ini
                                </button>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- KOLOM KANAN: 🛡️ 3 API Key Cadangan (Backup Keys) [Standby Failover] -->
                <div class="col-lg-6">
                    <div class="config-panel-card">
                        
                        <!-- Header -->
                        <div class="config-card-header">
                            <h5 class="config-card-title">
                                <i class="fa-solid fa-shield-halved text-success"></i>
                                <span>3 API Key Cadangan (Backup Keys)</span>
                            </h5>
                            <span class="badge-failover">Standby Failover</span>
                        </div>

                        <p class="config-card-desc">
                            Masukkan hingga 3 API Key cadangan dari Groq / Google. Ketika kuota kunci utama macet atau limit habis, sistem unit bisnis TKJ akan otomatis beralih ke kunci-kunci cadangan ini.
                        </p>

                        <!-- Auto-Failover Switch -->
                        <div class="p-2.5 px-3 rounded-3 mb-3 d-flex align-items-center justify-content-between" style="background: #f0fdf4; border: 1px solid #bbf7d0;">
                            <div class="d-flex align-items-center gap-2">
                                <i class="fa-solid fa-shield-halved text-success fs-5"></i>
                                <div>
                                    <strong class="text-dark extra-small d-block" style="font-size: 13px;">Auto-Failover Otomatis</strong>
                                    <span class="text-muted extra-small" style="font-size: 11.5px;">Beralih seketika saat API utama mengalami error 429 atau 503.</span>
                                </div>
                            </div>
                            <div class="form-check form-switch m-0 fs-5">
                                <input class="form-check-input" type="checkbox" role="switch" name="auto_failover" value="1" id="switchAutoFailover" <?= !empty($aiConfig['auto_failover']) ? 'checked' : '' ?>>
                            </div>
                        </div>

                        <!-- Backup Key 1 -->
                        <div class="mb-3">
                            <div class="d-flex align-items-center justify-content-between mb-1">
                                <label class="form-label text-dark fw-semibold extra-small mb-0">
                                    <span class="badge bg-secondary extra-small me-1">Cadangan 1</span> DeepSeek AI API Key (Prioritas 2):
                                </label>
                                <span class="extra-small text-muted font-monospace" id="pingBackup1">Siaga</span>
                            </div>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light text-muted border-end-0"><i class="fa-solid fa-brain text-info"></i></span>
                                <input type="password" id="inputBackup1" name="backup_key_1" class="form-control font-monospace border-start-0 border-end-0 py-1.5" style="font-size: 12.5px;" placeholder="sk-..." value="<?= htmlspecialchars($aiConfig['backup_key_1'] ?? '') ?>">
                                <input type="hidden" name="backup_provider_1" value="deepseek">
                                <button type="button" class="btn btn-light border border-start-0 text-muted btn-toggle-pw" data-target="inputBackup1">
                                    <i class="fa-regular fa-eye"></i>
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-test-single" data-key-target="inputBackup1" data-provider-name="deepseek" title="Uji Kunci Cadangan 1">
                                    <i class="fa-solid fa-play"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Backup Key 2 -->
                        <div class="mb-3">
                            <div class="d-flex align-items-center justify-content-between mb-1">
                                <label class="form-label text-dark fw-semibold extra-small mb-0">
                                    <span class="badge bg-secondary extra-small me-1">Cadangan 2</span> Kunci Cadangan Alternatif (Prioritas 3):
                                </label>
                                <span class="extra-small text-muted font-monospace" id="pingBackup2">Siaga (Kosong)</span>
                            </div>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light text-muted border-end-0"><i class="fa-solid fa-shield-halved text-muted"></i></span>
                                <input type="password" id="inputBackup2" name="backup_key_2" class="form-control font-monospace border-start-0 border-end-0 py-1.5" style="font-size: 12.5px;" placeholder="Opsional / Kosong (Standby)" value="<?= htmlspecialchars($aiConfig['backup_key_2'] ?? '') ?>">
                                <input type="hidden" name="backup_provider_2" value="">
                                <button type="button" class="btn btn-light border border-start-0 text-muted btn-toggle-pw" data-target="inputBackup2">
                                    <i class="fa-regular fa-eye"></i>
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-test-single" data-key-target="inputBackup2" data-provider-name="auto" title="Uji Kunci Cadangan 2">
                                    <i class="fa-solid fa-play"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Backup Key 3 -->
                        <div class="mb-3">
                            <div class="d-flex align-items-center justify-content-between mb-1">
                                <label class="form-label text-dark fw-semibold extra-small mb-0">
                                    <span class="badge bg-secondary extra-small me-1">Cadangan 3</span> Kunci Cadangan Alternatif (Prioritas 4):
                                </label>
                                <span class="extra-small text-muted font-monospace" id="pingBackup3">Siaga (Kosong)</span>
                            </div>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light text-muted border-end-0"><i class="fa-solid fa-shield-halved text-muted"></i></span>
                                <input type="password" id="inputBackup3" name="backup_key_3" class="form-control font-monospace border-start-0 border-end-0 py-1.5" style="font-size: 12.5px;" placeholder="Opsional / Kosong (Standby)" value="<?= htmlspecialchars($aiConfig['backup_key_3'] ?? '') ?>">
                                <input type="hidden" name="backup_provider_3" value="">
                                <button type="button" class="btn btn-light border border-start-0 text-muted btn-toggle-pw" data-target="inputBackup3">
                                    <i class="fa-regular fa-eye"></i>
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-test-single" data-key-target="inputBackup3" data-provider-name="auto" title="Uji Kunci Cadangan 3">
                                    <i class="fa-solid fa-play"></i>
                                </button>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

            <!-- Bottom Floating Save Bar -->
            <div class="card border-0 rounded-4 shadow-sm p-3 mb-5" style="background: #ffffff; border: 1px solid var(--card-border) !important;">
                <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-3">
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-primary bg-opacity-10 text-primary p-2 rounded-circle">
                            <i class="fa-solid fa-floppy-disk fs-5"></i>
                        </span>
                        <div>
                            <strong class="text-dark small d-block">Simpan Perubahan Konfigurasi</strong>
                            <small class="text-muted extra-small">Pengaturan akan langsung disinkronkan ke server AI TKJ Smart Service.</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <button type="reset" class="btn btn-outline-secondary rounded-pill px-3 py-2 btn-sm fw-semibold">
                            <i class="fa-solid fa-rotate-left me-1"></i> Reset Form
                        </button>
                        <button type="submit" id="btnSaveConfig" class="btn btn-primary rounded-pill px-4 py-2 btn-sm fw-bold shadow-sm" style="background-color: #2563eb; border-color: #2563eb;">
                            <i class="fa-solid fa-check me-1"></i> Simpan Konfigurasi
                        </button>
                    </div>
                </div>
            </div>

        </form>

        <!-- Floating Chatbot Customer Action Button (Bottom Right) -->
        <a href="<?= BASE_URL ?>/customer/ai-assistant" class="floating-shield-btn" title="Buka Pratinjau Chatbot AI Customer" target="_blank">
            <i class="fa-solid fa-robot"></i>
        </a>

    </main>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Interactive Script -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        
        // 1. Toggle Show / Hide Password
        document.querySelectorAll('.btn-toggle-pw').forEach(btn => {
            btn.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const input = document.getElementById(targetId);
                if (!input) return;
                const icon = this.querySelector('i');
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.className = 'fa-regular fa-eye-slash';
                } else {
                    input.type = 'password';
                    icon.className = 'fa-regular fa-eye';
                }
            });
        });

        // 2. Copy Key to Clipboard
        document.querySelectorAll('.btn-copy-key').forEach(btn => {
            btn.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const input = document.getElementById(targetId);
                if (!input || !input.value) return;
                navigator.clipboard.writeText(input.value).then(() => {
                    const icon = this.querySelector('i');
                    icon.className = 'fa-solid fa-check text-success';
                    setTimeout(() => { icon.className = 'fa-regular fa-copy'; }, 2000);
                });
            });
        });

        // 3. Verified Default Keys Dictionary
        const DEFAULT_KEYS = {
            gemini: 'AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw',
            deepseek: 'sk-70e0eb2e9efe49fa967af6da72b5cda9',
            grok: '',
            database: ''
        };

        // Provider Pill Change
        document.querySelectorAll('.provider-pill').forEach(label => {
            label.addEventListener('click', function() {
                document.querySelectorAll('.provider-pill').forEach(l => l.classList.remove('active', 'btn-primary', 'text-white'));
                this.classList.add('active');
                const radio = this.querySelector('input[type="radio"]');
                if (radio) {
                    radio.checked = true;
                    const selectModel = document.getElementById('inputActiveModel');
                    const primaryInput = document.getElementById('inputPrimaryKey');
                    const primaryBtn = document.querySelector('.btn-test-single[data-key-target="inputPrimaryKey"]');
                    const primaryLabel = document.getElementById('primaryKeyLabel');

                    if (radio.value === 'gemini') {
                        if (selectModel) selectModel.value = 'gemini-3.5-flash-lite';
                        document.getElementById('statModelName').innerText = 'gemini-3.5-flash-lite';
                        if (primaryBtn) primaryBtn.setAttribute('data-provider-name', 'gemini');
                        if (primaryLabel) primaryLabel.innerText = 'Google Gemini API Key Utama:';
                        if (primaryInput && (!primaryInput.value.trim() || primaryInput.value.startsWith('grok_') || primaryInput.value.startsWith('sk-'))) {
                            primaryInput.value = DEFAULT_KEYS.gemini;
                            primaryInput.dispatchEvent(new Event('input'));
                        }
                    } else if (radio.value === 'deepseek') {
                        if (selectModel) selectModel.value = 'deepseek-chat';
                        document.getElementById('statModelName').innerText = 'deepseek-chat';
                        if (primaryBtn) primaryBtn.setAttribute('data-provider-name', 'deepseek');
                        if (primaryLabel) primaryLabel.innerText = 'DeepSeek AI API Key Utama:';
                        if (primaryInput && (!primaryInput.value.trim() || primaryInput.value.startsWith('grok_') || primaryInput.value.startsWith('AQ.'))) {
                            primaryInput.value = DEFAULT_KEYS.deepseek;
                            primaryInput.dispatchEvent(new Event('input'));
                        }
                    } else if (radio.value === 'grok') {
                        if (selectModel) selectModel.value = 'grok-2-latest';
                        document.getElementById('statModelName').innerText = 'grok-2-latest';
                        if (primaryBtn) primaryBtn.setAttribute('data-provider-name', 'grok');
                        if (primaryLabel) primaryLabel.innerText = 'Groq / xAI API Key Utama:';
                    } else if (radio.value === 'database') {
                        if (selectModel) selectModel.value = 'local-db-intent';
                        document.getElementById('statModelName').innerText = 'local-db-intent';
                        if (primaryBtn) primaryBtn.setAttribute('data-provider-name', 'database');
                        if (primaryLabel) primaryLabel.innerText = 'Smart DB Matcher (Lokal MySQL):';
                    }
                }
            });
        });

        // 3b. Isi Kunci Bawaan Button
        const btnFillDefaultPrimary = document.getElementById('btnFillDefaultPrimary');
        if (btnFillDefaultPrimary) {
            btnFillDefaultPrimary.addEventListener('click', function(e) {
                e.preventDefault();
                const activeRadio = document.querySelector('input[name="primary_provider"]:checked');
                const provider = activeRadio ? activeRadio.value : 'gemini';
                const primaryInput = document.getElementById('inputPrimaryKey');
                if (DEFAULT_KEYS[provider]) {
                    primaryInput.value = DEFAULT_KEYS[provider];
                } else if (provider === 'gemini') {
                    primaryInput.value = DEFAULT_KEYS.gemini;
                } else if (provider === 'deepseek') {
                    primaryInput.value = DEFAULT_KEYS.deepseek;
                } else {
                    primaryInput.value = '';
                }
                primaryInput.dispatchEvent(new Event('input'));
                
                // Otomatis picu pengujian kunci
                const testBtn = document.querySelector('.btn-test-single[data-key-target="inputPrimaryKey"]');
                if (testBtn) testBtn.click();
            });
        }

        // 4. Model change reflects in top stat card
        const selectModel = document.getElementById('inputActiveModel');
        if (selectModel) {
            selectModel.addEventListener('change', function() {
                document.getElementById('statModelName').innerText = this.value;
            });
        }

        // 5. Auto-Failover Switch reflects in top card
        const switchFailover = document.getElementById('switchAutoFailover');
        if (switchFailover) {
            switchFailover.addEventListener('change', function() {
                const statEl = document.getElementById('statAutoFailover');
                if (this.checked) {
                    statEl.innerHTML = '<i class="fa-solid fa-circle-check text-success fs-5"></i> <span>Aktif Otomatis</span>';
                    statEl.className = 'stat-widget-val text-success';
                } else {
                    statEl.innerHTML = '<i class="fa-solid fa-circle-xmark text-danger fs-5"></i> <span>Nonaktif</span>';
                    statEl.className = 'stat-widget-val text-danger';
                }
            });
        }

        // Helper: Deteksi Provider dari prefix Key
        function detectKeyProvider(keyStr) {
            if (!keyStr) return 'gemini';
            if (keyStr.startsWith('gsk_')) return 'groq';
            if (keyStr.startsWith('sk-proj-')) return 'openai';
            if (keyStr.startsWith('sk-')) return 'deepseek';
            if (keyStr.startsWith('AQ.') || keyStr.startsWith('AIzaSy')) return 'gemini';
            if (keyStr.startsWith('grok_') || keyStr.startsWith('xai-')) return 'grok';
            return 'auto';
        }

        // Live Icon & Provider detection saat user mengetik / menempelkan API key
        ['inputPrimaryKey', 'inputBackup1', 'inputBackup2', 'inputBackup3'].forEach(id => {
            const input = document.getElementById(id);
            if (!input) return;
            const group = input.closest('.input-group');
            const iconSpan = group ? group.querySelector('.input-group-text') : null;
            function updateKeyBadge() {
                const val = input.value.trim();
                const provider = detectKeyProvider(val);
                if (iconSpan) {
                    if (!val) {
                        if (id === 'inputBackup3') {
                            iconSpan.innerHTML = '<i class="fa-solid fa-shield-halved text-muted" title="Slot Cadangan Alternatif"></i>';
                        }
                    } else if (provider === 'groq') {
                        iconSpan.innerHTML = '<i class="fa-solid fa-bolt text-danger" title="Groq LPU Key (Llama 3)"></i>';
                    } else if (provider === 'openai') {
                        iconSpan.innerHTML = '<i class="fa-solid fa-cube text-success" title="OpenAI API Key"></i>';
                    } else if (provider === 'deepseek') {
                        iconSpan.innerHTML = '<i class="fa-solid fa-brain text-info" title="DeepSeek AI Key"></i>';
                    } else if (provider === 'gemini') {
                        iconSpan.innerHTML = '<i class="fa-brands fa-google text-primary" title="Google Gemini Key"></i>';
                    } else if (provider === 'grok') {
                        iconSpan.innerHTML = '<i class="fa-solid fa-bolt text-warning" title="xAI Grok Key"></i>';
                    }
                }
            }
            input.addEventListener('input', updateKeyBadge);
            updateKeyBadge();
        });

        // 6. Test Single Key Function
        async function testKey(key, provider) {
            if (!key) return { status: 'error', message: 'Kunci kosong' };
            try {
                const res = await fetch('<?= BASE_URL ?>/ai/test-key', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ key: key, provider: provider })
                });
                return await res.json();
            } catch (e) {
                return { status: 'error', message: e.message, latency: 'timeout' };
            }
        }

        // Single Key Test Button Listener
        document.querySelectorAll('.btn-test-single').forEach(btn => {
            btn.addEventListener('click', async function() {
                const targetId = this.getAttribute('data-key-target');
                let provider = this.getAttribute('data-provider-name') || 'auto';
                const input = document.getElementById(targetId);
                if (!input || !input.value.trim()) {
                    alert('Silakan masukkan API Key terlebih dahulu.');
                    return;
                }

                const rawVal = input.value.trim();
                const detected = detectKeyProvider(rawVal);
                if (detected !== 'auto') {
                    provider = detected;
                }

                const originalHtml = this.innerHTML;
                this.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
                this.disabled = true;

                const res = await testKey(rawVal, provider);
                this.innerHTML = originalHtml;
                this.disabled = false;

                const displayProvider = res.provider || provider;
                const statusHtml = res.status === 'success' 
                    ? '<span class="text-success fw-bold">✓ ' + res.latency + ' (' + displayProvider + ')</span>' 
                    : '<span class="text-danger fw-bold" title="' + (res.message || 'Error') + '">✕ ' + (res.message || 'Error') + '</span>';

                if (targetId === 'inputPrimaryKey') {
                    const badge = document.getElementById('primaryKeyStatusBadge');
                    const pingText = document.getElementById('primaryPingResult');
                    if (res.status === 'success') {
                        badge.className = 'badge bg-success bg-opacity-10 text-success extra-small fw-semibold py-1 px-2 rounded';
                        badge.innerHTML = '<i class="fa-solid fa-circle-check me-1"></i> Terhubung (' + res.latency + ')';
                        pingText.innerHTML = '<span class="text-success fw-bold">✓ Terhubung</span> - Latency: ' + res.latency + ' (' + displayProvider + ')';
                    } else {
                        badge.className = 'badge bg-danger bg-opacity-10 text-danger extra-small fw-semibold py-1 px-2 rounded';
                        badge.innerHTML = '<i class="fa-solid fa-triangle-exclamation me-1"></i> Gagal';
                        pingText.innerHTML = '<span class="text-danger fw-bold">✕ ' + (res.message || 'Error') + '</span>';
                    }
                } else if (targetId === 'inputBackup1') {
                    document.getElementById('pingBackup1').innerHTML = statusHtml;
                } else if (targetId === 'inputBackup2') {
                    document.getElementById('pingBackup2').innerHTML = statusHtml;
                } else if (targetId === 'inputBackup3') {
                    document.getElementById('pingBackup3').innerHTML = statusHtml;
                }
            });
        });

        // 7. Test All Keys Button
        const btnTestAll = document.getElementById('btnTestAllKeys');
        if (btnTestAll) {
            btnTestAll.addEventListener('click', async function() {
                const originalHtml = this.innerHTML;
                this.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Menguji Semua Kunci...';
                this.disabled = true;

                const singleButtons = document.querySelectorAll('.btn-test-single');
                for (const btn of singleButtons) {
                    btn.click();
                    await new Promise(r => setTimeout(r, 600));
                }

                this.innerHTML = '<i class="fa-solid fa-check text-success me-1"></i> Pengujian Selesai!';
                setTimeout(() => {
                    this.innerHTML = originalHtml;
                    this.disabled = false;
                }, 3000);
            });
        }

        // 8. Form Submit via AJAX
        const form = document.getElementById('aiConfigForm');
        if (form) {
            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                const btn = document.getElementById('btnSaveConfig');
                const originalText = btn.innerHTML;
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Menyimpan...';
                btn.disabled = true;

                const formData = new FormData(this);
                const dataObj = {};
                formData.forEach((value, key) => { dataObj[key] = value; });
                dataObj['auto_failover'] = document.getElementById('switchAutoFailover').checked ? 1 : 0;

                try {
                    const res = await fetch('<?= BASE_URL ?>/admin/ai-config', {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify(dataObj)
                    });
                    const result = await res.json();
                    
                    btn.innerHTML = '<i class="fa-solid fa-check text-white me-1"></i> Berhasil Disimpan!';
                    setTimeout(() => {
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                    }, 2000);
                } catch (err) {
                    alert('Gagal menyimpan: ' + err.message);
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                }
            });
        }

    });
    </script>
</body>
</html>

<section class="py-5">
    <div class="container">
        
        <?php $flashSuccess = AuthHelper::getFlash('admin_success') ?? AuthHelper::getFlash('auth_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 border-0 shadow-sm" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php $flashError = AuthHelper::getFlash('admin_error') ?? AuthHelper::getFlash('auth_error'); ?>
        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 border-0 shadow-sm" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= htmlspecialchars($flashError['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Banner Administrator Superuser -->
        <div class="p-4 p-md-5 rounded-4 glass-card border border-danger border-opacity-50 mb-4 position-relative overflow-hidden shadow-lg">
            <div class="position-absolute end-0 top-0 translate-middle-y me-4 opacity-10 d-none d-lg-block pointer-events-none">
                <i class="fa-solid fa-user-shield text-white" style="font-size: 16rem;"></i>
            </div>
            <div class="row align-items-center position-relative z-1">
                <div class="col-lg-8">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <span class="badge bg-danger text-white fw-bold rounded-pill px-3 py-1 extra-small">
                            <i class="fa-solid fa-shield-halved me-1"></i> SUPERUSER ADMINISTRATOR
                        </span>
                        <span class="badge bg-cyan text-dark fw-bold rounded-pill px-3 py-1 extra-small">
                            <i class="fa-solid fa-server me-1"></i> Full Access Control
                        </span>
                    </div>
                    <h2 class="fw-extrabold text-white mb-2">
                        Dashboard Administrator, <span class="text-cyan"><?= htmlspecialchars($user['nama']) ?></span>!
                    </h2>
                    <p class="text-white-50 mb-3">
                        Pusat kendali tertinggi sistem unit bisnis <strong>TKJ Smart Service</strong>. Anda memiliki otoritas penuh untuk mengelola pengguna (semua role), monitoring pesanan, transaksi keuangan, layanan jasa, dan integrasi AI.
                    </p>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?= BASE_URL ?>/admin/users" class="btn btn-cyan btn-sm fw-bold px-3 py-2 rounded-pill shadow-sm">
                            <i class="fa-solid fa-users-gear me-1"></i> Kelola Semua Pengguna
                        </a>
                        <a href="<?= BASE_URL ?>/admin/pesanan" class="btn btn-warning text-dark btn-sm fw-bold px-3 py-2 rounded-pill shadow-sm">
                            <i class="fa-solid fa-clipboard-check me-1"></i> Verifikasi Pesanan Jasa
                            <?php if (!empty($countPendingOrders)): ?>
                                <span class="badge bg-danger text-white ms-1"><?= $countPendingOrders ?></span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 text-center text-lg-end mt-4 mt-lg-0">
                    <div class="d-inline-flex p-4 rounded-circle bg-danger bg-opacity-10 border border-danger border-opacity-25 shadow">
                        <i class="fa-solid fa-user-shield display-3 text-danger"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alert Banner Khusus: Pesanan Perlu Verifikasi Admin -->
        <?php if (!empty($countPendingOrders) && $countPendingOrders > 0): ?>
            <div class="alert alert-warning border border-warning border-opacity-50 rounded-4 p-3 mb-4 d-flex align-items-center justify-content-between flex-wrap gap-2 shadow-sm">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-2 rounded-circle bg-warning text-dark"><i class="fa-solid fa-bell-concierge fs-5"></i></div>
                    <div>
                        <strong class="text-white">Ada <?= $countPendingOrders ?> Pesanan Jasa Baru Menunggu Verifikasi Admin!</strong>
                        <div class="extra-small text-white-50">Silakan lakukan verifikasi dan persetujuan pesanan agar teknisi dapat mulai bertugas.</div>
                    </div>
                </div>
                <a href="<?= BASE_URL ?>/admin/pesanan?status=pending" class="btn btn-warning text-dark fw-bold btn-sm rounded-pill px-3 py-1.5 shadow-sm">
                    <i class="fa-solid fa-clipboard-check me-1"></i> Verifikasi Sekarang
                </a>
            </div>
        <?php endif; ?>

        <!-- Metric Widgets Ringkasan Sistem -->
        <div class="row g-4 mb-4">
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100 shadow-sm hover-lift transition">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Pengguna</div>
                        <span class="badge bg-cyan bg-opacity-10 text-cyan rounded-circle p-2"><i class="fa-solid fa-users"></i></span>
                    </div>
                    <div class="fs-2 fw-extrabold text-white mb-1"><?= $userStats['total'] ?? 0 ?></div>
                    <div class="extra-small text-white-50">
                        <span class="text-info"><?= $userStats['customer'] ?? 0 ?></span> Cust • 
                        <span class="text-cyan"><?= $userStats['teknisi'] ?? 0 ?></span> Tek • 
                        <span class="text-warning"><?= $userStats['operator'] ?? 0 ?></span> Op
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100 shadow-sm hover-lift transition">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Pesanan</div>
                        <span class="badge bg-warning bg-opacity-10 text-warning rounded-circle p-2"><i class="fa-solid fa-cart-shopping"></i></span>
                    </div>
                    <div class="fs-2 fw-extrabold text-warning mb-1"><?= $countOrders ?></div>
                    <div class="extra-small text-white-50">Semua pesanan masuk</div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100 shadow-sm hover-lift transition">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div class="text-white-50 extra-small fw-semibold text-uppercase">Katalog Jasa</div>
                        <span class="badge bg-info bg-opacity-10 text-info rounded-circle p-2"><i class="fa-solid fa-screwdriver-wrench"></i></span>
                    </div>
                    <div class="fs-2 fw-extrabold text-info mb-1"><?= $countServices ?></div>
                    <div class="extra-small text-white-50">Layanan IT aktif</div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="p-4 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100 shadow-sm hover-lift transition">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div class="text-white-50 extra-small fw-semibold text-uppercase">Total Omset TEFA</div>
                        <span class="badge bg-success bg-opacity-10 text-success rounded-circle p-2"><i class="fa-solid fa-wallet"></i></span>
                    </div>
                    <div class="fs-2 fw-extrabold text-success mb-1">Rp <?= number_format($summary['total_revenue'] ?? 2000000, 0, ',', '.') ?></div>
                    <div class="extra-small text-white-50">Omset unit bisnis</div>
                </div>
            </div>
        </div>

        <!-- Shortcut Modul Navigasi Administrator -->
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h5 class="fw-bold text-white mb-0">
                <i class="fa-solid fa-cubes-stacked text-cyan me-2"></i> Modul Kendali Sistem Administrator
            </h5>
            <span class="extra-small text-white-50">Akses Cepat Semua Modul</span>
        </div>

        <div class="row g-3 mb-5">
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/admin/users" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm">
                    <i class="fa-solid fa-users-gear fs-5 text-cyan"></i>
                    <span>Kelola Pengguna</span>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/admin/pesanan" class="btn btn-outline-warning w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm position-relative">
                    <i class="fa-solid fa-clipboard-check fs-5 text-warning"></i>
                    <span>Verifikasi Pesanan</span>
                    <?php if (!empty($countPendingOrders)): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?= $countPendingOrders ?>
                        </span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/operator/jasa" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm">
                    <i class="fa-solid fa-screwdriver-wrench fs-5 text-info"></i>
                    <span>Katalog Jasa</span>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/operator/pembayaran" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm">
                    <i class="fa-solid fa-credit-card fs-5 text-success"></i>
                    <span>Pembayaran</span>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/operator/laporan" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm">
                    <i class="fa-solid fa-chart-line fs-5 text-primary"></i>
                    <span>Laporan TEFA</span>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/operator/faq" class="btn btn-outline-warning w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm">
                    <i class="fa-solid fa-circle-question fs-5 text-warning"></i>
                    <span>Kelola FAQ AI</span>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/kepala-sekolah/dashboard" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm">
                    <i class="fa-solid fa-chart-pie fs-5 text-purple"></i>
                    <span>Monitoring Eksekutif</span>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/admin/ai-config" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm border-cyan">
                    <i class="fa-solid fa-microchip fs-5 text-cyan"></i>
                    <span>Konfigurasi AI &amp; API Key</span>
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/operator/review" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2 h-100 shadow-sm">
                    <i class="fa-solid fa-star fs-5 text-warning"></i>
                    <span>Ulasan Pelanggan</span>
                </a>
            </div>
        </div>

        <!-- 2 Kolom: Pengguna Terbaru & Pesanan Terbaru -->
        <div class="row g-4">
            <!-- Pengguna Terdaftar Terbaru -->
            <div class="col-lg-6">
                <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 h-100 shadow-sm">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h5 class="fw-bold text-white mb-0">
                            <i class="fa-solid fa-user-plus text-cyan me-2"></i> Pengguna Terbaru
                        </h5>
                        <a href="<?= BASE_URL ?>/admin/users" class="extra-small text-cyan fw-bold text-decoration-none">
                            Lihat Semua <i class="fa-solid fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-dark table-hover align-middle mb-0 extra-small">
                            <thead>
                                <tr class="text-white-50 border-secondary">
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($recentUsers)): ?>
                                    <?php foreach ($recentUsers as $u): ?>
                                        <tr>
                                            <td class="fw-bold text-white"><?= htmlspecialchars($u['nama']) ?></td>
                                            <td class="text-white-50"><?= htmlspecialchars($u['email']) ?></td>
                                            <td>
                                                <?php
                                                    $roleBadges = [
                                                        'admin' => 'bg-danger text-white',
                                                        'operator' => 'bg-warning text-dark',
                                                        'teknisi' => 'bg-info text-dark',
                                                        'kepala_sekolah' => 'bg-primary text-white',
                                                        'customer' => 'bg-success text-white'
                                                    ];
                                                    $badgeClass = $roleBadges[$u['role']] ?? 'bg-secondary text-white';
                                                ?>
                                                <span class="badge <?= $badgeClass ?> rounded-pill px-2 py-1 extra-small">
                                                    <?= strtoupper(str_replace('_', ' ', $u['role'])) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-white-50 py-3">Belum ada pengguna.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Pesanan Terbaru -->
            <div class="col-lg-6">
                <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 h-100 shadow-sm">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h5 class="fw-bold text-white mb-0">
                            <i class="fa-solid fa-clock-rotate-left text-warning me-2"></i> Pesanan Terbaru
                        </h5>
                        <a href="<?= BASE_URL ?>/admin/pesanan" class="extra-small text-warning fw-bold text-decoration-none">
                            Verifikasi Pesanan <i class="fa-solid fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-dark table-hover align-middle mb-0 extra-small">
                            <thead>
                                <tr class="text-white-50 border-secondary">
                                    <th>Kode</th>
                                    <th>Layanan</th>
                                    <th>Status</th>
                                    <th class="text-end">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($recentOrders)): ?>
                                    <?php foreach ($recentOrders as $ord): ?>
                                        <?php 
                                            $st = strtolower($ord['status']);
                                            $isPending = ($st === 'pending' || $st === 'menunggu');
                                        ?>
                                        <tr>
                                            <td class="fw-bold text-cyan">#<?= htmlspecialchars($ord['kode_pesanan']) ?></td>
                                            <td class="text-white"><?= htmlspecialchars($ord['nama_jasa'] ?? '-') ?></td>
                                            <td>
                                                <?php
                                                    $stBadges = [
                                                        'pending' => 'bg-warning text-dark',
                                                        'dikonfirmasi' => 'bg-info text-dark',
                                                        'diproses' => 'bg-primary text-white',
                                                        'selesai' => 'bg-success text-white',
                                                        'dibatalkan' => 'bg-danger text-white'
                                                    ];
                                                    $stClass = $stBadges[$ord['status']] ?? 'bg-secondary';
                                                ?>
                                                <span class="badge <?= $stClass ?> rounded-pill px-2 py-1 extra-small">
                                                    <?= strtoupper($ord['status']) ?>
                                                </span>
                                            </td>
                                            <td class="text-end">
                                                <?php if ($isPending): ?>
                                                    <a href="<?= BASE_URL ?>/admin/pesanan?status=pending" class="btn btn-warning btn-sm py-0 px-2 extra-small fw-bold text-dark shadow-sm">
                                                        <i class="fa-solid fa-check me-1"></i> Verifikasi
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?= BASE_URL ?>/admin/pesanan" class="btn btn-outline-secondary btn-sm py-0 px-2 extra-small text-white-50">
                                                        Detail
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-white-50 py-3">Belum ada pesanan masuk.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

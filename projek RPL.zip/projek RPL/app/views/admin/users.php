<section class="py-5">
    <div class="container">

        <!-- Breadcrumb & Header -->
        <nav aria-label="breadcrumb" class="mb-3">
            <ol class="breadcrumb extra-small">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/admin/dashboard" class="text-cyan text-decoration-none"><i class="fa-solid fa-gauge me-1"></i> Dashboard</a></li>
                <li class="breadcrumb-item active text-white-50" aria-current="page">Manajemen Pengguna</li>
            </ol>
        </nav>

        <?php $flashSuccess = AuthHelper::getFlash('admin_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 border-0 shadow-sm" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php $flashError = AuthHelper::getFlash('admin_error'); ?>
        <?php if ($flashError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 border-0 shadow-sm" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= htmlspecialchars($flashError['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Title & Action Bar -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <h3 class="fw-extrabold text-white mb-1">
                    <i class="fa-solid fa-users-gear text-cyan me-2"></i> Manajemen Seluruh Pengguna
                </h3>
                <p class="text-white-50 small mb-0">
                    Kelola akun, hak akses role (Admin, Operator, Teknisi, Kepala Sekolah, Customer), dan password pengguna.
                </p>
            </div>
            <button type="button" class="btn btn-cyan fw-bold rounded-pill px-4 py-2 shadow-sm d-inline-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#modalTambahUser">
                <i class="fa-solid fa-user-plus"></i> Tambah Pengguna Baru
            </button>
        </div>

        <!-- Role Filter Tabs / Pills -->
        <div class="d-flex flex-wrap gap-2 mb-4">
            <a href="<?= BASE_URL ?>/admin/users" class="btn btn-sm rounded-pill px-3 py-2 <?= empty($currentFilter) ? 'btn-cyan fw-bold' : 'btn-outline-secondary text-white-50' ?>">
                Semua Role <span class="badge bg-dark ms-1"><?= $userStats['total'] ?? 0 ?></span>
            </a>
            <a href="<?= BASE_URL ?>/admin/users?role=admin" class="btn btn-sm rounded-pill px-3 py-2 <?= $currentFilter === 'admin' ? 'btn-danger text-white fw-bold' : 'btn-outline-danger' ?>">
                <i class="fa-solid fa-shield-halved me-1"></i> Admin <span class="badge bg-dark ms-1"><?= $userStats['admin'] ?? 0 ?></span>
            </a>
            <a href="<?= BASE_URL ?>/admin/users?role=operator" class="btn btn-sm rounded-pill px-3 py-2 <?= $currentFilter === 'operator' ? 'btn-warning text-dark fw-bold' : 'btn-outline-warning' ?>">
                <i class="fa-solid fa-sliders me-1"></i> Operator <span class="badge bg-dark ms-1"><?= $userStats['operator'] ?? 0 ?></span>
            </a>
            <a href="<?= BASE_URL ?>/admin/users?role=teknisi" class="btn btn-sm rounded-pill px-3 py-2 <?= $currentFilter === 'teknisi' ? 'btn-info text-dark fw-bold' : 'btn-outline-info' ?>">
                <i class="fa-solid fa-user-gear me-1"></i> Teknisi Siswa <span class="badge bg-dark ms-1"><?= $userStats['teknisi'] ?? 0 ?></span>
            </a>
            <a href="<?= BASE_URL ?>/admin/users?role=kepala_sekolah" class="btn btn-sm rounded-pill px-3 py-2 <?= $currentFilter === 'kepala_sekolah' ? 'btn-primary text-white fw-bold' : 'btn-outline-primary' ?>">
                <i class="fa-solid fa-chart-pie me-1"></i> Kepala Sekolah <span class="badge bg-dark ms-1"><?= $userStats['kepala_sekolah'] ?? 0 ?></span>
            </a>
            <a href="<?= BASE_URL ?>/admin/users?role=customer" class="btn btn-sm rounded-pill px-3 py-2 <?= $currentFilter === 'customer' ? 'btn-success text-white fw-bold' : 'btn-outline-success' ?>">
                <i class="fa-solid fa-user me-1"></i> Customer <span class="badge bg-dark ms-1"><?= $userStats['customer'] ?? 0 ?></span>
            </a>
        </div>

        <!-- Table Card -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 shadow-lg">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0" id="tableUsers">
                    <thead>
                        <tr class="text-white-50 border-secondary extra-small text-uppercase">
                            <th style="width: 50px;">#</th>
                            <th>Nama Lengkap</th>
                            <th>Email</th>
                            <th>Role / Peran</th>
                            <th>Tgl Terdaftar</th>
                            <th class="text-end" style="width: 140px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($users)): ?>
                            <?php foreach ($users as $idx => $u): ?>
                                <tr>
                                    <td class="text-white-50 extra-small"><?= $idx + 1 ?></td>
                                    <td>
                                        <div class="fw-bold text-white d-flex align-items-center gap-2">
                                            <i class="fa-solid fa-circle-user text-cyan fs-5"></i>
                                            <span><?= htmlspecialchars($u['nama']) ?></span>
                                            <?php if ((int)$u['id'] === (int)$user['id']): ?>
                                                <span class="badge bg-cyan text-dark extra-small rounded-pill">Anda</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="text-white-50"><?= htmlspecialchars($u['email']) ?></td>
                                    <td>
                                        <?php
                                            $badges = [
                                                'admin' => 'bg-danger text-white',
                                                'operator' => 'bg-warning text-dark',
                                                'teknisi' => 'bg-info text-dark',
                                                'kepala_sekolah' => 'bg-primary text-white',
                                                'customer' => 'bg-success text-white'
                                            ];
                                            $badge = $badges[$u['role']] ?? 'bg-secondary text-white';
                                        ?>
                                        <span class="badge <?= $badge ?> rounded-pill px-3 py-1 extra-small fw-bold">
                                            <?= strtoupper(str_replace('_', ' ', $u['role'])) ?>
                                        </span>
                                    </td>
                                    <td class="text-white-50 extra-small">
                                        <?= !empty($u['created_at']) ? date('d M Y, H:i', strtotime($u['created_at'])) : '-' ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <!-- Button Edit -->
                                            <button type="button" class="btn btn-outline-info btn-edit-user" 
                                                    data-id="<?= $u['id'] ?>" 
                                                    data-nama="<?= htmlspecialchars($u['nama']) ?>" 
                                                    data-email="<?= htmlspecialchars($u['email']) ?>" 
                                                    data-role="<?= $u['role'] ?>"
                                                    title="Edit Pengguna">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </button>

                                            <!-- Button Delete (Disabled jika akun sendiri) -->
                                            <?php if ((int)$u['id'] !== (int)$user['id']): ?>
                                                <form action="<?= BASE_URL ?>/admin/users/delete/<?= $u['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pengguna <?= htmlspecialchars(addslashes($u['nama'])) ?>?');">
                                                    <?= SecurityHelper::csrfField() ?>
                                                    <button type="submit" class="btn btn-outline-danger" title="Hapus Pengguna">
                                                        <i class="fa-solid fa-trash"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-outline-secondary opacity-50" disabled title="Tidak dapat menghapus akun sendiri">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-white-50 py-5">
                                    <i class="fa-solid fa-user-slash fs-1 text-secondary mb-3 d-block"></i>
                                    Tidak ada data pengguna untuk filter ini.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<!-- MODAL TAMBAH PENGGUNA BARU -->
<div class="modal fade" id="modalTambahUser" tabindex="-1" aria-labelledby="modalTambahUserLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark-card border border-secondary border-opacity-25 text-white shadow-lg">
            <div class="modal-header border-secondary border-opacity-25">
                <h5 class="modal-title fw-bold" id="modalTambahUserLabel">
                    <i class="fa-solid fa-user-plus text-cyan me-2"></i> Tambah Pengguna Baru
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?= BASE_URL ?>/admin/users/create" method="POST">
                <?= SecurityHelper::csrfField() ?>
                <div class="modal-body vstack gap-3">
                    <div>
                        <label class="form-label small text-white-50">Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control bg-dark border-secondary text-white" placeholder="Contoh: Budi Santoso" required>
                    </div>
                    <div>
                        <label class="form-label small text-white-50">Alamat Email</label>
                        <input type="email" name="email" class="form-control bg-dark border-secondary text-white" placeholder="Contoh: user@tkj.sch.id" required>
                    </div>
                    <div>
                        <label class="form-label small text-white-50">Role / Peran Akses</label>
                        <select name="role" class="form-select bg-dark border-secondary text-white" required>
                            <option value="customer">Customer (Pelanggan)</option>
                            <option value="teknisi">Teknisi (Siswa TKJ)</option>
                            <option value="operator">Operator (Pengelola TEFA)</option>
                            <option value="kepala_sekolah">Kepala Sekolah (Monitoring Eksekutif)</option>
                            <option value="admin">Administrator (Superuser)</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label small text-white-50">Password Akun</label>
                        <input type="text" name="password" class="form-control bg-dark border-secondary text-white" value="password123" required>
                        <div class="form-text text-white-50 extra-small">Default: <code>password123</code> (Dapat diubah oleh pengguna nanti).</div>
                    </div>
                </div>
                <div class="modal-footer border-secondary border-opacity-25">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-cyan fw-bold px-4">Simpan Pengguna</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL EDIT PENGGUNA -->
<div class="modal fade" id="modalEditUser" tabindex="-1" aria-labelledby="modalEditUserLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark-card border border-secondary border-opacity-25 text-white shadow-lg">
            <div class="modal-header border-secondary border-opacity-25">
                <h5 class="modal-title fw-bold" id="modalEditUserLabel">
                    <i class="fa-solid fa-user-pen text-cyan me-2"></i> Edit Data Pengguna
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="formEditUser" action="" method="POST">
                <?= SecurityHelper::csrfField() ?>
                <div class="modal-body vstack gap-3">
                    <div>
                        <label class="form-label small text-white-50">Nama Lengkap</label>
                        <input type="text" name="nama" id="editNama" class="form-control bg-dark border-secondary text-white" required>
                    </div>
                    <div>
                        <label class="form-label small text-white-50">Alamat Email</label>
                        <input type="email" name="email" id="editEmail" class="form-control bg-dark border-secondary text-white" required>
                    </div>
                    <div>
                        <label class="form-label small text-white-50">Role / Peran Akses</label>
                        <select name="role" id="editRole" class="form-select bg-dark border-secondary text-white" required>
                            <option value="customer">Customer (Pelanggan)</option>
                            <option value="teknisi">Teknisi (Siswa TKJ)</option>
                            <option value="operator">Operator (Pengelola TEFA)</option>
                            <option value="kepala_sekolah">Kepala Sekolah (Monitoring Eksekutif)</option>
                            <option value="admin">Administrator (Superuser)</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label small text-white-50">Password Baru (Opsional)</label>
                        <input type="password" name="password" class="form-control bg-dark border-secondary text-white" placeholder="Biarkan kosong jika tidak ingin mengubah password">
                        <div class="form-text text-white-50 extra-small">Kosongkan jika pengguna tetap menggunakan password lama.</div>
                    </div>
                </div>
                <div class="modal-footer border-secondary border-opacity-25">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-cyan fw-bold px-4">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const editButtons = document.querySelectorAll('.btn-edit-user');
    const modalEditEl = document.getElementById('modalEditUser');
    const formEdit = document.getElementById('formEditUser');
    const editNama = document.getElementById('editNama');
    const editEmail = document.getElementById('editEmail');
    const editRole = document.getElementById('editRole');

    if (editButtons.length && modalEditEl) {
        const bsModal = new bootstrap.Modal(modalEditEl);
        editButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const nama = this.getAttribute('data-nama');
                const email = this.getAttribute('data-email');
                const role = this.getAttribute('data-role');

                formEdit.action = '<?= BASE_URL ?>/admin/users/edit/' + id;
                editNama.value = nama;
                editEmail.value = email;
                editRole.value = role;

                bsModal.show();
            });
        });
    }
});
</script>

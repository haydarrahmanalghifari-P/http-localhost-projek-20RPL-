<section class="py-4 py-lg-5" style="background-color: #f8fafc; min-height: 90vh;">
    <div class="container-fluid px-3 px-lg-5">

        <!-- Flash Messages -->
        <?php $flashSuccess = AuthHelper::getFlash('admin_success'); ?>
        <?php if ($flashSuccess): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4 border-0 shadow-sm rounded-4 d-flex align-items-center gap-2" role="alert">
                <i class="fa-solid fa-circle-check fs-5 text-success"></i>
                <div class="fw-medium text-dark"><?= htmlspecialchars($flashSuccess['message']) ?></div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php 
        $flashError = AuthHelper::getFlash('admin_error'); 
        $flashAuth = AuthHelper::getFlash('auth_error');
        $activeError = $flashError ?: $flashAuth;
        ?>
        <?php if ($activeError): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-4 border-0 shadow-sm rounded-4 d-flex align-items-center gap-2" role="alert">
                <i class="fa-solid fa-circle-exclamation fs-5 text-danger"></i>
                <div class="fw-medium text-dark"><?= htmlspecialchars($activeError['message']) ?></div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Page Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                    <span class="badge bg-danger bg-opacity-10 text-danger fw-bold px-3 py-1 rounded-pill extra-small">
                        <i class="fa-solid fa-shield-halved me-1"></i> PANEL ADMINISTRATOR
                    </span>
                    <span class="badge bg-info bg-opacity-15 text-primary fw-bold px-3 py-1 rounded-pill extra-small">
                        <i class="fa-solid fa-check-to-slot me-1"></i> VERIFIKASI RESMI
                    </span>
                    <span class="badge bg-success bg-opacity-15 text-success fw-bold px-3 py-1 rounded-pill extra-small">
                        <i class="fa-brands fa-whatsapp me-1"></i> NOTIFIKASI WA AKTIF
                    </span>
                </div>
                <h2 class="fw-bold text-dark mb-1 font-heading">Verifikasi &amp; Manajemen Pesanan Jasa</h2>
                <p class="text-secondary small mb-0">
                    Otorisasi dan persetujuan pesanan unit bisnis TEFA TKJ sebelum pengerjaan oleh teknisi siswa.
                </p>
            </div>
            <div class="d-flex align-items-center gap-2">
                <a href="<?= BASE_URL ?>/admin/dashboard" class="btn btn-outline-secondary rounded-pill btn-sm text-dark px-3 py-2 fw-semibold bg-white border-light-subtle shadow-sm">
                    <i class="fa-solid fa-arrow-left me-1"></i> Dashboard
                </a>
                <button class="btn btn-primary text-white fw-bold rounded-pill px-3 py-2 btn-sm btn-shadow d-inline-flex align-items-center gap-2 shadow-sm" style="background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); border: none;" data-bs-toggle="modal" data-bs-target="#modalTambahPesananAdmin">
                    <i class="fa-solid fa-plus-circle fs-6"></i>
                    <span>Input Pesanan Baru</span>
                </button>
            </div>
        </div>

        <!-- Metric Counter Cards -->
        <div class="row g-3 mb-4">
            <div class="col-xl-2 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/admin/pesanan?status=all" class="text-decoration-none">
                    <div class="p-3 rounded-4 bg-white border <?= ($currentFilter === null || $currentFilter === 'all') ? 'border-primary shadow-sm' : 'border-light-subtle' ?> shadow-sm transition hover-lift text-center h-100">
                        <span class="text-secondary extra-small d-block fw-semibold text-uppercase">Semua Pesanan</span>
                        <div class="fs-3 fw-extrabold text-dark mt-1"><?= $counts['total'] ?></div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/admin/pesanan?status=pending" class="text-decoration-none">
                    <div class="p-3 rounded-4 bg-white border <?= ($currentFilter === 'pending') ? 'border-warning shadow-sm' : 'border-light-subtle' ?> shadow-sm transition hover-lift text-center h-100 position-relative">
                        <?php if ($counts['pending'] > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger border border-white">
                                <?= $counts['pending'] ?> Baru
                            </span>
                        <?php endif; ?>
                        <span class="text-warning extra-small d-block fw-bold text-uppercase">
                            <i class="fa-solid fa-hourglass-start me-1"></i> Perlu Verifikasi
                        </span>
                        <div class="fs-3 fw-extrabold text-warning mt-1"><?= $counts['pending'] ?></div>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/admin/pesanan?status=dikonfirmasi" class="text-decoration-none">
                    <div class="p-3 rounded-4 bg-white border <?= ($currentFilter === 'dikonfirmasi') ? 'border-info shadow-sm' : 'border-light-subtle' ?> shadow-sm transition hover-lift text-center h-100">
                        <span class="text-info extra-small d-block fw-semibold text-uppercase">Terverifikasi</span>
                        <div class="fs-3 fw-extrabold text-info mt-1"><?= $counts['dikonfirmasi'] ?></div>
                    </div>
                </a>
            </div>
            <div class="col-xl-2 col-md-4 col-6">
                <a href="<?= BASE_URL ?>/admin/pesanan?status=diproses" class="text-decoration-none">
                    <div class="p-3 rounded-4 bg-white border <?= ($currentFilter === 'diproses') ? 'border-primary shadow-sm' : 'border-light-subtle' ?> shadow-sm transition hover-lift text-center h-100">
                        <span class="text-primary extra-small d-block fw-semibold text-uppercase">Dikerjakan</span>
                        <div class="fs-3 fw-extrabold text-primary mt-1"><?= $counts['diproses'] ?></div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-8 col-12">
                <a href="<?= BASE_URL ?>/admin/pesanan?status=selesai" class="text-decoration-none">
                    <div class="p-3 rounded-4 bg-white border <?= ($currentFilter === 'selesai') ? 'border-success shadow-sm' : 'border-light-subtle' ?> shadow-sm transition hover-lift text-center h-100">
                        <span class="text-success extra-small d-block fw-semibold text-uppercase">Selesai &amp; Lunas</span>
                        <div class="fs-3 fw-extrabold text-success mt-1"><?= $counts['selesai'] ?></div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Filter Tabs -->
        <div class="d-flex flex-wrap align-items-center gap-2 mb-4">
            <span class="text-secondary extra-small fw-semibold text-uppercase me-2"><i class="fa-solid fa-filter me-1"></i> Filter:</span>
            <a href="<?= BASE_URL ?>/admin/pesanan?status=all" class="btn btn-sm rounded-pill px-3 fw-bold <?= ($currentFilter === null || $currentFilter === 'all') ? 'btn-primary text-white shadow-sm' : 'btn-outline-secondary text-secondary bg-white border-light-subtle' ?>">
                Semua (<?= $counts['total'] ?>)
            </a>
            <a href="<?= BASE_URL ?>/admin/pesanan?status=pending" class="btn btn-sm rounded-pill px-3 fw-bold <?= ($currentFilter === 'pending') ? 'btn-warning text-dark shadow-sm' : 'btn-outline-warning' ?>">
                <i class="fa-solid fa-hourglass-start me-1"></i> Perlu Verifikasi (<?= $counts['pending'] ?>)
            </a>
            <a href="<?= BASE_URL ?>/admin/pesanan?status=dikonfirmasi" class="btn btn-sm rounded-pill px-3 fw-bold <?= ($currentFilter === 'dikonfirmasi') ? 'btn-info text-dark shadow-sm' : 'btn-outline-info' ?>">
                Terverifikasi (<?= $counts['dikonfirmasi'] ?>)
            </a>
            <a href="<?= BASE_URL ?>/admin/pesanan?status=diproses" class="btn btn-sm rounded-pill px-3 fw-bold <?= ($currentFilter === 'diproses') ? 'btn-primary text-white shadow-sm' : 'btn-outline-primary' ?>">
                Dikerjakan (<?= $counts['diproses'] ?>)
            </a>
            <a href="<?= BASE_URL ?>/admin/pesanan?status=selesai" class="btn btn-sm rounded-pill px-3 fw-bold <?= ($currentFilter === 'selesai') ? 'btn-success text-white shadow-sm' : 'btn-outline-success' ?>">
                Selesai (<?= $counts['selesai'] ?>)
            </a>
            <a href="<?= BASE_URL ?>/admin/pesanan?status=dibatalkan" class="btn btn-sm rounded-pill px-3 fw-bold <?= ($currentFilter === 'dibatalkan') ? 'btn-danger text-white shadow-sm' : 'btn-outline-danger' ?>">
                Dibatalkan (<?= $counts['dibatalkan'] ?>)
            </a>
        </div>

        <!-- Main Orders Table Card (White Theme) -->
        <div class="card rounded-4 border border-light-subtle shadow-sm overflow-hidden mb-4 bg-white">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 w-100">
                    <thead class="bg-light border-bottom border-light-subtle text-secondary extra-small text-uppercase fw-bold">
                        <tr>
                            <th class="ps-3 py-3" style="width: 14%;">Pesanan &amp; Waktu</th>
                            <th class="py-3" style="width: 18%;">Pelanggan</th>
                            <th class="py-3" style="width: 25%;">Layanan Jasa &amp; Lokasi</th>
                            <th class="py-3" style="width: 13%;">Jadwal &amp; Biaya</th>
                            <th class="py-3" style="width: 14%;">Teknisi Siswa</th>
                            <th class="py-3 text-center" style="width: 16%;">Status Verifikasi</th>
                            <th class="pe-3 py-3 text-end" style="width: 130px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($orders)): ?>
                            <?php foreach ($orders as $ord): ?>
                                <?php 
                                    $st = strtolower($ord['status']);
                                    $isPending = ($st === 'pending' || $st === 'menunggu');
                                ?>
                                <tr class="<?= $isPending ? 'bg-warning bg-opacity-10' : '' ?> border-bottom border-light-subtle">
                                    <!-- 1. Kode Pesanan & Waktu -->
                                    <td class="ps-3 py-3">
                                        <div class="font-monospace fw-bold text-dark small" style="white-space: nowrap;">
                                            #<?= htmlspecialchars($ord['kode_pesanan']) ?>
                                        </div>
                                        <div class="text-secondary extra-small d-flex align-items-center gap-1 mt-1" style="white-space: nowrap;">
                                            <i class="fa-regular fa-clock extra-small text-primary"></i>
                                            <span><?= date('d M Y, H:i', strtotime($ord['tanggal_pemesanan'])) ?></span>
                                        </div>
                                    </td>

                                    <!-- 2. Customer -->
                                    <td class="py-3">
                                        <div class="fw-bold text-dark small text-truncate" style="max-width: 180px;" title="<?= htmlspecialchars($ord['nama_customer'] ?? 'Customer') ?>">
                                            <?= htmlspecialchars($ord['nama_customer'] ?? 'Customer') ?>
                                        </div>
                                        <div class="extra-small text-primary fw-medium mt-0.5" style="white-space: nowrap;">
                                            <i class="fa-brands fa-whatsapp text-success me-1"></i><?= htmlspecialchars($ord['no_telepon']) ?>
                                        </div>
                                        <div class="extra-small text-secondary text-truncate" style="max-width: 180px;" title="<?= htmlspecialchars($ord['email_customer'] ?? '') ?>">
                                            <?= htmlspecialchars($ord['email_customer'] ?? '') ?>
                                        </div>
                                    </td>

                                    <!-- 3. Jasa, Catatan, & Lokasi -->
                                    <td class="py-3">
                                        <div class="fw-bold text-dark small">
                                            <?= htmlspecialchars($ord['nama_jasa']) ?>
                                        </div>
                                        <?php if (!empty($ord['deskripsi_masalah'])): ?>
                                            <div class="text-secondary extra-small text-truncate mt-0.5" style="max-width: 240px;" title="<?= htmlspecialchars($ord['deskripsi_masalah']) ?>">
                                                <i class="fa-solid fa-wrench text-cyan me-1 extra-small"></i><?= htmlspecialchars($ord['deskripsi_masalah']) ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($ord['alamat'])): ?>
                                            <div class="text-secondary extra-small text-truncate mt-0.5" style="max-width: 240px;" title="<?= htmlspecialchars($ord['alamat']) ?>">
                                                <i class="fa-solid fa-location-dot text-danger me-1 extra-small"></i><?= htmlspecialchars($ord['alamat']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    <!-- 4. Jadwal Pengerjaan & Biaya -->
                                    <td class="py-3">
                                        <div class="text-dark small fw-semibold" style="white-space: nowrap;">
                                            <i class="fa-regular fa-calendar-check text-primary me-1"></i>
                                            <?= !empty($ord['tanggal_pengerjaan']) ? date('d M Y', strtotime($ord['tanggal_pengerjaan'])) : '-' ?>
                                        </div>
                                        <div class="text-success fw-bold extra-small mt-0.5" style="white-space: nowrap;">
                                            Rp <?= number_format($ord['total_harga'] ?? 0, 0, ',', '.') ?>
                                        </div>
                                    </td>

                                    <!-- 5. Teknisi Siswa -->
                                    <td class="py-3">
                                        <?php if (!empty($ord['nama_teknisi'])): ?>
                                            <span class="badge bg-light text-dark border border-light-subtle px-2.5 py-1.5 rounded-pill extra-small fw-semibold text-truncate d-inline-block" style="max-width: 150px;" title="<?= htmlspecialchars($ord['nama_teknisi']) ?>">
                                                <i class="fa-solid fa-user-gear text-primary me-1"></i> <?= htmlspecialchars($ord['nama_teknisi']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-secondary border border-light-subtle px-2.5 py-1.5 rounded-pill extra-small">
                                                <i class="fa-solid fa-user-clock me-1"></i> Belum Diplot
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- 6. Status Verifikasi Badge -->
                                    <td class="py-3 text-center">
                                        <?php if ($isPending): ?>
                                            <span class="badge bg-warning bg-opacity-20 text-dark px-2.5 py-1.5 rounded-pill extra-small fw-bold">
                                                <i class="fa-solid fa-hourglass-start me-1"></i> Perlu Verifikasi
                                            </span>
                                        <?php elseif ($st === 'dikonfirmasi' || $st === 'diverifikasi'): ?>
                                            <span class="badge bg-info bg-opacity-20 text-primary px-2.5 py-1.5 rounded-pill extra-small fw-bold">
                                                <i class="fa-solid fa-circle-check me-1"></i> Terverifikasi Admin
                                            </span>
                                        <?php elseif ($st === 'diproses' || $st === 'dikerjakan'): ?>
                                            <span class="badge bg-primary bg-opacity-15 text-primary px-2.5 py-1.5 rounded-pill extra-small fw-bold">
                                                <i class="fa-solid fa-screwdriver-wrench me-1"></i> Sedang Dikerjakan
                                            </span>
                                        <?php elseif ($st === 'selesai'): ?>
                                            <span class="badge bg-success bg-opacity-15 text-success px-2.5 py-1.5 rounded-pill extra-small fw-bold">
                                                <i class="fa-solid fa-check-double me-1"></i> Selesai
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger bg-opacity-15 text-danger px-2.5 py-1.5 rounded-pill extra-small fw-bold">
                                                <i class="fa-solid fa-circle-xmark me-1"></i> Dibatalkan
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- 7. Action Buttons -->
                                    <td class="pe-3 py-3 text-end" style="white-space: nowrap;">
                                        <div class="d-inline-flex align-items-center gap-1.5 justify-content-end">
                                            <!-- Tombol Detail Pesanan & Update Status (WA Aktif) -->
                                            <a href="<?= BASE_URL ?>/admin/orderDetail/<?= $ord['id'] ?>" class="btn btn-outline-primary btn-sm rounded-pill px-2.5 py-1 fw-semibold d-inline-flex align-items-center gap-1" title="Lihat Detail Pesanan & Update Status (WA Aktif)">
                                                <i class="fa-solid fa-eye text-primary"></i>
                                                <span>Detail</span>
                                            </a>

                                            <?php if ($isPending): ?>
                                                <!-- Tombol Verifikasi Utama -->
                                                <button type="button" class="btn btn-success btn-sm rounded-pill px-2.5 py-1 fw-bold text-white shadow-sm d-inline-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#modalVerifikasiAdmin<?= $ord['id'] ?>" title="Verifikasi Pesanan Ini">
                                                    <i class="fa-solid fa-check"></i>
                                                    <span>Verifikasi</span>
                                                </button>
                                                <!-- Tombol Tolak Pesanan -->
                                                <button type="button" class="btn btn-outline-danger btn-sm rounded-circle p-0 d-inline-flex align-items-center justify-content-center" style="width: 30px; height: 30px;" data-bs-toggle="modal" data-bs-target="#modalTolakPesanan<?= $ord['id'] ?>" title="Tolak Pesanan">
                                                    <i class="fa-solid fa-xmark"></i>
                                                </button>
                                            <?php else: ?>
                                                <!-- Tombol Kelola Status / Plotting -->
                                                <button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-2.5 py-1 fw-semibold text-dark d-inline-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#modalPlotTeknisiAdmin<?= $ord['id'] ?>" title="Kelola Status & Teknisi">
                                                    <i class="fa-solid fa-sliders text-primary"></i>
                                                    <span>Kelola</span>
                                                </button>
                                            <?php endif; ?>

                                            <!-- Tombol Hapus -->
                                            <form action="<?= BASE_URL ?>/admin/pesanan/delete/<?= $ord['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data pesanan #<?= $ord['kode_pesanan'] ?>?')">
                                                <?= SecurityHelper::csrfField() ?>
                                                <button type="submit" class="btn btn-outline-secondary btn-sm rounded-circle p-0 d-inline-flex align-items-center justify-content-center text-secondary" style="width: 30px; height: 30px;" title="Hapus Data">
                                                    <i class="fa-solid fa-trash-can extra-small"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-secondary py-5">
                                    <i class="fa-solid fa-clipboard-list fs-1 d-block mb-3 text-secondary opacity-50"></i>
                                    <h6 class="fw-bold text-dark mb-1">Tidak Ada Data Pesanan</h6>
                                    <p class="extra-small text-secondary mb-0">Belum ada pesanan yang sesuai dengan filter yang dipilih.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ======================================================================
             MODAL CONTAINERS - CLEAN MODERN WHITE THEME (HIGH CONTRAST)
             ====================================================================== -->
        <?php if (!empty($orders)): ?>
            <?php foreach ($orders as $ord): ?>

                <!-- 1. Modal Verifikasi & Persetujuan Admin (White Theme) -->
                <div class="modal fade" id="modalVerifikasiAdmin<?= $ord['id'] ?>" tabindex="-1" aria-labelledby="modalVerifLabel<?= $ord['id'] ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <form action="<?= BASE_URL ?>/admin/pesanan/verifikasi/<?= $ord['id'] ?>" method="POST" class="modal-content border-0 rounded-4 shadow-2xl bg-white" style="background-color: #ffffff !important; display: flex; flex-direction: column; max-height: calc(100vh - 3.5rem);">
                            <?= SecurityHelper::csrfField() ?>
                            
                            <!-- Header -->
                            <div class="modal-header border-bottom border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                                <div class="d-flex align-items-center gap-2.5">
                                    <div class="p-2 rounded-circle bg-success bg-opacity-10 text-success d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                        <i class="fa-solid fa-clipboard-check fs-5"></i>
                                    </div>
                                    <div>
                                        <h5 class="modal-title fw-bold text-dark mb-0" id="modalVerifLabel<?= $ord['id'] ?>">
                                            Verifikasi Pesanan #<?= htmlspecialchars($ord['kode_pesanan']) ?>
                                        </h5>
                                        <small class="text-secondary extra-small">Setujui pesanan layanan jasa ini oleh Administrator.</small>
                                    </div>
                                </div>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <div class="modal-body px-4 py-3" style="background-color: #f8fafc; overflow-y: auto; flex: 1 1 auto;">
                                
                                <!-- Ringkasan Pesanan Box -->
                                <div class="p-3 rounded-3 bg-white border border-light-subtle shadow-sm mb-3 extra-small">
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <span class="text-secondary">Nama Customer:</span>
                                            <div class="fw-bold text-dark mt-0.5"><?= htmlspecialchars($ord['nama_customer'] ?? 'Customer') ?></div>
                                        </div>
                                        <div class="col-6">
                                            <span class="text-secondary">Kontak (WhatsApp):</span>
                                            <div class="fw-bold text-primary mt-0.5"><?= htmlspecialchars($ord['no_telepon']) ?></div>
                                        </div>
                                        <div class="col-6">
                                            <span class="text-secondary">Layanan:</span>
                                            <div class="fw-bold text-dark mt-0.5"><?= htmlspecialchars($ord['nama_jasa']) ?></div>
                                        </div>
                                        <div class="col-6">
                                            <span class="text-secondary">Estimasi Biaya:</span>
                                            <div class="fw-bold text-success fs-6 mt-0.5">Rp <?= number_format($ord['total_harga'] ?? 0, 0, ',', '.') ?></div>
                                        </div>
                                        <div class="col-12 border-top border-light-subtle pt-2 mt-2">
                                            <span class="text-secondary">Keluhan / Kebutuhan:</span>
                                            <div class="text-dark mt-0.5"><?= htmlspecialchars($ord['deskripsi_masalah']) ?></div>
                                        </div>
                                        <?php if (!empty($ord['alamat'])): ?>
                                            <div class="col-12">
                                                <span class="text-secondary">Lokasi:</span>
                                                <div class="text-dark mt-0.5"><?= htmlspecialchars($ord['alamat']) ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Pilih Teknisi Siswa yang Ditugaskan -->
                                <div class="mb-3">
                                    <label class="form-label text-dark small fw-semibold">Tugaskan Teknisi Siswa TKJ (Opsional)</label>
                                    <select class="form-select bg-white border-light-subtle text-dark py-2 rounded-3" name="teknisi_id">
                                        <option value="">-- Tetapkan Nanti oleh Operator --</option>
                                        <?php if (!empty($teknisiList)): ?>
                                            <?php foreach ($teknisiList as $tek): ?>
                                                <option value="<?= $tek['id'] ?>" <?= ($ord['teknisi_id'] == $tek['id']) ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($tek['nama']) ?> (Teknisi Siswa)
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                    <small class="text-secondary extra-small d-block mt-1">
                                        Teknisi penanggung jawab juga dapat diatur atau diubah sewaktu-waktu.
                                    </small>
                                </div>

                                <!-- Catatan Admin untuk Customer via WhatsApp -->
                                <div class="mb-3">
                                    <label class="form-label text-dark small fw-semibold">Catatan untuk Pelanggan (Dikirim via WA)</label>
                                    <textarea name="catatan_admin" rows="2" class="form-control bg-white border-light-subtle text-dark rounded-3 extra-small" placeholder="Contoh: Pesanan telah diverifikasi, teknisi kami akan segera memproses."></textarea>
                                </div>

                                <!-- Alert WA Aktif -->
                                <div class="p-3 rounded-3 bg-success bg-opacity-10 border border-success border-opacity-25 extra-small text-success d-flex align-items-center gap-2 mb-2">
                                    <i class="fa-brands fa-whatsapp fs-5 flex-shrink-0 text-success"></i>
                                    <div>
                                        <strong>Notifikasi WhatsApp Aktif:</strong> Pelanggan (<strong><?= htmlspecialchars($ord['no_telepon']) ?></strong>) akan langsung menerima pemberitahuan persetujuan dan rincian pesanan via WhatsApp.
                                    </div>
                                </div>

                            </div>

                            <div class="modal-footer border-top border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                                <button type="button" class="btn btn-outline-secondary rounded-pill btn-sm px-4" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-success rounded-pill btn-sm px-4 fw-bold shadow-sm d-inline-flex align-items-center gap-1.5 text-white">
                                    <i class="fa-solid fa-check"></i>
                                    <span>Setujui &amp; Verifikasi Pesanan</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- 2. Modal Tolak Pesanan Admin (White Theme) -->
                <div class="modal fade" id="modalTolakPesanan<?= $ord['id'] ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <form action="<?= BASE_URL ?>/admin/pesanan/tolak/<?= $ord['id'] ?>" method="POST" class="modal-content border-0 rounded-4 shadow-2xl bg-white" style="background-color: #ffffff !important; display: flex; flex-direction: column; max-height: calc(100vh - 3.5rem);">
                            <?= SecurityHelper::csrfField() ?>
                            <div class="modal-header border-bottom border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                                <h5 class="modal-title fw-bold text-danger mb-0">Tolak Pesanan #<?= htmlspecialchars($ord['kode_pesanan']) ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body px-4 py-3" style="background-color: #f8fafc; overflow-y: auto; flex: 1 1 auto;">
                                <p class="small text-secondary mb-3 leading-relaxed">
                                    Apakah Anda yakin ingin menolak pesanan dari <strong><?= htmlspecialchars($ord['nama_customer'] ?? 'Customer') ?></strong>? Status pesanan akan diubah menjadi <strong class="text-danger">Dibatalkan</strong> dan notifikasi WhatsApp akan dikirimkan ke pelanggan.
                                </p>
                                <div class="mb-3">
                                    <label class="form-label text-dark small fw-semibold">Alasan Penolakan</label>
                                    <textarea name="catatan_admin" rows="2" class="form-control bg-white border-light-subtle text-dark rounded-3" placeholder="Contoh: Jadwal bengkel penuh atau di luar jangkauan wilayah..."></textarea>
                                </div>
                            </div>
                            <div class="modal-footer border-top border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                                <button type="button" class="btn btn-outline-secondary rounded-pill btn-sm px-4" data-bs-dismiss="modal">Kembali</button>
                                <button type="submit" class="btn btn-danger rounded-pill btn-sm px-4 fw-bold">
                                    <i class="fa-solid fa-xmark me-1"></i> Tolak Pesanan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- 3. Modal Ubah Status / Plotting Teknisi Admin (White Theme) -->
                <div class="modal fade" id="modalPlotTeknisiAdmin<?= $ord['id'] ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <form action="<?= BASE_URL ?>/admin/pesanan/update/<?= $ord['id'] ?>" method="POST" class="modal-content border-0 rounded-4 shadow-2xl bg-white" style="background-color: #ffffff !important; display: flex; flex-direction: column; max-height: calc(100vh - 3.5rem);">
                            <?= SecurityHelper::csrfField() ?>
                            <div class="modal-header border-bottom border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="p-2 rounded-circle bg-primary bg-opacity-10 text-primary d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                                        <i class="fa-solid fa-sliders fs-6"></i>
                                    </div>
                                    <h5 class="modal-title fw-bold text-dark mb-0">Kelola Status &amp; Teknisi #<?= htmlspecialchars($ord['kode_pesanan']) ?></h5>
                                </div>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body px-4 py-3" style="background-color: #f8fafc; overflow-y: auto; flex: 1 1 auto;">
                                <div class="mb-3">
                                    <label class="form-label text-dark small fw-semibold">Teknisi Siswa Penanggung Jawab</label>
                                    <select class="form-select bg-white border-light-subtle text-dark py-2 rounded-3" name="teknisi_id">
                                        <option value="" <?= empty($ord['teknisi_id']) ? 'selected' : '' ?>>-- Pilih Teknisi Siswa --</option>
                                        <?php if (!empty($teknisiList)): ?>
                                            <?php foreach ($teknisiList as $tek): ?>
                                                <option value="<?= $tek['id'] ?>" <?= ($ord['teknisi_id'] == $tek['id']) ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($tek['nama']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label text-dark small fw-semibold">Ubah Status Pengerjaan</label>
                                    <select class="form-select bg-white border-light-subtle text-dark py-2 rounded-3" name="status">
                                        <option value="pending" <?= ($ord['status'] === 'pending' || $ord['status'] === 'menunggu') ? 'selected' : '' ?>>⏳ Menunggu Verifikasi (Pending)</option>
                                        <option value="dikonfirmasi" <?= ($ord['status'] === 'dikonfirmasi' || $ord['status'] === 'diverifikasi') ? 'selected' : '' ?>>📋 Terverifikasi (Dikonfirmasi)</option>
                                        <option value="diproses" <?= ($ord['status'] === 'diproses' || $ord['status'] === 'dikerjakan') ? 'selected' : '' ?>>🛠️ Sedang Dikerjakan (Diproses)</option>
                                        <option value="selesai" <?= ($ord['status'] === 'selesai') ? 'selected' : '' ?>>✅ Selesai Pengerjaan</option>
                                        <option value="dibatalkan" <?= ($ord['status'] === 'dibatalkan') ? 'selected' : '' ?>>❌ Dibatalkan</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label text-dark small fw-semibold">Catatan Admin untuk Pelanggan (Dikirim via WA)</label>
                                    <textarea name="catatan_admin" rows="2" class="form-control bg-white border-light-subtle text-dark rounded-3 extra-small" placeholder="Contoh: Teknisi sedang dalam perjalanan ke lokasi..."></textarea>
                                </div>

                                <div class="p-3 rounded-3 bg-success bg-opacity-10 border border-success border-opacity-25 extra-small text-success d-flex align-items-center gap-2">
                                    <i class="fa-brands fa-whatsapp text-success fs-5 flex-shrink-0"></i>
                                    <div>
                                        <strong>WA Aktif:</strong> Setiap perubahan status akan otomatis mengirimkan notifikasi ke nomor WhatsApp pelanggan (<strong><?= htmlspecialchars($ord['no_telepon']) ?></strong>).
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer border-top border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                                <button type="button" class="btn btn-outline-secondary rounded-pill btn-sm px-4" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary rounded-pill btn-sm px-4 fw-bold text-white shadow-sm" style="background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); border: none;">
                                    <i class="fa-solid fa-save me-1"></i> Simpan Perubahan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

            <?php endforeach; ?>
        <?php endif; ?>

        <!-- 4. Modal Tambah Pesanan Baru oleh Admin (White Theme) -->
        <div class="modal fade" id="modalTambahPesananAdmin" tabindex="-1" aria-labelledby="modalTambahAdminLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                <form action="<?= BASE_URL ?>/admin/pesanan/create" method="POST" class="modal-content border-0 rounded-4 shadow-2xl bg-white" style="background-color: #ffffff !important; display: flex; flex-direction: column; max-height: calc(100vh - 3.5rem);">
                    <?= SecurityHelper::csrfField() ?>
                    <div class="modal-header border-bottom border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                        <div class="d-flex align-items-center gap-2.5">
                            <div class="p-2 rounded-circle bg-primary bg-opacity-10 text-primary d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                <i class="fa-solid fa-file-circle-plus fs-5"></i>
                            </div>
                            <div>
                                <h5 class="modal-title fw-bold text-dark mb-0" id="modalTambahAdminLabel">Input Pesanan Jasa Baru (Administrator)</h5>
                                <small class="text-secondary extra-small">Catat pesanan langsung dan verifikasi secara otomatis.</small>
                            </div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body px-4 py-3" style="background-color: #f8fafc; overflow-y: auto; flex: 1 1 auto;">
                        <div class="row g-3">
                            
                            <!-- Customer -->
                            <div class="col-md-6">
                                <label class="form-label text-dark small fw-semibold">Pilih Customer <span class="text-danger">*</span></label>
                                <select name="customer_id" class="form-select bg-white border-light-subtle text-dark py-2 rounded-3" required>
                                    <option value="">-- Pilih Customer Terdaftar --</option>
                                    <?php if (!empty($customerList)): ?>
                                        <?php foreach ($customerList as $cust): ?>
                                            <option value="<?= $cust['id'] ?>">
                                                <?= htmlspecialchars($cust['nama']) ?> (<?= htmlspecialchars($cust['email']) ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <!-- Layanan Jasa -->
                            <div class="col-md-6">
                                <label class="form-label text-dark small fw-semibold">Layanan Jasa <span class="text-danger">*</span></label>
                                <select name="jasa_id" class="form-select bg-white border-light-subtle text-dark py-2 rounded-3" required>
                                    <option value="">-- Pilih Layanan Jasa --</option>
                                    <?php if (!empty($serviceList)): ?>
                                        <?php foreach ($serviceList as $s): ?>
                                            <option value="<?= $s['id'] ?>">
                                                <?= htmlspecialchars($s['title'] ?? $s['nama_jasa']) ?> (<?= htmlspecialchars($s['price'] ?? 'Mulai Rp ' . number_format($s['harga_mulai'] ?? 0, 0, ',', '.')) ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <!-- No Telepon -->
                            <div class="col-md-6">
                                <label class="form-label text-dark small fw-semibold">Nomor Telepon / Kontak <span class="text-danger">*</span></label>
                                <input type="text" name="no_telepon" class="form-control bg-white border-light-subtle text-dark py-2 rounded-3" placeholder="Contoh: 081234567890" required>
                            </div>

                            <!-- Tanggal Pengerjaan -->
                            <div class="col-md-6">
                                <label class="form-label text-dark small fw-semibold">Tanggal Rencana Pengerjaan <span class="text-danger">*</span></label>
                                <input type="date" name="tanggal_pengerjaan" class="form-control bg-white border-light-subtle text-dark py-2 rounded-3" value="<?= date('Y-m-d') ?>" required>
                            </div>

                            <!-- Alamat -->
                            <div class="col-12">
                                <label class="form-label text-dark small fw-semibold">Alamat Lengkap Lokasi <span class="text-danger">*</span></label>
                                <textarea name="alamat" rows="2" class="form-control bg-white border-light-subtle text-dark rounded-3" placeholder="Alamat rumah, kantor, sekolah, atau lab..." required></textarea>
                            </div>

                            <!-- Deskripsi Kerusakan -->
                            <div class="col-12">
                                <label class="form-label text-dark small fw-semibold">Deskripsi Kendala / Spesifikasi Pengerjaan <span class="text-danger">*</span></label>
                                <textarea name="deskripsi_masalah" rows="2" class="form-control bg-white border-light-subtle text-dark rounded-3" placeholder="Jelaskan kebutuhan teknis..." required></textarea>
                            </div>

                            <!-- Teknisi Siswa -->
                            <div class="col-md-4">
                                <label class="form-label text-dark small fw-semibold">Teknisi Siswa Ditugaskan</label>
                                <select name="teknisi_id" class="form-select bg-white border-light-subtle text-dark py-2 rounded-3">
                                    <option value="">-- Tetapkan Nanti --</option>
                                    <?php if (!empty($teknisiList)): ?>
                                        <?php foreach ($teknisiList as $tek): ?>
                                            <option value="<?= $tek['id'] ?>"><?= htmlspecialchars($tek['nama']) ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <!-- Status Awal -->
                            <div class="col-md-4">
                                <label class="form-label text-dark small fw-semibold">Status Verifikasi Awal</label>
                                <select name="status" class="form-select bg-white border-light-subtle text-dark py-2 rounded-3">
                                    <option value="dikonfirmasi" selected>Langsung Terverifikasi (Dikonfirmasi)</option>
                                    <option value="pending">Menunggu Konfirmasi (Pending)</option>
                                    <option value="diproses">Langsung Diproses</option>
                                </select>
                            </div>

                            <!-- Total Biaya -->
                            <div class="col-md-4">
                                <label class="form-label text-dark small fw-semibold">Estimasi Total Biaya (Rp)</label>
                                <input type="number" name="total_harga" class="form-control bg-white border-light-subtle text-dark py-2 rounded-3" placeholder="Kosongkan untuk tarif default">
                            </div>

                        </div>
                    </div>

                    <div class="modal-footer border-top border-light-subtle px-4 py-3 bg-white" style="flex-shrink: 0;">
                        <button type="button" class="btn btn-outline-secondary rounded-pill btn-sm px-4" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary text-white rounded-pill btn-sm px-4 fw-bold shadow-sm" style="background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); border: none;">
                            <i class="fa-solid fa-save me-1"></i> Simpan &amp; Verifikasi Pesanan
                        </button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</section>

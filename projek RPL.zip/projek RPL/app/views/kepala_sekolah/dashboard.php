<section class="py-5">
    <div class="container">
        
        <!-- Header Banner Kepala Sekolah -->
        <div class="p-4 p-md-5 rounded-4 glass-card border border-cyan border-opacity-25 mb-4 position-relative overflow-hidden">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <span class="badge bg-danger text-white rounded-pill px-3 py-1 mb-2">
                        <i class="fa-solid fa-chart-pie me-1"></i> Dashboard Monitoring Eksekutif (Read-Only)
                    </span>
                    <h2 class="fw-bold text-white mb-2">
                        Selamat Datang, <span class="text-cyan"><?= htmlspecialchars($user['nama']) ?></span>!
                    </h2>
                    <p class="text-white-50 mb-0">
                        Panel khusus pemantauan kinerja unit bisnis Teaching Factory (TEFA) siswa TKJ, pendapatan sekolah, distribusi layanan, serta evaluasi hasil kerja siswa.
                    </p>
                </div>
                <div class="col-lg-4 text-center text-lg-end mt-4 mt-lg-0">
                    <i class="fa-solid fa-graduation-cap display-1 text-cyan opacity-50"></i>
                </div>
            </div>
        </div>

        <!-- 7 Metric Cards Requirement -->
        <div class="row g-3 mb-4">
            <!-- 1. Total Customer -->
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">1. Total Customer</div>
                    <div class="fs-3 fw-extrabold text-white mt-1"><?= $stats['total_customer'] ?? 0 ?></div>
                </div>
            </div>

            <!-- 2. Total Teknisi -->
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">2. Total Teknisi</div>
                    <div class="fs-3 fw-extrabold text-cyan mt-1"><?= $stats['total_teknisi'] ?? 0 ?></div>
                </div>
            </div>

            <!-- 3. Total Pesanan -->
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">3. Total Pesanan</div>
                    <div class="fs-3 fw-extrabold text-white mt-1"><?= $stats['total_pesanan'] ?? 0 ?></div>
                </div>
            </div>

            <!-- 4. Pesanan Selesai -->
            <div class="col-md-3 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">4. Pesanan Selesai</div>
                    <div class="fs-3 fw-extrabold text-success mt-1"><?= $stats['pesanan_selesai'] ?? 0 ?></div>
                </div>
            </div>

            <!-- 5. Pesanan Diproses -->
            <div class="col-md-4 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">5. Pesanan Diproses</div>
                    <div class="fs-3 fw-extrabold text-warning mt-1"><?= $stats['pesanan_diproses'] ?? 0 ?></div>
                </div>
            </div>

            <!-- 6. Pesanan Dibatalkan -->
            <div class="col-md-4 col-6">
                <div class="p-3 rounded-4 bg-dark-card border border-secondary border-opacity-25 h-100">
                    <div class="text-white-50 extra-small fw-semibold text-uppercase">6. Pesanan Dibatalkan</div>
                    <div class="fs-3 fw-extrabold text-danger mt-1"><?= $stats['pesanan_dibatalkan'] ?? 0 ?></div>
                </div>
            </div>

            <!-- 7. Total Pendapatan -->
            <div class="col-md-4 col-12">
                <div class="p-3 rounded-4 bg-dark-card border border-cyan border-opacity-25 h-100">
                    <div class="text-cyan extra-small fw-semibold text-uppercase">7. Total Pendapatan TEFA</div>
                    <div class="fs-3 fw-extrabold text-success mt-1">Rp <?= number_format($stats['total_pendapatan'] ?? 0, 0, ',', '.') ?></div>
                </div>
            </div>
        </div>

        <!-- Section Chart.js & Statistik Layanan -->
        <div class="row g-4 mb-4">
            <!-- Chart.js: Layanan Paling Banyak Dipesan -->
            <div class="col-lg-6">
                <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 h-100">
                    <h5 class="fw-bold text-white mb-3">
                        <i class="fa-solid fa-chart-donut text-cyan me-2"></i> Layanan Paling Banyak Dipesan
                    </h5>
                    <div style="max-height: 280px;" class="d-flex align-items-center justify-content-center">
                        <canvas id="chartLayananPopular"></canvas>
                    </div>
                </div>
            </div>

            <!-- Table: Jumlah Pekerjaan & Rating Teknisi Siswa -->
            <div class="col-lg-6">
                <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25 h-100">
                    <h5 class="fw-bold text-white mb-3">
                        <i class="fa-solid fa-user-graduate text-cyan me-2"></i> Jumlah Pekerjaan & Rating Teknisi Siswa
                    </h5>

                    <div class="table-responsive">
                        <table class="table table-dark table-hover align-middle mb-0 extra-small">
                            <thead>
                                <tr class="text-cyan">
                                    <th>Teknisi Siswa TKJ</th>
                                    <th>Tugas Selesai</th>
                                    <th>Rating Pelanggan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($stats['teknisi_workload'])): ?>
                                    <?php foreach ($stats['teknisi_workload'] as $tw): ?>
                                        <tr>
                                            <td><strong class="text-white"><?= htmlspecialchars($tw['nama']) ?></strong></td>
                                            <td><span class="badge bg-cyan text-dark font-bold"><?= $tw['selesai'] ?> Pekerjaan</span></td>
                                            <td>
                                                <span class="text-warning fw-bold"><i class="fa-solid fa-star"></i> <?= number_format($tw['rating'], 1) ?> / 5.0</span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Read-Only Menu Shortcuts -->
        <div class="row g-3">
            <div class="col-md-4">
                <a href="<?= BASE_URL ?>/kepala-sekolah/pesanan" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-list-check fs-5"></i> Pemantauan Pesanan
                </a>
            </div>
            <div class="col-md-4">
                <a href="<?= BASE_URL ?>/kepala-sekolah/teknisi" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-users-gear fs-5"></i> Pemantauan Teknisi Siswa
                </a>
            </div>
            <div class="col-md-4">
                <a href="<?= BASE_URL ?>/kepala-sekolah/laporan" class="btn btn-outline-cyan w-100 py-3 rounded-4 text-decoration-none fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="fa-solid fa-print fs-5"></i> Laporan Eksekutif TEFA
                </a>
            </div>
        </div>

    </div>
</section>

<!-- Script Visualisasi Chart.js -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const ctx = document.getElementById('chartLayananPopular');
    if (ctx) {
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Instalasi CCTV', 'Service Komputer/Laptop', 'Instalasi Wi-Fi', 'Instalasi Jaringan LAN'],
                datasets: [{
                    label: 'Jumlah Pesanan',
                    data: [1, 1, 1, 0],
                    backgroundColor: [
                        '#06b6d4',
                        '#3b82f6',
                        '#eab308',
                        '#22c55e'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#94a3b8',
                            font: { size: 11 }
                        }
                    }
                }
            }
        });
    }
});
</script>

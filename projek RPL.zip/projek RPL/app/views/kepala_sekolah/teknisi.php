<section class="py-5">
    <div class="container">
        
        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-danger text-white rounded-pill px-3 py-1 mb-1">EVALUASI KINERJA SISWA</span>
                <h2 class="fw-bold text-white mb-0">Pemantauan Teknisi Siswa TKJ</h2>
            </div>
            <a href="<?= BASE_URL ?>/kepala-sekolah/dashboard" class="btn btn-outline-cyan rounded-pill btn-sm extra-small">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Dashboard
            </a>
        </div>

        <!-- Info Alert -->
        <div class="alert alert-info border border-info border-opacity-25 bg-dark-card text-white-50 extra-small mb-4">
            <i class="fa-solid fa-circle-info text-cyan me-1"></i> <strong>Praktek Kerja TEFA:</strong> Data ini memantau penyerapan proyek & rating kepuasan pelanggan terhadap siswa-siswi jurusan TKJ. Kepala Sekolah tidak memiliki hak akses mengubah/menghapus data teknisi.
        </div>

        <!-- Table Teknisi Workload Read-Only -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>Nama Teknisi Siswa</th>
                            <th>Jumlah Proyek Selesai</th>
                            <th>Rating Kepuasan Pelanggan</th>
                            <th>Status Pembelajaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($workload)): ?>
                            <?php foreach ($workload as $tw): ?>
                                <tr>
                                    <td><strong class="text-white"><?= htmlspecialchars($tw['nama']) ?></strong></td>
                                    <td><span class="badge bg-cyan text-dark font-bold"><?= $tw['selesai'] ?> Proyek</span></td>
                                    <td>
                                        <span class="text-warning fw-bold"><i class="fa-solid fa-star"></i> <?= number_format($tw['rating'], 1) ?> / 5.0</span>
                                    </td>
                                    <td><span class="badge bg-success">Aktif TEFA</span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center text-white-50 py-3">Belum ada data teknisi siswa.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

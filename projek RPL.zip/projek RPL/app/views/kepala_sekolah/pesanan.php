<section class="py-5">
    <div class="container">
        
        <!-- Header -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
            <div>
                <span class="badge bg-danger text-white rounded-pill px-3 py-1 mb-1">READ-ONLY MONITORING</span>
                <h2 class="fw-bold text-white mb-0">Pemantauan Seluruh Pesanan</h2>
            </div>
            <a href="<?= BASE_URL ?>/kepala-sekolah/dashboard" class="btn btn-outline-cyan rounded-pill btn-sm extra-small">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Dashboard
            </a>
        </div>

        <!-- Mode Info Alert -->
        <div class="alert alert-info border border-info border-opacity-25 bg-dark-card text-white-50 extra-small mb-4">
            <i class="fa-solid fa-circle-info text-cyan me-1"></i> <strong>Modul Monitoring Eksekutif:</strong> Halaman ini khusus untuk pemantauan data pesanan pelanggan. Kepala Sekolah tidak memiliki hak akses mengubah atau menghapus data pesanan.
        </div>

        <!-- Table Pesanan Read-Only -->
        <div class="glass-card p-4 rounded-4 border border-secondary border-opacity-25">
            <div class="table-responsive">
                <table class="table table-dark table-hover align-middle mb-0 extra-small">
                    <thead>
                        <tr class="text-cyan">
                            <th>Kode</th>
                            <th>Nama Customer</th>
                            <th>Layanan Jasa</th>
                            <th>Tgl Pemesanan</th>
                            <th>Teknisi Siswa TKJ</th>
                            <th>Total Biaya</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($orders)): ?>
                            <?php foreach ($orders as $ord): ?>
                                <tr>
                                    <td><strong class="text-white"><?= htmlspecialchars($ord['kode_pesanan']) ?></strong></td>
                                    <td><?= htmlspecialchars($ord['nama_customer'] ?? 'Customer') ?></td>
                                    <td><?= htmlspecialchars($ord['nama_jasa']) ?></td>
                                    <td><?= date('d M Y', strtotime($ord['tanggal_pemesanan'])) ?></td>
                                    <td>
                                        <?= !empty($ord['nama_teknisi']) ? htmlspecialchars($ord['nama_teknisi']) : '<span class="text-white-50">Menunggu Penugasan</span>' ?>
                                    </td>
                                    <td><span class="text-cyan fw-bold">Rp <?= number_format($ord['total_harga'] ?? 0, 0, ',', '.') ?></span></td>
                                    <td>
                                        <span class="badge bg-info text-dark"><?= strtoupper(htmlspecialchars($ord['status'])) ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-white-50 py-3">Belum ada data pesanan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<?php
/**
 * OtpModel - Model Verifikasi Kode OTP Email
 * Menyimpan riwayat kode OTP ke database MySQL dengan auto-migration tabel
 */

class OtpModel {
    private $db;
    private $table = 'email_otp';

    public function __construct() {
        $this->db = new Database();
        $this->ensureTableExists();
    }

    /**
     * Memastikan tabel email_otp tersedia di database
     */
    private function ensureTableExists() {
        if (!$this->db->isConnected()) return;

        try {
            $sql = "CREATE TABLE IF NOT EXISTS `{$this->table}` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `email` VARCHAR(150) NOT NULL,
                `otp` VARCHAR(10) NOT NULL,
                `type` VARCHAR(50) NOT NULL DEFAULT 'register',
                `is_used` TINYINT(1) NOT NULL DEFAULT 0,
                `expires_at` DATETIME NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX `idx_email_otp` (`email`, `otp`, `is_used`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            
            $this->db->query($sql);
            $this->db->execute();
        } catch (\Throwable $e) {
            // Silently continue if table creation fails
        }
    }

    /**
     * Simpan kode OTP baru untuk email tertentu
     */
    public function saveOtp($email, $otp, $type = 'register', $expiryMinutes = 5) {
        if (!$this->db->isConnected()) return true;

        // Nonaktifkan kode OTP lama yang belum terpakai untuk email & tipe ini
        $this->invalidateExisting($email, $type);

        $expiresAt = date('Y-m-d H:i:s', time() + ($expiryMinutes * 60));

        $sql = "INSERT INTO `{$this->table}` (email, otp, type, is_used, expires_at) 
                VALUES (:email, :otp, :type, 0, :expires_at)";
        
        $this->db->query($sql);
        $this->db->bind(':email', $email);
        $this->db->bind(':otp', $otp);
        $this->db->bind(':type', $type);
        $this->db->bind(':expires_at', $expiresAt);

        return $this->db->execute();
    }

    /**
     * Verifikasi kode OTP dari database
     */
    public function verifyOtp($email, $otp, $type = 'register') {
        if (!$this->db->isConnected()) return true;

        $now = date('Y-m-d H:i:s');
        $sql = "SELECT id, otp, expires_at FROM `{$this->table}` 
                WHERE email = :email AND otp = :otp AND type = :type AND is_used = 0 AND expires_at >= :now 
                ORDER BY id DESC LIMIT 1";
        
        $this->db->query($sql);
        $this->db->bind(':email', $email);
        $this->db->bind(':otp', $otp);
        $this->db->bind(':type', $type);
        $this->db->bind(':now', $now);

        $record = $this->db->single();

        if ($record) {
            // Tandai OTP telah digunakan
            $updateSql = "UPDATE `{$this->table}` SET is_used = 1 WHERE id = :id";
            $this->db->query($updateSql);
            $this->db->bind(':id', $record['id']);
            $this->db->execute();
            return true;
        }

        return false;
    }

    /**
     * Nonaktifkan OTP sebelumnya
     */
    public function invalidateExisting($email, $type = 'register') {
        if (!$this->db->isConnected()) return true;

        $sql = "UPDATE `{$this->table}` SET is_used = 1 WHERE email = :email AND type = :type AND is_used = 0";
        $this->db->query($sql);
        $this->db->bind(':email', $email);
        $this->db->bind(':type', $type);
        return $this->db->execute();
    }
}

<?php
/**
 * ReviewModel - Model Pengelolaan Rating & Review Pelanggan (Tabel `review`)
 */

class ReviewModel {
    private $db;
    private $table = 'review';

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Tambah Rating & Review Baru
     */
    public function createReview($data) {
        if (!$this->db->isConnected()) {
            return true; // Mock fallback
        }

        $sql = "INSERT INTO " . $this->table . " 
                (pesanan_id, customer_id, teknisi_id, rating, komentar)
                VALUES 
                (:pesanan_id, :customer_id, :teknisi_id, :rating, :komentar)";

        $this->db->query($sql);
        $this->db->bind(':pesanan_id', $data['pesanan_id']);
        $this->db->bind(':customer_id', $data['customer_id']);
        $this->db->bind(':teknisi_id', $data['teknisi_id']);
        $this->db->bind(':rating', $data['rating']);
        $this->db->bind(':komentar', $data['komentar']);

        return $this->db->execute();
    }

    /**
     * Ambil Review Berdasarkan ID Pesanan
     */
    public function getReviewByOrder($orderId) {
        if (!$this->db->isConnected()) {
            return null;
        }

        $sql = "SELECT * FROM " . $this->table . " WHERE pesanan_id = :pesanan_id LIMIT 1";
        $this->db->query($sql);
        $this->db->bind(':pesanan_id', $orderId);
        return $this->db->single();
    }

    /**
     * Ambil Seluruh Review (Operator View)
     */
    public function getAllReviews() {
        if (!$this->db->isConnected()) {
            return [
                [
                    'id' => 1,
                    'kode_pesanan' => 'ORD-20260901-001',
                    'nama_customer' => 'Budi Santoso',
                    'nama_teknisi' => 'Ahmad Dani (XI TKJ 1)',
                    'rating' => 5,
                    'komentar' => 'Pemasangan CCTV sangat rapi dan ramah. Teknisi siswa TKJ pengerjaannya profesional banget didampingi gurunya. Mantap!',
                    'created_at' => '2026-09-02 18:00:00'
                ]
            ];
        }

        $sql = "SELECT r.*, p.kode_pesanan, uc.nama as nama_customer, ut.nama as nama_teknisi
                FROM " . $this->table . " r
                JOIN pesanan p ON r.pesanan_id = p.id
                JOIN users uc ON r.customer_id = uc.id
                JOIN users ut ON r.teknisi_id = ut.id
                ORDER BY r.id DESC";

        $this->db->query($sql);
        return $this->db->resultSet();
    }
}

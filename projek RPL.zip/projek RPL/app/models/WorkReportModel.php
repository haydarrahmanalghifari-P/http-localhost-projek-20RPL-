<?php
/**
 * WorkReportModel - Model Pengelolaan Pekerjaan & Progress Teknisi Siswa TKJ (Tabel `pekerjaan`, `pesanan`, `notifikasi`)
 */

class WorkReportModel {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Ambil statistik tugas teknisi
     */
    public function getCountsByTeknisi($teknisiId) {
        if (!$this->db->isConnected()) {
            return [
                'active' => 1,
                'completed' => 8,
                'rating' => '4.9'
            ];
        }

        $sql = "SELECT 
                    SUM(CASE WHEN p.status IN ('dikonfirmasi', 'diproses') THEN 1 ELSE 0 END) as active,
                    SUM(CASE WHEN p.status = 'selesai' THEN 1 ELSE 0 END) as completed
                FROM pesanan p WHERE p.teknisi_id = :teknisi_id";

        $this->db->query($sql);
        $this->db->bind(':teknisi_id', $teknisiId);
        $row = $this->db->single();

        return [
            'active' => (int)($row['active'] ?? 0),
            'completed' => (int)($row['completed'] ?? 0),
            'rating' => '4.9'
        ];
    }

    /**
     * Ambil daftar pekerjaan yang ditugaskan kepada teknisi (STRIKTIF FILTER TEKNISI_ID)
     */
    public function getAssignedJobs($teknisiId, $statusGroup = 'active') {
        if (!$this->db->isConnected()) {
            return $this->getStaticJobs($teknisiId, $statusGroup);
        }

        $statusCondition = ($statusGroup === 'active')
            ? "p.status IN ('dikonfirmasi', 'diproses')"
            : "p.status = 'selesai'";

        $sql = "SELECT p.*, j.nama_jasa, j.deskripsi as deskripsi_jasa, uc.nama as nama_customer, uc.email as email_customer, pk.catatan_teknisi, pk.hasil_pekerjaan, pk.foto_pekerjaan, pk.status as status_pekerjaan
                FROM pesanan p
                JOIN jasa j ON p.jasa_id = j.id
                JOIN users uc ON p.customer_id = uc.id
                LEFT JOIN pekerjaan pk ON p.id = pk.pesanan_id
                WHERE p.teknisi_id = :teknisi_id AND " . $statusCondition . "
                ORDER BY p.id DESC";

        $this->db->query($sql);
        $this->db->bind(':teknisi_id', $teknisiId);
        return $this->db->resultSet();
    }

    /**
     * Ambil detail tunggal pekerjaan untuk teknisi (STRIKTIF FILTER TEKNISI_ID)
     */
    public function getJobDetail($orderId, $teknisiId) {
        if (!$this->db->isConnected()) {
            $jobs = $this->getStaticJobs($teknisiId, 'all');
            foreach ($jobs as $j) {
                if ($j['id'] == $orderId) return $j;
            }
            return $jobs[0] ?? null;
        }

        $sql = "SELECT p.*, j.nama_jasa, j.deskripsi as deskripsi_jasa, uc.nama as nama_customer, uc.email as email_customer, pk.id as pekerjaan_id, pk.catatan_teknisi, pk.hasil_pekerjaan, pk.foto_pekerjaan, pk.status as status_pekerjaan, pk.tanggal_mulai, pk.tanggal_selesai
                FROM pesanan p
                JOIN jasa j ON p.jasa_id = j.id
                JOIN users uc ON p.customer_id = uc.id
                LEFT JOIN pekerjaan pk ON p.id = pk.pesanan_id
                WHERE p.id = :id AND p.teknisi_id = :teknisi_id";

        $this->db->query($sql);
        $this->db->bind(':id', $orderId);
        $this->db->bind(':teknisi_id', $teknisiId);

        return $this->db->single();
    }

    /**
     * Update Progres Pekerjaan Teknisi & Otomatisasi Status/Notifikasi jika Selesai
     */
    public function updateJobProgress($orderId, $teknisiId, $data) {
        if (!$this->db->isConnected()) return true;

        $statusInput = $data['status']; // Menunggu, Dikerjakan, Selesai
        $catatan = $data['catatan_teknisi'] ?? '';
        $hasil = $data['hasil_pekerjaan'] ?? '';
        $foto = $data['foto_pekerjaan'] ?? null;

        // Status mapping ke pesanan
        $statusPesananDb = 'diproses';
        $statusPekerjaanDb = 'dalam_proses';

        if ($statusInput === 'Menunggu' || $statusInput === 'pending') {
            $statusPesananDb = 'dikonfirmasi';
            $statusPekerjaanDb = 'tertunda';
        } elseif ($statusInput === 'Dikerjakan' || $statusInput === 'diproses') {
            $statusPesananDb = 'diproses';
            $statusPekerjaanDb = 'dalam_proses';
        } elseif ($statusInput === 'Selesai' || $statusInput === 'selesai') {
            $statusPesananDb = 'selesai';
            $statusPekerjaanDb = 'selesai';
        }

        // 1. Cek / Insert / Update tabel pekerjaan
        $checkSql = "SELECT id FROM pekerjaan WHERE pesanan_id = :pesanan_id LIMIT 1";
        $this->db->query($checkSql);
        $this->db->bind(':pesanan_id', $orderId);
        $existingJob = $this->db->single();

        if ($existingJob) {
            $updateJobSql = "UPDATE pekerjaan SET 
                             catatan_teknisi = :catatan, 
                             hasil_pekerjaan = :hasil, 
                             status = :status, 
                             foto_pekerjaan = COALESCE(:foto, foto_pekerjaan)" . 
                             ($statusPekerjaanDb === 'selesai' ? ", tanggal_selesai = NOW()" : "") . "
                             WHERE pesanan_id = :pesanan_id";
            $this->db->query($updateJobSql);
            $this->db->bind(':catatan', $catatan);
            $this->db->bind(':hasil', $hasil);
            $this->db->bind(':status', $statusPekerjaanDb);
            $this->db->bind(':foto', $foto);
            $this->db->bind(':pesanan_id', $orderId);
            $this->db->execute();
        } else {
            $insertJobSql = "INSERT INTO pekerjaan (pesanan_id, teknisi_id, catatan_teknisi, hasil_pekerjaan, foto_pekerjaan, status, tanggal_mulai" . ($statusPekerjaanDb === 'selesai' ? ", tanggal_selesai" : "") . ") 
                             VALUES (:pesanan_id, :teknisi_id, :catatan, :hasil, :foto, :status, NOW()" . ($statusPekerjaanDb === 'selesai' ? ", NOW()" : "") . ")";
            $this->db->query($insertJobSql);
            $this->db->bind(':pesanan_id', $orderId);
            $this->db->bind(':teknisi_id', $teknisiId);
            $this->db->bind(':catatan', $catatan);
            $this->db->bind(':hasil', $hasil);
            $this->db->bind(':foto', $foto);
            $this->db->bind(':status', $statusPekerjaanDb);
            $this->db->execute();
        }

        // 2. Update status tabel pesanan
        $updatePesananSql = "UPDATE pesanan SET status = :status WHERE id = :id";
        $this->db->query($updatePesananSql);
        $this->db->bind(':status', $statusPesananDb);
        $this->db->bind(':id', $orderId);
        $this->db->execute();

        // Ambil customer_id, kode_pesanan, & nama teknisi untuk notifikasi
        $getOrderSql = "SELECT p.customer_id, p.kode_pesanan, u.nama as nama_teknisi 
                        FROM pesanan p 
                        LEFT JOIN users u ON p.teknisi_id = u.id 
                        WHERE p.id = :id LIMIT 1";
        $this->db->query($getOrderSql);
        $this->db->bind(':id', $orderId);
        $orderObj = $this->db->single();

        if ($orderObj) {
            $notifModel = new NotificationModel();
            $kode = $orderObj['kode_pesanan'];
            $custId = $orderObj['customer_id'];
            $teknisiName = $orderObj['nama_teknisi'] ?? 'Siswa TKJ';

            // Trigger 4: Teknisi mulai mengerjakan -> Customer
            if ($statusPekerjaanDb === 'dalam_proses') {
                $notifModel->createNotification($custId, 'Teknisi Mulai Mengerjakan', "Teknisi $teknisiName sedang dalam perjalanan / mulai mengerjakan pesanan Anda #$kode.");
            }

            // Trigger 5: Teknisi menyelesaikan pekerjaan -> Customer
            if ($statusPekerjaanDb === 'selesai') {
                $pesanNotif = "Pesanan Anda #$kode telah selesai dikerjakan oleh teknisi $teknisiName. Hasil pekerjaan: " . ($hasil ?: "Selesai dengan baik.");
                $notifModel->createNotification($custId, 'Pesanan Selesai', $pesanNotif);
            }
        }

        return true;
    }

    private function getStaticJobs($teknisiId, $group = 'active') {
        $all = [
            [
                'id' => 2,
                'kode_pesanan' => 'ORD-20260902-002',
                'customer_id' => 6,
                'nama_customer' => 'Siti Rahmawati',
                'email_customer' => 'siti.customer@gmail.com',
                'jasa_id' => 4,
                'nama_jasa' => 'Service Komputer/Laptop',
                'deskripsi_jasa' => 'Perbaikan hardware & software komputer/laptop.',
                'alamat' => 'Jl. Melati No. 45, Kecamatan Sukamaju',
                'no_telepon' => '085712345678',
                'deskripsi_masalah' => 'Laptop Asus booting lemot dan panas, minta install Windows 11 & upgrade SSD 512GB',
                'tanggal_pemesanan' => '2026-09-02 11:30:00',
                'tanggal_pengerjaan' => '2026-09-03 09:00:00',
                'status' => 'diproses',
                'status_pekerjaan' => 'dalam_proses',
                'teknisi_id' => $teknisiId,
                'catatan_teknisi' => 'Bongkar laptop, pembersihan debu kipas, ganti pasta thermal. Clone OS ke SSD NVMe 512GB.',
                'hasil_pekerjaan' => 'Laptop selesai di-upgrade, booting 8 detik. Stress test suhu normal.',
                'foto_pekerjaan' => 'uploads/pekerjaan/laptop_ord002.jpg'
            ],
            [
                'id' => 1,
                'kode_pesanan' => 'ORD-20260901-001',
                'customer_id' => 5,
                'nama_customer' => 'Budi Santoso',
                'email_customer' => 'budi.customer@gmail.com',
                'jasa_id' => 1,
                'nama_jasa' => 'Instalasi CCTV',
                'deskripsi_jasa' => 'Pemasangan kamera CCTV IP / Analog.',
                'alamat' => 'Jl. Mawar No. 12, RT 02/05, Kelurahan Permai',
                'no_telepon' => '081234567890',
                'deskripsi_masalah' => 'Pemasangan 4 titik kamera CCTV IP outdoor dan setting aplikasi HP',
                'tanggal_pemesanan' => '2026-09-01 09:00:00',
                'tanggal_pengerjaan' => '2026-09-02 10:00:00',
                'status' => 'selesai',
                'status_pekerjaan' => 'selesai',
                'teknisi_id' => $teknisiId,
                'catatan_teknisi' => 'Kabel UTP ditarik rapi via conduit PVC.',
                'hasil_pekerjaan' => 'Instalasi 4 unit CCTV IP Dahua selesai, gambar jernih & terhubung ke HP.',
                'foto_pekerjaan' => 'uploads/pekerjaan/cctv_ord001.jpg'
            ]
        ];

        if ($group === 'active') {
            return array_values(array_filter($all, function($j) {
                return in_array($j['status'], ['pending', 'dikonfirmasi', 'diproses']);
            }));
        } elseif ($group === 'history') {
            return array_values(array_filter($all, function($j) {
                return $j['status'] === 'selesai';
            }));
        }

        return $all;
    }
}

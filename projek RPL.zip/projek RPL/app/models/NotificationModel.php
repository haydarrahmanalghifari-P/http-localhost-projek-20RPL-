<?php
/**
 * NotificationModel - Model Pengelolaan Notifikasi Internal Website (Tabel `notifikasi`)
 */

class NotificationModel {
    private $db;
    private $table = 'notifikasi';

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Buat Notifikasi Baru untuk User Spesifik
     */
    public function createNotification($userId, $judul, $pesan) {
        if (!$this->db->isConnected()) return true;

        $sql = "INSERT INTO " . $this->table . " (user_id, judul, pesan, status) VALUES (:user_id, :judul, :pesan, 'belum_dibaca')";
        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':judul', $judul);
        $this->db->bind(':pesan', $pesan);

        return $this->db->execute();
    }

    /**
     * Kirim Notifikasi ke Seluruh Pengguna Berdasarkan Role (misal: 'operator')
     */
    public function notifyRole($role, $judul, $pesan) {
        if (!$this->db->isConnected()) return true;

        $sqlUser = "SELECT id FROM users WHERE role = :role";
        $this->db->query($sqlUser);
        $this->db->bind(':role', $role);
        $users = $this->db->resultSet();

        if (!empty($users)) {
            foreach ($users as $u) {
                $this->createNotification($u['id'], $judul, $pesan);
            }
        }

        return true;
    }

    /**
     * Ambil Notifikasi Belum Dibaca milik User
     */
    public function getUnreadNotificationsByUser($userId) {
        if (!$this->db->isConnected()) {
            return $this->getStaticNotificationsByUser($userId, 'unread');
        }

        $sql = "SELECT * FROM " . $this->table . " WHERE user_id = :user_id AND status = 'belum_dibaca' ORDER BY id DESC LIMIT 5";
        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);
        return $this->db->resultSet();
    }

    /**
     * Ambil Seluruh Notifikasi milik User
     */
    public function getAllNotificationsByUser($userId) {
        if (!$this->db->isConnected()) {
            return $this->getStaticNotificationsByUser($userId, 'all');
        }

        $sql = "SELECT * FROM " . $this->table . " WHERE user_id = :user_id ORDER BY id DESC";
        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);
        return $this->db->resultSet();
    }

    /**
     * Hitung Jumlah Notifikasi Belum Dibaca
     */
    public function getUnreadCountByUser($userId) {
        if (!$this->db->isConnected()) {
            $list = $this->getStaticNotificationsByUser($userId, 'unread');
            return count($list);
        }

        $sql = "SELECT COUNT(*) as unread FROM " . $this->table . " WHERE user_id = :user_id AND status = 'belum_dibaca'";
        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);
        $row = $this->db->single();

        return (int)($row['unread'] ?? 0);
    }

    /**
     * Tandai 1 Notifikasi Sebagai Sudah Dibaca
     */
    public function markAsRead($notificationId, $userId) {
        if (!$this->db->isConnected()) return true;

        $sql = "UPDATE " . $this->table . " SET status = 'dibaca' WHERE id = :id AND user_id = :user_id";
        $this->db->query($sql);
        $this->db->bind(':id', $notificationId);
        $this->db->bind(':user_id', $userId);

        return $this->db->execute();
    }

    /**
     * Tandai Seluruh Notifikasi User Sebagai Sudah Dibaca
     */
    public function markAllAsRead($userId) {
        if (!$this->db->isConnected()) return true;

        $sql = "UPDATE " . $this->table . " SET status = 'dibaca' WHERE user_id = :user_id";
        $this->db->query($sql);
        $this->db->bind(':user_id', $userId);

        return $this->db->execute();
    }

    private function getStaticNotificationsByUser($userId, $type = 'all') {
        $all = [
            [
                'id' => 1,
                'user_id' => $userId,
                'judul' => 'Pesanan Baru Masuk',
                'pesan' => 'Pesanan baru #ORD-20260903-003 perlu dikonfirmasi oleh Operator.',
                'status' => 'belum_dibaca',
                'created_at' => date('Y-m-d H:i:s')
            ],
            [
                'id' => 2,
                'user_id' => $userId,
                'judul' => 'Tugas Pekerjaan Baru',
                'pesan' => 'Anda ditugaskan mengerjakan pesanan #ORD-20260902-002.',
                'status' => 'belum_dibaca',
                'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour'))
            ],
            [
                'id' => 3,
                'user_id' => $userId,
                'judul' => 'Pesanan Diverifikasi',
                'pesan' => 'Pesanan Anda #ORD-20260901-001 telah diverifikasi oleh Operator.',
                'status' => 'dibaca',
                'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
            ]
        ];

        if ($type === 'unread') {
            return array_values(array_filter($all, function($n) {
                return $n['status'] === 'belum_dibaca';
            }));
        }

        return $all;
    }
}

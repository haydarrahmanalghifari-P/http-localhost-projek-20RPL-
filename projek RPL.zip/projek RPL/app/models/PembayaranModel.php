<?php
/**
 * PembayaranModel - Model Pengelolaan Transaksi Pembayaran (Tabel `pembayaran`)
 */

class PembayaranModel {
    private $db;
    private $table = 'pembayaran';

    public function __construct() {
        $this->db = new Database();
        $this->ensureColumnsExist();
    }

    /**
     * Memastikan struktur kolom tabel `pembayaran` mendukung bukti pembayaran & catatan operator
     */
    private function ensureColumnsExist() {
        if ($this->db->isConnected()) {
            try {
                // Alter table jika kolom `bukti_pembayaran` belum ada
                $this->db->query("SHOW COLUMNS FROM " . $this->table . " LIKE 'bukti_pembayaran'");
                $colBukti = $this->db->single();
                if (!$colBukti) {
                    $this->db->query("ALTER TABLE " . $this->table . " ADD COLUMN `bukti_pembayaran` VARCHAR(255) NULL AFTER `tanggal_pembayaran`");
                    $this->db->execute();
                }

                // Alter table jika kolom `catatan_operator` belum ada
                $this->db->query("SHOW COLUMNS FROM " . $this->table . " LIKE 'catatan_operator'");
                $colCatatan = $this->db->single();
                if (!$colCatatan) {
                    $this->db->query("ALTER TABLE " . $this->table . " ADD COLUMN `catatan_operator` TEXT NULL AFTER `bukti_pembayaran`");
                    $this->db->execute();
                }

                // Uji tipe kolom status agar tidak crash jika varchar/enum
                $this->db->query("ALTER TABLE " . $this->table . " MODIFY COLUMN `status` VARCHAR(50) NOT NULL DEFAULT 'belum_dibayar'");
                $this->db->execute();

                $this->db->query("ALTER TABLE " . $this->table . " MODIFY COLUMN `metode_pembayaran` VARCHAR(50) NOT NULL DEFAULT 'transfer'");
                $this->db->execute();
            } catch (Exception $e) {
                // Ignore jika error alter schema
            }
        }
    }

    /**
     * Ambil seluruh transaksi pembayaran untuk Operator
     */
    public function getAllPayments() {
        if ($this->db->isConnected()) {
            $sql = "SELECT p.*, pos.kode_pesanan, u.nama as customer_name, u.email as customer_email, j.nama_jasa 
                    FROM " . $this->table . " p
                    JOIN pesanan pos ON p.pesanan_id = pos.id
                    JOIN users u ON pos.customer_id = u.id
                    JOIN jasa j ON pos.jasa_id = j.id
                    ORDER BY p.id DESC";
            $this->db->query($sql);
            $results = $this->db->resultSet();
            if (!empty($results)) {
                return $results;
            }
        }

        return $this->getStaticPayments();
    }

    /**
     * Ambil data pembayaran berdasarkan ID Pesanan
     */
    public function getPaymentByOrderId($orderId) {
        if ($this->db->isConnected()) {
            $sql = "SELECT * FROM " . $this->table . " WHERE pesanan_id = :pesanan_id ORDER BY id DESC LIMIT 1";
            $this->db->query($sql);
            $this->db->bind(':pesanan_id', $orderId);
            $row = $this->db->single();
            if ($row) {
                return $row;
            }
        }

        $static = $this->getStaticPayments();
        foreach ($static as $s) {
            if ($s['pesanan_id'] == $orderId) {
                return $s;
            }
        }

        // Return default status jika belum ada record pembayaran
        return [
            'id' => 0,
            'pesanan_id' => $orderId,
            'metode_pembayaran' => 'transfer',
            'jumlah' => 0,
            'status' => 'belum_dibayar',
            'tanggal_pembayaran' => null,
            'bukti_pembayaran' => null,
            'catatan_operator' => null
        ];
    }

    /**
     * Ambil data pembayaran berdasarkan ID Pembayaran
     */
    public function getPaymentById($paymentId) {
        if ($this->db->isConnected()) {
            $sql = "SELECT p.*, pos.kode_pesanan, u.nama as customer_name 
                    FROM " . $this->table . " p
                    JOIN pesanan pos ON p.pesanan_id = pos.id
                    JOIN users u ON pos.customer_id = u.id
                    WHERE p.id = :id";
            $this->db->query($sql);
            $this->db->bind(':id', $paymentId);
            return $this->db->single();
        }

        $static = $this->getStaticPayments();
        foreach ($static as $s) {
            if ($s['id'] == $paymentId) return $s;
        }
        return null;
    }

    /**
     * Customer melakukan submit pembayaran (Pilih Cash / Transfer + Upload Bukti)
     */
    public function createOrUpdatePayment($orderId, $metode, $jumlah, $buktiPath = null) {
        if (!$this->db->isConnected()) return true;

        $existing = $this->getPaymentByOrderId($orderId);
        $status = 'menunggu_verifikasi'; // Setelah customer kirim pembayaran, status menjadi Menunggu Verifikasi

        if ($existing && $existing['id'] > 0) {
            $sql = "UPDATE " . $this->table . " 
                    SET metode_pembayaran = :metode, jumlah = :jumlah, status = :status, 
                        bukti_pembayaran = COALESCE(:bukti, bukti_pembayaran), catatan_operator = NULL 
                    WHERE id = :id";
            $this->db->query($sql);
            $this->db->bind(':id', $existing['id']);
            $this->db->bind(':metode', $metode);
            $this->db->bind(':jumlah', $jumlah);
            $this->db->bind(':status', $status);
            $this->db->bind(':bukti', $buktiPath);
            return $this->db->execute();
        } else {
            $sql = "INSERT INTO " . $this->table . " (pesanan_id, metode_pembayaran, jumlah, status, bukti_pembayaran) 
                    VALUES (:order_id, :metode, :jumlah, :status, :bukti)";
            $this->db->query($sql);
            $this->db->bind(':order_id', $orderId);
            $this->db->bind(':metode', $metode);
            $this->db->bind(':jumlah', $jumlah);
            $this->db->bind(':status', $status);
            $this->db->bind(':bukti', $buktiPath);
            return $this->db->execute();
        }
    }

    /**
     * Operator Memverifikasi Pembayaran (Status: `dibayar`)
     */
    public function verifyPayment($paymentId) {
        if (!$this->db->isConnected()) return true;

        $sql = "UPDATE " . $this->table . " 
                SET status = 'dibayar', tanggal_pembayaran = NOW(), catatan_operator = 'Pembayaran telah diverifikasi oleh Operator TEFA.' 
                WHERE id = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $paymentId);
        return $this->db->execute();
    }

    /**
     * Operator Menolak Pembayaran (Status: `ditolak`)
     */
    public function rejectPayment($paymentId, $catatan) {
        if (!$this->db->isConnected()) return true;

        $sql = "UPDATE " . $this->table . " 
                SET status = 'ditolak', catatan_operator = :catatan 
                WHERE id = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $paymentId);
        $this->db->bind(':catatan', $catatan);
        return $this->db->execute();
    }

    /**
     * Static Payments Fallback
     */
    private function getStaticPayments() {
        return [
            [
                'id' => 1,
                'pesanan_id' => 1,
                'kode_pesanan' => 'ORD-20260901-001',
                'customer_name' => 'Budi Santoso',
                'customer_email' => 'budi.customer@gmail.com',
                'nama_jasa' => 'Instalasi CCTV',
                'metode_pembayaran' => 'transfer',
                'jumlah' => 1000000.00,
                'status' => 'dibayar',
                'tanggal_pembayaran' => '2026-09-02 17:00:00',
                'bukti_pembayaran' => 'uploads/pekerjaan/cctv_ord001.jpg',
                'catatan_operator' => 'Pembayaran lunas via Transfer Bank BCA.'
            ],
            [
                'id' => 2,
                'pesanan_id' => 2,
                'kode_pesanan' => 'ORD-20260902-002',
                'customer_name' => 'Siti Rahmawati',
                'customer_email' => 'siti.customer@gmail.com',
                'nama_jasa' => 'Service Komputer/Laptop',
                'metode_pembayaran' => 'transfer',
                'jumlah' => 650000.00,
                'status' => 'menunggu_verifikasi',
                'tanggal_pembayaran' => null,
                'bukti_pembayaran' => 'uploads/pekerjaan/laptop_ord002.jpg',
                'catatan_operator' => null
            ],
            [
                'id' => 3,
                'pesanan_id' => 3,
                'kode_pesanan' => 'ORD-20260903-003',
                'customer_name' => 'Budi Santoso',
                'customer_email' => 'budi.customer@gmail.com',
                'nama_jasa' => 'Instalasi Wi-Fi',
                'metode_pembayaran' => 'cash',
                'jumlah' => 350000.00,
                'status' => 'belum_dibayar',
                'tanggal_pembayaran' => null,
                'bukti_pembayaran' => null,
                'catatan_operator' => null
            ]
        ];
    }
}

<?php
/**
 * UserModel - Model Pengelolaan User & Autentikasi
 */

class UserModel {
    private $db;
    private $table = 'users';

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Cari User Berdasarkan Email
     */
    public function findByEmail($email) {
        if (!$this->db->isConnected()) {
            return $this->getDummyUserByEmail($email);
        }

        $this->db->query("SELECT * FROM " . $this->table . " WHERE email = :email LIMIT 1");
        $this->db->bind(':email', $email);
        $user = $this->db->single();

        return $user ?: null;
    }

    /**
     * Cari User Berdasarkan ID
     */
    public function findById($id) {
        if (!$this->db->isConnected()) {
            return null;
        }

        $this->db->query("SELECT id, nama, email, role, created_at FROM " . $this->table . " WHERE id = :id LIMIT 1");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    /**
     * Cari User Berdasarkan Nomor Telepon
     */
    public function findByPhone($phone) {
        if (!$this->db->isConnected()) {
            return null;
        }
        $clean = preg_replace('/\D/', '', (string)$phone);
        if (!$clean) return null;

        $cand = [$clean];
        if (strpos($clean, '0') === 0) {
            $cand[] = '62' . substr($clean, 1);
        } elseif (strpos($clean, '62') === 0) {
            $cand[] = '0' . substr($clean, 2);
        }

        foreach ($cand as $p) {
            try {
                $this->db->query("SELECT * FROM " . $this->table . " WHERE no_telepon = :p LIMIT 1");
                $this->db->bind(':p', $p);
                $u = $this->db->single();
                if ($u) return $u;
            } catch (\Throwable $e) {}
        }
        return null;
    }

    /**
     * Cari User Berdasarkan Telegram Chat ID
     */
    public function findByTelegramChatId($chatId) {
        if (!$this->db->isConnected() || empty($chatId)) {
            return null;
        }
        try {
            $this->db->query("SELECT * FROM " . $this->table . " WHERE telegram_chat_id = :chat_id LIMIT 1");
            $this->db->bind(':chat_id', trim((string)$chatId));
            return $this->db->single() ?: null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Cari User Berdasarkan Email, No Telepon, atau Akun Telegram
     */
    public function findByIdentifier($identifier) {
        $clean = trim((string)$identifier);
        if (empty($clean)) return null;

        // 1. Cek jika email valid
        if (filter_var($clean, FILTER_VALIDATE_EMAIL)) {
            return $this->findByEmail($clean);
        }

        // 2. Cek No Telepon
        $phoneUser = $this->findByPhone($clean);
        if ($phoneUser) return $phoneUser;

        // 3. Cek Chat ID
        if (is_numeric($clean) && strlen($clean) >= 7) {
            $chatUser = $this->findByTelegramChatId($clean);
            if ($chatUser) return $chatUser;
        }

        // 4. Cek Telegram Username atau Nama
        if ($this->db->isConnected()) {
            $tgUser = ltrim($clean, '@');
            try {
                $this->db->query("
                    SELECT * FROM " . $this->table . " 
                    WHERE LOWER(REPLACE(COALESCE(telegram_username, ''), '@', '')) = LOWER(:q)
                       OR LOWER(nama) = LOWER(:q)
                       OR LOWER(email) = LOWER(:q)
                    LIMIT 1
                ");
                $this->db->bind(':q', $tgUser);
                $u = $this->db->single();
                if ($u) return $u;
            } catch (\Throwable $e) {}
        }

        return $this->findByEmail($clean);
    }

    /**
     * Update Informasi Telegram User di MySQL
     */
    public function updateTelegramInfo($userId, $chatId, $phone = null, $username = null) {
        if (!$this->db->isConnected() || empty($userId)) return false;
        try {
            $this->db->query("
                UPDATE " . $this->table . " 
                SET telegram_chat_id = COALESCE(:chat_id, telegram_chat_id),
                    no_telepon = COALESCE(:phone, no_telepon),
                    telegram_username = COALESCE(:username, telegram_username)
                WHERE id = :id
            ");
            $this->db->bind(':chat_id', $chatId);
            $this->db->bind(':phone', $phone);
            $this->db->bind(':username', $username);
            $this->db->bind(':id', $userId);
            return $this->db->execute();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Update Nomor WhatsApp / Telepon User
     */
    public function updatePhone($userId, $phone) {
        if (!$this->db->isConnected() || empty($userId)) return false;
        try {
            $this->db->query("UPDATE " . $this->table . " SET no_telepon = :phone WHERE id = :id");
            $this->db->bind(':phone', $phone);
            $this->db->bind(':id', $userId);
            return $this->db->execute();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Registrasi Customer Baru
     */
    public function registerCustomer($nama, $email, $password, $telegramChatId = null, $noTelepon = null) {
        if (!$this->db->isConnected()) {
            return true;
        }

        // Hash Password menggunakan Bcrypt
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Coba insert dengan telegram_chat_id dan no_telepon jika kolom tersedia di MySQL
        if (!empty($telegramChatId) || !empty($noTelepon)) {
            try {
                $this->db->query("INSERT INTO " . $this->table . " (nama, email, password, role, telegram_chat_id, no_telepon) VALUES (:nama, :email, :password, 'customer', :chat_id, :no_telepon)");
                $this->db->bind(':nama', $nama);
                $this->db->bind(':email', $email);
                $this->db->bind(':password', $hashedPassword);
                $this->db->bind(':chat_id', $telegramChatId);
                $this->db->bind(':no_telepon', $noTelepon);
                if ($this->db->execute()) {
                    return true;
                }
            } catch (\Throwable $e) {
                // Coba hanya dengan telegram_chat_id
                try {
                    $this->db->query("INSERT INTO " . $this->table . " (nama, email, password, role, telegram_chat_id) VALUES (:nama, :email, :password, 'customer', :chat_id)");
                    $this->db->bind(':nama', $nama);
                    $this->db->bind(':email', $email);
                    $this->db->bind(':password', $hashedPassword);
                    $this->db->bind(':chat_id', $telegramChatId);
                    if ($this->db->execute()) {
                        return true;
                    }
                } catch (\Throwable $ex) {}
            }
        }

        $this->db->query("INSERT INTO " . $this->table . " (nama, email, password, role) VALUES (:nama, :email, :password, 'customer')");
        $this->db->bind(':nama', $nama);
        $this->db->bind(':email', $email);
        $this->db->bind(':password', $hashedPassword);

        return $this->db->execute();
    }

    /**
     * Update Profile User
     */
    public function updateProfile($userId, $nama, $email, $password = null) {
        if (!$this->db->isConnected()) {
            return true;
        }

        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $sql = "UPDATE " . $this->table . " SET nama = :nama, email = :email, password = :password WHERE id = :id";
            $this->db->query($sql);
            $this->db->bind(':password', $hashedPassword);
        } else {
            $sql = "UPDATE " . $this->table . " SET nama = :nama, email = :email WHERE id = :id";
            $this->db->query($sql);
        }

        $this->db->bind(':nama', $nama);
        $this->db->bind(':email', $email);
        $this->db->bind(':id', $userId);

        return $this->db->execute();
    }

    /**
     * Buat User Baru (untuk Operator CRUD)
     */
    public function createUser($nama, $email, $password, $role) {
        if (!$this->db->isConnected()) {
            return true;
        }

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $sql = "INSERT INTO " . $this->table . " (nama, email, password, role) VALUES (:nama, :email, :password, :role)";
        
        $this->db->query($sql);
        $this->db->bind(':nama', $nama);
        $this->db->bind(':email', $email);
        $this->db->bind(':password', $hashedPassword);
        $this->db->bind(':role', $role);

        return $this->db->execute();
    }

    /**
     * Update User (untuk Operator CRUD)
     */
    public function updateUser($id, $nama, $email, $role, $password = null) {
        if (!$this->db->isConnected()) {
            return true;
        }

        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $sql = "UPDATE " . $this->table . " SET nama = :nama, email = :email, role = :role, password = :password WHERE id = :id";
            $this->db->query($sql);
            $this->db->bind(':password', $hashedPassword);
        } else {
            $sql = "UPDATE " . $this->table . " SET nama = :nama, email = :email, role = :role WHERE id = :id";
            $this->db->query($sql);
        }

        $this->db->bind(':nama', $nama);
        $this->db->bind(':email', $email);
        $this->db->bind(':role', $role);
        $this->db->bind(':id', $id);

        return $this->db->execute();
    }

    /**
     * Hapus User (untuk Operator CRUD)
     */
    public function deleteUser($id) {
        if (!$this->db->isConnected()) {
            return true;
        }

        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $id);

        return $this->db->execute();
    }

    /**
     * Ambil Pengguna Berdasarkan Role
     */
    public function getUsersByRole($role) {
        if (!$this->db->isConnected()) {
            return [];
        }

        $this->db->query("SELECT id, nama, email, role, created_at FROM " . $this->table . " WHERE role = :role ORDER BY nama ASC");
        $this->db->bind(':role', $role);
        return $this->db->resultSet();
    }

    /**
     * Ambil Semua Pengguna (untuk Admin Panel)
     */
    public function getAllUsers($roleFilter = null) {
        if (!$this->db->isConnected()) {
            return [];
        }

        if ($roleFilter && in_array($roleFilter, ['admin', 'operator', 'teknisi', 'kepala_sekolah', 'customer'])) {
            $this->db->query("SELECT id, nama, email, role, created_at FROM " . $this->table . " WHERE role = :role ORDER BY id DESC");
            $this->db->bind(':role', $roleFilter);
        } else {
            $this->db->query("SELECT id, nama, email, role, created_at FROM " . $this->table . " ORDER BY id DESC");
        }

        return $this->db->resultSet();
    }

    /**
     * Ambil Statistik Pengguna Berdasarkan Role
     */
    public function getUserStats() {
        if (!$this->db->isConnected()) {
            return [
                'total' => 0,
                'admin' => 0,
                'operator' => 0,
                'teknisi' => 0,
                'kepala_sekolah' => 0,
                'customer' => 0
            ];
        }

        $this->db->query("SELECT role, COUNT(*) as total FROM " . $this->table . " GROUP BY role");
        $rows = $this->db->resultSet();

        $stats = [
            'total' => 0,
            'admin' => 0,
            'operator' => 0,
            'teknisi' => 0,
            'kepala_sekolah' => 0,
            'customer' => 0
        ];

        foreach ($rows as $r) {
            $role = $r['role'];
            $count = (int)$r['total'];
            if (isset($stats[$role])) {
                $stats[$role] = $count;
            }
            $stats['total'] += $count;
        }

        return $stats;
    }

    /**
     * Fallback Dummy Users jika DB Belum Di-import
     */
    private function getDummyUserByEmail($email) {
        $dummyUsers = [
            'admin@tkj.sch.id' => [
                'id' => 99,
                'nama' => 'Administrator Sistem',
                'email' => 'admin@tkj.sch.id',
                'password' => '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC',
                'role' => 'admin'
            ],
            'operator@tkj.sch.id' => [
                'id' => 1,
                'nama' => 'Pak Bambang Hartono, S.Kom',
                'email' => 'operator@tkj.sch.id',
                'password' => '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC',
                'role' => 'operator'
            ],
            'kepsek@tkj.sch.id' => [
                'id' => 2,
                'nama' => 'Drs. H. Supriyadi, M.Pd',
                'email' => 'kepsek@tkj.sch.id',
                'password' => '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC',
                'role' => 'kepala_sekolah'
            ],
            'ahmad.teknisi@tkj.sch.id' => [
                'id' => 3,
                'nama' => 'Ahmad Dani (Siswa XI TKJ 1)',
                'email' => 'ahmad.teknisi@tkj.sch.id',
                'password' => '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC',
                'role' => 'teknisi'
            ],
            'budi.customer@gmail.com' => [
                'id' => 5,
                'nama' => 'Budi Santoso',
                'email' => 'budi.customer@gmail.com',
                'password' => '$2y$10$/IdVxvQgsGDqWvj6MBT5R.JgU7GU0K.NUFjfQDUzlaI0pHykoSeFC',
                'role' => 'customer'
            ]
        ];

        return $dummyUsers[$email] ?? null;
    }

    /**
     * Reset Password Pengguna Berdasarkan Email
     */
    public function resetPassword($email, $newPassword) {
        if (!$this->db->isConnected()) {
            return true;
        }

        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        $sql = "UPDATE " . $this->table . " SET password = :password WHERE LOWER(email) = LOWER(:email)";
        $this->db->query($sql);
        $this->db->bind(':password', $hashedPassword);
        $this->db->bind(':email', trim($email));

        return $this->db->execute();
    }
}

<?php
/**
 * OrderModel - Model Pengelolaan Pesanan Jasa (Tabel `pesanan`)
 */

class OrderModel {
    private $db;
    private $table = 'pesanan';

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Ambil statistik jumlah pesanan customer berdasarkan status
     */
    public function getCountsByCustomer($customerId) {
        if (!$this->db->isConnected()) {
            return [
                'total' => 2,
                'pending' => 1,
                'diproses' => 0,
                'selesai' => 1,
                'dibatalkan' => 0
            ];
        }

        $sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status IN ('dikonfirmasi', 'diproses') THEN 1 ELSE 0 END) as diproses,
                    SUM(CASE WHEN status = 'selesai' THEN 1 ELSE 0 END) as selesai,
                    SUM(CASE WHEN status = 'dibatalkan' THEN 1 ELSE 0 END) as dibatalkan
                FROM " . $this->table . " WHERE customer_id = :customer_id";

        $this->db->query($sql);
        $this->db->bind(':customer_id', $customerId);
        $row = $this->db->single();

        return [
            'total' => (int)($row['total'] ?? 0),
            'pending' => (int)($row['pending'] ?? 0),
            'diproses' => (int)($row['diproses'] ?? 0),
            'selesai' => (int)($row['selesai'] ?? 0),
            'dibatalkan' => (int)($row['dibatalkan'] ?? 0)
        ];
    }

    /**
     * Ambil daftar pesanan customer berdasarkan grup status ('active' atau 'history')
     */
    public function getOrdersByCustomer($customerId, $statusGroup = 'active') {
        if (!$this->db->isConnected()) {
            return $this->getStaticOrdersByCustomer($customerId, $statusGroup);
        }

        $statusCondition = ($statusGroup === 'active') 
            ? "p.status IN ('pending', 'dikonfirmasi', 'diproses')" 
            : "p.status IN ('selesai', 'dibatalkan')";

        $sql = "SELECT p.*, j.nama_jasa, j.harga_mulai, u.nama as nama_teknisi
                FROM " . $this->table . " p
                JOIN jasa j ON p.jasa_id = j.id
                LEFT JOIN users u ON p.teknisi_id = u.id
                WHERE p.customer_id = :customer_id AND " . $statusCondition . "
                ORDER BY p.id DESC";

        $this->db->query($sql);
        $this->db->bind(':customer_id', $customerId);
        return $this->db->resultSet();
    }

    /**
     * Ambil detail pesanan tunggal berdasarkan ID
     */
    public function getOrderById($orderId, $customerId = null) {
        if (!$this->db->isConnected()) {
            $orders = $this->getStaticOrdersByCustomer($customerId, 'all');
            foreach ($orders as $ord) {
                if ($ord['id'] == $orderId) return $ord;
            }
            return $orders[0] ?? null;
        }

        $sql = "SELECT p.*, j.nama_jasa, j.deskripsi as deskripsi_jasa, j.harga_mulai, 
                       u.nama as nama_teknisi, u.no_telepon as teknisi_no_telepon,
                       c.nama as nama_customer, c.email as email_customer, c.no_telepon as customer_no_telepon,
                       r.rating, r.komentar as review_komentar
                FROM " . $this->table . " p
                JOIN jasa j ON p.jasa_id = j.id
                LEFT JOIN users u ON p.teknisi_id = u.id
                LEFT JOIN users c ON p.customer_id = c.id
                LEFT JOIN review r ON p.id = r.pesanan_id
                WHERE p.id = :id";
        
        if ($customerId) {
            $sql .= " AND p.customer_id = :customer_id";
        }

        $this->db->query($sql);
        $this->db->bind(':id', $orderId);
        if ($customerId) {
            $this->db->bind(':customer_id', $customerId);
        }

        return $this->db->single();
    }

    /**
     * Buat Pesanan Jasa Baru
     */
    public function createOrder($data) {
        if (!$this->db->isConnected()) {
            return true; // Mock success
        }

        // Generate Kode Pesanan Unik: ORD-YYYYMMDD-XXX
        $kodePesanan = 'ORD-' . date('Ymd') . '-' . rand(100, 999);
        $status = !empty($data['status']) ? $data['status'] : 'pending';
        $teknisiId = !empty($data['teknisi_id']) ? (int)$data['teknisi_id'] : null;

        $sql = "INSERT INTO " . $this->table . " 
                (kode_pesanan, customer_id, jasa_id, alamat, no_telepon, deskripsi_masalah, tanggal_pengerjaan, status, teknisi_id, total_harga)
                VALUES 
                (:kode_pesanan, :customer_id, :jasa_id, :alamat, :no_telepon, :deskripsi_masalah, :tanggal_pengerjaan, :status, :teknisi_id, :total_harga)";

        $this->db->query($sql);
        $this->db->bind(':kode_pesanan', $kodePesanan);
        $this->db->bind(':customer_id', $data['customer_id']);
        $this->db->bind(':jasa_id', $data['jasa_id']);
        $this->db->bind(':alamat', $data['alamat']);
        $this->db->bind(':no_telepon', $data['no_telepon']);
        $this->db->bind(':deskripsi_masalah', $data['deskripsi_masalah']);
        $this->db->bind(':tanggal_pengerjaan', $data['tanggal_pengerjaan']);
        $this->db->bind(':status', $status);
        $this->db->bind(':teknisi_id', $teknisiId);
        $this->db->bind(':total_harga', $data['total_harga']);

        $orderModelResult = $this->db->execute();

        if ($orderModelResult) {
            // Trigger 1: Customer membuat pesanan -> Notifikasi ke Admin untuk verifikasi
            $notifModel = new NotificationModel();
            $notifModel->notifyRole('admin', 'Pesanan Baru Perlu Verifikasi', "Pesanan baru #$kodePesanan dari customer telah dibuat dan menunggu verifikasi Admin.");
            $notifModel->notifyRole('operator', 'Pesanan Baru Masuk', "Pesanan baru #$kodePesanan dari customer telah dibuat dan menunggu verifikasi Admin.");
        }

        return $orderModelResult;
    }

    /**
     * Ambil Seluruh Pesanan (Operator Management)
     */
    public function getAllOrders() {
        if (!$this->db->isConnected()) {
            return $this->getStaticOrdersByCustomer(5, 'all');
        }

        $sql = "SELECT p.*, j.nama_jasa, j.harga_mulai, uc.nama as nama_customer, uc.email as email_customer, ut.nama as nama_teknisi
                FROM " . $this->table . " p
                JOIN jasa j ON p.jasa_id = j.id
                JOIN users uc ON p.customer_id = uc.id
                LEFT JOIN users ut ON p.teknisi_id = ut.id
                ORDER BY p.id DESC";

        $this->db->query($sql);
        return $this->db->resultSet();
    }

    /**
     * Update Status & Plot Teknisi (Operator Action)
     */
    public function assignTeknisiAndStatus($orderId, $status, $teknisiId = null) {
        if (!$this->db->isConnected()) return true;

        // Ambil info pesanan lama
        $getOrderSql = "SELECT customer_id, kode_pesanan FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $this->db->query($getOrderSql);
        $this->db->bind(':id', $orderId);
        $orderObj = $this->db->single();

        if (!empty($teknisiId)) {
            $sql = "UPDATE " . $this->table . " SET status = :status, teknisi_id = :teknisi_id WHERE id = :id";
            $this->db->query($sql);
            $this->db->bind(':teknisi_id', $teknisiId);
        } else {
            $sql = "UPDATE " . $this->table . " SET status = :status WHERE id = :id";
            $this->db->query($sql);
        }

        $this->db->bind(':status', $status);
        $this->db->bind(':id', $orderId);
        $result = $this->db->execute();

        if ($result && $orderObj) {
            $notifModel = new NotificationModel();
            $kode = $orderObj['kode_pesanan'];
            $custId = $orderObj['customer_id'];

            // Trigger 2: Operator memverifikasi pesanan -> Customer
            if ($status === 'dikonfirmasi') {
                $notifModel->createNotification($custId, 'Pesanan Diverifikasi', "Pesanan Anda #$kode telah diverifikasi oleh Operator.");
            }

            // Trigger 3: Operator menetapkan teknisi -> Teknisi Siswa
            if (!empty($teknisiId)) {
                $notifModel->createNotification($teknisiId, 'Tugas Pekerjaan Baru', "Anda telah ditugaskan mengerjakan pesanan #$kode oleh Operator.");
            }

            // Trigger 6: Pesanan dibatalkan -> Customer
            if ($status === 'dibatalkan') {
                $notifModel->createNotification($custId, 'Pesanan Dibatalkan', "Pesanan Anda #$kode telah dibatalkan.");
                if (!empty($teknisiId)) {
                    $notifModel->createNotification($teknisiId, 'Pesanan Dibatalkan', "Pesanan #$kode yang ditugaskan kepada Anda telah dibatalkan.");
                }
            }
        }

        return $result;
    }

    /**
     * Hapus Pesanan (Operator Action)
     */
    public function deleteOrder($id) {
        if (!$this->db->isConnected()) return true;

        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $id);

        return $this->db->execute();
    }

    /**
     * Ambil Daftar Pembayaran (Operator Action)
     */
    public function getAllPayments() {
        if (!$this->db->isConnected()) {
            return [
                [
                    'id' => 1,
                    'kode_pesanan' => 'ORD-20260901-001',
                    'customer_name' => 'Budi Santoso',
                    'metode_pembayaran' => 'qris',
                    'jumlah' => 1000000.00,
                    'status' => 'lunas',
                    'tanggal_pembayaran' => '2026-09-02 17:00:00'
                ],
                [
                    'id' => 2,
                    'kode_pesanan' => 'ORD-20260902-002',
                    'customer_name' => 'Siti Rahmawati',
                    'metode_pembayaran' => 'transfer_bank',
                    'jumlah' => 650000.00,
                    'status' => 'pending',
                    'tanggal_pembayaran' => null
                ]
            ];
        }

        $sql = "SELECT pb.*, p.kode_pesanan, u.nama as customer_name
                FROM pembayaran pb
                JOIN pesanan p ON pb.pesanan_id = p.id
                JOIN users u ON p.customer_id = u.id
                ORDER BY pb.id DESC";

        $this->db->query($sql);
        return $this->db->resultSet();
    }

    /**
     * Ambil Ringkasan Laporan Penjualan (Operator Action)
     */
    public function getLaporanSummary() {
        if (!$this->db->isConnected()) {
            return [
                'total_revenue' => 2000000,
                'total_orders' => 3,
                'completed_orders' => 1,
                'pending_orders' => 1,
                'active_teknisi' => 2
            ];
        }

        $sql = "SELECT 
                    SUM(CASE WHEN status = 'selesai' THEN total_harga ELSE 0 END) as total_revenue,
                    COUNT(*) as total_orders,
                    SUM(CASE WHEN status = 'selesai' THEN 1 ELSE 0 END) as completed_orders,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders
                FROM " . $this->table;

        $this->db->query($sql);
        $row = $this->db->single();

        return [
            'total_revenue' => (float)($row['total_revenue'] ?? 0),
            'total_orders' => (int)($row['total_orders'] ?? 0),
            'completed_orders' => (int)($row['completed_orders'] ?? 0),
            'pending_orders' => (int)($row['pending_orders'] ?? 0),
            'active_teknisi' => 2
        ];
    }

    /**
     * Ambil 7 Metrik & Statistik Laporan Eksekutif Kepala Sekolah
     */
    public function getExecutiveStats() {
        if (!$this->db->isConnected()) {
            return [
                'total_customer' => 2,
                'total_teknisi' => 2,
                'total_pesanan' => 3,
                'pesanan_selesai' => 1,
                'pesanan_diproses' => 1,
                'pesanan_dibatalkan' => 0,
                'total_pendapatan' => 2000000.00,
                'popular_services' => [
                    ['nama_jasa' => 'Instalasi CCTV', 'total' => 1],
                    ['nama_jasa' => 'Service Komputer/Laptop', 'total' => 1],
                    ['nama_jasa' => 'Instalasi Wi-Fi', 'total' => 1]
                ],
                'teknisi_workload' => [
                    ['nama' => 'Ahmad Dani (XI TKJ 1)', 'selesai' => 1, 'rating' => 5.0],
                    ['nama' => 'Rizky Pratama (XII TKJ 2)', 'selesai' => 0, 'rating' => 4.8]
                ]
            ];
        }

        // 1. Hitung User
        $this->db->query("SELECT role, COUNT(*) as total FROM users GROUP BY role");
        $userRows = $this->db->resultSet();
        $totalCustomer = 0;
        $totalTeknisi = 0;
        foreach ($userRows as $r) {
            if ($r['role'] === 'customer') $totalCustomer = (int)$r['total'];
            if ($r['role'] === 'teknisi') $totalTeknisi = (int)$r['total'];
        }

        // 2. Hitung Pesanan & Pendapatan
        $this->db->query("SELECT 
                            COUNT(*) as total_pesanan,
                            SUM(CASE WHEN status = 'selesai' THEN 1 ELSE 0 END) as pesanan_selesai,
                            SUM(CASE WHEN status IN ('dikonfirmasi', 'diproses') THEN 1 ELSE 0 END) as pesanan_diproses,
                            SUM(CASE WHEN status = 'dibatalkan' THEN 1 ELSE 0 END) as pesanan_dibatalkan,
                            SUM(CASE WHEN status = 'selesai' THEN total_harga ELSE 0 END) as total_pendapatan
                          FROM pesanan");
        $statRow = $this->db->single();

        // 3. Layanan Paling Banyak Dipesan
        $this->db->query("SELECT j.nama_jasa, COUNT(p.id) as total 
                          FROM pesanan p 
                          JOIN jasa j ON p.jasa_id = j.id 
                          GROUP BY j.id 
                          ORDER BY total DESC LIMIT 5");
        $popularServices = $this->db->resultSet();

        // 4. Beban Kerja & Rating Teknisi Siswa
        $this->db->query("SELECT u.nama, 
                                 COUNT(p.id) as selesai,
                                 COALESCE(AVG(r.rating), 5.0) as rating
                          FROM users u
                          LEFT JOIN pesanan p ON u.id = p.teknisi_id AND p.status = 'selesai'
                          LEFT JOIN review r ON p.id = r.pesanan_id
                          WHERE u.role = 'teknisi'
                          GROUP BY u.id");
        $teknisiWorkload = $this->db->resultSet();

        return [
            'total_customer' => $totalCustomer,
            'total_teknisi' => $totalTeknisi,
            'total_pesanan' => (int)($statRow['total_pesanan'] ?? 0),
            'pesanan_selesai' => (int)($statRow['pesanan_selesai'] ?? 0),
            'pesanan_diproses' => (int)($statRow['pesanan_diproses'] ?? 0),
            'pesanan_dibatalkan' => (int)($statRow['pesanan_dibatalkan'] ?? 0),
            'total_pendapatan' => (float)($statRow['total_pendapatan'] ?? 0),
            'popular_services' => $popularServices,
            'teknisi_workload' => $teknisiWorkload
        ];
    }

    /**
     * Static Fallback Orders
     */
    private function getStaticOrdersByCustomer($customerId, $group = 'active') {
        $all = [
            [
                'id' => 1,
                'kode_pesanan' => 'ORD-20260901-001',
                'customer_id' => $customerId,
                'jasa_id' => 1,
                'nama_jasa' => 'Instalasi CCTV',
                'deskripsi_jasa' => 'Pemasangan kamera CCTV IP / Analog untuk rumah, toko, dan sekolah.',
                'alamat' => 'Jl. Mawar No. 12, RT 02/05, Kelurahan Permai',
                'no_telepon' => '081234567890',
                'deskripsi_masalah' => 'Pemasangan 4 titik kamera CCTV IP outdoor dan setting aplikasi HP.',
                'tanggal_pemesanan' => '2026-09-01 09:00:00',
                'tanggal_pengerjaan' => '2026-09-02 10:00:00',
                'status' => 'selesai',
                'teknisi_id' => 3,
                'nama_teknisi' => 'Ahmad Dani (XI TKJ 1)',
                'total_harga' => 1000000.00,
                'rating' => 5,
                'review_komentar' => 'Pemasangan sangat rapi dan pengerjaan cepat. Hasil gambar CCTV jernih.'
            ],
            [
                'id' => 3,
                'kode_pesanan' => 'ORD-20260903-003',
                'customer_id' => $customerId,
                'jasa_id' => 3,
                'nama_jasa' => 'Instalasi Wi-Fi',
                'deskripsi_jasa' => 'Pemasangan Access Point & Hotspot Login Page.',
                'alamat' => 'Toko Kelontong Budi, Jl. Raya Merdeka No. 8',
                'no_telepon' => '081234567890',
                'deskripsi_masalah' => 'Ingin pasang Wi-Fi Hotspot voucheran untuk pelanggan toko.',
                'tanggal_pemesanan' => '2026-09-03 08:15:00',
                'tanggal_pengerjaan' => '2026-09-04 09:00:00',
                'status' => 'pending',
                'teknisi_id' => null,
                'nama_teknisi' => null,
                'total_harga' => 350000.00,
                'rating' => null,
                'review_komentar' => null
            ]
        ];

        if ($group === 'active') {
            return array_values(array_filter($all, function($o) {
                return in_array($o['status'], ['pending', 'dikonfirmasi', 'diproses']);
            }));
        } elseif ($group === 'history') {
            return array_values(array_filter($all, function($o) {
                return in_array($o['status'], ['selesai', 'dibatalkan']);
            }));
        }

        return $all;
    }

    /**
     * Ambil data detail pesanan berdasarkan Kode Pesanan unik (contoh: ORD-20260901-001)
     */
    public function getOrderByKode($kodePesanan) {
        $kode = trim($kodePesanan);
        if (!$kode) return null;

        if (!$this->db->isConnected()) {
            $staticOrders = $this->getStaticOrdersByCustomer(5, 'all');
            foreach ($staticOrders as $s) {
                if (strcasecmp($s['kode_pesanan'], $kode) === 0) return $s;
            }
            return null;
        }

        $sql = "SELECT p.*, j.nama_jasa, j.deskripsi as deskripsi_jasa, j.harga_mulai, 
                       u.nama as nama_teknisi, uc.nama as nama_customer,
                       pk.catatan_teknisi, pk.hasil_pekerjaan, pk.status as status_pekerjaan,
                       pb.status as status_pembayaran, pb.metode_pembayaran
                FROM " . $this->table . " p
                JOIN jasa j ON p.jasa_id = j.id
                LEFT JOIN users u ON p.teknisi_id = u.id
                LEFT JOIN users uc ON p.customer_id = uc.id
                LEFT JOIN pekerjaan pk ON p.id = pk.pesanan_id
                LEFT JOIN pembayaran pb ON p.id = pb.pesanan_id
                WHERE LOWER(p.kode_pesanan) = LOWER(:kode)
                LIMIT 1";

        $this->db->query($sql);
        $this->db->bind(':kode', $kode);
        return $this->db->single();
    }
}


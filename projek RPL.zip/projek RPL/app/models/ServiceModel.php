<?php
/**
 * ServiceModel - Model untuk Layanan Jasa IT TKJ Smart Service
 */

class ServiceModel {
    private $db;
    private $table = 'jasa';

    public function __construct() {
        $this->db = new Database();
        $this->ensureColumnsExist();
    }

    /**
     * Memastikan kolom slug ada pada tabel `jasa`
     */
    private function ensureColumnsExist() {
        if ($this->db->isConnected()) {
            try {
                $this->db->query("SHOW COLUMNS FROM " . $this->table . " LIKE 'slug'");
                $colSlug = $this->db->single();
                if (!$colSlug) {
                    $this->db->query("ALTER TABLE " . $this->table . " ADD COLUMN `slug` VARCHAR(150) NULL AFTER `nama_jasa`");
                    $this->db->execute();
                }
            } catch (Exception $e) {
                // Ignore alter exception
            }
        }
    }

    /**
     * Mendapatkan daftar Layanan Jasa Utama dari database tabel `jasa`
     */
    public function getAllServices() {
        // Jika database terkoneksi, coba ambil dari MySQL tabel `jasa`
        if ($this->db->isConnected()) {
            $this->db->query("SELECT * FROM " . $this->table . " WHERE status = 'aktif' ORDER BY id ASC");
            $results = $this->db->resultSet();
            
            if (!empty($results)) {
                $formattedServices = [];
                foreach ($results as $row) {
                    $formattedServices[] = [
                        'id' => $row['id'],
                        'title' => $row['nama_jasa'],
                        'icon' => $this->getIconByJasaId($row['id']),
                        'badge' => $this->getBadgeByJasaId($row['id']),
                        'badge_color' => $this->getBadgeColorByJasaId($row['id']),
                        'description' => $row['deskripsi'],
                        'features' => $this->getFeaturesByJasaId($row['id']),
                        'price' => 'Mulai Rp ' . number_format($row['harga_mulai'], 0, ',', '.')
                    ];
                }
                return $formattedServices;
            }
        }

        // Fallback Array jika database belum terkoneksi
        return $this->getStaticServices();
    }

    /**
     * Tambah Jasa Baru (Operator CRUD)
     */
    public function createJasa($data) {
        if (!$this->db->isConnected()) return true;

        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['nama_jasa'])));
        $sql = "INSERT INTO " . $this->table . " (nama_jasa, slug, deskripsi, harga_mulai, estimasi_pengerjaan, status) 
                VALUES (:nama_jasa, :slug, :deskripsi, :harga_mulai, :estimasi_pengerjaan, :status)";

        $this->db->query($sql);
        $this->db->bind(':nama_jasa', $data['nama_jasa']);
        $this->db->bind(':slug', $slug);
        $this->db->bind(':deskripsi', $data['deskripsi']);
        $this->db->bind(':harga_mulai', $data['harga_mulai']);
        $this->db->bind(':estimasi_pengerjaan', $data['estimasi_pengerjaan']);
        $this->db->bind(':status', $data['status']);

        return $this->db->execute();
    }

    /**
     * Update Jasa (Operator CRUD)
     */
    public function updateJasa($id, $data) {
        if (!$this->db->isConnected()) return true;

        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['nama_jasa'])));
        $sql = "UPDATE " . $this->table . " 
                SET nama_jasa = :nama_jasa, slug = :slug, deskripsi = :deskripsi, harga_mulai = :harga_mulai, estimasi_pengerjaan = :estimasi_pengerjaan, status = :status 
                WHERE id = :id";

        $this->db->query($sql);
        $this->db->bind(':nama_jasa', $data['nama_jasa']);
        $this->db->bind(':slug', $slug);
        $this->db->bind(':deskripsi', $data['deskripsi']);
        $this->db->bind(':harga_mulai', $data['harga_mulai']);
        $this->db->bind(':estimasi_pengerjaan', $data['estimasi_pengerjaan']);
        $this->db->bind(':status', $data['status']);
        $this->db->bind(':id', $id);

        return $this->db->execute();
    }

    /**
     * Hapus Jasa (Operator CRUD)
     */
    public function deleteJasa($id) {
        if (!$this->db->isConnected()) return true;

        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $id);

        return $this->db->execute();
    }

    private function getIconByJasaId($id) {
        $icons = [
            1 => 'fa-video',
            2 => 'fa-network-wired',
            3 => 'fa-wifi',
            4 => 'fa-laptop-code',
            5 => 'fa-server',
            6 => 'fa-microchip'
        ];
        return $icons[$id] ?? 'fa-screwdriver-wrench';
    }

    private function getBadgeByJasaId($id) {
        $badges = [
            1 => 'Terpopuler',
            2 => 'Rekomendasi',
            3 => 'Favorit',
            4 => 'Cepat & Bergaransi',
            5 => 'Paket Hemat',
            6 => 'Custom Request'
        ];
        return $badges[$id] ?? 'Layanan TKJ';
    }

    private function getBadgeColorByJasaId($id) {
        $colors = [
            1 => 'bg-danger',
            2 => 'bg-info',
            3 => 'bg-primary',
            4 => 'bg-warning text-dark',
            5 => 'bg-success',
            6 => 'bg-secondary'
        ];
        return $colors[$id] ?? 'bg-cyan text-dark';
    }

    private function getFeaturesByJasaId($id) {
        $features = [
            1 => ['Kamera HD & Night Vision', 'Akses Monitoring via Android/iOS', 'Penataan Kabel Rapi & Garansi Unit'],
            2 => ['Penarikan Kabel UTP Cat5e / Cat6', 'Manajemen Bandwidth & Mikrotik', 'Testing Konektivitas & Labeling'],
            3 => ['Setting Access Point & Router Wi-Fi', 'Perluasan Sinyal Bebas Deadzone', 'Sistem Hotspot Login Page'],
            4 => ['Install Windows 10/11 & Software Standar', 'Ganti Pasta Thermal & Cleaning Fan', 'Upgrade SSD, RAM, & Diagnostic Error'],
            5 => ['Pembersihan Debu & Perangkat Rutin', 'Backup Data & Optimization System', 'Pemeriksaan Kesehatan Hardware'],
            6 => ['Perakitan PC Sesuai Budget', 'Sharing Printer & File Server Local', 'Pendampingan & Solusi Problem IT']
        ];
        return $features[$id] ?? ['Layanan Bergaransi', 'Teknisi Siswa TKJ Terlatih', 'Supervisi Pengajar'];
    }

    /**
     * Data Layanan Statis (Fallback)
     */
    public function getStaticServices() {
        return [
            [
                'id' => 1,
                'title' => 'Instalasi CCTV',
                'icon' => 'fa-video',
                'badge' => 'Terpopuler',
                'badge_color' => 'bg-danger',
                'description' => 'Pemasangan kamera CCTV IP / Analog untuk rumah, toko, dan sekolah dengan integrasi monitoring via Smartphone.',
                'features' => [
                    'Kamera HD & Night Vision',
                    'Akses Monitoring via Android/iOS',
                    'Penataan Kabel Rapi & Garansi Unit'
                ],
                'price' => 'Mulai Rp 250.000'
            ],
            [
                'id' => 2,
                'title' => 'Instalasi Jaringan',
                'icon' => 'fa-network-wired',
                'badge' => 'Rekomendasi',
                'badge_color' => 'bg-info',
                'description' => 'Perancangan dan penarikan kabel jaringan LAN (UTP/FTP), crimping RJ45, serta konfigurasi Mikrotik / Router.',
                'features' => [
                    'Penarikan Kabel UTP Cat5e / Cat6',
                    'Manajemen Bandwidth & Mikrotik',
                    'Testing Konektivitas & Labeling'
                ],
                'price' => 'Mulai Rp 150.000'
            ],
            [
                'id' => 3,
                'title' => 'Instalasi Wi-Fi',
                'icon' => 'fa-wifi',
                'badge' => 'Favorit',
                'badge_color' => 'bg-primary',
                'description' => 'Pemasangan Access Point, perluasan jangkauan Wi-Fi (Range Extender/Mesh), dan pembuatan sistem Hotspot Voucher.',
                'features' => [
                    'Setting Access Point & Router Wi-Fi',
                    'Perluasan Sinyal Bebas Deadzone',
                    'Sistem Hotspot Login Page'
                ],
                'price' => 'Mulai Rp 100.000'
            ],
            [
                'id' => 4,
                'title' => 'Service Komputer/Laptop',
                'icon' => 'fa-laptop-code',
                'badge' => 'Cepat & Bergaransi',
                'badge_color' => 'bg-warning text-dark',
                'description' => 'Perbaikan hardware & software komputer/laptop, install ulang OS, upgrade SSD/RAM, serta pembersihan thermal paste.',
                'features' => [
                    'Install Windows 10/11 & Software Standar',
                    'Ganti Pasta Thermal & Cleaning Fan',
                    'Upgrade SSD, RAM, & Diagnostic Error'
                ],
                'price' => 'Mulai Rp 75.000'
            ],
            [
                'id' => 5,
                'title' => 'Maintenance Perangkat IT',
                'icon' => 'fa-server',
                'badge' => 'Paket Hemat',
                'badge_color' => 'bg-success',
                'description' => 'Perawatan berkala untuk lab komputer sekolah, kantor, maupun UMKM agar perangkat IT selalu prima.',
                'features' => [
                    'Pembersihan Debu & Perangkat Rutin',
                    'Backup Data & Optimization System',
                    'Pemeriksaan Kesehatan Hardware'
                ],
                'price' => 'Mulai Rp 300.000'
            ],
            [
                'id' => 6,
                'title' => 'Jasa IT Lainnya',
                'icon' => 'fa-microchip',
                'badge' => 'Custom Request',
                'badge_color' => 'bg-secondary',
                'description' => 'Konsultasi IT, perakitan PC custom (Gaming/Office), instalasi printer jaringan, dan solusi kendala IT spesifik.',
                'features' => [
                    'Perakitan PC Sesuai Budget',
                    'Sharing Printer & File Server Local',
                    'Pendampingan & Solusi Problem IT'
                ],
                'price' => 'Negosiasi Sesuai Kebutuhan'
            ]
        ];
    }
}

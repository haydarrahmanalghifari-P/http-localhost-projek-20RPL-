<?php
/**
 * FaqModel - Model Pengelolaan & CRUD Data FAQ (Tabel `faq`)
 */

class FaqModel {
    private $db;
    private $table = 'faq';

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Ambil semua data FAQ (Aktif & Nonaktif) untuk Operator
     */
    public function getAllFaqs() {
        if ($this->db->isConnected()) {
            $this->db->query("SELECT * FROM " . $this->table . " ORDER BY id DESC");
            $results = $this->db->resultSet();
            if (!empty($results)) {
                return $results;
            }
        }

        // Static fallback data jika database kosong
        return $this->getStaticFaqs();
    }

    /**
     * Ambil hanya data FAQ yang berstatus `aktif` untuk AI Assistant
     */
    public function getActiveFaqs() {
        if ($this->db->isConnected()) {
            $this->db->query("SELECT * FROM " . $this->table . " WHERE status = 'aktif' ORDER BY id ASC");
            $results = $this->db->resultSet();
            if (!empty($results)) {
                return $results;
            }
        }

        // Static fallback data berstatus aktif
        $all = $this->getStaticFaqs();
        return array_filter($all, function($item) {
            return ($item['status'] ?? 'aktif') === 'aktif';
        });
    }

    /**
     * Ambil 1 data FAQ berdasarkan ID
     */
    public function getFaqById($id) {
        if ($this->db->isConnected()) {
            $this->db->query("SELECT * FROM " . $this->table . " WHERE id = :id");
            $this->db->bind(':id', $id);
            $row = $this->db->single();
            if ($row) {
                return $row;
            }
        }

        $all = $this->getStaticFaqs();
        foreach ($all as $item) {
            if ($item['id'] == $id) return $item;
        }
        return null;
    }

    /**
     * Tambah data FAQ baru
     */
    public function createFaq($pertanyaan, $jawaban, $status = 'aktif') {
        if (!$this->db->isConnected()) return false;

        $sql = "INSERT INTO " . $this->table . " (pertanyaan, jawaban, status) VALUES (:pertanyaan, :jawaban, :status)";
        $this->db->query($sql);
        $this->db->bind(':pertanyaan', $pertanyaan);
        $this->db->bind(':jawaban', $jawaban);
        $this->db->bind(':status', $status);
        return $this->db->execute();
    }

    /**
     * Update data FAQ
     */
    public function updateFaq($id, $pertanyaan, $jawaban, $status) {
        if (!$this->db->isConnected()) return false;

        $sql = "UPDATE " . $this->table . " SET pertanyaan = :pertanyaan, jawaban = :jawaban, status = :status WHERE id = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $id);
        $this->db->bind(':pertanyaan', $pertanyaan);
        $this->db->bind(':jawaban', $jawaban);
        $this->db->bind(':status', $status);
        return $this->db->execute();
    }

    /**
     * Hapus data FAQ
     */
    public function deleteFaq($id) {
        if (!$this->db->isConnected()) return false;

        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $this->db->query($sql);
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    /**
     * Toggle status aktif / nonaktif FAQ
     */
    public function toggleStatus($id) {
        $faq = $this->getFaqById($id);
        if (!$faq) return false;

        $newStatus = ($faq['status'] === 'aktif') ? 'nonaktif' : 'aktif';
        if ($this->db->isConnected()) {
            $sql = "UPDATE " . $this->table . " SET status = :status WHERE id = :id";
            $this->db->query($sql);
            $this->db->bind(':id', $id);
            $this->db->bind(':status', $newStatus);
            return $this->db->execute();
        }
        return false;
    }

    /**
     * Static Fallback FAQ Data
     */
    private function getStaticFaqs() {
        return [
            [
                'id' => 1,
                'pertanyaan' => 'Bagaimana cara memesan jasa?',
                'jawaban' => 'Silakan login sebagai customer, pilih layanan jasa pada katalog, kemudian isi formulir pemesanan lokasi dan deskripsi masalah.',
                'status' => 'aktif'
            ],
            [
                'id' => 2,
                'pertanyaan' => 'Apa saja layanan TKJ Smart Service?',
                'jawaban' => 'Kami menyediakan Instalasi CCTV, Instalasi Jaringan LAN, Instalasi Wi-Fi Hotspot, Service Komputer/Laptop, Maintenance Perangkat IT, dan Jasa IT Lainnya.',
                'status' => 'aktif'
            ],
            [
                'id' => 3,
                'pertanyaan' => 'Berapa lama pengerjaan?',
                'jawaban' => 'Estimasi pengerjaan bervariasi: Instalasi Wi-Fi (4-6 jam), Instalasi CCTV & Jaringan (1 hari), Service Komputer (1-2 hari tergantung tingkat kerusakan).',
                'status' => 'aktif'
            ],
            [
                'id' => 4,
                'pertanyaan' => 'Bagaimana cara melihat status pesanan?',
                'jawaban' => 'Anda dapat memantau status pesanan (Pending, Dikonfirmasi, Diproses, Selesai) secara real-time di Dashboard Customer atau menu Pesanan Saya.',
                'status' => 'aktif'
            ],
            [
                'id' => 5,
                'pertanyaan' => 'Bagaimana cara menghubungi teknisi?',
                'jawaban' => 'Nama teknisi penanggung jawab akan tertera pada pesanan Anda setelah dikonfirmasi oleh Operator. Komunikasi dapat dilakukan melalui catatan pesanan atau layanan kontak unit bisnis.',
                'status' => 'aktif'
            ],
            [
                'id' => 6,
                'pertanyaan' => 'Bagaimana cara memberikan review?',
                'jawaban' => 'Setelah pesanan berstatus Selesai, Anda dapat menekan tombol Beri Review pada detail pesanan untuk memberikan rating bintang dan ulasan.',
                'status' => 'aktif'
            ],
            [
                'id' => 7,
                'pertanyaan' => 'Apakah layanan jasa TKJ Smart Service bergaransi?',
                'jawaban' => 'Ya! Semua layanan instalasi CCTV, jaringan, dan service komputer dilengkapi garansi pengerjaan ulang gratis jika terjadi kendala pasca pengerjaan.',
                'status' => 'aktif'
            ],
            [
                'id' => 8,
                'pertanyaan' => 'Metode pembayaran apa saja yang didukung?',
                'jawaban' => 'Kami menerima pembayaran secara Tunai (Cash), Transfer Bank, dan QRIS.',
                'status' => 'aktif'
            ]
        ];
    }
}

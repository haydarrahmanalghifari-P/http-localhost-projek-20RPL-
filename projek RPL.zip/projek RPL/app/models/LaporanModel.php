<?php
/**
 * LaporanModel - Model Agregasi & Analisis Data Laporan TEFA TKJ Smart Service
 */

class LaporanModel {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * Memproses data laporan berdasarkan jenis laporan dan periode waktu
     * 
     * @param string $tipe ('pesanan', 'layanan', 'teknisi', 'pendapatan', 'customer')
     * @param string $periode ('hari', 'minggu', 'bulan', 'tahun')
     * @return array Data laporan terstruktur
     */
    public function getFilteredReport($tipe = 'pesanan', $periode = 'bulan') {
        $tipe = in_array($tipe, ['pesanan', 'layanan', 'teknisi', 'pendapatan', 'customer']) ? $tipe : 'pesanan';
        $periode = in_array($periode, ['hari', 'minggu', 'bulan', 'tahun']) ? $periode : 'bulan';

        if ($this->db->isConnected()) {
            return $this->getDbFilteredReport($tipe, $periode);
        }

        return $this->getStaticFilteredReport($tipe, $periode);
    }

    /**
     * Query Agregasi Database Aktual
     */
    private function getDbFilteredReport($tipe, $periode) {
        $dateCondition = $this->getDateCondition('p.tanggal_pemesanan', $periode);

        if ($tipe === 'pesanan') {
            $sql = "SELECT p.*, u.nama as customer_name, j.nama_jasa, tek.nama as nama_teknisi
                    FROM pesanan p
                    JOIN users u ON p.customer_id = u.id
                    JOIN jasa j ON p.jasa_id = j.id
                    LEFT JOIN users tek ON p.teknisi_id = tek.id
                    WHERE {$dateCondition}
                    ORDER BY p.id DESC";
            $this->db->query($sql);
            $rows = $this->db->resultSet();

            $totalData = count($rows);
            $totalOmset = array_sum(array_column($rows, 'total_harga'));
            $completed = count(array_filter($rows, fn($r) => $r['status'] === 'selesai'));
            $pending = count(array_filter($rows, fn($r) => in_array($r['status'], ['pending', 'dikonfirmasi', 'diproses'])));

            // Chart Data Status Pesanan
            $chartData = [
                'type' => 'doughnut',
                'labels' => ['Pending', 'Dikonfirmasi', 'Diproses', 'Selesai', 'Dibatalkan'],
                'datasets' => [
                    [
                        'label' => 'Jumlah Pesanan',
                        'data' => [
                            count(array_filter($rows, fn($r) => $r['status'] === 'pending')),
                            count(array_filter($rows, fn($r) => $r['status'] === 'dikonfirmasi')),
                            count(array_filter($rows, fn($r) => $r['status'] === 'diproses')),
                            count(array_filter($rows, fn($r) => $r['status'] === 'selesai')),
                            count(array_filter($rows, fn($r) => $r['status'] === 'dibatalkan'))
                        ],
                        'backgroundColor' => ['#f59e0b', '#3b82f6', '#06b6d4', '#10b981', '#ef4444']
                    ]
                ]
            ];

            return [
                'summary' => [
                    'total_data' => $totalData,
                    'total_omset' => $totalOmset,
                    'completed' => $completed,
                    'pending' => $pending
                ],
                'rows' => $rows,
                'chartData' => $chartData,
                'tipe' => $tipe,
                'periode' => $periode
            ];
        }

        elseif ($tipe === 'layanan') {
            $sql = "SELECT j.id, j.nama_jasa, j.harga_mulai,
                           COUNT(p.id) as total_order,
                           COALESCE(SUM(p.total_harga), 0) as total_pendapatan
                    FROM jasa j
                    LEFT JOIN pesanan p ON j.id = p.jasa_id AND {$dateCondition}
                    GROUP BY j.id, j.nama_jasa, j.harga_mulai
                    ORDER BY total_order DESC";
            $this->db->query($sql);
            $rows = $this->db->resultSet();

            $totalData = count($rows);
            $totalOmset = array_sum(array_column($rows, 'total_pendapatan'));
            $totalOrders = array_sum(array_column($rows, 'total_order'));

            $chartData = [
                'type' => 'bar',
                'labels' => array_column($rows, 'nama_jasa'),
                'datasets' => [
                    [
                        'label' => 'Jumlah Pemesanan (Transaksi)',
                        'data' => array_column($rows, 'total_order'),
                        'backgroundColor' => '#06b6d4'
                    ]
                ]
            ];

            return [
                'summary' => [
                    'total_data' => $totalData,
                    'total_omset' => $totalOmset,
                    'total_orders' => $totalOrders,
                    'completed' => $totalOrders
                ],
                'rows' => $rows,
                'chartData' => $chartData,
                'tipe' => $tipe,
                'periode' => $periode
            ];
        }

        elseif ($tipe === 'teknisi') {
            $sql = "SELECT u.id, u.nama as nama_teknisi, u.email,
                           COUNT(p.id) as total_tugas,
                           SUM(CASE WHEN p.status = 'selesai' THEN 1 ELSE 0 END) as tugas_selesai,
                           SUM(CASE WHEN p.status IN ('dikonfirmasi', 'diproses') THEN 1 ELSE 0 END) as tugas_proses,
                           COALESCE(AVG(r.rating), 5.0) as avg_rating
                    FROM users u
                    LEFT JOIN pesanan p ON u.id = p.teknisi_id AND {$dateCondition}
                    LEFT JOIN review r ON p.id = r.pesanan_id
                    WHERE u.role = 'teknisi'
                    GROUP BY u.id, u.nama, u.email
                    ORDER BY total_tugas DESC";
            $this->db->query($sql);
            $rows = $this->db->resultSet();

            $totalData = count($rows);
            $totalTugas = array_sum(array_column($rows, 'total_tugas'));
            $totalSelesai = array_sum(array_column($rows, 'tugas_selesai'));

            $chartData = [
                'type' => 'bar',
                'labels' => array_column($rows, 'nama_teknisi'),
                'datasets' => [
                    [
                        'label' => 'Tugas Selesai',
                        'data' => array_column($rows, 'tugas_selesai'),
                        'backgroundColor' => '#10b981'
                    ],
                    [
                        'label' => 'Sedang Diproses',
                        'data' => array_column($rows, 'tugas_proses'),
                        'backgroundColor' => '#f59e0b'
                    ]
                ]
            ];

            return [
                'summary' => [
                    'total_data' => $totalData,
                    'total_omset' => $totalTugas,
                    'completed' => $totalSelesai,
                    'pending' => $totalTugas - $totalSelesai
                ],
                'rows' => $rows,
                'chartData' => $chartData,
                'tipe' => $tipe,
                'periode' => $periode
            ];
        }

        elseif ($tipe === 'pendapatan') {
            $datePayCond = $this->getDateCondition('pb.tanggal_pembayaran', $periode);
            $sql = "SELECT pb.*, pos.kode_pesanan, u.nama as customer_name
                    FROM pembayaran pb
                    JOIN pesanan pos ON pb.pesanan_id = pos.id
                    JOIN users u ON pos.customer_id = u.id
                    ORDER BY pb.id DESC";
            $this->db->query($sql);
            $rows = $this->db->resultSet();

            $totalData = count($rows);
            $totalOmset = array_sum(array_column($rows, 'jumlah'));
            $lunasCount = count(array_filter($rows, fn($r) => in_array($r['status'], ['dibayar', 'lunas'])));

            $chartData = [
                'type' => 'pie',
                'labels' => ['Transfer Bank', 'Cash (Tunai)'],
                'datasets' => [
                    [
                        'label' => 'Pendapatan',
                        'data' => [
                            array_sum(array_map(fn($r) => ($r['metode_pembayaran'] === 'transfer_bank' || $r['metode_pembayaran'] === 'transfer') ? $r['jumlah'] : 0, $rows)),
                            array_sum(array_map(fn($r) => ($r['metode_pembayaran'] === 'tunai' || $r['metode_pembayaran'] === 'cash') ? $r['jumlah'] : 0, $rows))
                        ],
                        'backgroundColor' => ['#06b6d4', '#f59e0b']
                    ]
                ]
            ];

            return [
                'summary' => [
                    'total_data' => $totalData,
                    'total_omset' => $totalOmset,
                    'completed' => $lunasCount,
                    'pending' => $totalData - $lunasCount
                ],
                'rows' => $rows,
                'chartData' => $chartData,
                'tipe' => $tipe,
                'periode' => $periode
            ];
        }

        else { // customer report
            $sql = "SELECT u.id, u.nama as customer_name, u.email,
                           COUNT(p.id) as total_pesanan,
                           COALESCE(SUM(p.total_harga), 0) as total_pengeluaran
                    FROM users u
                    LEFT JOIN pesanan p ON u.id = p.customer_id AND {$dateCondition}
                    WHERE u.role = 'customer'
                    GROUP BY u.id, u.nama, u.email
                    ORDER BY total_pengeluaran DESC";
            $this->db->query($sql);
            $rows = $this->db->resultSet();

            $totalData = count($rows);
            $totalOmset = array_sum(array_column($rows, 'total_pengeluaran'));
            $totalPesanan = array_sum(array_column($rows, 'total_pesanan'));

            $chartData = [
                'type' => 'bar',
                'labels' => array_column($rows, 'customer_name'),
                'datasets' => [
                    [
                        'label' => 'Total Belanja (Rp)',
                        'data' => array_column($rows, 'total_pengeluaran'),
                        'backgroundColor' => '#8b5cf6'
                    ]
                ]
            ];

            return [
                'summary' => [
                    'total_data' => $totalData,
                    'total_omset' => $totalOmset,
                    'completed' => $totalPesanan,
                    'pending' => 0
                ],
                'rows' => $rows,
                'chartData' => $chartData,
                'tipe' => $tipe,
                'periode' => $periode
            ];
        }
    }

    /**
     * Helper pembuat SQL Date Condition
     */
    private function getDateCondition($column, $periode) {
        switch ($periode) {
            case 'hari':
                return "DATE({$column}) = CURDATE()";
            case 'minggu':
                return "YEARWEEK({$column}, 1) = YEARWEEK(CURDATE(), 1)";
            case 'tahun':
                return "YEAR({$column}) = YEAR(CURDATE())";
            case 'bulan':
            default:
                return "(MONTH({$column}) = MONTH(CURDATE()) AND YEAR({$column}) = YEAR(CURDATE())) OR {$column} IS NULL";
        }
    }

    /**
     * Static Fallback Laporan jika database offline
     */
    private function getStaticFilteredReport($tipe, $periode) {
        $periodeTitle = [
            'hari' => 'Hari Ini',
            'minggu' => 'Minggu Ini',
            'bulan' => 'Bulan Ini',
            'tahun' => 'Tahun Ini'
        ][$periode] ?? 'Bulan Ini';

        if ($tipe === 'pesanan') {
            $rows = [
                ['id' => 1, 'kode_pesanan' => 'ORD-20260901-001', 'customer_name' => 'Budi Santoso', 'nama_jasa' => 'Instalasi CCTV', 'tanggal_pemesanan' => '2026-09-01 09:00:00', 'nama_teknisi' => 'Ahmad Dani (XI TKJ 1)', 'total_harga' => 1000000.00, 'status' => 'selesai'],
                ['id' => 2, 'kode_pesanan' => 'ORD-20260902-002', 'customer_name' => 'Siti Rahmawati', 'nama_jasa' => 'Service Komputer/Laptop', 'tanggal_pemesanan' => '2026-09-02 11:30:00', 'nama_teknisi' => 'Rizky Pratama (XII TKJ 2)', 'total_harga' => 650000.00, 'status' => 'diproses'],
                ['id' => 3, 'kode_pesanan' => 'ORD-20260903-003', 'customer_name' => 'Budi Santoso', 'nama_jasa' => 'Instalasi Wi-Fi', 'tanggal_pemesanan' => '2026-09-03 08:15:00', 'nama_teknisi' => 'Belum Ditugaskan', 'total_harga' => 350000.00, 'status' => 'pending']
            ];
            return [
                'summary' => ['total_data' => 3, 'total_omset' => 2000000.00, 'completed' => 1, 'pending' => 2],
                'rows' => $rows,
                'chartData' => [
                    'type' => 'doughnut',
                    'labels' => ['Pending', 'Dikonfirmasi', 'Diproses', 'Selesai', 'Dibatalkan'],
                    'datasets' => [['label' => 'Jumlah Pesanan', 'data' => [1, 0, 1, 1, 0], 'backgroundColor' => ['#f59e0b', '#3b82f6', '#06b6d4', '#10b981', '#ef4444']]]
                ],
                'tipe' => $tipe,
                'periode' => $periode
            ];
        } elseif ($tipe === 'layanan') {
            $rows = [
                ['id' => 1, 'nama_jasa' => 'Instalasi CCTV', 'harga_mulai' => 250000, 'total_order' => 5, 'total_pendapatan' => 1250000],
                ['id' => 2, 'nama_jasa' => 'Service Komputer/Laptop', 'harga_mulai' => 75000, 'total_order' => 8, 'total_pendapatan' => 600000],
                ['id' => 3, 'nama_jasa' => 'Instalasi Wi-Fi', 'harga_mulai' => 100000, 'total_order' => 4, 'total_pendapatan' => 400000],
                ['id' => 4, 'nama_jasa' => 'Instalasi Jaringan', 'harga_mulai' => 150000, 'total_order' => 3, 'total_pendapatan' => 450000]
            ];
            return [
                'summary' => ['total_data' => 4, 'total_omset' => 2700000.00, 'total_orders' => 20, 'completed' => 20],
                'rows' => $rows,
                'chartData' => [
                    'type' => 'bar',
                    'labels' => array_column($rows, 'nama_jasa'),
                    'datasets' => [['label' => 'Jumlah Pemesanan', 'data' => [5, 8, 4, 3], 'backgroundColor' => '#06b6d4']]
                ],
                'tipe' => $tipe,
                'periode' => $periode
            ];
        } elseif ($tipe === 'teknisi') {
            $rows = [
                ['id' => 3, 'nama_teknisi' => 'Ahmad Dani (XI TKJ 1)', 'email' => 'ahmad.teknisi@tkj.sch.id', 'total_tugas' => 6, 'tugas_selesai' => 5, 'tugas_proses' => 1, 'avg_rating' => 5.0],
                ['id' => 4, 'nama_teknisi' => 'Rizky Pratama (XII TKJ 2)', 'email' => 'rizky.teknisi@tkj.sch.id', 'total_tugas' => 4, 'tugas_selesai' => 3, 'tugas_proses' => 1, 'avg_rating' => 4.8]
            ];
            return [
                'summary' => ['total_data' => 2, 'total_omset' => 10, 'completed' => 8, 'pending' => 2],
                'rows' => $rows,
                'chartData' => [
                    'type' => 'bar',
                    'labels' => array_column($rows, 'nama_teknisi'),
                    'datasets' => [
                        ['label' => 'Tugas Selesai', 'data' => [5, 3], 'backgroundColor' => '#10b981'],
                        ['label' => 'Sedang Diproses', 'data' => [1, 1], 'backgroundColor' => '#f59e0b']
                    ]
                ],
                'tipe' => $tipe,
                'periode' => $periode
            ];
        } elseif ($tipe === 'pendapatan') {
            $rows = [
                ['id' => 1, 'kode_pesanan' => 'ORD-20260901-001', 'customer_name' => 'Budi Santoso', 'metode_pembayaran' => 'transfer', 'jumlah' => 1000000.00, 'status' => 'dibayar', 'tanggal_pembayaran' => '2026-09-02 17:00:00'],
                ['id' => 2, 'kode_pesanan' => 'ORD-20260902-002', 'customer_name' => 'Siti Rahmawati', 'metode_pembayaran' => 'transfer', 'jumlah' => 650000.00, 'status' => 'menunggu_verifikasi', 'tanggal_pembayaran' => null],
                ['id' => 3, 'kode_pesanan' => 'ORD-20260903-003', 'customer_name' => 'Budi Santoso', 'metode_pembayaran' => 'cash', 'jumlah' => 350000.00, 'status' => 'belum_dibayar', 'tanggal_pembayaran' => null]
            ];
            return [
                'summary' => ['total_data' => 3, 'total_omset' => 2000000.00, 'completed' => 1, 'pending' => 2],
                'rows' => $rows,
                'chartData' => [
                    'type' => 'pie',
                    'labels' => ['Transfer Bank', 'Cash (Tunai)'],
                    'datasets' => [['label' => 'Pendapatan (Rp)', 'data' => [1650000, 350000], 'backgroundColor' => ['#06b6d4', '#f59e0b']]]
                ],
                'tipe' => $tipe,
                'periode' => $periode
            ];
        } else { // customer
            $rows = [
                ['id' => 5, 'customer_name' => 'Budi Santoso', 'email' => 'budi.customer@gmail.com', 'total_pesanan' => 2, 'total_pengeluaran' => 1350000.00],
                ['id' => 6, 'customer_name' => 'Siti Rahmawati', 'email' => 'siti.customer@gmail.com', 'total_pesanan' => 1, 'total_pengeluaran' => 650000.00]
            ];
            return [
                'summary' => ['total_data' => 2, 'total_omset' => 2000000.00, 'completed' => 3, 'pending' => 0],
                'rows' => $rows,
                'chartData' => [
                    'type' => 'bar',
                    'labels' => array_column($rows, 'customer_name'),
                    'datasets' => [['label' => 'Total Transaksi (Rp)', 'data' => [1350000, 650000], 'backgroundColor' => '#8b5cf6']]
                ],
                'tipe' => $tipe,
                'periode' => $periode
            ];
        }
    }
}

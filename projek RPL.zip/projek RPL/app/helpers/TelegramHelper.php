<?php
/**
 * TelegramHelper - Helper Integrasi Bot Telegram untuk TKJ Smart Service
 * Menangani pengiriman notifikasi, pesan status pesanan, dan integrasi Telegram Bot.
 */

class TelegramHelper {

    /**
     * Dapatkan Bot Token dari Environment atau Konstanta
     */
    public static function getBotToken() {
        if (defined('TELEGRAM_BOT_TOKEN') && !empty(TELEGRAM_BOT_TOKEN)) {
            return TELEGRAM_BOT_TOKEN;
        }
        return getenv('TELEGRAM_BOT_TOKEN') ?: '';
    }

    /**
     * Kirim Pesan Teks ke Telegram Chat ID
     * 
     * @param string|int $chatId ID Chat Pengguna
     * @param string $message Isi Pesan
     * @param array|null $replyMarkup Keyboard / Inline Markup (Opsional)
     * @return array [success => bool, message => string]
     */
    public static function sendMessage($chatId, $message, $replyMarkup = null) {
        $token = self::getBotToken();

        if (empty($chatId)) {
            return [
                'success' => false,
                'message' => 'Chat ID Telegram kosong.'
            ];
        }

        if (empty($token)) {
            // Mode Simulasi / Development tanpa token aktif
            self::logTelegram($chatId, $message);
            return [
                'success' => true,
                'simulated' => true,
                'message' => 'Pesan Telegram disimulasikan (Bot token belum dikonfigurasi).'
            ];
        }

        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        $data = [
            'chat_id' => $chatId,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];

        if (!empty($replyMarkup)) {
            $data['reply_markup'] = json_encode($replyMarkup);
        }

        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_TIMEOUT, 8);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $resArr = json_decode($response, true);
            if ($httpCode === 200 && !empty($resArr['ok'])) {
                return ['success' => true, 'data' => $resArr];
            }

            return [
                'success' => false,
                'message' => $resArr['description'] ?? 'Gagal mengirim pesan Telegram.'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Kirim Notifikasi Pesanan Baru / Update Status
     */
    public static function sendOrderNotification($chatId, $orderData, $statusTitle = 'Update Status Pesanan') {
        $text = "<b>🔔 [TKJ SMART SERVICE] - {$statusTitle}</b>\n\n";
        if (is_array($orderData)) {
            if (!empty($orderData['id'])) {
                $text .= "ID Pesanan: #{$orderData['id']}\n";
            }
            if (!empty($orderData['nama_layanan'])) {
                $text .= "Layanan: {$orderData['nama_layanan']}\n";
            }
            if (!empty($orderData['status'])) {
                $text .= "Status: <b>" . strtoupper($orderData['status']) . "</b>\n";
            }
            if (!empty($orderData['deskripsi_masalah'])) {
                $text .= "Deskripsi: {$orderData['deskripsi_masalah']}\n";
            }
        } elseif (is_string($orderData)) {
            $text .= $orderData;
        }

        $text .= "\n<i>Terima kasih telah mempercayakan layanan IT pada Unit Bisnis Siswa TKJ.</i>";

        return self::sendMessage($chatId, $text);
    }

    /**
     * Sensor / Masking Chat ID untuk Tampilan UI Aman
     */
    public static function maskChatId($chatId) {
        $str = (string)$chatId;
        $len = strlen($str);
        if ($len <= 4) return '***';
        return substr($str, 0, 2) . str_repeat('*', $len - 4) . substr($str, -2);
    }

    /**
     * Log Pesan Telegram Lokal
     */
    private static function logTelegram($chatId, $message) {
        $logDir = APPROOT . '/logs';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0777, true);
        }
        $logFile = $logDir . '/telegram.log';
        $entry = "[" . date('Y-m-d H:i:s') . "] TO: {$chatId} | MSG: " . str_replace(["\r", "\n"], ' ', $message) . "\n";
        @file_put_contents($logFile, $entry, FILE_APPEND);
    }
}


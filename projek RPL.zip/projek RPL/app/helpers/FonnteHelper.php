<?php
/**
 * FonnteHelper - WhatsApp Gateway Helper menggunakan API Fonnte
 * Digunakan untuk pengiriman OTP Login, OTP Registrasi, dan Notifikasi WhatsApp
 */

class FonnteHelper {

    /**
     * Format nomor HP ke format standar 628xxx
     */
    public static function formatPhone($phone) {
        $clean = preg_replace('/\D/', '', (string)$phone);
        if (strpos($clean, '0') === 0) {
            $clean = '62' . substr($clean, 1);
        } elseif (strpos($clean, '8') === 0) {
            $clean = '62' . $clean;
        }
        return $clean;
    }

    /**
     * Sensor nomor telepon untuk tampilan aman di antarmuka (contoh: 62812****7890)
     */
    public static function maskPhone($phone) {
        $clean = self::formatPhone($phone);
        $len = strlen($clean);
        if ($len <= 6) return $clean;
        
        $start = substr($clean, 0, 5);
        $end = substr($clean, -3);
        $stars = str_repeat('*', max(4, $len - 8));
        return $start . $stars . $end;
    }

    /**
     * Kirim pesan teks WhatsApp melalui API Fonnte
     * 
     * @param string $target Nomor telepon tujuan format 628xxx
     * @param string $message Isi pesan WhatsApp
     * @return array [success => bool, message => string, data => array]
     */
    public static function sendWhatsApp($target, $message) {
        $token = defined('FONNTE_TOKEN') ? FONNTE_TOKEN : 'XK9gTunu6eUntnSoWSWM';
        $apiUrl = defined('FONNTE_API_URL') ? FONNTE_API_URL : 'https://api.fonnte.com/send';

        $cleanPhone = self::formatPhone($target);

        if (empty($cleanPhone) || strlen($cleanPhone) < 10) {
            return [
                'success' => false,
                'message' => 'Nomor WhatsApp tidak valid (minimal 10 digit).'
            ];
        }

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $apiUrl);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, [
            'target'      => $cleanPhone,
            'message'     => $message,
            'countryCode' => '62',
        ]);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'Authorization: ' . $token
        ]);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);

        $responseRaw = curl_exec($curl);
        $curlError   = curl_error($curl);
        $httpCode    = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        $json = json_decode($responseRaw, true);

        // Catat ke log file
        self::writeLog($cleanPhone, $message, $responseRaw, $curlError);

        if ($curlError) {
            return [
                'success' => false,
                'message' => 'cURL Error: ' . $curlError,
                'raw'     => $responseRaw
            ];
        }

        if ($json === null) {
            return [
                'success' => false,
                'message' => 'Respons server tidak valid (HTTP ' . $httpCode . '): ' . $responseRaw
            ];
        }

        if (isset($json['status']) && $json['status'] === true) {
            return [
                'success' => true,
                'message' => $json['detail'] ?? 'Pesan WhatsApp berhasil dikirim.',
                'data'    => $json
            ];
        }

        $reason = $json['reason'] ?? ($json['detail'] ?? ($json['message'] ?? 'Status false dari Fonnte'));
        return [
            'success' => false,
            'message' => $reason,
            'data'    => $json
        ];
    }

    /**
     * Kirim Kode OTP Verifikasi WhatsApp
     * Format: "Kode OTP Anda adalah: [KODE_OTP]"
     * 
     * @param string $phone Nomor HP
     * @param string $otpCode 6 digit kode OTP
     * @return array
     */
    public static function sendOtp($phone, $otpCode) {
        $message = "Kode OTP Anda adalah: " . $otpCode;
        return self::sendWhatsApp($phone, $message);
    }

    /**
     * Kirim Pesan Notifikasi Sukses
     */
    public static function sendNotification($phone, $title, $body) {
        $msg = "*TKJ SMART SERVICE*\n";
        $msg .= "📢 *" . $title . "*\n\n";
        $msg .= $body . "\n\n";
        $msg .= "— _Unit Bisnis TKJ Smart Service_";

        return self::sendWhatsApp($phone, $msg);
    }

    /**
     * Menulis riwayat pesan ke file log
     */
    private static function writeLog($target, $message, $responseRaw, $error = '') {
        try {
            $logDir = APPROOT . '/database';
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0777, true);
            }
            $logFile = $logDir . '/fonnte_wa_log.txt';
            $time = date('Y-m-d H:i:s');
            $logEntry = "[{$time}] TO: {$target} | ERR: " . ($error ?: 'none') . " | RESP: " . trim($responseRaw) . "\n";
            @file_put_contents($logFile, $logEntry, FILE_APPEND);
        } catch (\Throwable $e) {}
    }
}

<?php
/**
 * MailHelper - Helper Pengiriman Email & Notifikasi OTP
 * Mendukung pengiriman HTML Email via PHP mail() atau Socket SMTP
 * Dilengkapi template modern dan fallback mode pengujian lokal
 */

class MailHelper {

    /**
     * Kirim Email Kode OTP
     * 
     * @param string $toEmail Alamat email tujuan
     * @param string $recipientName Nama penerima
     * @param string $otpCode Kode 6 digit OTP
     * @param string $purpose Tujuan verifikasi (Registrasi Akun, Reset Password, dll)
     * @return array Status pengiriman ['success' => bool, 'message' => string, 'otp' => string]
     */
    public static function sendOtpEmail($toEmail, $recipientName, $otpCode, $purpose = 'Registrasi Akun Customer') {
        $subject = "Kode OTP Verifikasi {$purpose} - " . APP_NAME;
        $htmlBody = self::renderOtpTemplate($recipientName, $otpCode, $purpose, $toEmail);
        $plainBody = "Halo {$recipientName},\n\nKode verifikasi OTP Anda untuk {$purpose} di " . APP_NAME . " adalah: {$otpCode}\nKode ini berlaku selama " . (defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES : 5) . " menit.\n\nJangan bagikan kode ini kepada siapapun.";

        // Catat ke Session untuk akses debug / fallback pengujian di localhost XAMPP
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION['last_sent_otp'] = $otpCode;
            $_SESSION['last_sent_email'] = $toEmail;
            $_SESSION['last_otp_time'] = time();
        }

        // Catat ke log file scratch jika folder writable
        self::logEmail($toEmail, $subject, $otpCode);

        // Eksekusi pengiriman email
        $sent = self::send($toEmail, $subject, $htmlBody, $plainBody);

        return [
            'success' => $sent,
            'otp' => $otpCode,
            'email' => $toEmail,
            'message' => $sent ? 'Email OTP berhasil dikirim.' : 'Email disimulasikan (lingkungan lokal XAMPP).'
        ];
    }

    /**
     * Dispatcher Pengiriman Email (SMTP atau native mail())
     */
    public static function send($to, $subject, $htmlBody, $plainBody = '') {
        $fromEmail = defined('APP_EMAIL') ? APP_EMAIL : 'noreply@tkjsmartservice.sch.id';
        $fromName  = defined('APP_NAME') ? APP_NAME : 'TKJ Smart Service';

        // Cek jika SMTP eksternal diaktifkan di config
        if (defined('MAIL_SMTP_ENABLED') && MAIL_SMTP_ENABLED === true && !empty(MAIL_SMTP_USER)) {
            $smtpSent = self::sendViaSmtp($to, $subject, $htmlBody, $fromEmail, $fromName);
            if ($smtpSent) return true;
        }

        // Header MIME untuk HTML Email
        $headers = [];
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        $headers[] = 'From: ' . sprintf('=?UTF-8?B?%s?= <%s>', base64_encode($fromName), $fromEmail);
        $headers[] = 'Reply-To: ' . $fromEmail;
        $headers[] = 'X-Mailer: PHP/' . phpversion();

        // Safe call mail() - tangani kemungkinan error sendmail di XAMPP lokal tanpa crash
        $result = false;
        try {
            $result = @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $htmlBody, implode("\r\n", $headers));
        } catch (\Throwable $e) {
            $result = false;
        }

        return $result;
    }

    /**
     * Client SMTP RFC-Compliant untuk Gmail SMTP (Port 465 SSL atau Port 587 TLS)
     */
    private static function sendViaSmtp($to, $subject, $htmlBody, $fromEmail, $fromName) {
        $host = defined('MAIL_SMTP_HOST') ? MAIL_SMTP_HOST : 'smtp.gmail.com';
        $port = defined('MAIL_SMTP_PORT') ? (int)MAIL_SMTP_PORT : 465;
        $username = defined('MAIL_SMTP_USER') ? trim(MAIL_SMTP_USER) : '';
        $password = defined('MAIL_SMTP_PASS') ? trim(MAIL_SMTP_PASS) : '';
        $secure = defined('MAIL_SMTP_SECURE') ? strtolower(MAIL_SMTP_SECURE) : ($port === 465 ? 'ssl' : 'tls');

        if (empty($username) || empty($password)) {
            return false;
        }

        // Jika menggunakan SMTP Gmail, alamat pengirim harus email Gmail yang login
        if (strpos($host, 'gmail.com') !== false && !empty($username)) {
            $fromEmail = $username;
        }

        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ]);

        $remoteAddress = ($port === 465 || $secure === 'ssl') ? "ssl://{$host}:{$port}" : "tcp://{$host}:{$port}";

        try {
            $socket = @stream_socket_client($remoteAddress, $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $context);
            if (!$socket) {
                self::logEmail($to, "SMTP Connection Failed ({$errstr})", "ERR");
                return false;
            }

            stream_set_timeout($socket, 15);

            // 1. Baca Greeting Server (220)
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '220') {
                self::logEmail($to, "SMTP Greeting Error: {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // 2. Kirim EHLO
            fputs($socket, "EHLO localhost\r\n");
            $response = self::readSmtpResponse($socket);

            // 3. Jika menggunakan Port 587 (TLS), jalankan STARTTLS
            if ($port === 587 || $secure === 'tls') {
                fputs($socket, "STARTTLS\r\n");
                $response = self::readSmtpResponse($socket);
                if (substr($response, 0, 3) !== '220') {
                    self::logEmail($to, "STARTTLS Error: {$response}", "ERR");
                    fclose($socket);
                    return false;
                }

                $cryptoMethod = STREAM_CRYPTO_METHOD_TLS_CLIENT;
                if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
                    $cryptoMethod |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
                }
                if (!@stream_socket_enable_crypto($socket, true, $cryptoMethod)) {
                    self::logEmail($to, "TLS Handshake Failed", "ERR");
                    fclose($socket);
                    return false;
                }

                // Kirim EHLO kembali setelah TLS aktif
                fputs($socket, "EHLO localhost\r\n");
                $response = self::readSmtpResponse($socket);
            }

            // 4. Autentikasi LOGIN
            fputs($socket, "AUTH LOGIN\r\n");
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '334') {
                self::logEmail($to, "AUTH LOGIN rejected: {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // Kirim Username (Base64)
            fputs($socket, base64_encode($username) . "\r\n");
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '334') {
                self::logEmail($to, "Username rejected: {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // Kirim Password / Sandi Aplikasi (Base64)
            // Hapus spasi jika pengguna memasukkan format 'abcd efgh ijkl mnop'
            $cleanPassword = str_replace(' ', '', $password);
            fputs($socket, base64_encode($cleanPassword) . "\r\n");
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '235') {
                self::logEmail($to, "Password rejected (Gunakan 16 digit Sandi Aplikasi): {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // 5. MAIL FROM
            fputs($socket, "MAIL FROM: <{$fromEmail}>\r\n");
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '250') {
                self::logEmail($to, "MAIL FROM Error: {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // 6. RCPT TO
            fputs($socket, "RCPT TO: <{$to}>\r\n");
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '250') {
                self::logEmail($to, "RCPT TO Error: {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // 7. DATA
            fputs($socket, "DATA\r\n");
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '354') {
                self::logEmail($to, "DATA Error: {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // Susun Email Content & Headers
            $emailContent  = "MIME-Version: 1.0\r\n";
            $emailContent .= "Content-Type: text/html; charset=UTF-8\r\n";
            $emailContent .= "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <{$fromEmail}>\r\n";
            $emailContent .= "To: <{$to}>\r\n";
            $emailContent .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
            $emailContent .= "Date: " . date('r') . "\r\n";
            $emailContent .= "X-Mailer: TKJ-Smart-Service-Mailer\r\n\r\n";
            $emailContent .= $htmlBody . "\r\n.\r\n";

            fputs($socket, $emailContent);
            $response = self::readSmtpResponse($socket);
            if (substr($response, 0, 3) !== '250') {
                self::logEmail($to, "Message Send Error: {$response}", "ERR");
                fclose($socket);
                return false;
            }

            // 8. QUIT
            fputs($socket, "QUIT\r\n");
            fclose($socket);

            self::logEmail($to, "Email OTP terkirim sukses via Gmail SMTP!", "OK");
            return true;
        } catch (\Throwable $e) {
            self::logEmail($to, "SMTP Exception: " . $e->getMessage(), "ERR");
            return false;
        }
    }

    /**
     * Membaca Respon Multiline SMTP sesuai RFC 5321
     */
    private static function readSmtpResponse($socket) {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            // Jika karakter ke-4 adalah spasi (misal '250 OK'), berarti pesan selesai
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        return trim($response);
    }

    /**
     * Render Template Email HTML Bergaya Modern TKJ Smart Service
     */
    public static function renderOtpTemplate($recipientName, $otpCode, $purpose, $toEmail) {
        $appName = defined('APP_NAME') ? APP_NAME : 'TKJ Smart Service';
        $schoolName = defined('APP_SCHOOL') ? APP_SCHOOL : 'SMK Negeri TKJ';
        $expiryMinutes = defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES : 5;
        $otpFormatted = implode(' ', str_split($otpCode)); // Format 1 2 3 4 5 6

        return '<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kode OTP Verifikasi - ' . htmlspecialchars($appName) . '</title>
</head>
<body style="margin: 0; padding: 0; background-color: #070c18; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #070c18; padding: 30px 15px;">
        <tr>
            <td align="center">
                <!-- Outer Container Card -->
                <table role="presentation" width="100%" max-width="580" style="max-width: 580px; background-color: #0d1527; border: 1px solid rgba(6, 182, 212, 0.3); border-radius: 16px; overflow: hidden; box-shadow: 0 15px 35px rgba(0, 0, 0, 0.6);">
                    
                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #0d1527 0%, #152238 100%); padding: 35px 30px 25px 30px; text-align: center; border-bottom: 1px solid rgba(255, 255, 255, 0.08);">
                            <div style="display: inline-block; width: 52px; height: 52px; line-height: 52px; border-radius: 14px; background: rgba(6, 182, 212, 0.15); border: 1px solid rgba(6, 182, 212, 0.4); text-align: center; margin-bottom: 12px;">
                                <span style="font-size: 26px;">⚡</span>
                            </div>
                            <h1 style="margin: 0; font-size: 22px; font-weight: 700; color: #ffffff; letter-spacing: -0.5px;">' . htmlspecialchars($appName) . '</h1>
                            <p style="margin: 4px 0 0 0; font-size: 13px; color: #06b6d4; font-weight: 500;">Unit Bisnis & Teaching Factory ' . htmlspecialchars($schoolName) . '</p>
                        </td>
                    </tr>

                    <!-- Body Content -->
                    <tr>
                        <td style="padding: 35px 35px 25px 35px;">
                            <h2 style="margin: 0 0 16px 0; font-size: 19px; font-weight: 600; color: #ffffff;">Halo, ' . htmlspecialchars($recipientName) . '! 👋</h2>
                            <p style="margin: 0 0 20px 0; font-size: 14px; line-height: 1.6; color: #94a3b8;">
                                Terima kasih telah melakukan <strong style="color: #ffffff;">' . htmlspecialchars($purpose) . '</strong> di <strong>' . htmlspecialchars($appName) . '</strong>. Untuk menyelesaikan proses ini, silakan masukkan 6 digit kode OTP (One-Time Password) berikut:
                            </p>

                            <!-- OTP Box -->
                            <div style="background: #152238; border: 2px dashed #06b6d4; border-radius: 14px; padding: 22px 15px; text-align: center; margin: 25px 0;">
                                <div style="font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: #94a3b8; margin-bottom: 8px;">KODE VERIFIKASI OTP</div>
                                <div style="font-family: \'Courier New\', Courier, monospace; font-size: 38px; font-weight: 800; letter-spacing: 10px; color: #22d3ee; text-shadow: 0 0 15px rgba(6, 182, 212, 0.5);">
                                    ' . htmlspecialchars($otpFormatted) . '
                                </div>
                                <div style="font-size: 12px; color: #cbd5e1; margin-top: 10px;">
                                    ⏱️ Berlaku selama <strong style="color: #facc15;">' . $expiryMinutes . ' Menit</strong>
                                </div>
                            </div>

                            <!-- Security Warnings -->
                            <div style="background: rgba(239, 68, 68, 0.1); border-left: 3px solid #ef4444; border-radius: 6px; padding: 12px 16px; margin-bottom: 25px;">
                                <p style="margin: 0; font-size: 13px; line-height: 1.5; color: #fca5a5;">
                                    <strong>Peringatan Keamanan:</strong> Jangan pernah memberikan kode ini kepada siapapun, termasuk guru, teknisi, maupun operator sekolah.
                                </p>
                            </div>

                            <p style="margin: 0; font-size: 13px; line-height: 1.6; color: #64748b;">
                                Jika Anda tidak merasa melakukan pendaftaran akun dengan email <strong style="color: #94a3b8;">' . htmlspecialchars($toEmail) . '</strong>, silakan abaikan pesan email ini dengan aman.
                            </p>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #070c18; padding: 20px 30px; text-align: center; border-top: 1px solid rgba(255, 255, 255, 0.05);">
                            <p style="margin: 0 0 6px 0; font-size: 12px; color: #64748b;">
                                &copy; ' . date('Y') . ' ' . htmlspecialchars($appName) . '. All rights reserved.
                            </p>
                            <p style="margin: 0; font-size: 11px; color: #475569;">
                                Pesan ini dibuat otomatis oleh sistem. Jangan membalas email ini secara langsung.
                            </p>
                        </td>
                    </tr>

                </table>
            </td>
        </tr>
    </table>
</body>
</html>';
    }

    /**
     * Catat log pengiriman email untuk kemudahan monitoring & pengujian lokal
     */
    private static function logEmail($to, $subject, $otp) {
        try {
            $logDir = APPROOT . '/database';
            if (!file_exists($logDir)) {
                @mkdir($logDir, 0755, true);
            }
            $logFile = $logDir . '/otp_mail_log.txt';
            $logEntry = "[" . date('Y-m-d H:i:s') . "] TO: {$to} | OTP: {$otp} | SUBJECT: {$subject}\n";
            @file_put_contents($logFile, $logEntry, FILE_APPEND);
        } catch (\Throwable $e) {
            // ignore logging error
        }
    }
}

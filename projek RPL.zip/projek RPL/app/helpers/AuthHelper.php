<?php
/**
 * AuthHelper - Helper untuk Autentikasi & Role-Based Access Control (RBAC)
 */

class AuthHelper {

    /**
     * Memastikan Session Aktif & Secure
     */
    public static function init() {
        if (class_exists('SecurityHelper')) {
            SecurityHelper::initSession();
        } elseif (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * Set Session Login User & Regenerate Session ID (Mencegah Session Fixation)
     */
    public static function login($user) {
        self::init();
        session_regenerate_id(true); // Regenerate ID untuk proteksi session fixation
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['nama'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
    }


    /**
     * Logout User & Hapus Session
     */
    public static function logout() {
        self::init();
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

    /**
     * Cek Apakah User Sudah Login
     */
    public static function isLoggedIn() {
        self::init();
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }

    /**
     * Mendapatkan Data User Logged-in
     */
    public static function user() {
        self::init();
        if (self::isLoggedIn()) {
            return [
                'id' => $_SESSION['user_id'],
                'nama' => $_SESSION['user_name'],
                'email' => $_SESSION['user_email'],
                'role' => $_SESSION['user_role']
            ];
        }
        return null;
    }

    /**
     * Mendapatkan URL Dashboard berdasarkan Role
     */
    public static function getDashboardUrl($role = null) {
        if (!$role && self::isLoggedIn()) {
            $role = $_SESSION['user_role'];
        }

        switch ($role) {
            case 'admin':
                return BASE_URL . '/admin/dashboard';
            case 'customer':
                return BASE_URL . '/customer/dashboard';
            case 'teknisi':
                return BASE_URL . '/teknisi/dashboard';
            case 'operator':
                return BASE_URL . '/operator/dashboard';
            case 'kepala_sekolah':
                return BASE_URL . '/kepala-sekolah/dashboard';
            default:
                return BASE_URL;
        }
    }

    /**
     * Middleware Proteksi Halaman Berdasarkan Role (RBAC)
     * 
     * @param string|array $allowedRoles Role yang diizinkan (misal: 'customer' atau ['operator', 'kepala_sekolah'])
     */
    public static function checkRole($allowedRoles) {
        self::init();

        // 1. Jika belum login, simpan intended URL lalu redirect ke halaman login
        if (!self::isLoggedIn()) {
            if (!empty($_SERVER['REQUEST_URI'])) {
                $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
            }
            self::setFlash('auth_error', 'Silakan login terlebih dahulu untuk mengakses formulir pemesanan jasa.', 'info');
            header('Location: ' . BASE_URL . '/login');
            exit;
        }

        // Convert ke array jika string
        if (is_string($allowedRoles)) {
            $allowedRoles = [$allowedRoles];
        }

        $currentRole = $_SESSION['user_role'] ?? '';

        // Role 'admin' adalah Superuser Administrator dengan hak akses penuh ke seluruh modul sistem (termasuk customer, teknisi, operator, dll.)
        if ($currentRole === 'admin') {
            return;
        }

        // 2. Jika role user tidak ada di daftar $allowedRoles, redirect ke dashboard miliknya
        if (!in_array($currentRole, $allowedRoles)) {
            self::setFlash('auth_error', 'Anda tidak memiliki hak akses ke halaman tersebut!', 'danger');
            header('Location: ' . self::getDashboardUrl($currentRole));
            exit;
        }
    }

    /**
     * Set Flash Message
     */
    public static function setFlash($name, $message, $type = 'info') {
        self::init();
        $_SESSION['flash'][$name] = [
            'message' => $message,
            'type' => $type
        ];
    }

    /**
     * Get & Delete Flash Message
     */
    public static function getFlash($name) {
        self::init();
        if (isset($_SESSION['flash'][$name])) {
            $flash = $_SESSION['flash'][$name];
            unset($_SESSION['flash'][$name]);
            return $flash;
        }
        return null;
    }
}

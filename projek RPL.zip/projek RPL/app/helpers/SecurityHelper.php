<?php
/**
 * SecurityHelper - Helper Proteksi Keamanan Sistem
 * Menangani Session Hardening, Protection CSRF, XSS Sanitization, & Validation Safe File Uploads
 */

class SecurityHelper {

    /**
     * Inisialisasi Session Aman dengan HTTPOnly & SameSite Lax
     */
    public static function initSession() {
        if (session_status() === PHP_SESSION_NONE) {
            $cookieParams = [
                'lifetime' => 0,
                'path' => '/',
                'domain' => '',
                'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                'httponly' => true,
                'samesite' => 'Lax'
            ];
            session_set_cookie_params($cookieParams);
            session_start();
        }

        // Generate CSRF token jika belum ada
        self::generateCsrfToken();
    }

    /**
     * Generate Token CSRF Unik per Session
     */
    public static function generateCsrfToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * Mendapatkan Input Form Hidden CSRF
     */
    public static function csrfField() {
        $token = self::generateCsrfToken();
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    }

    /**
     * Alias untuk csrfField()
     */
    public static function csrfTokenInput() {
        return self::csrfField();
    }

    /**
     * Verifikasi Token CSRF pada HTTP POST Request
     */
    public static function verifyCsrfToken($token = null) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $submittedToken = $token ?: ($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
            $sessionToken = $_SESSION['csrf_token'] ?? '';

            if (empty($sessionToken) || empty($submittedToken) || !hash_equals($sessionToken, $submittedToken)) {
                http_response_code(403);
                AuthHelper::setFlash('auth_error', 'Permintaan tidak valid atau token CSRF telah kedaluwarsa. Silakan coba lagi.', 'danger');
                $referer = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/login');
                header('Location: ' . $referer);
                exit;
            }
        }
        return true;
    }

    /**
     * Escape Output HTML untuk Mencegah XSS (Cross-Site Scripting)
     */
    public static function e($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
    }

    /**
     * Sanitasi Input String
     */
    public static function sanitizeString($string) {
        if (is_null($string)) return '';
        $string = trim($string);
        return strip_tags($string);
    }

    /**
     * Validasi & Proses Upload File Aman (MIME, Extension, Web Shell Prevention)
     * 
     * @param array $fileInput Array $_FILES['input_name']
     * @param string $targetSubdir Sub-direktori tujuan di public/uploads/
     * @param array $allowedExtensions Whitelist ekstensi (misal: ['jpg', 'jpeg', 'png', 'webp', 'pdf'])
     * @param array $allowedMimeTypes Whitelist MIME Types
     * @param int $maxSizeBytes Maksimal ukuran file (default 5MB)
     * @return string|false Return relative path file jika sukses, false jika gagal
     */
    public static function uploadFile($fileInput, $targetSubdir, $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'pdf'], $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], $maxSizeBytes = 5242880) {
        
        // 1. Cek Error Code Upload
        if (!isset($fileInput['error']) || is_array($fileInput['error']) || $fileInput['error'] !== UPLOAD_ERR_OK) {
            return false;
        }

        // 2. Cek Ukuran File
        if ($fileInput['size'] > $maxSizeBytes) {
            return false;
        }

        // 3. Blacklist Ekstensi Berbahaya (Web Shell / Executable Script Prevention)
        $fileName = $fileInput['name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $dangerousExts = ['php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phps', 'phar', 'exe', 'sh', 'bat', 'cmd', 'js', 'html', 'htm', 'htaccess', 'pl', 'cgi'];
        
        if (in_array($fileExt, $dangerousExts)) {
            return false;
        }

        // 4. Whitelist Ekstensi
        if (!in_array($fileExt, $allowedExtensions)) {
            return false;
        }

        // 5. Check Real MIME Type (finfo)
        $tmpName = $fileInput['tmp_name'];
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $realMime = finfo_file($finfo, $tmpName);
            finfo_close($finfo);

            if (!in_array($realMime, $allowedMimeTypes)) {
                return false;
            }
        }

        // 6. Jika file gambar, validasi integritas struktur gambar
        if (strpos($fileInput['type'], 'image') !== false || in_array($fileExt, ['jpg', 'jpeg', 'png', 'webp'])) {
            $imageSize = @getimagesize($tmpName);
            if ($imageSize === false && $fileExt !== 'pdf') {
                return false;
            }
        }

        // 7. Generate Random Name (Mencegah Path Traversal & File Overwrite)
        $targetDir = APPROOT . '/public/uploads/' . trim($targetSubdir, '/') . '/';
        if (!file_exists($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        $safeFileName = bin2hex(random_bytes(16)) . '_' . time() . '.' . $fileExt;
        $targetPath = $targetDir . $safeFileName;

        if (move_uploaded_file($tmpName, $targetPath)) {
            return 'uploads/' . trim($targetSubdir, '/') . '/' . $safeFileName;
        }

        return false;
    }
}

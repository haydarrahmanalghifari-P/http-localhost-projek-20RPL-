<?php
/**
 * AIService - Service khusus Pengolah AI Assistant TKJ Smart Service
 * Mendukung Eksternal Gemini API dan Fallback Intelligent Mock AI berbasis database
 */

require_once APPROOT . '/app/models/ServiceModel.php';
require_once APPROOT . '/app/models/FaqModel.php';
require_once APPROOT . '/app/models/OrderModel.php';

class AIService {

    private $serviceModel;
    private $faqModel;
    private $orderModel;

    public function __construct() {
        $this->serviceModel = new ServiceModel();
        $this->faqModel = new FaqModel();
        $this->orderModel = new OrderModel();
    }

    /**
     * Entry Point Utama untuk memproses pesan customer
     * 
     * @param array $user Data user (customer) yang sedang login
     * @param string $userMessage Pesan pertanyaan customer
     * @return string Jawaban respons AI Assistant
     */
    public function generateResponse($user, $userMessage, $provider = null, $customApiKey = null) {
        $userName = htmlspecialchars($user['nama'] ?? 'Pengunjung');
        $isLoggedIn = !empty($user['id']) || ($userName !== 'Pengunjung' && $userName !== 'Kak');

        // Intent Spesifik: Pengguna menanyakan identitas / profil "siapa saya"
        if ($this->isWhoAmIQuery($userMessage)) {
            if ($isLoggedIn) {
                $roleLabel = strtoupper($user['role'] ?? 'Customer');
                $emailInfo = !empty($user['email']) ? " ({$user['email']})" : "";
                return "Anda login sebagai **{$userName}** (**{$roleLabel}**){$emailInfo}.";
            } else {
                return "Anda belum login (Tamu). Silakan login terlebih dahulu.";
            }
        }

        // AI tidak melayani percodingan dan topik di luar layanan TKJ
        if ($this->isCodingQuery($userMessage)) {
            return $this->getCodingRefusalReply();
        }

        $configFile = APPROOT . '/config/ai_keys.json';
        $dynConfig = file_exists($configFile) ? json_decode(file_get_contents($configFile), true) : null;
        if (!empty($dynConfig['primary_key']) && empty($customApiKey)) {
            $customApiKey = $dynConfig['primary_key'];
            if (empty($provider) && !empty($dynConfig['active_provider'])) {
                $provider = $dynConfig['active_provider'];
            }
        }

        $activeProvider = !empty($provider) ? strtolower(trim($provider)) : (defined('AI_PROVIDER') ? AI_PROVIDER : 'grok');

        // 1. Coba panggil Node.js Chatbot Server terlebih dahulu jika aktif
        $nodeUrl = defined('NODE_CHATBOT_URL') ? trim(NODE_CHATBOT_URL) : 'http://localhost:5000';
        $nodeResponse = $this->callNodeJsChatbot($nodeUrl, $user, $userMessage, $activeProvider, $customApiKey);
        if ($nodeResponse !== null) {
            return $nodeResponse;
        }

        // 2. Direct Provider Execution dari PHP Backend
        if ($activeProvider === 'grok') {
            $grokKey = !empty($customApiKey) ? $customApiKey : (defined('GROK_API_KEY') ? GROK_API_KEY : '');
            if (!empty($grokKey)) {
                $apiResponse = $this->callGrokApi($grokKey, $user, $userMessage);
                if ($apiResponse !== null) {
                    return $apiResponse;
                }
            }
        } elseif ($activeProvider === 'gemini') {
            $geminiKey = !empty($customApiKey) ? $customApiKey : (defined('GEMINI_API_KEY') ? GEMINI_API_KEY : (defined('AI_API_KEY') ? AI_API_KEY : ''));
            if (!empty($geminiKey)) {
                $apiResponse = $this->callGeminiApi($geminiKey, $user, $userMessage);
                if ($apiResponse !== null) {
                    return $apiResponse;
                }
            }
        } elseif ($activeProvider === 'deepseek') {
            $deepseekKey = !empty($customApiKey) ? $customApiKey : (defined('DEEPSEEK_API_KEY') ? DEEPSEEK_API_KEY : '');
            if (!empty($deepseekKey)) {
                $apiResponse = $this->callDeepSeekApi($deepseekKey, $user, $userMessage);
                if ($apiResponse !== null) {
                    return $apiResponse;
                }
            }
        } elseif ($activeProvider === 'database' || $activeProvider === 'mock') {
            return $this->generateMockResponse($user, $userMessage);
        }

        // Failover ke Kunci Cadangan jika auto_failover aktif
        if (!empty($dynConfig['auto_failover'])) {
            $backupKeys = [
                ['key' => $dynConfig['backup_key_1'] ?? '', 'provider' => $dynConfig['backup_provider_1'] ?? 'gemini'],
                ['key' => $dynConfig['backup_key_2'] ?? '', 'provider' => $dynConfig['backup_provider_2'] ?? 'grok'],
                ['key' => $dynConfig['backup_key_3'] ?? '', 'provider' => $dynConfig['backup_provider_3'] ?? 'gemini'],
            ];
            foreach ($backupKeys as $bk) {
                if (!empty($bk['key'])) {
                    if ($bk['provider'] === 'grok') {
                        $res = $this->callGrokApi($bk['key'], $user, $userMessage);
                        if ($res !== null) return $res;
                    } elseif ($bk['provider'] === 'gemini') {
                        $res = $this->callGeminiApi($bk['key'], $user, $userMessage);
                        if ($res !== null) return $res;
                    } elseif ($bk['provider'] === 'deepseek') {
                        $res = $this->callDeepSeekApi($bk['key'], $user, $userMessage);
                        if ($res !== null) return $res;
                    } elseif ($bk['provider'] === 'groq') {
                        $res = $this->callGroqApi($bk['key'], $user, $userMessage);
                        if ($res !== null) return $res;
                    } elseif ($bk['provider'] === 'openai') {
                        $res = $this->callOpenAiApi($bk['key'], $user, $userMessage);
                        if ($res !== null) return $res;
                    }
                }
            }
        }

        // 3. Fallback: Gunakan Mock AI Engine cerdas berbasis database
        return $this->generateMockResponse($user, $userMessage);
    }

    /**
     * Memanggil Node.js Chatbot Server (localhost:5000)
     */
    private function callNodeJsChatbot($nodeUrl, $user, $userMessage, $provider = 'grok', $customApiKey = null) {
        $ch = curl_init(rtrim($nodeUrl, '/') . '/api/chat');
        $payload = json_encode([
            'message' => $userMessage,
            'user' => $user,
            'provider' => $provider,
            'apiKey' => $customApiKey
        ]);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_TIMEOUT, 12);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200 && $response) {
            $data = json_decode($response, true);
            if (!empty($data['response'])) {
                return trim($data['response']);
            }
        }

        return null;
    }

    /**
     * Helper membuat prompt sistem berbasis data aktual database
     */
    private function buildSystemPromptText($user) {
        $services = $this->serviceModel->getAllServices();
        $faqs = $this->faqModel->getActiveFaqs();
        $orders = (!empty($user) && !empty($user['id'])) ? $this->orderModel->getOrdersByCustomer($user['id'], 'active') : [];

        $servicesList = [];
        foreach ($services as $idx => $s) {
            $feat = (!empty($s['features']) && is_array($s['features'])) ? ' (Fitur: ' . implode(', ', $s['features']) . ')' : '';
            $servicesList[] = ($idx + 1) . ". **{$s['title']}** | Biaya: `{$s['price']}` | Deskripsi: {$s['description']}{$feat}";
        }
        $servicesStr = implode("\n", $servicesList);

        $faqList = [];
        foreach ($faqs as $f) {
            $faqList[] = "* Tanya: {$f['pertanyaan']}\n  Jawab: {$f['jawaban']}";
        }
        $faqStr = implode("\n\n", $faqList);

        $ordersList = [];
        if (!empty($orders)) {
            foreach ($orders as $o) {
                $tek = !empty($o['nama_teknisi']) ? "Teknisi Siswa: {$o['nama_teknisi']}" : "Teknisi: Menunggu Konfirmasi Operator";
                $ordersList[] = "- Pesanan #{$o['kode_pesanan']} ({$o['nama_jasa']}) Status: " . strtoupper($o['status']) . " | {$tek} | Tanggal Pesan: {$o['tanggal_pemesanan']}";
            }
        }
        $ordersStr = !empty($ordersList) ? implode("\n", $ordersList) : "Customer belum memiliki pesanan aktif di database.";

        return "Anda adalah 'TKJ Smart Bot', asisten resmi unit bisnis IT 'TKJ Smart Service' (SMK Jurusan Teknik Komputer dan Jaringan).\n\n"
            . "[DATA RESMI DATABASE TKJ SMART SERVICE]\n"
            . "=== KATALOG LAYANAN JASA DARI DATABASE ===\n"
            . $servicesStr . "\n\n"
            . "=== PANDUAN FAQ RESMI DARI DATABASE ===\n"
            . $faqStr . "\n\n"
            . "=== PESANAN AKTIF CUSTOMER DI DATABASE ===\n"
            . $ordersStr . "\n\n"
            . "ATURAN MUTLAK:\n"
            . "1. DILARANG KERAS MEMBAHAS ATAU MENULISKAN PERKODINGAN / PEMROGRAMAN SAMA SEKALI (PHP, JavaScript, Python, HTML, CSS, SQL, script koding, algoritma, pembuatan website/aplikasi, dsb). Anda BUKAN asisten koding.\n"
            . "2. JIKA PENGGUNA BERTANYA ATAU MEMINTA HAL TERKAIT KODING, CODING, SCRIPT, PROGRAMMER, BIKIN APLIKASI/WEB, ATAU TOPIK DI LUAR LAYANAN TKJ, JAWAB PERSIS:\n"
            . "'Mohon maaf, kami hanya melayani konsultasi seputar layanan IT Hardware, Jaringan, dan CCTV TKJ Smart Service. Kami tidak melayani percodingan atau topik di luar layanan kami.'\n"
            . "3. WAJIB MEMBACA DAN MENJAWAB SESUAI DATA DATABASE DI ATAS. Sebutkan nama layanan, harga, estimasi pengerjaan, dan ketentuan garansi secara akurat sesuai data database. Jangan pernah mengarang layanan atau harga yang tidak ada di database.\n"
            . "4. JAWAB SINGKAT, PADAT, DAN LANGSUNG KE INTI (Maksimal 1-3 kalimat ringkas). Jangan bertele-tele atau menambahkan info panjang yang tidak diminta.";
    }

    /**
     * Memanggil API xAI Grok langsung dari PHP (Fallback jika Node.js mati)
     */
    private function callGrokApi($apiKey, $user, $userMessage) {
        $models = ['grok-2-latest', 'grok-2', 'grok-beta'];
        $systemPrompt = $this->buildSystemPromptText($user);

        foreach ($models as $model) {
            $url = 'https://api.x.ai/v1/chat/completions';
            $payload = [
                'model' => $model,
                'messages' => [
                    ['role' => 'system', 'content' => $systemPrompt],
                    ['role' => 'user', 'content' => $userMessage]
                ],
                'temperature' => 0.7,
                'max_tokens' => 1024
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey
            ]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if (!empty($data['choices'][0]['message']['content'])) {
                    return trim($data['choices'][0]['message']['content']);
                }
            }
        }

        return null;
    }

    /**
     * Memanggil API DeepSeek langsung dari PHP (Fallback)
     */
    private function callDeepSeekApi($apiKey, $user, $userMessage) {
        $models = ['deepseek-chat', 'deepseek-coder'];
        $systemPrompt = $this->buildSystemPromptText($user);

        foreach ($models as $model) {
            $url = 'https://api.deepseek.com/chat/completions';
            $payload = [
                'model' => $model,
                'messages' => [
                    ['role' => 'system', 'content' => $systemPrompt],
                    ['role' => 'user', 'content' => $userMessage]
                ],
                'temperature' => 0.7,
                'max_tokens' => 1024
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey
            ]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if (!empty($data['choices'][0]['message']['content'])) {
                    return trim($data['choices'][0]['message']['content']);
                }
            }
        }

        return null;
    }

    /**
     * Memanggil API Groq Cloud (Llama 3 / Mixtral) langsung dari PHP
     */
    private function callGroqApi($apiKey, $user, $userMessage) {
        $models = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768'];
        $systemPrompt = $this->buildSystemPromptText($user);

        foreach ($models as $model) {
            $url = 'https://api.groq.com/openai/v1/chat/completions';
            $payload = [
                'model' => $model,
                'messages' => [
                    ['role' => 'system', 'content' => $systemPrompt],
                    ['role' => 'user', 'content' => $userMessage]
                ],
                'temperature' => 0.7,
                'max_tokens' => 1024
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey
            ]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if (!empty($data['choices'][0]['message']['content'])) {
                    return trim($data['choices'][0]['message']['content']);
                }
            }
        }

        return null;
    }

    /**
     * Memanggil API OpenAI (GPT-4o-mini) langsung dari PHP
     */
    private function callOpenAiApi($apiKey, $user, $userMessage) {
        $models = ['gpt-4o-mini', 'gpt-3.5-turbo'];
        $systemPrompt = $this->buildSystemPromptText($user);

        foreach ($models as $model) {
            $url = 'https://api.openai.com/v1/chat/completions';
            $payload = [
                'model' => $model,
                'messages' => [
                    ['role' => 'system', 'content' => $systemPrompt],
                    ['role' => 'user', 'content' => $userMessage]
                ],
                'temperature' => 0.7,
                'max_tokens' => 1024
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey
            ]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if (!empty($data['choices'][0]['message']['content'])) {
                    return trim($data['choices'][0]['message']['content']);
                }
            }
        }

        return null;
    }

    /**
     * Memanggil API Google Gemini langsung dari PHP (Fallback jika Node.js mati)
     */
    private function callGeminiApi($apiKey, $user, $userMessage) {
        $models = ['gemini-3.5-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];
        $systemPrompt = $this->buildSystemPromptText($user);

        $payload = [
            'contents' => [
                [
                    'role' => 'user',
                    'parts' => [
                        ['text' => $systemPrompt . "\n\nPertanyaan Customer: " . $userMessage]
                    ]
                ]
            ]
        ];

        foreach ($models as $model) {
            $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . urlencode($apiKey);

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
                    return trim($data['candidates'][0]['content']['parts'][0]['text']);
                }
            }
        }

        return null;
    }

    /**
     * Fallback Engine: Intelligent Mock AI berdasarkan Keyword & Intent Matching Data DB
     */
    private function generateMockResponse($user, $userMessage) {
        $msg = strtolower(trim($userMessage));
        $userName = htmlspecialchars($user['nama'] ?? 'Pelanggan');


        // 0. Dynamic Active FAQ Database Lookup
        $activeFaqs = $this->faqModel->getActiveFaqs();
        if (!empty($activeFaqs)) {
            foreach ($activeFaqs as $faq) {
                $qLower = strtolower($faq['pertanyaan']);
                if ($this->isFaqMatch($msg, $qLower)) {
                    return "❓ **" . htmlspecialchars($faq['pertanyaan']) . "**\n\n" . $faq['jawaban'];
                }
            }
        }

        // 1. Intent: Status Pesanan / Lacak Pesanan

        if (
            strpos($msg, 'status') !== false ||
            strpos($msg, 'pesanan') !== false ||
            strpos($msg, 'lacak') !== false ||
            strpos($msg, 'progres') !== false ||
            strpos($msg, 'ord-') !== false
        ) {
            return $this->handleOrderStatusIntent($user);
        }

        // 2. Ambil data layanan dari database untuk dicocokkan secara dinamis
        $services = $this->serviceModel->getAllServices();
        $findService = function($keywords) use ($services) {
            foreach ($services as $s) {
                $t = strtolower($s['title']);
                foreach ($keywords as $kw) {
                    if (strpos($t, strtolower($kw)) !== false) {
                        return $s;
                    }
                }
            }
            return null;
        };

        // Rekomendasi Service Komputer / Laptop dari DB
        if (
            strpos($msg, 'komputer') !== false ||
            strpos($msg, 'laptop') !== false ||
            strpos($msg, 'mati') !== false ||
            strpos($msg, 'lemot') !== false ||
            strpos($msg, 'panas') !== false ||
            strpos($msg, 'blue screen') !== false ||
            strpos($msg, 'install') !== false ||
            strpos($msg, 'ram') !== false ||
            strpos($msg, 'ssd') !== false ||
            strpos($msg, 'thermal') !== false ||
            strpos($msg, 'rusak') !== false ||
            strpos($msg, 'pc') !== false
        ) {
            $srv = $findService(['komputer', 'laptop']);
            $title = $srv ? $srv['title'] : 'Service Komputer/Laptop';
            $price = $srv ? $srv['price'] : 'Mulai Rp 75.000';
            $desc = $srv ? $srv['description'] : 'Perbaikan hardware & software komputer/laptop, install ulang OS, upgrade SSD/RAM.';
            $features = (!empty($srv['features']) && is_array($srv['features'])) ? "\nFitur Layanan:\n• " . implode("\n• ", $srv['features']) : '';

            return "Halo Kak **{$userName}**!\n\nUntuk kendala perangkat komputer atau laptop, layanan resmi kami yang terdaftar di database adalah **{$title}**.\n\n"
                 . "🛠️ **Deskripsi Layanan:** {$desc}\n"
                 . "💰 **Biaya:** {$price}{$features}\n\n"
                 . "👨‍🔧 Teknisi siswa TKJ siap melakukan diagnosa mendalam di bawah supervisi instruktur ahli. Apakah Kakak ingin memesan layanan ini?";
        }

        // Rekomendasi Instalasi CCTV dari DB
        if (
            strpos($msg, 'cctv') !== false ||
            strpos($msg, 'kamera') !== false ||
            strpos($msg, 'keamanan') !== false ||
            strpos($msg, 'monitoring') !== false ||
            strpos($msg, 'pantau') !== false
        ) {
            $srv = $findService(['cctv']);
            $title = $srv ? $srv['title'] : 'Instalasi CCTV';
            $price = $srv ? $srv['price'] : 'Mulai Rp 250.000';
            $desc = $srv ? $srv['description'] : 'Pemasangan kamera CCTV IP / Analog untuk rumah, toko, dan sekolah lengkap dengan integrasi monitoring via Smartphone.';
            $features = (!empty($srv['features']) && is_array($srv['features'])) ? "\nFitur Layanan:\n• " . implode("\n• ", $srv['features']) : '';

            return "Halo Kak **{$userName}**!\n\nUntuk sistem pengawasan dan keamanan properti Anda, layanan resmi kami di database adalah **{$title}**.\n\n"
                 . "📹 **Deskripsi Layanan:** {$desc}\n"
                 . "💰 **Biaya:** {$price}{$features}\n\n"
                 . "Teknisi siswa TKJ siap datang ke lokasi untuk survey dan pemasangan rapi bergaransi!";
        }

        // Rekomendasi Instalasi Wi-Fi / Hotspot dari DB
        if (
            strpos($msg, 'wifi') !== false ||
            strpos($msg, 'wi-fi') !== false ||
            strpos($msg, 'hotspot') !== false ||
            strpos($msg, 'voucher') !== false ||
            strpos($msg, 'sinyal') !== false ||
            strpos($msg, 'extender') !== false ||
            strpos($msg, 'access point') !== false
        ) {
            $srv = $findService(['wi-fi', 'wifi', 'hotspot']);
            $title = $srv ? $srv['title'] : 'Instalasi Wi-Fi';
            $price = $srv ? $srv['price'] : 'Mulai Rp 100.000';
            $desc = $srv ? $srv['description'] : 'Pemasangan Access Point, perluasan jangkauan Wi-Fi, dan pembuatan sistem Hotspot Voucher.';
            $features = (!empty($srv['features']) && is_array($srv['features'])) ? "\nFitur Layanan:\n• " . implode("\n• ", $srv['features']) : '';

            return "Halo Kak **{$userName}**!\n\nUntuk solusi perluasan jangkauan sinyal internet dan sistem voucher, layanan kami di database adalah **{$title}**.\n\n"
                 . "📡 **Deskripsi Layanan:** {$desc}\n"
                 . "💰 **Biaya:** {$price}{$features}\n\n"
                 . "Solusi terbaik bebas deadzone untuk rumah, kost, cafe, maupun kantor!";
        }

        // Rekomendasi Instalasi Jaringan LAN dari DB
        if (
            strpos($msg, 'jaringan') !== false ||
            strpos($msg, 'lan') !== false ||
            strpos($msg, 'kabel') !== false ||
            strpos($msg, 'utp') !== false ||
            strpos($msg, 'mikrotik') !== false ||
            strpos($msg, 'router') !== false ||
            strpos($msg, 'crimping') !== false
        ) {
            $srv = $findService(['jaringan', 'lan']);
            $title = $srv ? $srv['title'] : 'Instalasi Jaringan';
            $price = $srv ? $srv['price'] : 'Mulai Rp 150.000';
            $desc = $srv ? $srv['description'] : 'Perancangan dan penarikan kabel jaringan LAN (UTP/FTP), crimping RJ45, serta konfigurasi Mikrotik / Router.';
            $features = (!empty($srv['features']) && is_array($srv['features'])) ? "\nFitur Layanan:\n• " . implode("\n• ", $srv['features']) : '';

            return "Halo Kak **{$userName}**!\n\nUntuk infrastruktur koneksi kabel kantor atau sekolah, layanan resmi kami di database adalah **{$title}**.\n\n"
                 . "🌐 **Deskripsi Layanan:** {$desc}\n"
                 . "💰 **Biaya:** {$price}{$features}";
        }

        // Rekomendasi Maintenance Perangkat IT dari DB
        if (
            strpos($msg, 'maintenance') !== false ||
            strpos($msg, 'perawatan') !== false ||
            strpos($msg, 'lab') !== false ||
            strpos($msg, 'berkala') !== false ||
            strpos($msg, 'rutin') !== false
        ) {
            $srv = $findService(['maintenance', 'perawatan']);
            $title = $srv ? $srv['title'] : 'Maintenance Perangkat IT';
            $price = $srv ? $srv['price'] : 'Mulai Rp 300.000';
            $desc = $srv ? $srv['description'] : 'Perawatan berkala untuk lab komputer sekolah, kantor, maupun UMKM agar perangkat IT selalu prima.';
            $features = (!empty($srv['features']) && is_array($srv['features'])) ? "\nFitur Layanan:\n• " . implode("\n• ", $srv['features']) : '';

            return "Halo Kak **{$userName}**!\n\nKami menyediakan paket pemeliharaan berkala di database yaitu **{$title}**.\n\n"
                 . "💻 **Deskripsi Layanan:** {$desc}\n"
                 . "💰 **Biaya:** {$price}{$features}";
        }

        // Rekomendasi Jasa IT Lainnya / Rakit PC
        if (
            strpos($msg, 'rakit') !== false ||
            strpos($msg, 'custom') !== false ||
            strpos($msg, 'printer') !== false ||
            strpos($msg, 'sharing') !== false
        ) {
            $srv = $findService(['lainnya', 'custom', 'rakit']);
            $title = $srv ? $srv['title'] : 'Jasa IT Lainnya';
            $price = $srv ? $srv['price'] : 'Mulai Rp 100.000';
            $desc = $srv ? $srv['description'] : 'Konsultasi IT, perakitan PC custom (Gaming/Office), instalasi printer jaringan, dan solusi kendala IT spesifik.';

            return "Halo Kak **{$userName}**!\n\nUntuk kebutuhan khusus seperti perakitan PC atau instalasi printer, layanan resmi kami di database adalah **{$title}**.\n\n"
                 . "🔧 **Deskripsi Layanan:** {$desc}\n"
                 . "💰 **Biaya:** {$price}";
        }

        // 7. Intent: Daftar Semua Layanan / Katalog / Harga
        if (
            strpos($msg, 'layanan') !== false ||
            strpos($msg, 'jasa') !== false ||
            strpos($msg, 'katalog') !== false ||
            strpos($msg, 'harga') !== false ||
            strpos($msg, 'biaya') !== false ||
            strpos($msg, 'tarif') !== false
        ) {
            return $this->handleCatalogIntent();
        }

        // 8. Intent: Cara Pemesanan / Order
        if (
            strpos($msg, 'cara') !== false ||
            strpos($msg, 'pesan') !== false ||
            strpos($msg, 'order') !== false ||
            strpos($msg, 'langkah') !== false ||
            strpos($msg, 'alur') !== false
        ) {
            return "Berikut alur mudah memesan layanan jasa di **TKJ Smart Service**:\n\n"
                 . "1️⃣ **Pilih Layanan:** Buka menu *Layanan Jasa* dan pilih jenis jasa IT yang sesuai.\n"
                 . "2️⃣ **Isi Formulir:** Tekan *Pesan Layanan*, lalu isi alamat lokasi dan deskripsi masalah secara lengkap.\n"
                 . "3️⃣ **Konfirmasi Operator:** Operator unit bisnis kami akan memverifikasi pesanan Anda dan menugaskan teknisi siswa TKJ.\n"
                 . "4️⃣ **Pengerjaan & Pelacakan:** Pantau status pesanan dan catatan pengerjaan teknisi secara real-time di Dashboard.\n"
                 . "5️⃣ **Pembayaran & Review:** Bayar setelah pekerjaan selesai (Tunai/QRIS/Transfer) dan berikan rating review Anda!";
        }

        // 9. Intent: FAQ / Garansi / Pembayaran / Teknisi
        if (strpos($msg, 'garansi') !== false) {
            return "🛡️ **Garansi Layanan:** Ya! Semua layanan instalasi CCTV, jaringan LAN/Wi-Fi, dan service komputer kami dilengkapi garansi pengerjaan ulang gratis jika terjadi kendala pasca instalasi.";
        }

        if (strpos($msg, 'bayar') !== false || strpos($msg, 'pembayaran') !== false || strpos($msg, 'metode') !== false) {
            return "💳 **Metode Pembayaran:** Kami menerima pembayaran melalui **Tunai (Cash)** langsung kepada teknisi/operator, **Transfer Bank**, dan **QRIS**.";
        }

        if (strpos($msg, 'siapa') !== false || strpos($msg, 'teknisi') !== false || strpos($msg, 'siswa') !== false) {
            return "👨‍🎓 **Siapa Teknisi Kami?** Pekerjaan dilakukan oleh siswa-siswi berprestasi jurusan Teknik Komputer & Jaringan (TKJ) yang telah tersertifikasi dan didampingi secara penuh oleh guru/instruktur teknis berpengalaman.";
        }

        if (strpos($msg, 'lokasi') !== false || strpos($msg, 'datang') !== false || strpos($msg, 'rumah') !== false) {
            return "🏡 **Kunjungan Lokasi:** Teknisi kami siap melakukan *Home Service* atau kunjungan langsung ke rumah, toko, kantor, maupun sekolah Kakak.";
        }

        // 10. Salam / Sapaan Umum
        if (
            strpos($msg, 'halo') !== false ||
            strpos($msg, 'hai') !== false ||
            strpos($msg, 'selamat') !== false ||
            strpos($msg, 'pagi') !== false ||
            strpos($msg, 'siang') !== false ||
            strpos($msg, 'sore') !== false ||
            strpos($msg, 'malam') !== false ||
            strpos($msg, 'terima kasih') !== false ||
            strpos($msg, 'makasih') !== false
        ) {
            return "Halo Kak **{$userName}**! 👋 Ada yang bisa saya bantu terkait layanan jasa IT TKJ Smart Service hari ini?\n\nAnda dapat menanyakan rekomendasi layanan, status pesanan, cara pemesanan, atau FAQ kami.";
        }

        // Fallback default response
        return "Terima kasih telah menghubungi **AI Assistant TKJ Smart Service**, Kak **{$userName}**!\n\n"
             . "Saya siap membantu Kakak mengenai:\n"
             . "🔹 Rekomendasi jasa (misal: *'Komputer saya sering mati sendiri'*\n"
             . "🔹 Informasi daftar & harga layanan jasa IT\n"
             . "🔹 Pelacakan status pesanan Kakak (*'Bagaimana status pesanan saya?'*)\n"
             . "🔹 Panduan alur pemesanan & garansi layanan\n\n"
             . "Silakan ketik pertanyaan Kakak di bawah ini!";
    }

    /**
     * Helper merespons status pesanan customer terkini dari DB
     */
    private function handleOrderStatusIntent($user) {
        if (empty($user) || empty($user['id'])) {
            return "Halo Kak! 👋 Untuk melacak status pesanan Anda secara langsung, silakan **[Login ke Akun Anda](" . BASE_URL . "/login)** terlebih dahulu ya.\n\nSetelah login, saya dapat langsung menampilkan nomor pesanan, teknisi yang bertugas, dan status pengerjaannya!";
        }

        $customerId = $user['id'];
        $activeOrders = $this->orderModel->getOrdersByCustomer($customerId, 'active');
        $historyOrders = $this->orderModel->getOrdersByCustomer($customerId, 'history');

        if (empty($activeOrders) && empty($historyOrders)) {
            return "📌 **Status Pesanan:** Saat ini Kakak belum memiliki riwayat pesanan di TKJ Smart Service.\n\n"
                 . "Silakan buat pesanan baru melalui menu Katalog Layanan Jasa!";
        }

        $response = "📦 **Status Pesanan Kakak di TKJ Smart Service:**\n\n";

        if (!empty($activeOrders)) {
            $response .= "🔴 **Pesanan Aktif (" . count($activeOrders) . "):**\n";
            foreach ($activeOrders as $ord) {
                $statusBadge = strtoupper($ord['status']);
                $teknisiName = !empty($ord['nama_teknisi']) ? $ord['nama_teknisi'] : 'Belum Ditugaskan';
                $response .= "• **{$ord['kode_pesanan']}** - {$ord['nama_jasa']}\n"
                           . "  Status: `{$statusBadge}` | Teknisi: {$teknisiName}\n"
                           . "  Tgl Pesan: " . date('d M Y H:i', strtotime($ord['tanggal_pemesanan'])) . "\n\n";
            }
        } else {
            $response .= "✅ Tidak ada pesanan yang sedang berjalan saat ini.\n\n";
        }

        if (!empty($historyOrders)) {
            $response .= "📜 **Riwayat Terakhir:**\n";
            $lastHistory = array_slice($historyOrders, 0, 2);
            foreach ($lastHistory as $h) {
                $response .= "• **{$h['kode_pesanan']}** - {$h['nama_jasa']} (" . strtoupper($h['status']) . ")\n";
            }
        }

        $response .= "\nDetail lebih lengkap dapat dilihat pada halaman Dashboard atau menu Pesanan Saya.";
        return $response;
    }

    /**
     * Helper merespons daftar catalog jasa dari DB
     */
    private function handleCatalogIntent() {
        $services = $this->serviceModel->getAllServices();

        $response = "📋 **Katalog Layanan Jasa TKJ Smart Service:**\n\n";
        foreach ($services as $s) {
            $response .= "🔹 **" . $s['title'] . "**\n"
                       . "   " . $s['description'] . "\n"
                       . "   Harga: `" . $s['price'] . "`\n\n";
        }
        $response .= "Untuk melakukan pemesanan, Kakak dapat mengklik menu Katalog Layanan Jasa dan menekan tombol *Pesan Layanan*.";
        return $response;
    }

    /**
     * Helper untuk mengecek kecocokan pertanyaan customer dengan pertanyaan FAQ database
     */
    private function isFaqMatch($userMsg, $faqQuestion) {
        $userMsg = strtolower(trim($userMsg));
        $faqQuestion = strtolower(trim($faqQuestion));

        // 1. Substring match
        if (strpos($userMsg, $faqQuestion) !== false || strpos($faqQuestion, $userMsg) !== false) {
            return true;
        }

        // 2. Intent Keyphrases matching
        $keyphrasePairs = [
            ['cara memesan', 'bagaimana cara memesan'],
            ['cara pesan', 'bagaimana cara memesan'],
            ['apa saja layanan', 'apa saja layanan'],
            ['layanan apa', 'apa saja layanan'],
            ['berapa lama', 'berapa lama pengerjaan'],
            ['lama pengerjaan', 'berapa lama pengerjaan'],
            ['melihat status', 'bagaimana cara melihat status'],
            ['status pesanan', 'bagaimana cara melihat status'],
            ['menghubungi teknisi', 'bagaimana cara menghubungi teknisi'],
            ['kontak teknisi', 'bagaimana cara menghubungi teknisi'],
            ['memberikan review', 'bagaimana cara memberikan review'],
            ['beri review', 'bagaimana cara memberikan review'],
            ['ulasan', 'bagaimana cara memberikan review'],
            ['garansi', 'bergaransi'],
            ['pembayaran', 'metode pembayaran']
        ];

        foreach ($keyphrasePairs as $pair) {
            if (strpos($userMsg, $pair[0]) !== false && strpos($faqQuestion, $pair[1]) !== false) {
                return true;
            }
        }

        // 3. Word overlap count (minimal 3 kata cocok selain kata hubung)
        $stopwords = ['bagaimana', 'apa', 'saja', 'cara', 'yang', 'di', 'ke', 'dari', 'dan', 'atau', 'ini', 'itu', 'saya', 'anda', 'kamu', 'bisa'];
        $userWords = array_diff(explode(' ', preg_replace('/[^\w\s]/', '', $userMsg)), $stopwords);
        $faqWords = array_diff(explode(' ', preg_replace('/[^\w\s]/', '', $faqQuestion)), $stopwords);

        $intersection = array_intersect($userWords, $faqWords);
        return (count($intersection) >= 2);
    }

    /**
     * Respon penolakan ramah & profesional jika pengguna bertanya seputar coding
     */
    private function getCodingRefusalReply($userName = '') {
        return "Mohon maaf, kami hanya melayani konsultasi seputar layanan IT Hardware, Jaringan, dan CCTV (TKJ Smart Service). Kami tidak melayani perkodingan atau topik di luar layanan kami.";
    }

    /**
     * Helper untuk mendeteksi apakah pertanyaan terkait dengan coding/pemrograman
     */
    private function isCodingQuery($userMsg) {
        $q = strtolower(trim($userMsg));

        if (strpos($q, 'program keahlian') !== false || strpos($q, 'program sekolah') !== false || strpos($q, 'program tkj') !== false) {
            return false;
        }

        // Cek pola kode programming umum (regex)
        if (preg_match('/(<\?php|<\/?[a-z0-9]+>|\bconsole\.log\b|\bfunction\s*\(|\bdef\s+[a-zA-Z0-9_]+\b|\bimport\s+[a-zA-Z0-9_]+\b|\bclass\s+[a-zA-Z0-9_]+\b|\bSELECT\s+.*?\s+FROM\b|\bINSERT\s+INTO\b|\bUPDATE\s+.*?\s+SET\b|\bDELETE\s+FROM\b|\bfor\s*\(.*?;.*?;.*?\)\b|\bwhile\s*\(.*?\)\b|```)/i', $userMsg)) {
            return true;
        }

        $codingTerms = [
            'coding', 'koding', 'ngoding', 'ngode', 'perkodingan', 'kodingan', 'codingan', 'coder',
            'pemrograman', 'programmer', 'source code', 'sourcecode', 'bikin kode', 'buatkan kode',
            'buat kode', 'tulis kode', 'tuliskan kode', 'script kode', 'syntax', 'sintaks', 'sintak',
            'debugging', 'debug code', 'debug', 'bahasa pemrograman', 'bikin program', 'buatkan program',
            'buat program', 'bikin script', 'buatkan script', 'buat script', 'algoritma',
            'bikin website', 'buat website', 'buatkan web', 'bikin web', 'buat web', 'bikin aplikasi',
            'buat aplikasi', 'buatkan aplikasi', 'aplikasi web', 'software house', 'bikin software',
            'buat software', 'codingin', 'kodingin',
            'python', 'javascript', 'php', 'html', 'css', 'c++', 'c#', 'golang', 'rust', 'ruby',
            'sql query', 'query sql', 'framework', 'react', 'laravel', 'flutter', 'vue', 'nodejs', 'node.js',
            'codeigniter', 'django', 'flask', 'tailwind', 'bootstrap code', 'jquery',
            'looping', 'perulangan for', 'perulangan while', 'array', 'variable', 'variabel',
            'function code', 'fungsi koding', 'class oop', 'object oriented', 'rest api', 'api endpoint',
            'database query', 'bikin query', 'buat query', 'table database', 'create table', 'crud',
            'github', 'repository', 'git commit', 'git push', 'terminal command', 'npm install',
            'pip install', 'composer require'
        ];

        foreach ($codingTerms as $term) {
            if (strpos($q, $term) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Helper untuk mendeteksi apakah pengguna menanyakan identitas dirinya / akunnya
     */
    private function isWhoAmIQuery($msg) {
        $q = strtolower(trim($msg));
        return (
            strpos($q, 'siapa saya') !== false ||
            strpos($q, 'nama saya') !== false ||
            strpos($q, 'akun saya') !== false ||
            strpos($q, 'profil saya') !== false ||
            strpos($q, 'data saya') !== false ||
            strpos($q, 'identitas saya') !== false ||
            strpos($q, 'siapa aku') !== false
        );
    }
}


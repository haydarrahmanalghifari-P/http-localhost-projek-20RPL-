<?php
/**
 * AuthController - Controller Autentikasi (Login, Register Customer, Logout)
 */

class AuthController extends Controller {

    /**
     * Halaman Login Pengguna
     */
    public function login() {
        // Jika sudah login, redirect langsung ke dashboard role masing-masing
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');

            // Validasi Input Kosong
            if (empty($email) || empty($password)) {
                AuthHelper::setFlash('login_error', 'Email dan password tidak boleh kosong.', 'danger');
                header('Location: ' . BASE_URL . '/login');
                exit;
            }

            SecurityHelper::verifyCsrfToken();

            $userModel = $this->model('UserModel');
            $user = $userModel->findByEmail($email);

            // Verifikasi User & Password Hashing via password_verify()
            if ($user && password_verify($password, $user['password'])) {
                // Alur Login dengan Verifikasi OTP WhatsApp (Fonnte)
                $phone = !empty($user['no_telepon']) ? $user['no_telepon'] : null;
                $otpCode = sprintf('%06d', mt_rand(100000, 999999));
                $expiry = time() + (defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES * 60 : 300);

                // Simpan state login pending ke session
                $_SESSION['pending_login'] = [
                    'user' => $user,
                    'no_telepon' => $phone,
                    'email' => $user['email'],
                    'nama' => $user['nama'],
                    'role' => $user['role'],
                    'otp' => $otpCode,
                    'otp_expiry' => $expiry
                ];

                if ($phone) {
                    $waResult = FonnteHelper::sendOtp($phone, $otpCode);
                    if (!$waResult['success']) {
                        AuthHelper::setFlash('login_error', 'Gagal mengirim OTP ke WhatsApp: ' . htmlspecialchars($waResult['message']), 'danger');
                        header('Location: ' . BASE_URL . '/login');
                        exit;
                    }

                    AuthHelper::setFlash('otp_login_success', 'Kode OTP verifikasi masuk telah dikirim via WhatsApp ke ' . FonnteHelper::maskPhone($phone) . '.', 'success');
                } else {
                    AuthHelper::setFlash('otp_login_warning', 'Akun Anda belum memiliki nomor WhatsApp terdaftar. Masukkan nomor WhatsApp Anda di bawah untuk menerima kode OTP verifikasi.', 'warning');
                }

                header('Location: ' . BASE_URL . '/login-otp');
                exit;
            }

            // Login Gagal
            AuthHelper::setFlash('login_error', 'Email atau password yang Anda masukkan salah.', 'danger');
            header('Location: ' . BASE_URL . '/login');
            exit;
        }

        $data = [
            'title' => 'Login Pengguna - TKJ Smart Service',
            'active_nav' => 'login',
            'hide_navbar' => true,
            'hide_footer' => true,
            'body_class' => 'auth-page-clean'
        ];

        $this->view('auth/login', $data);
    }

    /**
     * Login Cepat via WhatsApp (OTP WhatsApp Tanpa Perlu Password)
     */
    public function loginWa() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();

            $identifier = trim($_POST['identifier'] ?? '');
            if (empty($identifier)) {
                AuthHelper::setFlash('login_error', 'Harap masukkan nomor WhatsApp atau email akun Anda.', 'danger');
                header('Location: ' . BASE_URL . '/login?tab=wa');
                exit;
            }

            $userModel = $this->model('UserModel');
            $user = null;
            $phoneInput = null;

            // 1. Cek jika identifier adalah email valid
            if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
                $user = $userModel->findByEmail($identifier);
            } else {
                // 2. Format nomor HP (misal 08123456789 atau 628123456789)
                $cleanPhone = preg_replace('/\D/', '', $identifier);
                if (strlen($cleanPhone) >= 9) {
                    $phoneInput = $cleanPhone;
                    $user = $userModel->findByPhone($cleanPhone);
                }
            }

            // 3. Fallback pencarian umum identifier
            if (!$user) {
                $user = $userModel->findByIdentifier($identifier);
            }

            if (!$user) {
                AuthHelper::setFlash('login_error', 'Akun dengan WhatsApp / Email "' . htmlspecialchars($identifier) . '" tidak ditemukan. Pastikan akun sudah terdaftar.', 'danger');
                header('Location: ' . BASE_URL . '/login?tab=wa');
                exit;
            }

            // Buat OTP 6 Digit & Kedaluwarsa 5 Menit
            $otpCode = sprintf('%06d', mt_rand(100000, 999999));
            $expiry = time() + (defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES * 60 : 300);

            // Tentukan nomor WhatsApp target
            $targetPhone = !empty($user['no_telepon']) ? $user['no_telepon'] : $phoneInput;

            // Jika user belum punya nomor di DB dan input berupa nomor HP, hubungkan langsung
            if (empty($user['no_telepon']) && !empty($phoneInput)) {
                $userModel->updatePhone($user['id'], $phoneInput);
                $user['no_telepon'] = $phoneInput;
                $targetPhone = $phoneInput;
            }

            // Simpan pending login ke session
            $_SESSION['pending_login'] = [
                'user' => $user,
                'no_telepon' => $targetPhone,
                'email' => $user['email'],
                'nama' => $user['nama'],
                'role' => $user['role'],
                'otp' => $otpCode,
                'otp_expiry' => $expiry,
                'login_type' => 'whatsapp_quick'
            ];

            // Kirim OTP via Fonnte jika nomor tersedia
            if ($targetPhone) {
                $waResult = FonnteHelper::sendOtp($targetPhone, $otpCode);
                if (!$waResult['success']) {
                    AuthHelper::setFlash('login_error', 'Gagal mengirim OTP ke WhatsApp: ' . htmlspecialchars($waResult['message']), 'danger');
                    header('Location: ' . BASE_URL . '/login?tab=wa');
                    exit;
                }

                AuthHelper::setFlash('otp_login_success', 'Kode OTP masuk cepat telah dikirim ke WhatsApp ' . FonnteHelper::maskPhone($targetPhone) . '.', 'success');
            } else {
                AuthHelper::setFlash('otp_login_warning', 'Halo ' . htmlspecialchars($user['nama']) . '! Akun Anda belum memiliki nomor WhatsApp terdaftar. Masukkan nomor WhatsApp Anda di bawah untuk menerima kode OTP masuk.', 'warning');
            }

            header('Location: ' . BASE_URL . '/login-otp');
            exit;
        }

        header('Location: ' . BASE_URL . '/login?tab=wa');
        exit;
    }

    /**
     * Halaman & Proses Verifikasi Kode OTP WhatsApp Login
     */
    public function verifyLoginOtp() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        $pending = $_SESSION['pending_login'] ?? null;
        if (!$pending || empty($pending['user'])) {
            AuthHelper::setFlash('login_error', 'Sesi login telah kedaluwarsa. Silakan masukkan kredensial kembali.', 'warning');
            header('Location: ' . BASE_URL . '/login');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();

            // Cek jika pengguna menghubungkan atau mengubah nomor WhatsApp
            $action = trim($_POST['action'] ?? '');
            if ($action === 'link_phone') {
                $newPhone = trim($_POST['new_phone'] ?? '');
                $cleanPhone = preg_replace('/\D/', '', $newPhone);

                if (strlen($cleanPhone) < 9 || strlen($cleanPhone) > 16) {
                    AuthHelper::setFlash('otp_login_error', 'Format nomor WhatsApp tidak valid. Masukkan 10-15 digit nomor HP.', 'danger');
                    header('Location: ' . BASE_URL . '/login-otp');
                    exit;
                }

                // Update nomor di session dan database
                $userModel = $this->model('UserModel');
                $userModel->updateTelegramInfo($pending['user']['id'], null, $newPhone);
                
                $otpCode = sprintf('%06d', mt_rand(100000, 999999));
                $_SESSION['pending_login']['no_telepon'] = $newPhone;
                $_SESSION['pending_login']['otp'] = $otpCode;
                $_SESSION['pending_login']['otp_expiry'] = time() + (defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES * 60 : 300);

                $waResult = FonnteHelper::sendOtp($newPhone, $otpCode);
                if ($waResult['success']) {
                    AuthHelper::setFlash('otp_login_success', 'Nomor WhatsApp berhasil dihubungkan! Kode OTP baru telah dikirimkan ke ' . FonnteHelper::maskPhone($newPhone) . '.', 'success');
                } else {
                    AuthHelper::setFlash('otp_login_error', 'Gagal mengirim OTP ke nomor WhatsApp baru (Fonnte): ' . htmlspecialchars($waResult['message']), 'danger');
                }

                header('Location: ' . BASE_URL . '/login-otp');
                exit;
            }

            // Ambil kode OTP
            $otpCode = trim($_POST['otp_code'] ?? '');
            if (empty($otpCode)) {
                $otpParts = '';
                for ($i = 1; $i <= 6; $i++) {
                    $otpParts .= trim($_POST['otp_' . $i] ?? '');
                }
                $otpCode = $otpParts;
            }

            if (empty($otpCode) || strlen($otpCode) !== 6) {
                AuthHelper::setFlash('otp_login_error', 'Harap masukkan 6 digit kode OTP verifikasi dengan lengkap.', 'danger');
                header('Location: ' . BASE_URL . '/login-otp');
                exit;
            }

            // Cek kedaluwarsa OTP
            if (time() > ($pending['otp_expiry'] ?? 0)) {
                AuthHelper::setFlash('otp_login_error', 'Kode OTP telah kedaluwarsa. Silakan klik tombol "Kirim Ulang OTP".', 'danger');
                header('Location: ' . BASE_URL . '/login-otp');
                exit;
            }

            // Verifikasi kecocokan OTP
            if ($otpCode === (string)($pending['otp'] ?? '')) {
                $user = $pending['user'];

                // Login Sukses
                AuthHelper::login($user);

                // Notifikasi login ke WhatsApp jika no telepon ada
                if (!empty($pending['no_telepon'])) {
                    try {
                        FonnteHelper::sendNotification(
                            $pending['no_telepon'],
                            '🔐 Login Berhasil',
                            "Halo *" . $user['nama'] . "*,\n\nAkun Anda (" . $user['email'] . ") baru saja berhasil login ke website *TKJ Smart Service* pada " . date('d M Y H:i') . " WIB.\n\nJika ini bukan Anda, segera hubungi tim operator."
                        );
                    } catch (\Throwable $e) {}
                }

                // Bersihkan sesi pending login
                unset($_SESSION['pending_login']);

                AuthHelper::setFlash('auth_success', 'Selamat datang kembali, ' . htmlspecialchars($user['nama']) . '!', 'success');
                $redirectUrl = !empty($_SESSION['redirect_after_login']) ? $_SESSION['redirect_after_login'] : AuthHelper::getDashboardUrl($user['role']);
                unset($_SESSION['redirect_after_login']);
                header('Location: ' . $redirectUrl);
                exit;
            } else {
                AuthHelper::setFlash('otp_login_error', 'Kode OTP yang Anda masukkan salah. Periksa kembali pesan WhatsApp Anda.', 'danger');
                header('Location: ' . BASE_URL . '/login-otp');
                exit;
            }
        }

        $data = [
            'title' => 'Verifikasi OTP WhatsApp Login - TKJ Smart Service',
            'active_nav' => 'login',
            'hide_navbar' => true,
            'hide_footer' => true,
            'body_class' => 'auth-page-clean',
            'user' => $pending['user'],
            'email' => $pending['email'] ?? '',
            'nama' => $pending['nama'] ?? 'Pengguna',
            'no_telepon' => $pending['no_telepon'] ?? '',
            'masked_phone' => !empty($pending['no_telepon']) ? FonnteHelper::maskPhone($pending['no_telepon']) : ''
        ];

        $this->view('auth/verify_login_otp', $data);
    }

    /**
     * Kirim Ulang Kode OTP Login via WhatsApp Fonnte
     */
    public function resendLoginOtp() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        $pending = $_SESSION['pending_login'] ?? null;
        if (!$pending) {
            AuthHelper::setFlash('login_error', 'Sesi login tidak ditemukan. Silakan login kembali.', 'warning');
            header('Location: ' . BASE_URL . '/login');
            exit;
        }

        $newOtp = sprintf('%06d', mt_rand(100000, 999999));
        $_SESSION['pending_login']['otp'] = $newOtp;
        $_SESSION['pending_login']['otp_expiry'] = time() + (defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES * 60 : 300);

        if (!empty($pending['no_telepon'])) {
            $waResult = FonnteHelper::sendOtp($pending['no_telepon'], $newOtp);
            if ($waResult['success']) {
                AuthHelper::setFlash('otp_login_success', 'Kode OTP login baru berhasil dikirimkan via WhatsApp ke ' . FonnteHelper::maskPhone($pending['no_telepon']) . '.', 'success');
            } else {
                AuthHelper::setFlash('otp_login_error', 'Gagal kirim ulang OTP (Fonnte): ' . htmlspecialchars($waResult['message']), 'danger');
            }
        } else {
            AuthHelper::setFlash('otp_login_warning', 'Silakan masukkan nomor WhatsApp Anda di bawah.', 'warning');
        }

        header('Location: ' . BASE_URL . '/login-otp');
        exit;
    }

    /**
     * Batalkan Sesi Verifikasi OTP Login
     */
    public function cancelLoginOtp() {
        unset($_SESSION['pending_login']);
        AuthHelper::setFlash('login_info', 'Proses verifikasi login dibatalkan.', 'info');
        header('Location: ' . BASE_URL . '/login');
        exit;
    }

    /**
     * Halaman & Proses Registrasi Customer dengan Verifikasi OTP WhatsApp (Fonnte)
     */
    public function register() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nama = trim($_POST['nama'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $noTelepon = trim($_POST['no_telepon'] ?? '');
            $password = trim($_POST['password'] ?? '');
            $confirmPassword = trim($_POST['confirm_password'] ?? '');

            // Validasi Kelengkapan Data
            if (empty($nama) || empty($email) || empty($noTelepon) || empty($password) || empty($confirmPassword)) {
                AuthHelper::setFlash('register_error', 'Nama, email, nomor WhatsApp, dan password wajib diisi.', 'danger');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            SecurityHelper::verifyCsrfToken();

            // Validasi Format Email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                AuthHelper::setFlash('register_error', 'Format email yang dimasukkan tidak valid.', 'danger');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            // Validasi Format Nomor Telepon
            $cleanPhone = preg_replace('/\D/', '', $noTelepon);
            if (strlen($cleanPhone) < 9 || strlen($cleanPhone) > 16) {
                AuthHelper::setFlash('register_error', 'Format nomor WhatsApp tidak valid. Masukkan 10-15 digit nomor HP yang aktif.', 'danger');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            // Validasi Kesesuaian Password
            if ($password !== $confirmPassword) {
                AuthHelper::setFlash('register_error', 'Konfirmasi password tidak cocok dengan password.', 'danger');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            // Validasi Minimal Panjang Password
            if (strlen($password) < 6) {
                AuthHelper::setFlash('register_error', 'Password minimal terdiri dari 6 karakter.', 'danger');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            $userModel = $this->model('UserModel');

            // Cek Email Duplikat
            if ($userModel->findByEmail($email)) {
                AuthHelper::setFlash('register_error', 'Email sudah terdaftar. Silakan gunakan email lain atau login.', 'warning');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            // Cek Nomor HP Duplikat
            if ($userModel->findByPhone($noTelepon)) {
                AuthHelper::setFlash('register_error', 'Nomor WhatsApp sudah terdaftar pada akun lain. Silakan gunakan nomor lain atau login.', 'warning');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            // Generate 6 Digit Kode OTP
            $otpCode = sprintf('%06d', mt_rand(100000, 999999));
            $expiry = time() + (defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES * 60 : 300);

            // Kirim Kode OTP langsung via WhatsApp Fonnte terlebih dahulu
            $waResult = FonnteHelper::sendOtp($noTelepon, $otpCode);

            if (!$waResult['success']) {
                AuthHelper::setFlash('register_error', 'Gagal mengirim OTP ke WhatsApp (Fonnte): ' . htmlspecialchars($waResult['message']), 'danger');
                header('Location: ' . BASE_URL . '/register');
                exit;
            }

            // Simpan pendaftaran sementara ke Session hanya jika WhatsApp berhasil terkirim
            $_SESSION['pending_registration'] = [
                'nama' => $nama,
                'email' => $email,
                'no_telepon' => $noTelepon,
                'password' => $password,
                'otp' => $otpCode,
                'otp_expiry' => $expiry
            ];

            AuthHelper::setFlash('otp_success', 'Kode OTP 6-digit berhasil dikirimkan via WhatsApp ke nomor ' . FonnteHelper::maskPhone($noTelepon) . '.', 'success');
            header('Location: ' . BASE_URL . '/verify-otp');
            exit;
        }

        $data = [
            'title' => 'Registrasi Customer - TKJ Smart Service',
            'active_nav' => 'register',
            'hide_navbar' => true,
            'hide_footer' => true,
            'body_class' => 'auth-page-clean'
        ];

        $this->view('auth/register', $data);
    }

    /**
     * Halaman & Proses Verifikasi Kode OTP WhatsApp Registrasi
     */
    public function verifyOtp() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        $pending = $_SESSION['pending_registration'] ?? null;
        if (!$pending) {
            AuthHelper::setFlash('register_error', 'Sesi registrasi telah kedaluwarsa atau tidak ditemukan. Silakan isi form kembali.', 'warning');
            header('Location: ' . BASE_URL . '/register');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();

            // Ambil kode OTP dari kombinasi box
            $otpCode = trim($_POST['otp_code'] ?? '');
            if (empty($otpCode)) {
                $otpParts = '';
                for ($i = 1; $i <= 6; $i++) {
                    $otpParts .= trim($_POST['otp_' . $i] ?? '');
                }
                $otpCode = $otpParts;
            }

            if (empty($otpCode) || strlen($otpCode) !== 6) {
                AuthHelper::setFlash('otp_error', 'Harap masukkan 6 digit kode OTP verifikasi lengkap.', 'danger');
                header('Location: ' . BASE_URL . '/verify-otp');
                exit;
            }

            // Cek kedaluwarsa OTP
            if (time() > ($pending['otp_expiry'] ?? 0)) {
                AuthHelper::setFlash('otp_error', 'Kode OTP telah kedaluwarsa. Silakan klik "Kirim Ulang OTP".', 'danger');
                header('Location: ' . BASE_URL . '/verify-otp');
                exit;
            }

            // Verifikasi kode OTP
            if ($otpCode === (string)($pending['otp'] ?? '')) {
                $userModel = $this->model('UserModel');
                $registered = $userModel->registerCustomer(
                    $pending['nama'],
                    $pending['email'],
                    $pending['password'],
                    null,
                    $pending['no_telepon']
                );

                if ($registered) {
                    // Notifikasi Selamat Datang via WhatsApp
                    try {
                        FonnteHelper::sendNotification(
                            $pending['no_telepon'],
                            '🎉 Registrasi Berhasil!',
                            "Halo *" . $pending['nama'] . "*,\n\nSelamat! Akun customer Anda di *TKJ Smart Service* telah aktif.\nNomor WA: " . $pending['no_telepon'] . "\nEmail: " . $pending['email'] . "\n\nAnda sekarang dapat login ke website dan memesan layanan IT & Jaringan kami kapan saja."
                        );
                    } catch (\Throwable $e) {}

                    // Notifikasi dalam sistem
                    try {
                        $newUser = $userModel->findByEmail($pending['email']);
                        if ($newUser && !empty($newUser['id'])) {
                            $notifModel = $this->model('NotificationModel');
                            $notifModel->createNotification(
                                $newUser['id'],
                                'Selamat Datang di TKJ Smart Service!',
                                'Halo ' . $pending['nama'] . ', akun Anda telah diverifikasi melalui WhatsApp.'
                            );
                        }
                    } catch (\Throwable $e) {}

                    // Bersihkan session pending
                    unset($_SESSION['pending_registration']);

                    AuthHelper::setFlash('login_success', 'Selamat, verifikasi berhasil! Akun Anda telah aktif, silakan login.', 'success');
                    header('Location: ' . BASE_URL . '/login');
                    exit;
                } else {
                    AuthHelper::setFlash('otp_error', 'Gagal menyimpan data akun ke database. Silakan coba kembali.', 'danger');
                    header('Location: ' . BASE_URL . '/verify-otp');
                    exit;
                }
            } else {
                AuthHelper::setFlash('otp_error', 'Kode OTP yang Anda masukkan salah. Periksa kembali pesan WhatsApp Anda.', 'danger');
                header('Location: ' . BASE_URL . '/verify-otp');
                exit;
            }
        }

        // Tampilan Form Verifikasi OTP
        $data = [
            'title' => 'Verifikasi OTP WhatsApp - TKJ Smart Service',
            'active_nav' => 'register',
            'hide_navbar' => true,
            'hide_footer' => true,
            'body_class' => 'auth-page-clean',
            'email' => $pending['email'],
            'nama' => $pending['nama'],
            'no_telepon' => $pending['no_telepon'] ?? '',
            'masked_phone' => !empty($pending['no_telepon']) ? FonnteHelper::maskPhone($pending['no_telepon']) : ''
        ];

        $this->view('auth/verify_otp', $data);
    }

    /**
     * Kirim Ulang Kode OTP WhatsApp Registrasi
     */
    public function resendOtp() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        $pending = $_SESSION['pending_registration'] ?? null;
        if (!$pending) {
            AuthHelper::setFlash('register_error', 'Sesi registrasi tidak ditemukan. Silakan isi form pendaftaran.', 'warning');
            header('Location: ' . BASE_URL . '/register');
            exit;
        }

        $newOtp = sprintf('%06d', mt_rand(100000, 999999));
        $_SESSION['pending_registration']['otp'] = $newOtp;
        $_SESSION['pending_registration']['otp_expiry'] = time() + (defined('OTP_EXPIRY_MINUTES') ? OTP_EXPIRY_MINUTES * 60 : 300);

        $waResult = FonnteHelper::sendOtp($pending['no_telepon'], $newOtp);
        if ($waResult['success']) {
            AuthHelper::setFlash('otp_success', 'Kode OTP baru berhasil dikirimkan via WhatsApp ke nomor ' . FonnteHelper::maskPhone($pending['no_telepon']) . '.', 'success');
        } else {
            AuthHelper::setFlash('otp_error', 'Gagal kirim ulang OTP (Fonnte): ' . htmlspecialchars($waResult['message']), 'danger');
        }

        header('Location: ' . BASE_URL . '/verify-otp');
        exit;
    }

    /**
     * Batalkan Sesi Verifikasi OTP Registrasi
     */
    public function cancelOtp() {
        unset($_SESSION['pending_registration']);
        AuthHelper::setFlash('register_info', 'Proses verifikasi dibatalkan. Silakan lakukan pendaftaran kembali.', 'info');
        header('Location: ' . BASE_URL . '/register');
        exit;
    }

    /**
     * Logout Session User
     */
    public function logout() {
        AuthHelper::logout();
        AuthHelper::setFlash('login_info', 'Anda telah berhasil keluar dari sistem.', 'info');
        header('Location: ' . BASE_URL . '/login');
        exit;
    }

    /**
     * Halaman Lupa Password (Langkah 1: Verifikasi Email)
     */
    public function lupaPassword() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');

            if (empty($email)) {
                AuthHelper::setFlash('lupa_error', 'Alamat email wajib diisi.', 'danger');
                header('Location: ' . BASE_URL . '/lupa-password');
                exit;
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                AuthHelper::setFlash('lupa_error', 'Format email yang dimasukkan tidak valid.', 'danger');
                header('Location: ' . BASE_URL . '/lupa-password');
                exit;
            }

            SecurityHelper::verifyCsrfToken();

            $userModel = $this->model('UserModel');
            $user = $userModel->findByEmail($email);

            if (!$user) {
                AuthHelper::setFlash('lupa_error', 'Alamat email tidak terdaftar dalam sistem.', 'danger');
                header('Location: ' . BASE_URL . '/lupa-password');
                exit;
            }

            // Simpan data verifikasi ke session
            $_SESSION['reset_email'] = $user['email'];
            $_SESSION['reset_user_name'] = $user['nama'];
            $_SESSION['reset_user_id'] = $user['id'];
            $_SESSION['reset_user_role'] = $user['role'];

            AuthHelper::setFlash('reset_info', 'Akun terverifikasi! Silakan tentukan password baru untuk akun Anda.', 'info');
            header('Location: ' . BASE_URL . '/reset-password');
            exit;
        }

        $data = [
            'title' => 'Lupa Password - TKJ Smart Service',
            'active_nav' => 'login',
            'hide_navbar' => true,
            'hide_footer' => true,
            'body_class' => 'auth-page-clean'
        ];

        $this->view('auth/lupa_password', $data);
    }

    /**
     * Halaman Reset Password Baru (Langkah 2: Buat Password Baru)
     */
    public function resetPassword() {
        if (AuthHelper::isLoggedIn()) {
            header('Location: ' . AuthHelper::getDashboardUrl());
            exit;
        }

        // Cek apakah user telah melewati tahap verifikasi email
        if (empty($_SESSION['reset_email'])) {
            AuthHelper::setFlash('lupa_error', 'Sesi verifikasi telah kedaluwarsa. Masukkan email Anda terlebih dahulu.', 'warning');
            header('Location: ' . BASE_URL . '/lupa-password');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $newPassword = trim($_POST['new_password'] ?? '');
            $confirmPassword = trim($_POST['confirm_password'] ?? '');

            if (empty($newPassword) || empty($confirmPassword)) {
                AuthHelper::setFlash('reset_error', 'Semua kolom password wajib diisi.', 'danger');
                header('Location: ' . BASE_URL . '/reset-password');
                exit;
            }

            if (strlen($newPassword) < 6) {
                AuthHelper::setFlash('reset_error', 'Password minimal terdiri dari 6 karakter.', 'danger');
                header('Location: ' . BASE_URL . '/reset-password');
                exit;
            }

            if ($newPassword !== $confirmPassword) {
                AuthHelper::setFlash('reset_error', 'Konfirmasi password tidak cocok dengan password baru.', 'danger');
                header('Location: ' . BASE_URL . '/reset-password');
                exit;
            }

            SecurityHelper::verifyCsrfToken();

            $email = $_SESSION['reset_email'];
            $userId = $_SESSION['reset_user_id'] ?? null;
            $userName = $_SESSION['reset_user_name'] ?? 'User';

            $userModel = $this->model('UserModel');
            $updated = $userModel->resetPassword($email, $newPassword);

            if ($updated) {
                // Buat notifikasi keamanan ke user jika user_id ada
                if ($userId) {
                    try {
                        $notifModel = $this->model('NotificationModel');
                        $notifModel->createNotification(
                            $userId,
                            'Password Berhasil Diubah',
                            'Password akun Anda baru saja diperbarui pada ' . date('d M Y H:i') . ' WIB. Jika ini bukan Anda, segera hubungi Operator.'
                        );
                    } catch (Exception $e) {
                        // ignore notification exception
                    }
                }

                // Bersihkan session reset
                unset($_SESSION['reset_email'], $_SESSION['reset_user_name'], $_SESSION['reset_user_id'], $_SESSION['reset_user_role']);

                AuthHelper::setFlash('login_success', 'Password akun ' . htmlspecialchars($userName) . ' berhasil diperbarui! Silakan masuk dengan password baru.', 'success');
                header('Location: ' . BASE_URL . '/login');
                exit;
            } else {
                AuthHelper::setFlash('reset_error', 'Gagal memperbarui password. Silakan coba kembali.', 'danger');
                header('Location: ' . BASE_URL . '/reset-password');
                exit;
            }
        }

        $data = [
            'title' => 'Buat Password Baru - TKJ Smart Service',
            'active_nav' => 'login',
            'hide_navbar' => true,
            'hide_footer' => true,
            'body_class' => 'auth-page-clean',
            'email' => $_SESSION['reset_email'],
            'nama' => $_SESSION['reset_user_name'] ?? 'User'
        ];

        $this->view('auth/reset_password', $data);
    }
}

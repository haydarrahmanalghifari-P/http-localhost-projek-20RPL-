<?php
/**
 * OperatorController - Modul Pengelolaan Sistem Operator (TEFA TKJ)
 */

class OperatorController extends Controller {

    public function __construct() {
        // Proteksi RBAC: Hanya role 'operator' yang diizinkan
        AuthHelper::checkRole('operator');
    }

    /**
     * 1. Dashboard Operator
     */
    public function dashboard() {
        $user = AuthHelper::user();
        $userModel = $this->model('UserModel');
        $orderModel = $this->model('OrderModel');

        $customers = $userModel->getUsersByRole('customer');
        $teknisiList = $userModel->getUsersByRole('teknisi');
        $orders = $orderModel->getAllOrders();
        $summary = $orderModel->getLaporanSummary();

        $data = [
            'title' => 'Dashboard Operator - TKJ Smart Service',
            'user' => $user,
            'countCustomers' => count($customers),
            'countTeknisi' => count($teknisiList),
            'countOrders' => count($orders),
            'summary' => $summary,
            'recentOrders' => array_slice($orders, 0, 5),
            'active_nav' => 'dashboard'
        ];

        $this->view('operator/dashboard', $data);
    }

    /**
     * 2. Kelola Data Customer (CRUD)
     */
    public function customer($action = null, $id = null) {
        $userModel = $this->model('UserModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();

            if ($action === 'create') {

                $nama = trim($_POST['nama'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $password = trim($_POST['password'] ?? 'password123');

                if (!empty($nama) && !empty($email)) {
                    $userModel->createUser($nama, $email, $password, 'customer');
                    AuthHelper::setFlash('op_success', 'Data Customer berhasil ditambahkan.', 'success');
                }
            } elseif ($action === 'edit' && $id) {
                $nama = trim($_POST['nama'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $password = trim($_POST['password'] ?? '');

                if (!empty($nama) && !empty($email)) {
                    $userModel->updateUser($id, $nama, $email, 'customer', $password);
                    AuthHelper::setFlash('op_success', 'Data Customer berhasil diperbarui.', 'success');
                }
            } elseif ($action === 'delete' && $id) {
                $userModel->deleteUser($id);
                AuthHelper::setFlash('op_success', 'Data Customer berhasil dihapus.', 'success');
            }
            header('Location: ' . BASE_URL . '/operator/customer');
            exit;
        }

        $customers = $userModel->getUsersByRole('customer');
        $data = [
            'title' => 'Kelola Data Customer - TKJ Smart Service',
            'customers' => $customers,
            'active_nav' => 'customer'
        ];

        $this->view('operator/customer', $data);
    }

    /**
     * 3. Kelola Data Teknisi Siswa TKJ (CRUD)
     */
    public function teknisi($action = null, $id = null) {
        $userModel = $this->model('UserModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();
            if ($action === 'create') {
                $nama = trim($_POST['nama'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $password = trim($_POST['password'] ?? 'password123');

                if (!empty($nama) && !empty($email)) {
                    $userModel->createUser($nama, $email, $password, 'teknisi');
                    AuthHelper::setFlash('op_success', 'Data Teknisi Siswa berhasil ditambahkan.', 'success');
                }
            } elseif ($action === 'edit' && $id) {
                $nama = trim($_POST['nama'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $password = trim($_POST['password'] ?? '');

                if (!empty($nama) && !empty($email)) {
                    $userModel->updateUser($id, $nama, $email, 'teknisi', $password);
                    AuthHelper::setFlash('op_success', 'Data Teknisi Siswa berhasil diperbarui.', 'success');
                }
            } elseif ($action === 'delete' && $id) {
                $userModel->deleteUser($id);
                AuthHelper::setFlash('op_success', 'Data Teknisi Siswa berhasil dihapus.', 'success');
            }
            header('Location: ' . BASE_URL . '/operator/teknisi');
            exit;
        }

        $teknisiList = $userModel->getUsersByRole('teknisi');
        $data = [
            'title' => 'Kelola Data Teknisi TKJ - TKJ Smart Service',
            'teknisiList' => $teknisiList,
            'active_nav' => 'teknisi'
        ];

        $this->view('operator/teknisi', $data);
    }

    /**
     * 4. Kelola Katalog Jasa IT (CRUD)
     */
    public function jasa($action = null, $id = null) {
        $serviceModel = $this->model('ServiceModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();
            if ($action === 'create') {
                $namaJasa = trim($_POST['nama_jasa'] ?? '');
                $deskripsi = trim($_POST['deskripsi'] ?? '');
                $hargaMulai = (float)($_POST['harga_mulai'] ?? 0);
                $estimasi = trim($_POST['estimasi_pengerjaan'] ?? '');
                $status = trim($_POST['status'] ?? 'aktif');

                if (!empty($namaJasa)) {
                    $serviceModel->createJasa([
                        'nama_jasa' => $namaJasa,
                        'deskripsi' => $deskripsi,
                        'harga_mulai' => $hargaMulai,
                        'estimasi_pengerjaan' => $estimasi,
                        'status' => $status
                    ]);
                    AuthHelper::setFlash('op_success', 'Layanan Jasa baru berhasil ditambahkan.', 'success');
                }
            } elseif ($action === 'edit' && $id) {
                $namaJasa = trim($_POST['nama_jasa'] ?? '');
                $deskripsi = trim($_POST['deskripsi'] ?? '');
                $hargaMulai = (float)($_POST['harga_mulai'] ?? 0);
                $estimasi = trim($_POST['estimasi_pengerjaan'] ?? '');
                $status = trim($_POST['status'] ?? 'aktif');

                if (!empty($namaJasa)) {
                    $serviceModel->updateJasa($id, [
                        'nama_jasa' => $namaJasa,
                        'deskripsi' => $deskripsi,
                        'harga_mulai' => $hargaMulai,
                        'estimasi_pengerjaan' => $estimasi,
                        'status' => $status
                    ]);
                    AuthHelper::setFlash('op_success', 'Layanan Jasa berhasil diperbarui.', 'success');
                }
            } elseif ($action === 'delete' && $id) {
                $serviceModel->deleteJasa($id);
                AuthHelper::setFlash('op_success', 'Layanan Jasa berhasil dihapus.', 'success');
            }
            header('Location: ' . BASE_URL . '/operator/jasa');
            exit;
        }

        $services = $serviceModel->getAllServices();
        $data = [
            'title' => 'Kelola Katalog Jasa IT - TKJ Smart Service',
            'services' => $services,
            'active_nav' => 'jasa'
        ];

        $this->view('operator/jasa', $data);
    }

    /**
     * 5. Kelola Pesanan, Plotting Teknisi, & Ubah Status
     */
    public function pesanan($action = null, $id = null) {
        $orderModel = $this->model('OrderModel');
        $userModel = $this->model('UserModel');
        $serviceModel = $this->model('ServiceModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();
            if ($action === 'create') {
                $customerId = (int)($_POST['customer_id'] ?? 0);
                $jasaId = (int)($_POST['jasa_id'] ?? 0);
                $noTelepon = trim($_POST['no_telepon'] ?? '');
                $alamat = trim($_POST['alamat'] ?? '');
                $deskripsiMasalah = trim($_POST['deskripsi_masalah'] ?? '');
                $tanggalPengerjaan = trim($_POST['tanggal_pengerjaan'] ?? date('Y-m-d'));
                $teknisiId = !empty($_POST['teknisi_id']) ? (int)$_POST['teknisi_id'] : null;
                $statusInput = trim($_POST['status'] ?? 'pending');
                $totalHarga = (float)($_POST['total_harga'] ?? 0);

                if (empty($customerId) || empty($jasaId) || empty($noTelepon) || empty($alamat) || empty($deskripsiMasalah)) {
                    AuthHelper::setFlash('op_error', 'Gagal membuat pesanan: Kolom Customer, Layanan Jasa, No. Kontak, Alamat, dan Deskripsi wajib diisi!', 'danger');
                } else {
                    // Jika total_harga kosong atau 0, ambil dari katalog jasa
                    if ($totalHarga <= 0) {
                        $allSvc = $serviceModel->getAllServices();
                        foreach ($allSvc as $s) {
                            if ($s['id'] == $jasaId) {
                                preg_match_all('/\d+/', str_replace('.', '', $s['price'] ?? ''), $matches);
                                if (!empty($matches[0][0])) {
                                    $totalHarga = (float)$matches[0][0];
                                }
                                break;
                            }
                        }
                    }

                    $orderData = [
                        'customer_id' => $customerId,
                        'jasa_id' => $jasaId,
                        'no_telepon' => $noTelepon,
                        'alamat' => $alamat,
                        'deskripsi_masalah' => $deskripsiMasalah,
                        'tanggal_pengerjaan' => $tanggalPengerjaan,
                        'status' => $statusInput,
                        'teknisi_id' => $teknisiId,
                        'total_harga' => $totalHarga
                    ];

                    if ($orderModel->createOrder($orderData)) {
                        AuthHelper::setFlash('op_success', 'Pesanan layanan jasa baru berhasil dibuat langsung oleh Admin/Operator.', 'success');
                    } else {
                        AuthHelper::setFlash('op_error', 'Gagal menyimpan pesanan baru ke sistem database.', 'danger');
                    }
                }
                header('Location: ' . BASE_URL . '/operator/pesanan');
                exit;

            } elseif ($action === 'update' && $id) {
                $statusInput = trim($_POST['status'] ?? 'pending');
                $teknisiId = (int)($_POST['teknisi_id'] ?? 0);

                // Cek Pesanan
                $existingOrder = $orderModel->getOrderById($id);
                if ($existingOrder && in_array(strtolower($existingOrder['status']), ['pending', 'menunggu'])) {
                    if (in_array(strtolower($statusInput), ['dikonfirmasi', 'diverifikasi', 'diproses', 'selesai'])) {
                        AuthHelper::setFlash('op_error', 'Hak Akses Dibatasi: Verifikasi awal dan persetujuan pesanan baru hanya dapat dilakukan oleh Administrator.', 'danger');
                        header('Location: ' . BASE_URL . '/operator/pesanan');
                        exit;
                    }
                }

                // Mapping Status Input ke Enum DB
                $statusDb = 'pending';
                if ($statusInput === 'Menunggu' || $statusInput === 'pending') $statusDb = 'pending';
                elseif ($statusInput === 'Diverifikasi' || $statusInput === 'dikonfirmasi') $statusDb = 'dikonfirmasi';
                elseif ($statusInput === 'Diproses' || $statusInput === 'Dikerjakan' || $statusInput === 'diproses') $statusDb = 'diproses';
                elseif ($statusInput === 'Selesai' || $statusInput === 'selesai') $statusDb = 'selesai';
                elseif ($statusInput === 'Dibatalkan' || $statusInput === 'dibatalkan') $statusDb = 'dibatalkan';

                $orderModel->assignTeknisiAndStatus($id, $statusDb, $teknisiId);
                AuthHelper::setFlash('op_success', 'Pesanan dan teknisi penanggung jawab berhasil diperbarui.', 'success');
            } elseif ($action === 'delete' && $id) {
                $orderModel->deleteOrder($id);
                AuthHelper::setFlash('op_success', 'Pesanan berhasil dihapus.', 'success');
            }
            header('Location: ' . BASE_URL . '/operator/pesanan');
            exit;
        }

        $orders = $orderModel->getAllOrders();
        $teknisiList = $userModel->getUsersByRole('teknisi');
        $customerList = $userModel->getUsersByRole('customer');
        $serviceList = $serviceModel->getAllServices();

        $data = [
            'title' => 'Kelola Pesanan & Plotting Teknisi - TKJ Smart Service',
            'orders' => $orders,
            'teknisiList' => $teknisiList,
            'customerList' => $customerList,
            'serviceList' => $serviceList,
            'active_nav' => 'pesanan'
        ];

        $this->view('operator/pesanan', $data);
    }

    /**
     * 6. Melihat Pembayaran Pelanggan
     */
    public function pembayaran($action = null, $id = null) {
        $pembayaranModel = $this->model('PembayaranModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST' || $action === 'verifikasi') {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                SecurityHelper::verifyCsrfToken();
            }
            if ($action === 'verifikasi' && $id) {
                $pembayaranModel->verifyPayment($id);
                AuthHelper::setFlash('op_success', 'Pembayaran transaksi telah berhasil diverifikasi (Status: Dibayar/Lunas).', 'success');
            } elseif ($action === 'tolak' && $id) {
                $catatan = trim($_POST['catatan_operator'] ?? 'Bukti pembayaran tidak valid / tidak sesuai.');
                $pembayaranModel->rejectPayment($id, $catatan);
                AuthHelper::setFlash('op_success', 'Pembayaran transaksi telah ditolak.', 'warning');
            }

            header('Location: ' . BASE_URL . '/operator/pembayaran');
            exit;
        }

        $payments = $pembayaranModel->getAllPayments();

        $data = [
            'title' => 'Melihat & Verifikasi Pembayaran - TKJ Smart Service',
            'payments' => $payments,
            'active_nav' => 'pembayaran'
        ];

        $this->view('operator/pembayaran', $data);
    }


    /**
     * 7. Melihat Ulasan & Rating Customer
     */
    public function review() {
        $reviewModel = $this->model('ReviewModel');
        $reviews = $reviewModel->getAllReviews();

        $data = [
            'title' => 'Melihat Rating & Review - TKJ Smart Service',
            'reviews' => $reviews,
            'active_nav' => 'review'
        ];

        $this->view('operator/review', $data);
    }

    /**
     * 8. Melihat Laporan Penjualan & Performa
     */
    public function laporan() {
        $laporanModel = $this->model('LaporanModel');

        $tipe = trim($_GET['tipe'] ?? 'pesanan');
        $periode = trim($_GET['periode'] ?? 'bulan');

        $reportData = $laporanModel->getFilteredReport($tipe, $periode);

        $data = [
            'title' => 'Laporan Modul TEFA - Operator TKJ Smart Service',
            'reportData' => $reportData,
            'isOperator' => true,
            'active_nav' => 'laporan'
        ];

        $this->view('operator/laporan', $data);
    }


    /**
     * 9. Kelola Data FAQ (Frequently Asked Questions) Operator
     */
    public function faq($action = null, $id = null) {
        $faqModel = $this->model('FaqModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST' || $action === 'toggle' || $action === 'delete') {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                SecurityHelper::verifyCsrfToken();
            }
            if ($action === 'create') {
                $pertanyaan = trim($_POST['pertanyaan'] ?? '');
                $jawaban = trim($_POST['jawaban'] ?? '');
                $status = trim($_POST['status'] ?? 'aktif');

                if (!empty($pertanyaan) && !empty($jawaban)) {
                    $faqModel->createFaq($pertanyaan, $jawaban, $status);
                    AuthHelper::setFlash('op_success', 'FAQ baru berhasil ditambahkan.', 'success');
                } else {
                    AuthHelper::setFlash('op_error', 'Pertanyaan dan jawaban wajib diisi.', 'danger');
                }
            } elseif ($action === 'edit' && $id) {
                $pertanyaan = trim($_POST['pertanyaan'] ?? '');
                $jawaban = trim($_POST['jawaban'] ?? '');
                $status = trim($_POST['status'] ?? 'aktif');

                if (!empty($pertanyaan) && !empty($jawaban)) {
                    $faqModel->updateFaq($id, $pertanyaan, $jawaban, $status);
                    AuthHelper::setFlash('op_success', 'Data FAQ berhasil diperbarui.', 'success');
                } else {
                    AuthHelper::setFlash('op_error', 'Pertanyaan dan jawaban wajib diisi.', 'danger');
                }
            } elseif ($action === 'toggle' && $id) {
                $faqModel->toggleStatus($id);
                AuthHelper::setFlash('op_success', 'Status FAQ berhasil diubah.', 'success');
            } elseif ($action === 'delete' && $id) {
                $faqModel->deleteFaq($id);
                AuthHelper::setFlash('op_success', 'FAQ berhasil dihapus.', 'success');
            }

            header('Location: ' . BASE_URL . '/operator/faq');
            exit;
        }

        $faqs = $faqModel->getAllFaqs();

        $data = [
            'title' => 'Kelola FAQ AI Assistant - TKJ Smart Service',
            'faqs' => $faqs,
            'active_nav' => 'faq'
        ];

        $this->view('operator/faq', $data);
    }
}


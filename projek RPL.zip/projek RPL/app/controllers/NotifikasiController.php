<?php
/**
 * NotifikasiController - Controller Pengelolaan Notifikasi Internal Website
 */

class NotifikasiController extends Controller {

    public function __construct() {
        // Wajib Logged In
        if (!AuthHelper::isLoggedIn()) {
            AuthHelper::setFlash('auth_error', 'Silakan login terlebih dahulu.', 'warning');
            header('Location: ' . BASE_URL . '/login');
            exit;
        }
    }

    /**
     * Halaman Daftar Seluruh Notifikasi Pengguna
     */
    public function index() {
        $user = AuthHelper::user();
        $notifModel = $this->model('NotificationModel');
        $notifications = $notifModel->getAllNotificationsByUser($user['id']);

        $data = [
            'title' => 'Notifikasi Saya - TKJ Smart Service',
            'user' => $user,
            'notifications' => $notifications,
            'active_nav' => 'notifikasi'
        ];

        $this->view('notifikasi/index', $data);
    }

    /**
     * Tandai 1 Notifikasi Sebagai Sudah Dibaca
     */
    public function read($id = null) {
        if ($id) {
            $user = AuthHelper::user();
            $notifModel = $this->model('NotificationModel');
            $notifModel->markAsRead($id, $user['id']);
        }

        $referer = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/notifikasi');
        header('Location: ' . $referer);
        exit;
    }

    /**
     * Tandai Seluruh Notifikasi Sebagai Sudah Dibaca
     */
    public function readAll() {
        $user = AuthHelper::user();
        $notifModel = $this->model('NotificationModel');
        $notifModel->markAllAsRead($user['id']);

        AuthHelper::setFlash('notif_success', 'Seluruh notifikasi telah ditandai sebagai sudah dibaca.', 'success');
        $referer = $_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/notifikasi');
        header('Location: ' . $referer);
        exit;
    }
}

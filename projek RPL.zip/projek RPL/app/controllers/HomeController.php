<?php
/**
 * HomeController - Controller Halaman Home
 */

class HomeController extends Controller {
    /**
     * Display Halaman Utama TKJ Smart Service
     */
    public function index() {
        // Ambil Data Layanan Jasa dari Model
        $serviceModel = $this->model('ServiceModel');
        $services = $serviceModel->getAllServices();

        // Ambil Data FAQ aktif
        require_once APPROOT . '/app/models/FaqModel.php';
        $faqModel = new FaqModel();
        $faqs = $faqModel->getActiveFaqs();

        // Data yang dilempar ke View
        $data = [
            'title' => 'TKJ Smart Service - Solusi Layanan IT Terpercaya Siswa TKJ',
            'active_nav' => 'home',
            'services' => $services,
            'faqs' => $faqs
        ];

        // Load View home/index
        $this->view('home/index', $data);
    }
}

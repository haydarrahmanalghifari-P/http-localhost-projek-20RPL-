<?php
/**
 * AdminController - Modul Administrator Utama / Superuser
 * Mengelola seluruh pengguna (semua role), hak akses sistem, dan ringkasan unit bisnis TEFA.
 */

class AdminController extends Controller {

    public function __construct() {
        // Proteksi RBAC: Hanya role 'admin' yang diizinkan
        AuthHelper::checkRole('admin');
    }

    /**
     * 1. Dashboard Utama Administrator
     */
    public function dashboard() {
        $user = AuthHelper::user();
        $userModel = $this->model('UserModel');
        $orderModel = $this->model('OrderModel');
        $serviceModel = $this->model('ServiceModel');

        $userStats = $userModel->getUserStats();
        $orders = $orderModel->getAllOrders();
        $summary = $orderModel->getLaporanSummary();
        $services = $serviceModel->getAllServices();
        $allUsers = $userModel->getAllUsers();

        $countPendingOrders = 0;
        foreach ($orders as $ord) {
            $st = strtolower($ord['status']);
            if ($st === 'pending' || $st === 'menunggu') {
                $countPendingOrders++;
            }
        }

        $data = [
            'title' => 'Dashboard Administrator - TKJ Smart Service',
            'user' => $user,
            'userStats' => $userStats,
            'countOrders' => count($orders),
            'countPendingOrders' => $countPendingOrders,
            'countServices' => count($services),
            'summary' => $summary,
            'recentUsers' => array_slice($allUsers, 0, 5),
            'recentOrders' => array_slice($orders, 0, 5),
            'active_nav' => 'dashboard'
        ];

        $this->view('admin/dashboard', $data);
    }

    /**
     * 2. Manajemen Semua Pengguna (CRUD Multi-Role: Admin, Operator, Teknisi, Kepala Sekolah, Customer)
     */
    public function users($action = null, $id = null) {
        $user = AuthHelper::user();
        $userModel = $this->model('UserModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();

            if ($action === 'create') {
                $nama = trim($_POST['nama'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $password = trim($_POST['password'] ?? 'password123');
                $role = trim($_POST['role'] ?? 'customer');

                // Validasi role
                $allowedRoles = ['admin', 'operator', 'teknisi', 'kepala_sekolah', 'customer'];
                if (!in_array($role, $allowedRoles)) {
                    $role = 'customer';
                }

                if (empty($nama) || empty($email)) {
                    AuthHelper::setFlash('admin_error', 'Nama dan Email wajib diisi!', 'danger');
                } else {
                    $existing = $userModel->findByEmail($email);
                    if ($existing) {
                        AuthHelper::setFlash('admin_error', 'Email sudah terdaftar di sistem! Gunakan email lain.', 'danger');
                    } else {
                        $userModel->createUser($nama, $email, $password, $role);
                        AuthHelper::setFlash('admin_success', "Pengguna baru berhasil ditambahkan sebagai " . strtoupper(str_replace('_', ' ', $role)) . ".", 'success');
                    }
                }
                header('Location: ' . BASE_URL . '/admin/users');
                exit;

            } elseif ($action === 'edit' && $id) {
                $nama = trim($_POST['nama'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $role = trim($_POST['role'] ?? 'customer');
                $password = trim($_POST['password'] ?? '');

                $allowedRoles = ['admin', 'operator', 'teknisi', 'kepala_sekolah', 'customer'];
                if (!in_array($role, $allowedRoles)) {
                    $role = 'customer';
                }

                if (!empty($nama) && !empty($email)) {
                    $userModel->updateUser($id, $nama, $email, $role, !empty($password) ? $password : null);
                    AuthHelper::setFlash('admin_success', 'Data pengguna berhasil diperbarui.', 'success');
                }
                header('Location: ' . BASE_URL . '/admin/users');
                exit;

            } elseif ($action === 'delete' && $id) {
                // Cegah admin menghapus akunnya sendiri
                if ((int)$id === (int)$user['id']) {
                    AuthHelper::setFlash('admin_error', 'Anda tidak dapat menghapus akun Anda sendiri yang sedang aktif!', 'danger');
                } else {
                    $userModel->deleteUser($id);
                    AuthHelper::setFlash('admin_success', 'Pengguna berhasil dihapus dari sistem.', 'success');
                }
                header('Location: ' . BASE_URL . '/admin/users');
                exit;
            }
        }

        $roleFilter = isset($_GET['role']) ? trim($_GET['role']) : null;
        $users = $userModel->getAllUsers($roleFilter);
        $userStats = $userModel->getUserStats();

        $data = [
            'title' => 'Manajemen Pengguna - Administrator TKJ Smart Service',
            'user' => $user,
            'users' => $users,
            'userStats' => $userStats,
            'currentFilter' => $roleFilter,
            'active_nav' => 'users'
        ];

        $this->view('admin/users', $data);
    }

    /**
     * 3. Modul Verifikasi & Pengelolaan Pesanan Jasa Administrator
     */
    public function pesanan($action = null, $id = null) {
        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');
        $userModel = $this->model('UserModel');
        $serviceModel = $this->model('ServiceModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();

            if ($action === 'verifikasi' && $id) {
                // Verifikasi Pesanan oleh Admin
                $teknisiId = !empty($_POST['teknisi_id']) ? (int)$_POST['teknisi_id'] : null;
                $catatan = trim($_POST['catatan_admin'] ?? '');
                $orderModel->assignTeknisiAndStatus($id, 'dikonfirmasi', $teknisiId);

                // Kirim Notifikasi WhatsApp Otomatis ke Customer
                $waResult = $this->sendOrderNotificationWa($id, 'dikonfirmasi', $catatan);
                $waNote = ($waResult && !empty($waResult['success'])) ? ' & Notifikasi WhatsApp berhasil dikirim ke Pelanggan.' : '.';

                AuthHelper::setFlash('admin_success', "Pesanan #$id telah berhasil diverifikasi & disetujui oleh Administrator" . $waNote, 'success');
                $redirectUrl = !empty($_POST['from_detail']) ? BASE_URL . '/admin/orderDetail/' . $id : BASE_URL . '/admin/pesanan';
                header('Location: ' . $redirectUrl);
                exit;

            } elseif ($action === 'tolak' && $id) {
                // Tolak / Batalkan Pesanan oleh Admin
                $catatan = trim($_POST['catatan_admin'] ?? 'Pesanan dibatalkan oleh Administrator.');
                $orderModel->assignTeknisiAndStatus($id, 'dibatalkan', null);

                // Kirim Notifikasi WhatsApp Pembatalan
                $waResult = $this->sendOrderNotificationWa($id, 'dibatalkan', $catatan);
                $waNote = ($waResult && !empty($waResult['success'])) ? ' & Notifikasi WhatsApp telah dikirim ke Pelanggan.' : '.';

                AuthHelper::setFlash('admin_success', "Pesanan #$id telah ditolak / dibatalkan oleh Administrator" . $waNote, 'warning');
                $redirectUrl = !empty($_POST['from_detail']) ? BASE_URL . '/admin/orderDetail/' . $id : BASE_URL . '/admin/pesanan';
                header('Location: ' . $redirectUrl);
                exit;

            } elseif ($action === 'update' && $id) {
                $statusInput = trim($_POST['status'] ?? 'pending');
                $teknisiId = !empty($_POST['teknisi_id']) ? (int)$_POST['teknisi_id'] : null;
                $catatan = trim($_POST['catatan_admin'] ?? '');

                $statusDb = 'pending';
                if ($statusInput === 'Menunggu' || $statusInput === 'pending') $statusDb = 'pending';
                elseif ($statusInput === 'Diverifikasi' || $statusInput === 'dikonfirmasi') $statusDb = 'dikonfirmasi';
                elseif ($statusInput === 'Diproses' || $statusInput === 'Dikerjakan' || $statusInput === 'diproses' || $statusInput === 'processing' || $statusInput === 'shipped') $statusDb = 'diproses';
                elseif ($statusInput === 'Selesai' || $statusInput === 'selesai' || $statusInput === 'completed') $statusDb = 'selesai';
                elseif ($statusInput === 'Dibatalkan' || $statusInput === 'dibatalkan' || $statusInput === 'cancelled') $statusDb = 'dibatalkan';

                $orderModel->assignTeknisiAndStatus($id, $statusDb, $teknisiId);

                // Kirim Notifikasi WhatsApp Otomatis ke Customer
                $waResult = $this->sendOrderNotificationWa($id, $statusDb, $catatan);
                $waNote = ($waResult && !empty($waResult['success'])) ? ' & Notifikasi WhatsApp otomatis terkirim ke Pelanggan.' : '.';

                AuthHelper::setFlash('admin_success', "Status pesanan #$id berhasil diperbarui" . $waNote, 'success');
                $redirectUrl = !empty($_POST['from_detail']) ? BASE_URL . '/admin/orderDetail/' . $id : BASE_URL . '/admin/pesanan';
                header('Location: ' . $redirectUrl);
                exit;

            } elseif ($action === 'create') {
                $customerId = (int)($_POST['customer_id'] ?? 0);
                $jasaId = (int)($_POST['jasa_id'] ?? 0);
                $noTelepon = trim($_POST['no_telepon'] ?? '');
                $alamat = trim($_POST['alamat'] ?? '');
                $deskripsiMasalah = trim($_POST['deskripsi_masalah'] ?? '');
                $tanggalPengerjaan = trim($_POST['tanggal_pengerjaan'] ?? date('Y-m-d'));
                $teknisiId = !empty($_POST['teknisi_id']) ? (int)$_POST['teknisi_id'] : null;
                $statusInput = trim($_POST['status'] ?? 'dikonfirmasi'); // Otomatis diverifikasi jika dibuat admin
                $totalHarga = (float)($_POST['total_harga'] ?? 0);

                if (empty($customerId) || empty($jasaId) || empty($noTelepon) || empty($alamat) || empty($deskripsiMasalah)) {
                    AuthHelper::setFlash('admin_error', 'Gagal membuat pesanan: Kolom Customer, Layanan, Kontak, Alamat, dan Deskripsi wajib diisi!', 'danger');
                } else {
                    if ($totalHarga <= 0) {
                        $allSvc = $serviceModel->getAllServices();
                        foreach ($allSvc as $s) {
                            if ($s['id'] == $jasaId) {
                                preg_match_all('/\d+/', str_replace('.', '', $s['price'] ?? ''), $matches);
                                if (!empty($matches[0][0])) {
                                    $totalHarga = (float)$matches[0][0];
                                }
                                break;
                            }
                        }
                    }

                    $orderData = [
                        'customer_id' => $customerId,
                        'jasa_id' => $jasaId,
                        'no_telepon' => $noTelepon,
                        'alamat' => $alamat,
                        'deskripsi_masalah' => $deskripsiMasalah,
                        'tanggal_pengerjaan' => $tanggalPengerjaan,
                        'status' => $statusInput,
                        'teknisi_id' => $teknisiId,
                        'total_harga' => $totalHarga
                    ];

                    if ($orderModel->createOrder($orderData)) {
                        AuthHelper::setFlash('admin_success', 'Pesanan baru berhasil dibuat dan diverifikasi langsung oleh Administrator.', 'success');
                    } else {
                        AuthHelper::setFlash('admin_error', 'Gagal menyimpan pesanan baru ke database.', 'danger');
                    }
                }
                header('Location: ' . BASE_URL . '/admin/pesanan');
                exit;

            } elseif ($action === 'delete' && $id) {
                $orderModel->deleteOrder($id);
                AuthHelper::setFlash('admin_success', 'Pesanan berhasil dihapus oleh Administrator.', 'success');
                header('Location: ' . BASE_URL . '/admin/pesanan');
                exit;
            }
        }

        // Tampilan Halaman Detail Pesanan (Detail Pesanan & Update Status dengan WA Aktif)
        if ($action === 'detail' && $id) {
            $order = $orderModel->getOrderById($id);
            if (!$order) {
                AuthHelper::setFlash('admin_error', "Pesanan #$id tidak ditemukan di database.", 'danger');
                header('Location: ' . BASE_URL . '/admin/pesanan');
                exit;
            }

            $teknisiList = $userModel->getUsersByRole('teknisi');
            $data = [
                'title' => 'Detail Pesanan #' . ($order['kode_pesanan'] ?? $order['id']) . ' - TKJ Smart Service',
                'user' => $user,
                'order' => $order,
                'teknisiList' => $teknisiList,
                'active_nav' => 'pesanan'
            ];

            $this->view('admin/order_detail', $data);
            return;
        }

        $filterStatus = isset($_GET['status']) ? trim($_GET['status']) : null;
        $allOrders = $orderModel->getAllOrders();

        $countPending = 0;
        $countDikonfirmasi = 0;
        $countDiproses = 0;
        $countSelesai = 0;
        $countDibatalkan = 0;

        foreach ($allOrders as $o) {
            $st = strtolower($o['status']);
            if ($st === 'pending' || $st === 'menunggu') $countPending++;
            elseif ($st === 'dikonfirmasi' || $st === 'diverifikasi') $countDikonfirmasi++;
            elseif ($st === 'diproses' || $st === 'dikerjakan') $countDiproses++;
            elseif ($st === 'selesai') $countSelesai++;
            elseif ($st === 'dibatalkan') $countDibatalkan++;
        }

        $filteredOrders = $allOrders;
        if (!empty($filterStatus) && $filterStatus !== 'all') {
            $filteredOrders = array_values(array_filter($allOrders, function($o) use ($filterStatus) {
                $st = strtolower($o['status']);
                if ($filterStatus === 'pending') return ($st === 'pending' || $st === 'menunggu');
                if ($filterStatus === 'dikonfirmasi') return ($st === 'dikonfirmasi' || $st === 'diverifikasi');
                if ($filterStatus === 'diproses') return ($st === 'diproses' || $st === 'dikerjakan');
                return $st === $filterStatus;
            }));
        }

        $teknisiList = $userModel->getUsersByRole('teknisi');
        $customerList = $userModel->getUsersByRole('customer');
        $serviceList = $serviceModel->getAllServices();

        $data = [
            'title' => 'Verifikasi & Manajemen Pesanan - Administrator TKJ Smart Service',
            'user' => $user,
            'orders' => $filteredOrders,
            'currentFilter' => $filterStatus,
            'counts' => [
                'total' => count($allOrders),
                'pending' => $countPending,
                'dikonfirmasi' => $countDikonfirmasi,
                'diproses' => $countDiproses,
                'selesai' => $countSelesai,
                'dibatalkan' => $countDibatalkan
            ],
            'teknisiList' => $teknisiList,
            'customerList' => $customerList,
            'serviceList' => $serviceList,
            'active_nav' => 'pesanan'
        ];

        $this->view('admin/pesanan', $data);
    }

    /**
     * Halaman Detail Pesanan (Alias: /admin/orderDetail/{id})
     */
    public function orderDetail($id = null) {
        if (!$id) {
            header('Location: ' . BASE_URL . '/admin/pesanan');
            exit;
        }
        $this->pesanan('detail', $id);
    }

    public function order_detail($id = null) {
        $this->orderDetail($id);
    }

    /**
     * Kirim Notifikasi WhatsApp Otomatis ke Customer saat Status Pesanan Diperbarui
     */
    private function sendOrderNotificationWa($orderId, $newStatus, $catatanAdmin = null) {
        $orderModel = $this->model('OrderModel');
        $order = $orderModel->getOrderById($orderId);
        if (!$order) return false;

        $targetPhone = !empty($order['no_telepon']) ? $order['no_telepon'] : ($order['customer_no_telepon'] ?? null);
        if (empty($targetPhone)) return false;

        $namaCustomer = $order['nama_customer'] ?? 'Pelanggan';
        $kodePesanan = $order['kode_pesanan'] ?? ('ORD-' . $orderId);
        $namaJasa = $order['nama_jasa'] ?? 'Layanan Jasa IT';
        $totalHarga = 'Rp ' . number_format($order['total_harga'] ?? 0, 0, ',', '.');
        $namaTeknisi = !empty($order['nama_teknisi']) ? $order['nama_teknisi'] : 'Belum diplot';
        $alamat = !empty($order['alamat']) ? $order['alamat'] : '-';

        $statusConfig = [
            'pending' => [
                'emoji' => '⏳',
                'label' => 'Pending (Menunggu Verifikasi)',
                'desc' => 'Pesanan Anda telah diterima di sistem dan sedang menunggu antrean verifikasi oleh Administrator.'
            ],
            'dikonfirmasi' => [
                'emoji' => '📋',
                'label' => 'Dikonfirmasi (Terverifikasi Admin)',
                'desc' => 'Pesanan Anda telah berhasil DIVERIFIKASI & DISETUJUI oleh Administrator. Teknisi siswa TEFA TKJ dijadwalkan untuk pengerjaan.'
            ],
            'diproses' => [
                'emoji' => '🛠️',
                'label' => 'Processing (Sedang Diproses/Dikerjakan)',
                'desc' => 'Layanan jasa IT Anda sedang dalam penanganan aktif oleh Teknisi Siswa dengan supervisi instruktur ahli.'
            ],
            'selesai' => [
                'emoji' => '✅',
                'label' => 'Completed (Pesanan Selesai)',
                'desc' => 'Layanan jasa IT telah selesai dikerjakan dengan hasil prima dan bergaransi resmi unit bisnis TEFA TKJ. Terima kasih atas kepercayaan Anda!'
            ],
            'dibatalkan' => [
                'emoji' => '❌',
                'label' => 'Cancelled (Pesanan Dibatalkan)',
                'desc' => 'Mohon maaf, pesanan layanan jasa Anda telah dibatalkan oleh Administrator. Silakan hubungi kami untuk informasi lebih lanjut.'
            ]
        ];

        $stInfo = $statusConfig[$newStatus] ?? [
            'emoji' => '🔔',
            'label' => ucfirst($newStatus),
            'desc' => 'Status pesanan Anda telah diperbarui.'
        ];

        $linkDetail = BASE_URL . '/customer/pesanan';

        $message = "🔔 *UPDATE STATUS PESANAN - TKJ SMART SERVICE*\n\n"
            . "Halo *" . $namaCustomer . "*,\n"
            . "Status pesanan jasa Anda telah diperbarui oleh Administrator:\n\n"
            . "📋 *No. Pesanan:* #" . $kodePesanan . "\n"
            . "🛠️ *Layanan Jasa:* " . $namaJasa . "\n"
            . "📌 *Status Baru:* " . $stInfo['emoji'] . " *" . $stInfo['label'] . "*\n"
            . "💰 *Total Biaya:* " . $totalHarga . "\n"
            . "👨‍🔧 *Teknisi TEFA:* " . $namaTeknisi . "\n"
            . "📍 *Lokasi:* " . $alamat . "\n\n"
            . "📝 *Keterangan:* \n"
            . $stInfo['desc'] . "\n";

        if (!empty($catatanAdmin)) {
            $message .= "💬 *Catatan Admin:* " . $catatanAdmin . "\n";
        }

        $message .= "\n🔎 *Cek Progres Pesanan:*\n" . $linkDetail . "\n\n"
            . "Salam hangat,\n*Unit Bisnis & Teaching Factory (TEFA) TKJ SMK*";

        try {
            $res = FonnteHelper::sendWhatsApp($targetPhone, $message);
            return $res;
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Shortcut Delegasi ke Modul Layanan Jasa
     */
    public function jasa() {
        header('Location: ' . BASE_URL . '/operator/jasa');
        exit;
    }

    /**
     * Shortcut Delegasi ke Modul Pembayaran
     */
    public function pembayaran() {
        header('Location: ' . BASE_URL . '/operator/pembayaran');
        exit;
    }

    /**
     * Shortcut Delegasi ke Modul Laporan
     */
    public function laporan() {
        header('Location: ' . BASE_URL . '/operator/laporan');
        exit;
    }

    /**
     * Shortcut Delegasi ke Modul FAQ AI
     */
    public function faq() {
        header('Location: ' . BASE_URL . '/operator/faq');
        exit;
    }

    /**
     * Dashboard Konfigurasi AI & Multi API Key Cadangan
     * URL: /admin/ai-config atau /admin/ai
     */
    public function ai_config() {
        $user = AuthHelper::user();
        $configFile = APPROOT . '/config/ai_keys.json';

        // Load data konfigurasi yang tersimpan
        $aiConfig = [
            'active_provider' => 'gemini',
            'active_model' => 'gemini-3.5-flash-lite',
            'auto_failover' => true,
            'primary_key' => defined('GEMINI_API_KEY') ? GEMINI_API_KEY : '',
            'primary_provider' => 'gemini',
            'backup_key_1' => defined('DEEPSEEK_API_KEY') ? DEEPSEEK_API_KEY : '',
            'backup_provider_1' => 'deepseek',
            'backup_key_2' => '',
            'backup_provider_2' => '',
            'backup_key_3' => '',
            'backup_provider_3' => '',
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if (file_exists($configFile)) {
            $saved = json_decode(file_get_contents($configFile), true);
            if (is_array($saved)) {
                $aiConfig = array_merge($aiConfig, $saved);
            }
        }

        // Tangani Request POST untuk Menyimpan Konfigurasi
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') || 
                      (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false);

            if ($isAjax) {
                $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
            } else {
                SecurityHelper::verifyCsrfToken();
                $input = $_POST;
            }

            if (isset($input['primary_key'])) {
                $aiConfig['primary_key'] = trim($input['primary_key']);
            }
            if (isset($input['primary_provider'])) {
                $aiConfig['primary_provider'] = trim($input['primary_provider']);
                $aiConfig['active_provider'] = $aiConfig['primary_provider'];
            }
            if (isset($input['active_model'])) {
                $aiConfig['active_model'] = trim($input['active_model']);
            }
            if (isset($input['backup_key_1'])) {
                $aiConfig['backup_key_1'] = trim($input['backup_key_1']);
                if (strpos($aiConfig['backup_key_1'], 'sk-') === 0) $aiConfig['backup_provider_1'] = 'deepseek';
                elseif (strpos($aiConfig['backup_key_1'], 'AQ.') === 0 || strpos($aiConfig['backup_key_1'], 'AIzaSy') === 0) $aiConfig['backup_provider_1'] = 'gemini';
                elseif (strpos($aiConfig['backup_key_1'], 'grok_') === 0) $aiConfig['backup_provider_1'] = 'grok';
                elseif (!empty($input['backup_provider_1'])) $aiConfig['backup_provider_1'] = trim($input['backup_provider_1']);
            }
            if (isset($input['backup_key_2'])) {
                $aiConfig['backup_key_2'] = trim($input['backup_key_2']);
                if (strpos($aiConfig['backup_key_2'], 'sk-') === 0) $aiConfig['backup_provider_2'] = 'deepseek';
                elseif (strpos($aiConfig['backup_key_2'], 'AQ.') === 0 || strpos($aiConfig['backup_key_2'], 'AIzaSy') === 0) $aiConfig['backup_provider_2'] = 'gemini';
                elseif (strpos($aiConfig['backup_key_2'], 'grok_') === 0) $aiConfig['backup_provider_2'] = 'grok';
                elseif (!empty($input['backup_provider_2'])) $aiConfig['backup_provider_2'] = trim($input['backup_provider_2']);
            }
            if (isset($input['backup_key_3'])) {
                $aiConfig['backup_key_3'] = trim($input['backup_key_3']);
                if (strpos($aiConfig['backup_key_3'], 'sk-') === 0) $aiConfig['backup_provider_3'] = 'deepseek';
                elseif (strpos($aiConfig['backup_key_3'], 'AQ.') === 0 || strpos($aiConfig['backup_key_3'], 'AIzaSy') === 0) $aiConfig['backup_provider_3'] = 'gemini';
                elseif (strpos($aiConfig['backup_key_3'], 'grok_') === 0) $aiConfig['backup_provider_3'] = 'grok';
                elseif (!empty($input['backup_provider_3'])) $aiConfig['backup_provider_3'] = trim($input['backup_provider_3']);
            }
            $aiConfig['auto_failover'] = !empty($input['auto_failover']);
            $aiConfig['updated_at'] = date('Y-m-d H:i:s');

            file_put_contents($configFile, json_encode($aiConfig, JSON_PRETTY_PRINT));

            if ($isAjax) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Konfigurasi AI dan Multi API Key cadangan berhasil disimpan!',
                    'data' => $aiConfig
                ]);
                exit;
            }

            AuthHelper::setFlash('admin_success', 'Konfigurasi AI dan Multi API Key cadangan berhasil diperbarui.', 'success');
            header('Location: ' . BASE_URL . '/admin/ai-config');
            exit;
        }

        $data = [
            'title' => 'Konfigurasi AI & API Key - Administrator TKJ Smart Service',
            'user' => $user,
            'aiConfig' => $aiConfig,
            'active_nav' => 'ai_config',
            'hide_navbar' => true,
            'hide_footer' => true
        ];

        $this->view('admin/ai_config', $data);
    }

    /**
     * Alias route untuk ai_config
     */
    public function ai() {
        $this->ai_config();
    }

    /**
     * Endpoint Pengujian API Key AI secara Real-time (Ping Test & Latency)
     * URL: POST /admin/test-ai-key
     */
    public function test_ai_key() {
        header('Content-Type: application/json; charset=utf-8');
        
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $key = trim($input['key'] ?? '');
        $provider = trim($input['provider'] ?? '');

        if (empty($key)) {
            echo json_encode(['status' => 'error', 'message' => 'API Key tidak boleh kosong.']);
            exit;
        }

        // Auto-detect provider cerdas berdasarkan format prefix API Key
        if (strpos($key, 'gsk_') === 0) {
            $provider = 'groq';
        } elseif (strpos($key, 'sk-proj-') === 0) {
            $provider = 'openai';
        } elseif (strpos($key, 'sk-') === 0) {
            $provider = 'deepseek';
        } elseif (strpos($key, 'grok_') === 0 || strpos($key, 'xai-') === 0) {
            $provider = 'grok';
        } elseif (strpos($key, 'AQ.') === 0 || strpos($key, 'AIzaSy') === 0) {
            $provider = 'gemini';
        } elseif (empty($provider) || $provider === 'auto') {
            $provider = 'gemini';
        }

        $start = microtime(true);
        $isValid = false;
        $errorMsg = '';

        if ($provider === 'groq') {
            $ch = curl_init('https://api.groq.com/openai/v1/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi Groq'));
            }
        } elseif ($provider === 'openai') {
            $ch = curl_init('https://api.openai.com/v1/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi OpenAI'));
            }
        } elseif ($provider === 'grok') {
            $ch = curl_init('https://api.x.ai/v1/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi'));
            }
        } elseif ($provider === 'gemini') {
            $ch = curl_init("https://generativelanguage.googleapis.com/v1beta/models?key=" . urlencode($key));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi'));
            }
        } elseif ($provider === 'deepseek') {
            $ch = curl_init('https://api.deepseek.com/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi DeepSeek'));
            }
        } else {
            $isValid = true;
        }

        $latency = round((microtime(true) - $start) * 1000);

        if ($isValid) {
            echo json_encode([
                'status' => 'success',
                'latency' => $latency . ' ms',
                'provider' => $provider,
                'message' => 'Kunci valid & terhubung aktif.'
            ]);
        } else {
            // Jika network offline atau DNS blokir, tetap berikan latency simulasi terukur
            echo json_encode([
                'status' => 'error',
                'latency' => $latency . ' ms',
                'provider' => $provider,
                'message' => 'Respon: ' . $errorMsg
            ]);
        }
        exit;
    }
}

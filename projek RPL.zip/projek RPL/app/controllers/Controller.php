<?php
/**
 * Base Controller Class
 * Kelas utama yang menjadi induk dari seluruh Controller
 */

class Controller {
    /**
     * Memuat file View dan mengirimkan data
     * 
     * @param string $view Nama file view (misal: 'home/index')
     * @param array $data Data yang dikirim ke view
     */
    public function view($view, $data = []) {
        // Extract array data agar menjadi variabel terpisah (misal: $data['title'] menjadi $title)
        extract($data);

        // Render Head & Navbar
        if (file_exists(APPROOT . '/app/views/templates/header.php')) {
            require_once APPROOT . '/app/views/templates/header.php';
        }
        if (empty($hide_navbar) && file_exists(APPROOT . '/app/views/templates/navbar.php')) {
            require_once APPROOT . '/app/views/templates/navbar.php';
        }

        // Render Konten View Utama
        $viewFile = APPROOT . '/app/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            echo "<div class='container my-5 alert alert-danger'>View <b>{$view}.php</b> tidak ditemukan!</div>";
        }

        // Render Footer
        if (empty($hide_footer) && file_exists(APPROOT . '/app/views/templates/footer.php')) {
            require_once APPROOT . '/app/views/templates/footer.php';
        }
    }

    /**
     * Memuat dan menginstansiasi file Model
     * 
     * @param string $model Nama class Model (misal: 'ServiceModel')
     * @return object Instance dari model
     */
    public function model($model) {
        $modelFile = APPROOT . '/app/models/' . $model . '.php';
        if (file_exists($modelFile)) {
            require_once $modelFile;
            return new $model();
        } else {
            die("Model <b>{$model}.php</b> tidak ditemukan!");
        }
    }
}

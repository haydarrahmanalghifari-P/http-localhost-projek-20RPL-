<?php
/**
 * AIController - Controller khusus penanganan endpoint percakapan AI Assistant
 */

require_once APPROOT . '/app/services/AIService.php';

class AIController extends Controller {

    private $aiService;

    public function __construct() {
        AuthHelper::init();
        $this->aiService = new AIService();
    }

    /**
     * Endpoint API AJAX chat AI Assistant
     * URL: POST /ai/chat
     */
    public function chat() {
        // Set Header JSON
        header('Content-Type: application/json; charset=utf-8');

        // Ambil input JSON atau POST parameter
        $input = json_decode(file_get_contents('php://input'), true);
        $message = trim($input['message'] ?? $_POST['message'] ?? '');

        if (empty($message)) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Pesan tidak boleh kosong.'
            ]);
            exit;
        }

        $user = AuthHelper::isLoggedIn() ? AuthHelper::user() : null;
        if (!$user && !empty($input['user']) && !empty($input['user']['isLoggedIn'])) {
            $user = [
                'id' => $input['user']['id'] ?? null,
                'nama' => $input['user']['nama'] ?? 'Pengunjung',
                'email' => $input['user']['email'] ?? '',
                'role' => $input['user']['role'] ?? 'customer'
            ];
        }
        if (!$user) {
            $user = [
                'id' => null,
                'nama' => 'Pengunjung',
                'role' => 'guest'
            ];
        }

        $provider = trim($input['provider'] ?? $_POST['provider'] ?? '');
        $apiKey = trim($input['apiKey'] ?? $_POST['apiKey'] ?? '');
        if (empty($provider)) {
            $provider = defined('AI_PROVIDER') ? AI_PROVIDER : 'gemini';
        }

        // Panggil AIService untuk memproses jawaban
        $aiResponse = $this->aiService->generateResponse($user, $message, $provider, $apiKey);

        $providerLabels = [
            'grok' => 'Grok AI (xAI)',
            'gemini' => 'Google Gemini',
            'database' => 'Smart DB AI (Lokal)'
        ];

        echo json_encode([
            'status' => 'success',
            'response' => $aiResponse,
            'provider' => $provider,
            'providerName' => $providerLabels[$provider] ?? ucfirst($provider),
            'timestamp' => date('H:i')
        ]);
        exit;
    }

    /**
     * Endpoint API untuk mendapatkan daftar AI Provider yang tersedia
     * URL: GET /ai/providers
     */
    public function providers() {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'success',
            'active_provider' => defined('AI_PROVIDER') ? AI_PROVIDER : 'grok',
            'providers' => [
                [
                    'id' => 'grok',
                    'name' => 'Grok AI (xAI)',
                    'badge' => '⚡ Grok AI',
                    'badge_class' => 'badge-ai-grok',
                    'description' => 'Model xAI Grok-2 / Grok Beta super responsif',
                    'has_default_key' => !empty(defined('GROK_API_KEY') ? GROK_API_KEY : '')
                ],
                [
                    'id' => 'gemini',
                    'name' => 'Google Gemini',
                    'badge' => '✨ Gemini 3.5',
                    'badge_class' => 'badge-ai-gemini',
                    'description' => 'Google Gemini Flash multimodal intelligence',
                    'has_default_key' => !empty(defined('GEMINI_API_KEY') ? GEMINI_API_KEY : '')
                ],
                [
                    'id' => 'database',
                    'name' => 'Smart DB Assistant',
                    'badge' => '🗄️ Local DB',
                    'badge_class' => 'badge-ai-db',
                    'description' => 'Cerdas offline berbasis data MySQL lokal unit bisnis TKJ',
                    'has_default_key' => true
                ]
            ]
        ]);
        exit;
    }

    /**
     * Endpoint index fallback untuk AIController
     */
    public function index() {
        // Redirect ke route view customer/ai-assistant atau home
        if (AuthHelper::isLoggedIn() && AuthHelper::role() === 'customer') {
            header('Location: ' . BASE_URL . '/customer/ai-assistant');
        } else {
            header('Location: ' . BASE_URL);
        }
        exit;
    }

    /**
     * Endpoint API JSON untuk menyediakan konteks data aktual dari database
     * URL: GET /ai/context atau POST /ai/context
     */
    public function context() {
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true) ?: [];
        $customerId = $input['customerId'] ?? $_GET['customerId'] ?? ($_GET['userId'] ?? null);

        if (!$customerId && AuthHelper::isLoggedIn()) {
            $user = AuthHelper::user();
            $customerId = $user['id'] ?? null;
        }

        $serviceModel = new ServiceModel();
        $faqModel = new FaqModel();
        $orderModel = new OrderModel();
        $userModel = new UserModel();

        // 1. Data Layanan Jasa Aktif dari Database
        $services = $serviceModel->getAllServices();

        // 2. Data FAQ Aktif dari Database
        $faqs = $faqModel->getActiveFaqs();

        // 3. Statistik Pengguna Sistem Berdasarkan Role dari Database
        $userStats = $userModel->getUserStats();

        // 4. Data Pesanan Customer (Jika login / ada customerId)
        $customerOrders = [];
        $orderStats = null;
        if ($customerId) {
            $customerOrders = $orderModel->getOrdersByCustomer($customerId, 'active');
            $orderStats = $orderModel->getCountsByCustomer($customerId);
        }

        // 5. Data Pencarian Pesanan Spesifik (jika ada kode_pesanan yang ditanyakan)
        $orderCode = $input['orderCode'] ?? $_GET['orderCode'] ?? null;
        $searchedOrder = null;
        if ($orderCode) {
            $searchedOrder = $orderModel->getOrderByKode($orderCode);
        }

        echo json_encode([
            'status' => 'success',
            'app' => [
                'name' => defined('APP_NAME') ? APP_NAME : 'TKJ Smart Service',
                'tagline' => defined('APP_TAGLINE') ? APP_TAGLINE : 'Layanan Jasa IT Unit Bisnis Siswa TKJ',
                'school' => defined('APP_SCHOOL') ? APP_SCHOOL : 'SMK Negeri TKJ',
                'phone' => defined('APP_PHONE') ? APP_PHONE : '0812-3456-7890',
                'email' => defined('APP_EMAIL') ? APP_EMAIL : 'info@tkjsmartservice.sch.id',
            ],
            'services' => $services,
            'faqs' => $faqs,
            'user_stats' => $userStats,
            'customer_orders' => $customerOrders,
            'order_stats' => $orderStats,
            'searched_order' => $searchedOrder,
            'timestamp' => date('Y-m-d H:i:s')
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * Endpoint API untuk menguji koneksi API Key secara Real-time (Latency & Validitas)
     * URL: POST /ai/test-key
     */
    public function test_key() {
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $key = trim($input['key'] ?? '');
        $provider = trim($input['provider'] ?? '');

        if (empty($key)) {
            echo json_encode(['status' => 'error', 'message' => 'API Key tidak boleh kosong.']);
            exit;
        }

        // Auto-detect provider cerdas berdasarkan format prefix API Key
        if (strpos($key, 'gsk_') === 0) {
            $provider = 'groq';
        } elseif (strpos($key, 'sk-proj-') === 0) {
            $provider = 'openai';
        } elseif (strpos($key, 'sk-') === 0) {
            $provider = 'deepseek';
        } elseif (strpos($key, 'grok_') === 0 || strpos($key, 'xai-') === 0) {
            $provider = 'grok';
        } elseif (strpos($key, 'AQ.') === 0 || strpos($key, 'AIzaSy') === 0) {
            $provider = 'gemini';
        } elseif (empty($provider) || $provider === 'auto') {
            $provider = 'gemini';
        }

        $start = microtime(true);
        $isValid = false;
        $errorMsg = '';

        if ($provider === 'groq') {
            $ch = curl_init('https://api.groq.com/openai/v1/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi Groq'));
            }
        } elseif ($provider === 'openai') {
            $ch = curl_init('https://api.openai.com/v1/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi OpenAI'));
            }
        } elseif ($provider === 'grok') {
            $ch = curl_init('https://api.x.ai/v1/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi'));
            }
        } elseif ($provider === 'gemini') {
            $ch = curl_init("https://generativelanguage.googleapis.com/v1beta/models?key=" . urlencode($key));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi'));
            }
        } elseif ($provider === 'deepseek') {
            $ch = curl_init('https://api.deepseek.com/models');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $key,
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($httpCode === 200) {
                $isValid = true;
            } else {
                $errorMsg = "HTTP {$httpCode}: " . ($curlErr ?: (substr($response, 0, 100) ?: 'Gagal autentikasi DeepSeek'));
            }
        } else {
            $isValid = true;
        }

        $latency = round((microtime(true) - $start) * 1000);

        if ($isValid) {
            echo json_encode([
                'status' => 'success',
                'latency' => $latency . ' ms',
                'provider' => $provider,
                'message' => 'Kunci valid & terhubung aktif.'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'latency' => $latency . ' ms',
                'provider' => $provider,
                'message' => 'Respon: ' . $errorMsg
            ]);
        }
        exit;
    }
}

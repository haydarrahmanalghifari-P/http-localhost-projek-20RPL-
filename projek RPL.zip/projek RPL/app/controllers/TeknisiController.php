<?php
/**
 * TeknisiController - Modul Pengelolaan Pekerjaan Teknisi Siswa TKJ
 */

class TeknisiController extends Controller {

    public function __construct() {
        // Proteksi RBAC: Hanya role 'teknisi' yang diizinkan
        AuthHelper::checkRole('teknisi');
    }

    /**
     * 1. Dashboard Utama Teknisi
     */
    public function dashboard() {
        $user = AuthHelper::user();
        $workModel = $this->model('WorkReportModel');

        $counts = $workModel->getCountsByTeknisi($user['id']);
        $assignedJobs = $workModel->getAssignedJobs($user['id'], 'active');

        $data = [
            'title' => 'Dashboard Teknisi TKJ - TKJ Smart Service',
            'user' => $user,
            'counts' => $counts,
            'jobs' => $assignedJobs,
            'active_nav' => 'dashboard'
        ];

        $this->view('teknisi/dashboard', $data);
    }

    /**
     * 2. Daftar Pekerjaan Ditugaskan & Routing Sub-Actions
     */
    public function pekerjaan($action = null, $id = null) {
        if ($action === 'detail' && $id) {
            return $this->pekerjaanDetail($id);
        }

        $user = AuthHelper::user();
        $workModel = $this->model('WorkReportModel');

        // Form POST Update Progress Pekerjaan
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($action === 'update' || isset($_POST['order_id']))) {
            SecurityHelper::verifyCsrfToken();

            $orderId = (int)($id ?: ($_POST['order_id'] ?? 0));
            $statusInput = trim($_POST['status'] ?? 'Dikerjakan'); // Menunggu, Dikerjakan, Selesai
            $catatan = trim($_POST['catatan_teknisi'] ?? '');
            $hasil = trim($_POST['hasil_pekerjaan'] ?? '');

            // Handle Foto Bukti Pengerjaan
            $fotoPath = null;
            if (isset($_FILES['foto_pekerjaan']) && $_FILES['foto_pekerjaan']['error'] === UPLOAD_ERR_OK) {
                $uploaded = SecurityHelper::uploadFile($_FILES['foto_pekerjaan'], 'pekerjaan', ['jpg', 'jpeg', 'png', 'webp']);
                if ($uploaded) {
                    $fotoPath = $uploaded;
                } else {
                    AuthHelper::setFlash('teknisi_error', 'Gagal mengunggah foto pekerjaan. Harap gunakan format gambar valid (JPG/PNG/WEBP) maks 5MB.', 'danger');
                    header('Location: ' . BASE_URL . '/teknisi/pekerjaan/detail/' . $orderId);
                    exit;
                }
            }


            $updateData = [
                'status' => $statusInput,
                'catatan_teknisi' => $catatan,
                'hasil_pekerjaan' => $hasil,
                'foto_pekerjaan' => $fotoPath
            ];

            $workModel->updateJobProgress($orderId, $user['id'], $updateData);
            AuthHelper::setFlash('teknisi_success', 'Progress pekerjaan berhasil diperbarui!', 'success');
            header('Location: ' . BASE_URL . '/teknisi/pekerjaan/detail/' . $orderId);
            exit;
        }

        $assignedJobs = $workModel->getAssignedJobs($user['id'], 'active');
        $data = [
            'title' => 'Pekerjaan Ditugaskan - TKJ Smart Service',
            'jobs' => $assignedJobs,
            'active_nav' => 'pekerjaan'
        ];

        $this->view('teknisi/pekerjaan', $data);
    }

    /**
     * 3. Detail Pekerjaan & Form Log Progress
     */
    public function pekerjaanDetail($id = null) {
        if (!$id) {
            header('Location: ' . BASE_URL . '/teknisi/pekerjaan');
            exit;
        }

        $user = AuthHelper::user();
        $workModel = $this->model('WorkReportModel');
        $job = $workModel->getJobDetail($id, $user['id']);

        if (!$job) {
            AuthHelper::setFlash('teknisi_error', 'Pekerjaan tidak ditemukan atau bukan tugas Anda.', 'danger');
            header('Location: ' . BASE_URL . '/teknisi/pekerjaan');
            exit;
        }

        $data = [
            'title' => 'Detail Tugas #' . $job['kode_pesanan'],
            'job' => $job,
            'active_nav' => 'pekerjaan'
        ];

        $this->view('teknisi/pekerjaan_detail', $data);
    }

    /**
     * 4. Riwayat Pekerjaan Selesai
     */
    public function riwayat() {
        $user = AuthHelper::user();
        $workModel = $this->model('WorkReportModel');
        $historyJobs = $workModel->getAssignedJobs($user['id'], 'history');

        $data = [
            'title' => 'Riwayat Pekerjaan - TKJ Smart Service',
            'jobs' => $historyJobs,
            'active_nav' => 'riwayat'
        ];

        $this->view('teknisi/riwayat', $data);
    }

    /**
     * 5. Ubah Profil Teknisi
     */
    public function profile() {
        $user = AuthHelper::user();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();
            $nama = trim($_POST['nama'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $newPassword = trim($_POST['new_password'] ?? '');
            $confirmPassword = trim($_POST['confirm_password'] ?? '');

            if (empty($nama) || empty($email)) {
                AuthHelper::setFlash('teknisi_error', 'Nama dan email wajib diisi.', 'danger');
                header('Location: ' . BASE_URL . '/teknisi/profile');
                exit;
            }

            $passwordToUpdate = null;
            if (!empty($newPassword)) {
                if ($newPassword !== $confirmPassword) {
                    AuthHelper::setFlash('teknisi_error', 'Konfirmasi password baru tidak cocok.', 'danger');
                    header('Location: ' . BASE_URL . '/teknisi/profile');
                    exit;
                }
                $passwordToUpdate = $newPassword;
            }

            $userModel = $this->model('UserModel');
            if ($userModel->updateProfile($user['id'], $nama, $email, $passwordToUpdate)) {
                $_SESSION['user_name'] = $nama;
                $_SESSION['user_email'] = $email;

                AuthHelper::setFlash('teknisi_success', 'Profil teknisi berhasil diperbarui.', 'success');
                header('Location: ' . BASE_URL . '/teknisi/profile');
                exit;
            }
        }

        $data = [
            'title' => 'Profil Teknisi - TKJ Smart Service',
            'user' => AuthHelper::user(),
            'active_nav' => 'profile'
        ];

        $this->view('teknisi/profile', $data);
    }
}

<?php
/**
 * KepalaSekolahController - Modul Monitoring Eksekutif Kepala Sekolah (100% Read-Only)
 */

class KepalaSekolahController extends Controller {

    public function __construct() {
        // Proteksi RBAC: Hanya role 'kepala_sekolah' yang diizinkan
        AuthHelper::checkRole('kepala_sekolah');
    }

    /**
     * 1. Dashboard Eksekutif Kepala Sekolah
     */
    public function dashboard() {
        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');
        $stats = $orderModel->getExecutiveStats();

        $data = [
            'title' => 'Dashboard Eksekutif Kepala Sekolah - TKJ Smart Service',
            'user' => $user,
            'stats' => $stats,
            'active_nav' => 'dashboard'
        ];

        $this->view('kepala_sekolah/dashboard', $data);
    }

    /**
     * 2. Monitoring Pesanan Pelanggan (Read-Only)
     */
    public function pesanan() {
        $orderModel = $this->model('OrderModel');
        $orders = $orderModel->getAllOrders();

        $data = [
            'title' => 'Pemantauan Pesanan - Kepala Sekolah',
            'orders' => $orders,
            'active_nav' => 'pesanan'
        ];

        $this->view('kepala_sekolah/pesanan', $data);
    }

    /**
     * 3. Pemantauan Teknisi Siswa & Performa TEFA (Read-Only)
     */
    public function teknisi() {
        $orderModel = $this->model('OrderModel');
        $stats = $orderModel->getExecutiveStats();

        $data = [
            'title' => 'Pemantauan Teknisi Siswa TKJ - Kepala Sekolah',
            'workload' => $stats['teknisi_workload'] ?? [],
            'active_nav' => 'teknisi'
        ];

        $this->view('kepala_sekolah/teknisi', $data);
    }

    public function laporan() {
        $laporanModel = $this->model('LaporanModel');

        $tipe = trim($_GET['tipe'] ?? 'pesanan');
        $periode = trim($_GET['periode'] ?? 'bulan');

        $reportData = $laporanModel->getFilteredReport($tipe, $periode);

        $data = [
            'title' => 'Laporan Eksekutif TEFA - Kepala Sekolah',
            'reportData' => $reportData,
            'isOperator' => false,
            'active_nav' => 'laporan'
        ];

        $this->view('kepala_sekolah/laporan', $data);
    }
}


<?php
/**
 * CustomerController - Modul Lengkap Layanan Customer TKJ Smart Service
 */

class CustomerController extends Controller {

    public function __construct() {
        // Proteksi RBAC: Hanya role 'customer' yang diizinkan
        AuthHelper::checkRole('customer');
    }

    /**
     * 1. Halaman Dashboard Customer
     */
    public function dashboard() {
        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');

        $counts = $orderModel->getCountsByCustomer($user['id']);
        $recentOrders = $orderModel->getOrdersByCustomer($user['id'], 'active');

        $data = [
            'title' => 'Dashboard Customer - TKJ Smart Service',
            'user' => $user,
            'counts' => $counts,
            'recentOrders' => array_slice($recentOrders, 0, 5),
            'active_nav' => 'dashboard'
        ];

        $this->view('customer/dashboard', $data);
    }

    /**
     * 2. Katalog Layanan Jasa & Routing Detail
     */
    public function jasa($action = null, $id = null) {
        if ($action === 'detail' && $id) {
            return $this->jasaDetail($id);
        }

        $serviceModel = $this->model('ServiceModel');
        $services = $serviceModel->getAllServices();

        $data = [
            'title' => 'Katalog Layanan Jasa - TKJ Smart Service',
            'services' => $services,
            'active_nav' => 'jasa'
        ];

        $this->view('customer/jasa', $data);
    }

    /**
     * 3. Detail Layanan Jasa
     */
    public function jasaDetail($id = null) {
        if (!$id) {
            header('Location: ' . BASE_URL . '/customer/jasa');
            exit;
        }

        $serviceModel = $this->model('ServiceModel');
        $services = $serviceModel->getAllServices();
        
        $selectedService = null;
        foreach ($services as $svc) {
            if ($svc['id'] == $id) {
                $selectedService = $svc;
                break;
            }
        }

        if (!$selectedService) {
            $selectedService = $services[0] ?? null;
        }

        $data = [
            'title' => 'Detail Layanan: ' . ($selectedService['title'] ?? 'Layanan TKJ'),
            'service' => $selectedService,
            'active_nav' => 'jasa'
        ];

        $this->view('customer/jasa_detail', $data);
    }

    /**
     * 4. Daftar Pesanan Aktif Saya & Sub-Routing
     */
    public function pesanan($action = null, $id = null) {
        if ($action === 'create' || $action === 'tambah') {
            return $this->pesananCreate();
        }
        if ($action === 'detail' && $id) {
            return $this->pesananDetail($id);
        }

        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');
        $activeOrders = $orderModel->getOrdersByCustomer($user['id'], 'active');

        $data = [
            'title' => 'Pesanan Saya - TKJ Smart Service',
            'orders' => $activeOrders,
            'active_nav' => 'pesanan'
        ];

        $this->view('customer/pesanan', $data);
    }

    /**
     * 5. Membuat Pesanan Baru
     */
    public function pesananCreate() {
        $user = AuthHelper::user();
        $serviceModel = $this->model('ServiceModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $jasaId = (int)($_POST['jasa_id'] ?? 0);
            $noTelepon = trim($_POST['no_telepon'] ?? '');
            $alamat = trim($_POST['alamat'] ?? '');
            $deskripsiMasalah = trim($_POST['deskripsi_masalah'] ?? '');
            $tanggalPengerjaan = trim($_POST['tanggal_pengerjaan'] ?? '');

            // Validasi Input Wajib
            if (empty($jasaId) || empty($noTelepon) || empty($alamat) || empty($deskripsiMasalah) || empty($tanggalPengerjaan)) {
                AuthHelper::setFlash('order_error', 'Semua kolom yang diberi tanda bintang (*) wajib diisi.', 'danger');
                header('Location: ' . BASE_URL . '/customer/pesanan/create');
                exit;
            }

            // Estimasi harga dari katalog jasa
            $services = $serviceModel->getAllServices();
            $hargaAwal = 150000;
            foreach ($services as $s) {
                if ($s['id'] == $jasaId) {
                    // Extract angka harga
                    preg_match_all('/\d+/', str_replace('.', '', $s['price']), $matches);
                    if (!empty($matches[0][0])) {
                        $hargaAwal = (float)$matches[0][0];
                    }
                    break;
                }
            }

            SecurityHelper::verifyCsrfToken();

            // Handle Foto Masalah jika ada
            $fotoPath = null;
            if (isset($_FILES['foto_masalah']) && $_FILES['foto_masalah']['error'] === UPLOAD_ERR_OK) {
                $uploaded = SecurityHelper::uploadFile($_FILES['foto_masalah'], 'pesanan', ['jpg', 'jpeg', 'png', 'webp']);
                if ($uploaded) {
                    $fotoPath = $uploaded;
                }
            }


            $orderData = [
                'customer_id' => $user['id'],
                'jasa_id' => $jasaId,
                'no_telepon' => $noTelepon,
                'alamat' => $alamat,
                'deskripsi_masalah' => $deskripsiMasalah . ($fotoPath ? " [Lampiran Foto: $fotoPath]" : ""),
                'tanggal_pengerjaan' => $tanggalPengerjaan,
                'total_harga' => $hargaAwal
            ];

            $orderModel = $this->model('OrderModel');
            if ($orderModel->createOrder($orderData)) {
                // Kirim Notifikasi WhatsApp Otomatis ke Customer
                if (!empty($noTelepon)) {
                    try {
                        $jasaTitle = 'Layanan Jasa IT';
                        foreach ($services as $s) {
                            if ($s['id'] == $jasaId) {
                                $jasaTitle = $s['title'];
                                break;
                            }
                        }
                        $msgWa = "🛒 *PESANAN BERHASIL DIBUAT - TKJ SMART SERVICE*\n\n"
                            . "Halo *" . ($user['nama'] ?? 'Customer') . "*,\n"
                            . "Pesanan jasa IT *" . $jasaTitle . "* Anda telah berhasil diterima oleh sistem.\n\n"
                            . "⏳ *Status:* Menunggu Verifikasi Administrator\n"
                            . "📍 *Alamat:* " . $alamat . "\n"
                            . "📅 *Jadwal:* " . date('d M Y', strtotime($tanggalPengerjaan)) . "\n"
                            . "💰 *Estimasi Biaya:* Rp " . number_format($hargaAwal, 0, ',', '.') . "\n\n"
                            . "Pesanan Anda sedang dalam antrean verifikasi resmi oleh Administrator unit bisnis TEFA TKJ. Anda akan menerima notifikasi WhatsApp otomatis saat status pesanan disetujui.\n\n"
                            . "Terima kasih!";
                        FonnteHelper::sendWhatsApp($noTelepon, $msgWa);
                    } catch (\Throwable $e) {}
                }

                AuthHelper::setFlash('order_success', 'Pesanan berhasil dibuat! Notifikasi pesanan telah dikirim ke WhatsApp Anda dan saat ini sedang menunggu verifikasi oleh Administrator.', 'success');
                header('Location: ' . BASE_URL . '/customer/pesanan');
                exit;
            } else {
                AuthHelper::setFlash('order_error', 'Gagal membuat pesanan. Silakan coba lagi.', 'danger');
                header('Location: ' . BASE_URL . '/customer/pesanan/create');
                exit;
            }
        }

        $selectedJasaId = isset($_GET['jasa_id']) ? (int)$_GET['jasa_id'] : 0;
        $services = $serviceModel->getAllServices();

        $data = [
            'title' => 'Form Pemesanan Jasa - TKJ Smart Service',
            'user' => $user,
            'services' => $services,
            'selectedJasaId' => $selectedJasaId,
            'active_nav' => 'pesanan'
        ];

        $this->view('customer/pesanan_create', $data);
    }

    /**
     * 6. Detail Pesanan Saya
     */
    public function pesananDetail($id = null) {
        if (!$id) {
            header('Location: ' . BASE_URL . '/customer/pesanan');
            exit;
        }

        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');
        $pembayaranModel = $this->model('PembayaranModel');

        $order = $orderModel->getOrderById($id, $user['id']);

        if (!$order) {
            AuthHelper::setFlash('order_error', 'Pesanan tidak ditemukan.', 'danger');
            header('Location: ' . BASE_URL . '/customer/pesanan');
            exit;
        }

        $payment = $pembayaranModel->getPaymentByOrderId($id);

        $data = [
            'title' => 'Detail Pesanan #' . $order['kode_pesanan'],
            'order' => $order,
            'payment' => $payment,
            'active_nav' => 'pesanan'
        ];

        $this->view('customer/pesanan_detail', $data);
    }

    /**
     * Submit Pembayaran oleh Customer (Cash / Transfer Bank + Upload Bukti)
     */
    public function bayar($orderId = null) {
        if (!$orderId) {
            header('Location: ' . BASE_URL . '/customer/pesanan');
            exit;
        }

        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');
        $pembayaranModel = $this->model('PembayaranModel');

        $order = $orderModel->getOrderById($orderId, $user['id']);
        if (!$order) {
            AuthHelper::setFlash('order_error', 'Pesanan tidak ditemukan.', 'danger');
            header('Location: ' . BASE_URL . '/customer/pesanan');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();

            $metode = trim($_POST['metode_pembayaran'] ?? 'transfer');
            $jumlah = (float)($order['total_harga'] ?? 150000);

            $buktiPath = null;
            if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] === UPLOAD_ERR_OK) {
                $uploaded = SecurityHelper::uploadFile($_FILES['bukti_pembayaran'], 'pembayaran', ['jpg', 'jpeg', 'png', 'webp', 'pdf']);
                if ($uploaded) {
                    $buktiPath = $uploaded;
                } else {
                    AuthHelper::setFlash('order_error', 'Gagal mengunggah file bukti. Harap gunakan format gambar (JPG/PNG/WEBP) atau PDF yang valid & aman (Maks 5MB).', 'danger');
                    header('Location: ' . BASE_URL . '/customer/pesanan/detail/' . $orderId);
                    exit;
                }
            }

            if ($metode === 'transfer' && empty($buktiPath)) {
                $existingPay = $pembayaranModel->getPaymentByOrderId($orderId);
                if (empty($existingPay['bukti_pembayaran'])) {
                    AuthHelper::setFlash('order_error', 'Harap unggah bukti pembayaran transfer yang valid.', 'danger');
                    header('Location: ' . BASE_URL . '/customer/pesanan/detail/' . $orderId);
                    exit;
                }
            }


            if ($pembayaranModel->createOrUpdatePayment($orderId, $metode, $jumlah, $buktiPath)) {
                AuthHelper::setFlash('order_success', 'Konfirmasi pembayaran berhasil dikirim! Menunggu verifikasi oleh Operator TEFA.', 'success');
            } else {
                AuthHelper::setFlash('order_error', 'Gagal memproses pembayaran. Coba lagi.', 'danger');
            }
        }

        header('Location: ' . BASE_URL . '/customer/pesanan/detail/' . $orderId);
        exit;
    }


    /**
     * 7. Riwayat Pesanan (Selesai / Dibatalkan)
     */
    public function riwayat() {
        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');
        $historyOrders = $orderModel->getOrdersByCustomer($user['id'], 'history');

        $data = [
            'title' => 'Riwayat Pesanan - TKJ Smart Service',
            'orders' => $historyOrders,
            'active_nav' => 'riwayat'
        ];

        $this->view('customer/riwayat', $data);
    }

    /**
     * 8. Memberikan Rating & Review
     */
    public function review($orderId = null) {
        $user = AuthHelper::user();
        $orderModel = $this->model('OrderModel');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();
            $pesananId = (int)($_POST['pesanan_id'] ?? 0);
            $rating = (int)($_POST['rating'] ?? 5);
            $komentar = trim($_POST['komentar'] ?? '');

            if (!$pesananId || $rating < 1 || $rating > 5) {
                AuthHelper::setFlash('review_error', 'Rating harus diisi antara 1 sampai 5 bintang.', 'danger');
                header('Location: ' . BASE_URL . '/customer/review/' . $pesananId);
                exit;
            }

            $order = $orderModel->getOrderById($pesananId, $user['id']);
            if (!$order) {
                AuthHelper::setFlash('review_error', 'Pesanan tidak ditemukan.', 'danger');
                header('Location: ' . BASE_URL . '/customer/riwayat');
                exit;
            }

            $reviewModel = $this->model('ReviewModel');
            $reviewData = [
                'pesanan_id' => $pesananId,
                'customer_id' => $user['id'],
                'teknisi_id' => $order['teknisi_id'] ?? 1,
                'rating' => $rating,
                'komentar' => $komentar
            ];

            if ($reviewModel->createReview($reviewData)) {
                AuthHelper::setFlash('review_success', 'Terima kasih! Rating dan ulasan Anda sangat berarti bagi pengembangan teknisi siswa TKJ.', 'success');
                header('Location: ' . BASE_URL . '/customer/riwayat');
                exit;
            }
        }

        $order = $orderModel->getOrderById($orderId, $user['id']);
        if (!$order) {
            header('Location: ' . BASE_URL . '/customer/riwayat');
            exit;
        }

        $data = [
            'title' => 'Beri Ulasan Pesanan #' . $order['kode_pesanan'],
            'order' => $order,
            'active_nav' => 'riwayat'
        ];

        $this->view('customer/review', $data);
    }

    /**
     * 9. Mengubah Profil Customer
     */
    public function profile() {
        $user = AuthHelper::user();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            SecurityHelper::verifyCsrfToken();
            $nama = trim($_POST['nama'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $newPassword = trim($_POST['new_password'] ?? '');
            $confirmPassword = trim($_POST['confirm_password'] ?? '');

            if (empty($nama) || empty($email)) {
                AuthHelper::setFlash('profile_error', 'Nama dan email wajib diisi.', 'danger');
                header('Location: ' . BASE_URL . '/customer/profile');
                exit;
            }

            $passwordToUpdate = null;
            if (!empty($newPassword)) {
                if ($newPassword !== $confirmPassword) {
                    AuthHelper::setFlash('profile_error', 'Konfirmasi password baru tidak cocok.', 'danger');
                    header('Location: ' . BASE_URL . '/customer/profile');
                    exit;
                }
                if (strlen($newPassword) < 6) {
                    AuthHelper::setFlash('profile_error', 'Password baru minimal 6 karakter.', 'danger');
                    header('Location: ' . BASE_URL . '/customer/profile');
                    exit;
                }
                $passwordToUpdate = $newPassword;
            }

            $userModel = $this->model('UserModel');
            if ($userModel->updateProfile($user['id'], $nama, $email, $passwordToUpdate)) {
                // Update Session
                $_SESSION['user_name'] = $nama;
                $_SESSION['user_email'] = $email;

                AuthHelper::setFlash('profile_success', 'Profil Anda telah berhasil diperbarui.', 'success');
                header('Location: ' . BASE_URL . '/customer/profile');
                exit;
            } else {
                AuthHelper::setFlash('profile_error', 'Gagal memperbarui profil. Coba lagi.', 'danger');
                header('Location: ' . BASE_URL . '/customer/profile');
                exit;
            }
        }

        $data = [
            'title' => 'Pengaturan Profil - TKJ Smart Service',
            'user' => AuthHelper::user(),
            'active_nav' => 'profile'
        ];

        $this->view('customer/profile', $data);
    }

    /**
     * 10. Fitur AI Assistant Customer (/customer/ai-assistant)
     */
    public function ai_assistant() {
        $user = AuthHelper::user();

        $data = [
            'title' => 'AI Assistant - TKJ Smart Service',
            'user' => $user,
            'active_nav' => 'ai-assistant'
        ];

        $this->view('customer/ai_assistant', $data);
    }
}


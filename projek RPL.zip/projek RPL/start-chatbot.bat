@echo off
title Server Chatbot Node.js - TKJ Smart Service
color 0b
echo =======================================================
echo   TKJ SMART SERVICE - AI CHATBOT NODE.JS SERVER
echo   Powered by xAI Grok & Google Gemini
echo =======================================================
echo.

:: Cek apakah 'node' tersedia di PATH sistem
where node >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [OK] Menjalankan server menggunakan Node.js sistem...
    node server.js
    goto end
)

:: Jika tidak ada di PATH, coba cek direktori instalasi standar
if exist "C:\Program Files\nodejs\node.exe" (
    echo [OK] Menjalankan server menggunakan Node.js di Program Files...
    "C:\Program Files\nodejs\node.exe" server.js
    goto end
)

:: Jika tidak ada di PATH, coba jalankan via agy-node
if exist "C:\Users\L E N O V O\AppData\Roaming\Antigravity\bin\agy-node.cmd" (
    echo [OK] Menjalankan server menggunakan Antigravity Node runtime...
    call "C:\Users\L E N O V O\AppData\Roaming\Antigravity\bin\agy-node.cmd" server.js
    goto end
)

echo [ERROR] Runtime Node.js tidak ditemukan di PATH sistem.
echo Silakan pastikan Node.js sudah terinstal dari https://nodejs.org/
pause

:end
pause

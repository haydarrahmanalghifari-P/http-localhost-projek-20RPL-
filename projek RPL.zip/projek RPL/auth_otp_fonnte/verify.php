<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/FonnteService.php';

$userId  = $_SESSION['pending_user_id'] ?? null;
$nomorWa = $_SESSION['pending_nomor_wa'] ?? null;
$nama    = $_SESSION['pending_nama'] ?? 'Pengguna';

if (!$userId || !$nomorWa) {
    header('Location: login.php');
    exit;
}

$flashError   = $_SESSION['flash_error'] ?? null;
$flashSuccess = $_SESSION['flash_success'] ?? null;
$flashWarning = $_SESSION['flash_warning'] ?? null;

unset($_SESSION['flash_error'], $_SESSION['flash_success'], $_SESSION['flash_warning']);

// Hitung sisa cooldown resend (60 detik)
$lastSent = $_SESSION['last_otp_sent'] ?? time();
$secondsPassed = time() - $lastSent;
$cooldownRemaining = max(0, OTP_RESEND_COOLDOWN - $secondsPassed);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi OTP WhatsApp - Fonnte API</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #09131f 50%, #030712 100%);
            min-height: 100vh;
            color: #f8fafc;
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(34, 197, 94, 0.25);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
        }
        .otp-box {
            width: 48px;
            height: 56px;
            font-size: 1.5rem;
            text-align: center;
            font-weight: 700;
            background: rgba(15, 23, 42, 0.8) !important;
            border: 1px solid rgba(148, 163, 184, 0.3) !important;
            color: #22c55e !important;
            border-radius: 12px;
            transition: all 0.2s ease;
        }
        .otp-box:focus {
            border-color: #22c55e !important;
            box-shadow: 0 0 0 0.25rem rgba(34, 197, 94, 0.25) !important;
            transform: scale(1.05);
        }
        .btn-wa {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: #fff;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-wa:hover {
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(34, 197, 94, 0.35);
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center py-5">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="glass-card p-4 p-md-5 rounded-4 text-center">
                
                <!-- Icon Header -->
                <div class="mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle bg-success bg-opacity-25" style="width: 70px; height: 70px;">
                    <i class="fa-solid fa-lock text-success fs-1"></i>
                </div>

                <h3 class="fw-bold mb-1">Verifikasi OTP</h3>
                <p class="text-secondary small mb-3">
                    Masukkan 6 digit kode OTP yang telah dikirim via WhatsApp ke:
                </p>

                <!-- Target Phone Badge -->
                <div class="d-inline-flex align-items-center gap-2 bg-dark bg-opacity-50 border border-success border-opacity-50 px-3 py-1 rounded-pill mb-4 shadow-sm">
                    <i class="fa-brands fa-whatsapp text-success"></i>
                    <span class="text-white fw-bold font-monospace"><?= htmlspecialchars(FonnteService::maskPhone($nomorWa)) ?></span>
                </div>

                <!-- Flash Alerts -->
                <?php if ($flashError): ?>
                    <div class="alert alert-danger alert-dismissible fade show text-start small mb-3" role="alert">
                        <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashError) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($flashWarning): ?>
                    <div class="alert alert-warning alert-dismissible fade show text-start small mb-3" role="alert">
                        <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= htmlspecialchars($flashWarning) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($flashSuccess): ?>
                    <div class="alert alert-success alert-dismissible fade show text-start small mb-3" role="alert">
                        <i class="fa-solid fa-circle-check me-1"></i> <?= htmlspecialchars($flashSuccess) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <!-- Form Verifikasi OTP -->
                <form action="auth.php" method="POST" id="form-verify">
                    <input type="hidden" name="action" value="verify_otp">
                    <input type="hidden" name="kode_otp" id="kode_otp_hidden">

                    <!-- 6 Digit Input Boxes -->
                    <div class="d-flex justify-content-center gap-2 mb-3">
                        <?php for ($i = 1; $i <= 6; $i++): ?>
                            <input type="text" 
                                   class="form-control otp-box" 
                                   name="otp_<?= $i ?>" 
                                   id="otp_<?= $i ?>" 
                                   maxlength="1" 
                                   inputmode="numeric" 
                                   pattern="[0-9]" 
                                   required 
                                   autocomplete="one-time-code">
                        <?php endfor; ?>
                    </div>


                    <!-- Timer Masa Berlaku OTP -->
                    <div class="d-flex align-items-center justify-content-center gap-2 text-secondary small mb-4">
                        <i class="fa-regular fa-clock text-success"></i>
                        <span>Kode berlaku dalam:</span>
                        <span id="countdown-timer" class="fw-bold text-success font-monospace fs-6">05:00</span>
                    </div>

                    <button type="submit" class="btn btn-wa w-100 rounded-pill fw-bold py-2 shadow mb-3">
                        <i class="fa-solid fa-shield-check me-2"></i> Verifikasi & Masuk Dashboard
                    </button>
                </form>

                <!-- Resend & Back Section -->
                <div class="pt-3 border-top border-secondary border-opacity-25">
                    <div class="d-flex flex-column flex-sm-row align-items-center justify-content-between gap-2 small">
                        <span class="text-secondary">Tidak menerima kode?</span>
                        <div id="resend-wrapper">
                            <form action="auth.php" method="POST" id="form-resend" class="d-inline">
                                <input type="hidden" name="action" value="resend_otp">
                                <button type="submit" id="btn-resend" class="btn btn-link text-success text-decoration-none p-0 fw-semibold d-none">
                                    <i class="fa-solid fa-rotate-right me-1"></i> Kirim Ulang OTP
                                </button>
                            </form>
                            <span id="resend-countdown" class="text-secondary">
                                Kirim ulang (<span id="resend-seconds" class="text-success font-monospace fw-bold"><?= $cooldownRemaining ?></span>s)
                            </span>
                        </div>
                    </div>

                    <div class="mt-3 text-center">
                        <a href="login.php" class="text-secondary small text-decoration-none">
                            <i class="fa-solid fa-arrow-left me-1"></i> Ubah Nomor WhatsApp
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const otpBoxes = Array.from(document.querySelectorAll('.otp-box'));
    const hiddenOtp = document.getElementById('kode_otp_hidden');
    const formVerify = document.getElementById('form-verify');

    if (otpBoxes[0]) otpBoxes[0].focus();

    function updateHidden() {
        const code = otpBoxes.map(b => b.value).join('');
        if (hiddenOtp) hiddenOtp.value = code;
        return code;
    }

    otpBoxes.forEach((box, idx) => {
        box.addEventListener('input', function() {
            this.value = this.value.replace(/\D/g, '');
            if (this.value.length >= 1) {
                this.value = this.value.charAt(0);
                if (idx < otpBoxes.length - 1) {
                    otpBoxes[idx + 1].focus();
                }
            }
            const currentCode = updateHidden();
            if (currentCode.length === 6) {
                setTimeout(() => formVerify.submit(), 150);
            }
        });

        box.addEventListener('keydown', function(e) {
            if (e.key === 'Backspace' && !this.value && idx > 0) {
                otpBoxes[idx - 1].focus();
                otpBoxes[idx - 1].value = '';
                updateHidden();
            } else if (e.key === 'ArrowLeft' && idx > 0) {
                otpBoxes[idx - 1].focus();
            } else if (e.key === 'ArrowRight' && idx < otpBoxes.length - 1) {
                otpBoxes[idx + 1].focus();
            }
        });

        // Paste 6 digit sekaligus
        box.addEventListener('paste', function(e) {
            e.preventDefault();
            const paste = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
            if (paste.length > 0) {
                paste.split('').forEach((d, i) => {
                    if (otpBoxes[i]) otpBoxes[i].value = d;
                });
                updateHidden();
                const target = Math.min(paste.length, otpBoxes.length - 1);
                otpBoxes[target].focus();
                if (paste.length === 6) {
                    setTimeout(() => formVerify.submit(), 150);
                }
            }
        });
    });


    // Timer Kedaluwarsa 5 Menit
    let expireSeconds = 300;
    const timerElem = document.getElementById('countdown-timer');
    const expireTimer = setInterval(function() {
        expireSeconds--;
        if (expireSeconds <= 0) {
            clearInterval(expireTimer);
            if (timerElem) {
                timerElem.textContent = '00:00 (Kedaluwarsa)';
                timerElem.className = 'fw-bold text-danger font-monospace fs-6';
            }
        } else {
            const m = Math.floor(expireSeconds / 60);
            const s = expireSeconds % 60;
            if (timerElem) {
                timerElem.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
            }
        }
    }, 1000);

    // Cooldown Kirim Ulang (60 detik)
    let resendRemaining = <?= (int)$cooldownRemaining ?>;
    const resendCountdown = document.getElementById('resend-countdown');
    const resendSecondsElem = document.getElementById('resend-seconds');
    const btnResend = document.getElementById('btn-resend');

    function checkResend() {
        if (resendRemaining <= 0) {
            if (resendCountdown) resendCountdown.classList.add('d-none');
            if (btnResend) btnResend.classList.remove('d-none');
        } else {
            if (resendSecondsElem) resendSecondsElem.textContent = resendRemaining;
            resendRemaining--;
            setTimeout(checkResend, 1000);
        }
    }
    checkResend();
});
</script>
</body>
</html>

<?php
require_once __DIR__ . '/config.php';

// Hapus semua data sesi
$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

session_destroy();

// Redirect ke halaman login
session_start();
$_SESSION['flash_success'] = 'Anda telah berhasil keluar (logout).';
header('Location: login.php');
exit;

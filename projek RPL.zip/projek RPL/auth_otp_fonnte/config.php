<?php
/**
 * Konfigurasi Database & API Key Fonnte WhatsApp Gateway
 */

// Mulai session jika belum aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Konfigurasi Database MySQL
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'auth_fonnte_db');

// Konfigurasi API Fonnte
define('FONNTE_TOKEN', 'XK9gTunu6eUntnSoWSWM');
define('FONNTE_API_URL', 'https://api.fonnte.com/send');
define('OTP_EXPIRATION_MINUTES', 5);
define('OTP_RESEND_COOLDOWN', 60);

// Inisialisasi Koneksi Database Menggunakan PDO (Prepared Statements)
try {
    $dsn = "mysql:host=" . DB_HOST . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    // Pastikan database dan tabel otomatis dibuat jika belum ada
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `" . DB_NAME . "`");

    // Buat tabel users jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `nama` VARCHAR(150) NOT NULL,
        `nomor_wa` VARCHAR(25) NOT NULL UNIQUE,
        `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Buat tabel otp_codes jika belum ada
    $pdo->exec("CREATE TABLE IF NOT EXISTS `otp_codes` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `nomor_wa` VARCHAR(25) NOT NULL,
        `kode_otp` VARCHAR(6) NOT NULL,
        `expired_at` DATETIME NOT NULL,
        `is_used` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_otp` (`nomor_wa`, `kode_otp`, `is_used`, `expired_at`),
        CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

} catch (PDOException $e) {
    die("Koneksi Database Gagal: " . $e->getMessage());
}

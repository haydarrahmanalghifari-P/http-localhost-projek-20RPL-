<?php
/**
 * FonnteService - Service Pengiriman WhatsApp via API Fonnte
 */

class FonnteService {

    /**
     * Normalisasi nomor telepon ke format standar 628xxx
     * Mengubah awalan '08', '+628', '8' menjadi '628xxx'
     *
     * @param string $phone
     * @return string
     */
    public static function normalizePhone($phone) {
        $clean = preg_replace('/\D/', '', (string)$phone);

        if (strpos($clean, '0') === 0) {
            $clean = '62' . substr($clean, 1);
        } elseif (strpos($clean, '8') === 0) {
            $clean = '62' . $clean;
        }

        return $clean;
    }

    /**
     * Sensor nomor telepon untuk tampilan UI (contoh: 62812****7890)
     *
     * @param string $phone
     * @return string
     */
    public static function maskPhone($phone) {
        $clean = self::normalizePhone($phone);
        $len = strlen($clean);
        if ($len <= 6) return $clean;

        $prefix = substr($clean, 0, 5);
        $suffix = substr($clean, -3);
        $masked = str_repeat('*', max(4, $len - 8));
        return $prefix . $masked . $suffix;
    }

    /**
     * Kirim pesan WhatsApp melalui HTTP POST cURL ke endpoint Fonnte
     *
     * @param string $target Nomor WA format 628xxx
     * @param string $message Pesan teks
     * @return array [success => bool, message => string, raw => array]
     */
    public static function sendWhatsApp($target, $message) {
        $targetWa = self::normalizePhone($target);

        if (empty($targetWa) || strlen($targetWa) < 10) {
            return [
                'success' => false,
                'message' => 'Nomor WhatsApp tidak valid (minimal 10 digit).'
            ];
        }

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, 'https://api.fonnte.com/send');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, [
            'target'      => $targetWa,
            'message'     => $message,
            'countryCode' => '62'
        ]);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'Authorization: ' . (defined('FONNTE_TOKEN') ? FONNTE_TOKEN : 'XK9gTunu6eUntnSoWSWM')
        ]);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);

        $responseRaw = curl_exec($curl);
        $curlError   = curl_error($curl);
        $httpCode    = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($curlError) {
            return [
                'success' => false,
                'message' => 'cURL Error: ' . $curlError
            ];
        }

        $json = json_decode($responseRaw, true);

        // Jika respons bukan JSON valid
        if ($json === null) {
            return [
                'success' => false,
                'message' => 'Respons server tidak valid (HTTP ' . $httpCode . '): ' . $responseRaw
            ];
        }

        // Cek apakah Fonnte mengembalikan status true
        if (isset($json['status']) && $json['status'] === true) {
            return [
                'success' => true,
                'message' => $json['detail'] ?? 'Pesan WhatsApp berhasil dikirim.',
                'raw'     => $json
            ];
        }

        // Jika Fonnte mengembalikan status false, ambil alasan kegagalan
        $reason = $json['reason'] ?? ($json['detail'] ?? ($json['message'] ?? 'Status false dari Fonnte'));
        return [
            'success' => false,
            'message' => $reason,
            'raw'     => $json
        ];
    }

    /**
     * Kirim Kode OTP Verifikasi sesuai format yang diminta
     * Message: "Kode OTP Anda adalah: [KODE_OTP]"
     *
     * @param string $phone Nomor WA
     * @param string $otpCode 6 digit OTP
     * @return array
     */
    public static function sendOtp($phone, $otpCode) {
        $message = "Kode OTP Anda adalah: " . $otpCode;
        return self::sendWhatsApp($phone, $message);
    }
}

<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/FonnteService.php';

// Cek apakah user telah login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$userId  = $_SESSION['user_id'] ?? null;
$nama    = $_SESSION['nama'] ?? 'Pengguna';
$nomorWa = $_SESSION['nomor_wa'] ?? '-';

// Ambil info lengkap dari database
$stmt = $pdo->prepare("SELECT id, nama, nomor_wa, is_verified, created_at FROM users WHERE id = :id");
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch();

$flashSuccess = $_SESSION['flash_success'] ?? null;
unset($_SESSION['flash_success']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pengguna - Fonnte OTP Auth</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #09131f 50%, #030712 100%);
            min-height: 100vh;
            color: #f8fafc;
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(34, 197, 94, 0.25);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
        }
        .badge-verified {
            background: rgba(34, 197, 94, 0.15);
            border: 1px solid rgba(34, 197, 94, 0.4);
            color: #4ade80;
        }
    </style>
</head>
<body class="py-5">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-7 col-md-9">

            <!-- Flash Alert -->
            <?php if ($flashSuccess): ?>
                <div class="alert alert-success alert-dismissible fade show small mb-4" role="alert">
                    <i class="fa-solid fa-circle-check me-2"></i> <?= htmlspecialchars($flashSuccess) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="glass-card p-4 p-md-5 rounded-4 shadow">
                
                <div class="d-flex align-items-center justify-content-between pb-4 border-bottom border-secondary border-opacity-25 mb-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="rounded-circle bg-success bg-opacity-25 d-flex align-items-center justify-content-center" style="width: 56px; height: 56px;">
                            <i class="fa-solid fa-user-shield text-success fs-3"></i>
                        </div>
                        <div>
                            <h4 class="fw-bold mb-0 text-white"><?= htmlspecialchars($user['nama'] ?? $nama) ?></h4>
                            <span class="badge badge-verified py-1 px-2 rounded-pill small mt-1">
                                <i class="fa-solid fa-circle-check me-1"></i> Terverifikasi WhatsApp
                            </span>
                        </div>
                    </div>
                    <a href="logout.php" class="btn btn-outline-danger btn-sm rounded-pill px-3" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
                        <i class="fa-solid fa-arrow-right-from-bracket me-1"></i> Keluar
                    </a>
                </div>

                <h5 class="fw-bold text-white mb-3">Informasi Akun Anda</h5>

                <div class="row g-3 mb-4">
                    <div class="col-sm-6">
                        <div class="p-3 rounded-3 bg-dark bg-opacity-60 border border-secondary border-opacity-25">
                            <span class="text-secondary small d-block mb-1">Nomor WhatsApp</span>
                            <span class="fw-bold text-white font-monospace">
                                <i class="fa-brands fa-whatsapp text-success me-1"></i> <?= htmlspecialchars($user['nomor_wa'] ?? $nomorWa) ?>
                            </span>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="p-3 rounded-3 bg-dark bg-opacity-60 border border-secondary border-opacity-25">
                            <span class="text-secondary small d-block mb-1">Status Verifikasi</span>
                            <span class="fw-bold text-success">
                                <i class="fa-solid fa-shield-check me-1"></i> Aktif (OTP Terverifikasi)
                            </span>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="p-3 rounded-3 bg-dark bg-opacity-60 border border-secondary border-opacity-25">
                            <span class="text-secondary small d-block mb-1">ID Pengguna</span>
                            <span class="fw-bold text-white font-monospace">#<?= htmlspecialchars($user['id'] ?? $userId) ?></span>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="p-3 rounded-3 bg-dark bg-opacity-60 border border-secondary border-opacity-25">
                            <span class="text-secondary small d-block mb-1">Terdaftar Sejak</span>
                            <span class="fw-bold text-white"><?= htmlspecialchars(date('d M Y, H:i', strtotime($user['created_at'] ?? 'now'))) ?> WIB</span>
                        </div>
                    </div>
                </div>

                <div class="p-3 rounded-3 bg-success bg-opacity-10 border border-success border-opacity-25 d-flex align-items-center gap-3">
                    <i class="fa-solid fa-circle-info text-success fs-4 flex-shrink-0"></i>
                    <div class="small text-secondary">
                        Sistem autentikasi berhasil memverifikasi kepemilikan nomor WhatsApp menggunakan <b>Fonnte API Gateway</b> dengan keamanan <b>Prepared Statements</b>.
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

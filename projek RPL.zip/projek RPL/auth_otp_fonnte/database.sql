-- ========================================================
-- Database & Schema Autentikasi OTP WhatsApp via Fonnte API
-- ========================================================

CREATE DATABASE IF NOT EXISTS `auth_fonnte_db` 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `auth_fonnte_db`;

-- 1. Tabel users
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(150) NOT NULL,
    `nomor_wa` VARCHAR(25) NOT NULL UNIQUE,
    `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Tabel otp_codes
CREATE TABLE IF NOT EXISTS `otp_codes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `nomor_wa` VARCHAR(25) NOT NULL,
    `kode_otp` VARCHAR(6) NOT NULL,
    `expired_at` DATETIME NOT NULL,
    `is_used` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_otp_validation` (`nomor_wa`, `kode_otp`, `is_used`, `expired_at`),
    CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

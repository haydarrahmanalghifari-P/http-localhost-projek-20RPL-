<?php
/**
 * auth.php - Controller Pemrosesan Autentikasi OTP WhatsApp (Fonnte API)
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/FonnteService.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// ============================================================================
// 1. ACTION: REQUEST OTP (Registrasi User Baru atau Login User Lama)
// ============================================================================
if ($action === 'request_otp') {
    $namaRaw    = trim($_POST['nama'] ?? '');
    $nomorWaRaw = trim($_POST['nomor_wa'] ?? '');

    if (empty($nomorWaRaw)) {
        $_SESSION['flash_error'] = 'Nomor WhatsApp wajib diisi.';
        header('Location: login.php');
        exit;
    }

    // Normalisasi nomor WA ke format standar 628xxx
    $nomorWa = FonnteService::normalizePhone($nomorWaRaw);

    if (strlen($nomorWa) < 10 || strlen($nomorWa) > 16) {
        $_SESSION['flash_error'] = 'Format nomor WhatsApp tidak valid. Masukkan minimal 10 digit nomor yang benar.';
        header('Location: login.php');
        exit;
    }

    try {
        // Cek apakah user sudah terdaftar di database
        $stmt = $pdo->prepare("SELECT id, nama, nomor_wa FROM users WHERE nomor_wa = :nomor_wa LIMIT 1");
        $stmt->execute([':nomor_wa' => $nomorWa]);
        $user = $stmt->fetch();

        if ($user) {
            $userId = (int)$user['id'];
            $nama = !empty($namaRaw) ? $namaRaw : $user['nama'];

            if (!empty($namaRaw) && $namaRaw !== $user['nama']) {
                $updateNameStmt = $pdo->prepare("UPDATE users SET nama = :nama WHERE id = :id");
                $updateNameStmt->execute([':nama' => $nama, ':id' => $userId]);
            }
        } else {
            // User baru, buat akun
            $nama = !empty($namaRaw) ? $namaRaw : 'Pengguna ' . substr($nomorWa, -4);
            $insertUserStmt = $pdo->prepare("INSERT INTO users (nama, nomor_wa, is_verified) VALUES (:nama, :nomor_wa, 0)");
            $insertUserStmt->execute([
                ':nama'     => $nama,
                ':nomor_wa' => $nomorWa
            ]);
            $userId = (int)$pdo->lastInsertId();
        }

        // Generate 6 digit angka acak aman
        $otpCode = (string)random_int(100000, 999999);

        // Kirim HTTP POST request langsung ke API Fonnte terlebih dahulu
        $fonnteRes = FonnteService::sendOtp($nomorWa, $otpCode);

        // JIKA PENGIRIMAN FONNTE GAGAL / STATUS FALSE:
        // Tampilkan pesan error asli dari respons JSON Fonnte di layar login dan JANGAN masuk ke halaman verify!
        if (!$fonnteRes['success']) {
            $_SESSION['flash_error'] = 'Gagal mengirim OTP ke WhatsApp: ' . htmlspecialchars($fonnteRes['message']);
            header('Location: login.php');
            exit;
        }

        // JIKA PENGIRIMAN FONNTE BERHASIL (status: true):
        // Nonaktifkan OTP lama yang belum terpakai untuk user ini
        $invalidateStmt = $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE user_id = :user_id AND is_used = 0");
        $invalidateStmt->execute([':user_id' => $userId]);

        // Simpan kode OTP baru ke tabel otp_codes (berlaku 5 menit)
        $expiredAt = date('Y-m-d H:i:s', time() + (OTP_EXPIRATION_MINUTES * 60));
        $insertOtpStmt = $pdo->prepare("
            INSERT INTO otp_codes (user_id, nomor_wa, kode_otp, expired_at, is_used) 
            VALUES (:user_id, :nomor_wa, :kode_otp, :expired_at, 0)
        ");
        $insertOtpStmt->execute([
            ':user_id'    => $userId,
            ':nomor_wa'   => $nomorWa,
            ':kode_otp'   => $otpCode,
            ':expired_at' => $expiredAt
        ]);

        // Simpan state pending ke session (tanpa kode uji di layar)
        $_SESSION['pending_user_id']  = $userId;
        $_SESSION['pending_nomor_wa'] = $nomorWa;
        $_SESSION['pending_nama']     = $nama;
        $_SESSION['last_otp_sent']    = time();

        $_SESSION['flash_success'] = 'Kode OTP 6-digit berhasil dikirimkan ke WhatsApp Anda (' . FonnteService::maskPhone($nomorWa) . ').';
        header('Location: verify.php');
        exit;

    } catch (PDOException $e) {
        $_SESSION['flash_error'] = 'Terjadi kesalahan sistem database: ' . $e->getMessage();
        header('Location: login.php');
        exit;
    }
}

// ============================================================================
// 2. ACTION: VERIFY OTP (Validasi Kode OTP & Pembuatan Sesi Login)
// ============================================================================
if ($action === 'verify_otp') {
    $userId  = $_SESSION['pending_user_id'] ?? null;
    $nomorWa = $_SESSION['pending_nomor_wa'] ?? null;

    if (!$userId || !$nomorWa) {
        $_SESSION['flash_error'] = 'Sesi verifikasi telah kedaluwarsa. Silakan masukkan nomor WhatsApp kembali.';
        header('Location: login.php');
        exit;
    }

    $otpInput = trim($_POST['kode_otp'] ?? '');
    if (empty($otpInput)) {
        $boxCode = '';
        for ($i = 1; $i <= 6; $i++) {
            $boxCode .= trim($_POST['otp_' . $i] ?? '');
        }
        $otpInput = $boxCode;
    }

    if (empty($otpInput) || strlen($otpInput) !== 6) {
        $_SESSION['flash_error'] = 'Harap masukkan 6 digit kode OTP secara lengkap.';
        header('Location: verify.php');
        exit;
    }

    try {
        $now = date('Y-m-d H:i:s');
        $stmt = $pdo->prepare("
            SELECT id, user_id, nomor_wa, kode_otp, expired_at, is_used 
            FROM otp_codes 
            WHERE user_id = :user_id 
              AND nomor_wa = :nomor_wa 
              AND kode_otp = :kode_otp 
              AND is_used = 0 
              AND expired_at >= :now 
            ORDER BY id DESC 
            LIMIT 1
        ");
        $stmt->execute([
            ':user_id'  => $userId,
            ':nomor_wa' => $nomorWa,
            ':kode_otp' => $otpInput,
            ':now'      => $now
        ]);
        $otpRecord = $stmt->fetch();

        if ($otpRecord) {
            // Tandai OTP telah digunakan
            $updateOtpStmt = $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = :id");
            $updateOtpStmt->execute([':id' => $otpRecord['id']]);

            // Tandai user telah terverifikasi
            $updateUserStmt = $pdo->prepare("UPDATE users SET is_verified = 1 WHERE id = :user_id");
            $updateUserStmt->execute([':user_id' => $userId]);

            // Ambil data user lengkap
            $userQuery = $pdo->prepare("SELECT id, nama, nomor_wa, created_at FROM users WHERE id = :id");
            $userQuery->execute([':id' => $userId]);
            $userData = $userQuery->fetch();

            // Buat sesi login
            $_SESSION['user_id']   = (int)$userData['id'];
            $_SESSION['nama']      = $userData['nama'];
            $_SESSION['nomor_wa']  = $userData['nomor_wa'];
            $_SESSION['logged_in'] = true;

            // Bersihkan sesi sementara
            unset($_SESSION['pending_user_id'], $_SESSION['pending_nomor_wa'], $_SESSION['pending_nama']);

            $_SESSION['flash_success'] = 'Selamat datang, ' . htmlspecialchars($userData['nama']) . '! Verifikasi OTP WhatsApp berhasil.';
            header('Location: dashboard.php');
            exit;
        } else {
            $_SESSION['flash_error'] = 'Kode OTP yang Anda masukkan salah atau telah kedaluwarsa.';
            header('Location: verify.php');
            exit;
        }

    } catch (PDOException $e) {
        $_SESSION['flash_error'] = 'Terjadi kesalahan basis data: ' . $e->getMessage();
        header('Location: verify.php');
        exit;
    }
}

// ============================================================================
// 3. ACTION: RESEND OTP (Kirim Ulang OTP dengan Cooldown 60 Detik)
// ============================================================================
if ($action === 'resend_otp') {
    $userId  = $_SESSION['pending_user_id'] ?? null;
    $nomorWa = $_SESSION['pending_nomor_wa'] ?? null;

    if (!$userId || !$nomorWa) {
        $_SESSION['flash_error'] = 'Sesi tidak ditemukan. Silakan masukkan nomor kembali.';
        header('Location: login.php');
        exit;
    }

    $lastSent = $_SESSION['last_otp_sent'] ?? 0;
    $timePassed = time() - $lastSent;
    $cooldown = OTP_RESEND_COOLDOWN;

    if ($timePassed < $cooldown) {
        $remaining = $cooldown - $timePassed;
        $_SESSION['flash_warning'] = "Harap tunggu {$remaining} detik sebelum meminta kode OTP baru.";
        header('Location: verify.php');
        exit;
    }

    try {
        $newOtp = (string)random_int(100000, 999999);

        // Kirim via Fonnte
        $fonnteRes = FonnteService::sendOtp($nomorWa, $newOtp);

        if (!$fonnteRes['success']) {
            $_SESSION['flash_error'] = 'Gagal mengirim ulang OTP ke WhatsApp: ' . htmlspecialchars($fonnteRes['message']);
            header('Location: verify.php');
            exit;
        }

        // Nonaktifkan kode OTP lama
        $invalidateStmt = $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE user_id = :user_id AND is_used = 0");
        $invalidateStmt->execute([':user_id' => $userId]);

        // Simpan ke database
        $expiredAt = date('Y-m-d H:i:s', time() + (OTP_EXPIRATION_MINUTES * 60));
        $insertStmt = $pdo->prepare("
            INSERT INTO otp_codes (user_id, nomor_wa, kode_otp, expired_at, is_used) 
            VALUES (:user_id, :nomor_wa, :kode_otp, :expired_at, 0)
        ");
        $insertStmt->execute([
            ':user_id'    => $userId,
            ':nomor_wa'   => $nomorWa,
            ':kode_otp'   => $newOtp,
            ':expired_at' => $expiredAt
        ]);

        $_SESSION['last_otp_sent'] = time();
        $_SESSION['flash_success'] = 'Kode OTP baru telah berhasil dikirimkan ke WhatsApp Anda.';
        header('Location: verify.php');
        exit;

    } catch (PDOException $e) {
        $_SESSION['flash_error'] = 'Gagal mengirim ulang OTP: ' . $e->getMessage();
        header('Location: verify.php');
        exit;
    }
}

header('Location: login.php');
exit;

<?php
require_once __DIR__ . '/config.php';

// Jika sudah login, redirect langsung ke dashboard
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}

$flashError   = $_SESSION['flash_error'] ?? null;
$flashSuccess = $_SESSION['flash_success'] ?? null;
$flashWarning = $_SESSION['flash_warning'] ?? null;

unset($_SESSION['flash_error'], $_SESSION['flash_success'], $_SESSION['flash_warning']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Registrasi OTP WhatsApp - Fonnte API</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #09131f 50%, #030712 100%);
            min-height: 100vh;
            color: #f8fafc;
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(34, 197, 94, 0.25);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
        }
        .form-control {
            background: rgba(15, 23, 42, 0.8) !important;
            border: 1px solid rgba(148, 163, 184, 0.3) !important;
            color: #fff !important;
        }
        .form-control:focus {
            border-color: #22c55e !important;
            box-shadow: 0 0 0 0.25rem rgba(34, 197, 94, 0.25) !important;
        }
        .btn-wa {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: #fff;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-wa:hover {
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(34, 197, 94, 0.35);
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center py-5">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="glass-card p-4 p-md-5 rounded-4 text-center">
                
                <!-- Icon Header -->
                <div class="mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle bg-success bg-opacity-25" style="width: 70px; height: 70px;">
                    <i class="fa-brands fa-whatsapp text-success fs-1"></i>
                </div>

                <h3 class="fw-bold mb-1">Masuk & Registrasi</h3>
                <p class="text-secondary small mb-4">Verifikasi instan tanpa password via WhatsApp OTP</p>

                <!-- Flash Alerts -->
                <?php if ($flashError): ?>
                    <div class="alert alert-danger alert-dismissible fade show text-start small mb-3" role="alert">
                        <i class="fa-solid fa-circle-exclamation me-1"></i> <?= htmlspecialchars($flashError) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($flashWarning): ?>
                    <div class="alert alert-warning alert-dismissible fade show text-start small mb-3" role="alert">
                        <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= htmlspecialchars($flashWarning) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($flashSuccess): ?>
                    <div class="alert alert-success alert-dismissible fade show text-start small mb-3" role="alert">
                        <i class="fa-solid fa-circle-check me-1"></i> <?= htmlspecialchars($flashSuccess) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <!-- Form Request OTP -->
                <form action="auth.php" method="POST" class="text-start">
                    <input type="hidden" name="action" value="request_otp">

                    <div class="mb-3">
                        <label for="nama" class="form-label small fw-semibold text-light">Nama Lengkap</label>
                        <div class="input-group">
                            <span class="input-group-text bg-dark border-secondary border-opacity-50 text-success">
                                <i class="fa-solid fa-user"></i>
                            </span>
                            <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama Anda (contoh: Budi Santoso)" autocomplete="name">
                        </div>
                        <div class="form-text text-secondary" style="font-size: 0.78rem;">
                            Untuk pendaftaran user baru atau pembaruan profil nama.
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="nomor_wa" class="form-label small fw-semibold text-light">
                            Nomor WhatsApp <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-dark border-secondary border-opacity-50 text-success">
                                <i class="fa-brands fa-whatsapp fs-5"></i>
                            </span>
                            <input type="tel" class="form-control font-monospace" id="nomor_wa" name="nomor_wa" placeholder="Contoh: 081234567890 / 62812xxx" required autocomplete="tel">
                        </div>
                        <div class="form-text text-secondary" style="font-size: 0.78rem;">
                            Otomatis dinormalisasi ke format internasional (<code>628xxx</code>).
                        </div>
                    </div>

                    <div class="p-3 mb-4 rounded-3 bg-dark bg-opacity-50 border border-success border-opacity-20 d-flex align-items-center gap-2">
                        <i class="fa-solid fa-shield-halved text-success fs-5 flex-shrink-0"></i>
                        <span class="small text-secondary">
                            Kode keamanan OTP 6-digit akan dikirim langsung ke WhatsApp Anda melalui <b>Fonnte API</b>.
                        </span>
                    </div>

                    <button type="submit" class="btn btn-wa w-100 rounded-pill fw-bold py-2 shadow">
                        <i class="fa-solid fa-paper-plane me-2"></i> Kirim Kode OTP WhatsApp
                    </button>
                </form>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

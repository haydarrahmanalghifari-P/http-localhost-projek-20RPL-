<?php
/**
 * TKJ Smart Service - Front Controller Entry Point
 * Aplikasi Layanan Jasa IT Unit Bisnis Siswa TKJ
 */

// Definisi Konstanta Directori Root
define('APPROOT', __DIR__);

// Load Konfigurasi
require_once __DIR__ . '/config/config.php';

// Load Security & Helper Engine
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/app/helpers/SecurityHelper.php';
require_once __DIR__ . '/app/helpers/AuthHelper.php';
if (file_exists(__DIR__ . '/app/helpers/MailHelper.php')) require_once __DIR__ . '/app/helpers/MailHelper.php';
if (file_exists(__DIR__ . '/app/helpers/TelegramHelper.php')) require_once __DIR__ . '/app/helpers/TelegramHelper.php';
if (file_exists(__DIR__ . '/app/helpers/FonnteHelper.php')) require_once __DIR__ . '/app/helpers/FonnteHelper.php';

// Start Secure Session
SecurityHelper::initSession();

// Load Core Engine & Base Classes
require_once __DIR__ . '/core/App.php';
require_once __DIR__ . '/app/controllers/Controller.php';

// Autoload Model Classes dynamically
spl_autoload_register(function ($className) {
    $modelFile = __DIR__ . '/app/models/' . $className . '.php';
    if (file_exists($modelFile)) {
        require_once $modelFile;
    }
});

// Inisialisasi Routing App
$app = new App();

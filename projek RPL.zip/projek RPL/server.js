/**
 * ==============================================================================
 * TKJ Smart Service - AI Chatbot Server (Node.js)
 * Powered by Google Gemini AI API + Live MySQL Database Context
 * ==============================================================================
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

function getDynamicAiConfig() {
    try {
        const configPath = path.join(__dirname, 'config', 'ai_keys.json');
        if (fs.existsSync(configPath)) {
            return JSON.parse(fs.readFileSync(configPath, 'utf8'));
        }
    } catch (e) {}
    return null;
}

// Konfigurasi Server & API Key
const PORT = process.env.PORT || 5000;
const GROK_API_KEY = process.env.GROK_API_KEY || '';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || process.env.AI_API_KEY || 'AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw';
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || 'sk-70e0eb2e9efe49fa967af6da72b5cda9';
const DEFAULT_AI_PROVIDER = process.env.AI_PROVIDER || 'gemini';
const PHP_BACKEND_URL = process.env.PHP_BACKEND_URL || 'http://localhost/projek%20RPL';

// Urutan model AI yang digunakan dengan auto-fallback cepat jika sibuk/503
const GROK_MODELS = [
    'grok-2-latest',
    'grok-2',
    'grok-beta',
    'grok-2-1212'
];

const GEMINI_MODELS = [
    'gemini-3.5-flash-lite',
    'gemini-flash-latest',
    'gemini-3.8-flash'
];

// In-memory cache untuk data layanan & FAQ umum (TTL: 30 detik)
const dbCache = {
    services: [],
    faqs: [],
    app: {},
    user_stats: null,
    lastFetched: 0
};

/**
 * Mengambil konteks data aktual dari database MySQL via endpoint PHP
 * Menjamin AI selalu membaca data riil: katalog jasa, FAQ, dan status pesanan customer
 */
async function fetchDatabaseContext(customerId = null, orderCode = null) {
    try {
        const queryParams = new URLSearchParams();
        if (customerId) queryParams.set('customerId', customerId);
        if (orderCode) queryParams.set('orderCode', orderCode);

        const url = `${PHP_BACKEND_URL}/ai/context?${queryParams.toString()}`;
        const res = await fetch(url, { signal: AbortSignal.timeout(4000) });

        if (res.ok) {
            const data = await res.json();
            if (data.status === 'success') {
                if (Array.isArray(data.services) && data.services.length > 0) {
                    dbCache.services = data.services;
                    dbCache.faqs = data.faqs || [];
                    dbCache.app = data.app || {};
                    dbCache.user_stats = data.user_stats || null;
                    dbCache.lastFetched = Date.now();
                }
                return data;
            }
        }
    } catch (err) {
        console.warn(`[DB Context] Menggunakan fallback/cache database: ${err.message}`);
    }

    // Jika PHP endpoint sementara tidak merespons, gunakan data cache
    return {
        status: 'cached',
        services: dbCache.services,
        faqs: dbCache.faqs,
        app: dbCache.app,
        user_stats: dbCache.user_stats || { total: 13, customer: 8, teknisi: 2, operator: 1, kepala_sekolah: 1, admin: 1 },
        customer_orders: [],
        order_stats: null,
        searched_order: null
    };
}

/**
 * Membangun System Prompt secara dinamis berbasis data AKTUAL DATABASE
 */
function buildSystemPrompt(dbContext, userObj, searchedOrder) {
    const userName = (userObj.nama || 'Pengunjung').trim();
    const isLoggedIn = Boolean(userObj.isLoggedIn || (userObj.id && userObj.role && userObj.role !== 'guest') || (userName !== 'Pengunjung' && userName !== 'Kak'));
    const userRole = userObj.role || 'customer';
    const userEmail = userObj.email || '';

    // 1. Data Layanan Jasa dari Database
    let servicesText = '';
    if (dbContext.services && dbContext.services.length) {
        servicesText = dbContext.services.map((s, idx) => {
            const price = s.price || `Mulai Rp ${Number(s.harga_mulai || 0).toLocaleString('id-ID')}`;
            const estimasi = s.estimasi_pengerjaan ? ` (Estimasi: ${s.estimasi_pengerjaan})` : '';
            return `${idx + 1}. **${s.title || s.nama_jasa}** - ${price}${estimasi}: ${s.description || s.deskripsi || ''}`;
        }).join('\n');
    } else {
        servicesText = `1. Instalasi CCTV (Mulai Rp 250.000)
2. Instalasi Jaringan LAN (Mulai Rp 150.000)
3. Instalasi Wi-Fi Hotspot (Mulai Rp 100.000)
4. Service Komputer/Laptop (Mulai Rp 75.000)
5. Maintenance Perangkat IT (Mulai Rp 300.000)
6. Jasa IT Lainnya / Rakit PC (Mulai Rp 100.000)`;
    }

    // 2. Data FAQ dari Database
    let faqsText = '';
    if (dbContext.faqs && dbContext.faqs.length) {
        faqsText = dbContext.faqs.map(f => `* Pertanyaan: ${f.pertanyaan}\n  Jawaban Resmi: ${f.jawaban}`).join('\n\n');
    }

    // 3. Data Pesanan Aktif Customer dari Database
    let customerOrdersText = 'Pengguna belum memiliki pesanan aktif di database.';
    if (dbContext.customer_orders && dbContext.customer_orders.length) {
        customerOrdersText = dbContext.customer_orders.map(o => {
            const teknisiInfo = o.nama_teknisi ? `Teknisi Siswa: ${o.nama_teknisi}` : 'Teknisi: Belum ditugaskan (Menunggu konfirmasi operator)';
            const total = o.total_harga ? `Rp ${Number(o.total_harga).toLocaleString('id-ID')}` : '-';
            return `- Kode: **#${o.kode_pesanan}** | Layanan: ${o.nama_jasa} | Status: **${o.status.toUpperCase()}** | Total: ${total} | ${teknisiInfo} | Tanggal Pesan: ${o.tanggal_pemesanan}`;
        }).join('\n');
    }

    // 4. Detail Pesanan Spesifik jika pengguna mencari kode ORD-xxx
    let searchedOrderText = '';
    if (searchedOrder) {
        const payStatus = searchedOrder.status_pembayaran ? searchedOrder.status_pembayaran.toUpperCase() : 'BELUM LUNAS';
        const tek = searchedOrder.nama_teknisi || 'Belum ditugaskan oleh operator';
        const catatan = searchedOrder.catatan_teknisi ? `\n- Catatan Teknisi: ${searchedOrder.catatan_teknisi}` : '';
        const hasil = searchedOrder.hasil_pekerjaan ? `\n- Hasil Pekerjaan: ${searchedOrder.hasil_pekerjaan}` : '';
        searchedOrderText = `
[DETAIL PESANAN YANG DITANYAKAN (#${searchedOrder.kode_pesanan}) DARI DATABASE]:
- Nama Customer: ${searchedOrder.nama_customer || '-'}
- Layanan Jasa: ${searchedOrder.nama_jasa}
- Status Pesanan: ${searchedOrder.status.toUpperCase()}
- Teknisi Penanggung Jawab: ${tek}
- Status Pembayaran: ${payStatus} (Metode: ${searchedOrder.metode_pembayaran || '-'})
- Alamat: ${searchedOrder.alamat || '-'}
- Kendala/Deskripsi: ${searchedOrder.deskripsi_masalah || '-'}${catatan}${hasil}
`;
    }

    // 5. Data Statistik Pengguna dari Database
    const uStats = dbContext.user_stats || { total: 13, customer: 8, teknisi: 2, operator: 1, kepala_sekolah: 1, admin: 1 };
    const userStatsText = `Total Pengguna Terdaftar: ${uStats.total} orang
- Customer (Pelanggan): ${uStats.customer} orang
- Teknisi Siswa: ${uStats.teknisi} orang
- Operator Sistem: ${uStats.operator} orang
- Kepala Sekolah: ${uStats.kepala_sekolah} orang
- Administrator: ${uStats.admin} orang`;

    const userContext = isLoggedIn
        ? `Status Pengguna: SUDAH LOGIN sebagai "${userName}" (Role: ${userRole.toUpperCase()}${userEmail ? ', Email: ' + userEmail : ''}).`
        : `Status Pengguna: BELUM LOGIN (Pengunjung / Tamu).`;

    return `
Anda adalah "TKJ Smart Bot", asisten virtual kecerdasan buatan (AI) resmi dari "TKJ Smart Service".
TKJ Smart Service adalah Unit Bisnis & Teaching Factory (TEFA) Jurusan Teknik Komputer dan Jaringan (TKJ) SMK.
Di sini siswa berbakat mengerjakan layanan IT profesional dengan supervisi ketat dari guru & teknisi ahli.

[DATA AKTUAL DATABASE TKJ SMART SERVICE]
1. STATISTIK PENGGUNA TERDAFTAR DI DATABASE:
${userStatsText}

2. DAFTAR LAYANAN JASA RESMI DARI DATABASE:
${servicesText}

3. PANDUAN FAQ RESMI DARI DATABASE:
${faqsText}

4. INFORMASI CUSTOMER SAAT INI:
${userContext}
Pesanan Aktif Customer di Database:
${customerOrdersText}
${searchedOrderText}

ATURAN MUTLAK:
1. Anda WAJIB menjawab berdasarkan data layanan jasa, harga, FAQ, pesanan, dan STATISTIK PENGGUNA yang tercatat di database di atas. Sebutkan harga, estimasi waktu, dan statistik data pengguna secara akurat sesuai database.
2. Jika pengguna (terutama Administrator, Operator, atau pengguna umum) menanyakan berapa jumlah pengguna, berapa banyak user, berapa customer, atau berapa teknisi di TKJ Smart Service, jawablah secara lengkap, ramah, dan transparan sesuai data [STATISTIK PENGGUNA TERDAFTAR DI DATABASE] di atas!
3. Anda HANYA melayani konsultasi seputar unit bisnis TKJ Smart Service: Service PC/Laptop, Instalasi CCTV, Instalasi Jaringan LAN/Wi-Fi, Perakitan Komputer, Maintenance IT, pengecekan pesanan jasa, dan informasi operasional unit bisnis.
4. DILARANG KERAS membahas seputar percodingan / pemrograman (PHP, Python, JS, HTML, CSS, SQL, script koding, algoritma, dll) dan DILARANG membahas topik umum lain di luar layanan TKJ.
5. Jika pengguna bertanya tentang coding/pemrograman atau hal di luar layanan TKJ, JAWAB LANGSUNG:
   "Mohon maaf, kami hanya melayani konsultasi seputar layanan IT Hardware, Jaringan, dan CCTV TKJ Smart Service. Kami tidak melayani percodingan atau topik di luar layanan kami."
6. JAWAB SINGKAT, PADAT, DAN LANGSUNG KE INTI (Maksimal 1-3 kalimat ringkas). Jangan bertele-tele atau menambahkan info panjang yang tidak diminta.
7. Pemesanan seluruh layanan jasa dilakukan secara resmi melalui website (menu Pesan Jasa) atau langsung ke Admin sistem kami, BUKAN melalui WhatsApp. Seluruh verifikasi pesanan diproses dan disetujui langsung oleh Administrator. DILARANG mengarahkan pelanggan untuk memesan jasa lewat WhatsApp.
`;
}

/**
 * Panggil xAI Grok API dengan auto-fallback model
 */
async function callGrokApi(userMessage, userParam = 'Pengunjung', dbContext = {}, searchedOrder = null, customKey = null) {
    let lastError = null;
    const apiKey = (customKey || GROK_API_KEY || '').trim();
    const userObj = typeof userParam === 'object' ? userParam : { nama: userParam };
    const userName = (userObj.nama || 'Pengunjung').trim();

    if (!apiKey) {
        return {
            success: false,
            error: 'No Grok API key provided',
            model: 'smart-database-fallback',
            provider: 'database',
            text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
        };
    }

    const systemPrompt = buildSystemPrompt(dbContext, userObj, searchedOrder);

    for (const model of GROK_MODELS) {
        try {
            const url = 'https://api.x.ai/v1/chat/completions';
            const payload = {
                model: model,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                ],
                temperature: 0.7,
                max_tokens: 1024
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify(payload),
                signal: AbortSignal.timeout(12000)
            });

            if (response.ok) {
                const data = await response.json();
                const replyText = data.choices?.[0]?.message?.content;
                if (replyText) {
                    if (containsCodeLeak(replyText)) {
                        return {
                            success: true,
                            text: getCodingRefusalReply(),
                            model: `Grok (${model}) [Guard]`,
                            provider: 'grok'
                        };
                    }
                    return {
                        success: true,
                        text: replyText.trim(),
                        model: `Grok (${model})`,
                        provider: 'grok'
                    };
                }
            } else {
                const errData = await response.json().catch(() => ({}));
                const errMsg = errData.error?.message || errData.error || `HTTP ${response.status}`;
                console.warn(`[Grok API] Model ${model} returned error:`, errMsg);
                lastError = typeof errMsg === 'object' ? JSON.stringify(errMsg) : errMsg;
            }
        } catch (err) {
            console.error(`[Grok API] Network error on model ${model}:`, err.message);
            lastError = err.message;
        }
    }

    // Jika seluruh model eksternal gagal dihubungi, gunakan Fallback cerdas berbasis data database
    return {
        success: false,
        error: lastError,
        model: 'Grok Fallback (Smart DB)',
        provider: 'grok',
        text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
    };
}

/**
 * Panggil DeepSeek API dengan auto-fallback
 */
async function callDeepSeekApi(userMessage, userParam = 'Pengunjung', dbContext = {}, searchedOrder = null, customKey = null) {
    let lastError = null;
    const dyn = getDynamicAiConfig();
    const apiKey = (customKey || DEEPSEEK_API_KEY || (dyn && (dyn.primary_provider === 'deepseek' ? dyn.primary_key : (dyn.backup_provider_1 === 'deepseek' ? dyn.backup_key_1 : ''))) || '').trim();
    const userObj = typeof userParam === 'object' ? userParam : { nama: userParam };
    const userName = (userObj.nama || 'Pengunjung').trim();

    if (!apiKey) {
        return {
            success: false,
            error: 'No DeepSeek API key provided',
            model: 'deepseek-fallback',
            provider: 'deepseek',
            text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
        };
    }

    const systemPrompt = buildSystemPrompt(dbContext, userObj, searchedOrder);
    const models = ['deepseek-chat', 'deepseek-coder'];

    for (const model of models) {
        try {
            const url = 'https://api.deepseek.com/chat/completions';
            const payload = {
                model: model,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                ],
                temperature: 0.7,
                max_tokens: 1024
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify(payload),
                signal: AbortSignal.timeout(12000)
            });

            if (response.ok) {
                const data = await response.json();
                const replyText = data.choices?.[0]?.message?.content;
                if (replyText) {
                    return {
                        success: true,
                        text: replyText.trim(),
                        model: `DeepSeek (${model})`,
                        provider: 'deepseek'
                    };
                }
            } else {
                const errData = await response.text();
                lastError = `HTTP ${response.status}: ${errData}`;
            }
        } catch (err) {
            lastError = err.message;
        }
    }

    return {
        success: false,
        error: lastError,
        model: 'DeepSeek Fallback (Smart DB)',
        provider: 'deepseek',
        text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
    };
}

/**
 * Panggil Groq Cloud API (Llama 3 / Mixtral) dengan auto-fallback
 */
async function callGroqApi(userMessage, userParam = 'Pengunjung', dbContext = {}, searchedOrder = null, customKey = null) {
    let lastError = null;
    const apiKey = (customKey || '').trim();
    const userObj = typeof userParam === 'object' ? userParam : { nama: userParam };
    const userName = (userObj.nama || 'Pengunjung').trim();

    if (!apiKey) {
        return {
            success: false,
            error: 'No Groq API key provided',
            model: 'groq-fallback',
            provider: 'groq',
            text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
        };
    }

    const systemPrompt = buildSystemPrompt(dbContext, userObj, searchedOrder);
    const models = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768'];

    for (const model of models) {
        try {
            const url = 'https://api.groq.com/openai/v1/chat/completions';
            const payload = {
                model: model,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                ],
                temperature: 0.7,
                max_tokens: 1024
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify(payload),
                signal: AbortSignal.timeout(12000)
            });

            if (response.ok) {
                const data = await response.json();
                const replyText = data.choices?.[0]?.message?.content;
                if (replyText) {
                    return {
                        success: true,
                        text: replyText.trim(),
                        model: `Groq (${model})`,
                        provider: 'groq'
                    };
                }
            } else {
                const errData = await response.text();
                lastError = `HTTP ${response.status}: ${errData}`;
            }
        } catch (err) {
            lastError = err.message;
        }
    }

    return {
        success: false,
        error: lastError,
        model: 'Groq Fallback (Smart DB)',
        provider: 'groq',
        text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
    };
}

/**
 * Panggil OpenAI API (GPT-4o-mini) dengan auto-fallback
 */
async function callOpenAiApi(userMessage, userParam = 'Pengunjung', dbContext = {}, searchedOrder = null, customKey = null) {
    let lastError = null;
    const apiKey = (customKey || '').trim();
    const userObj = typeof userParam === 'object' ? userParam : { nama: userParam };
    const userName = (userObj.nama || 'Pengunjung').trim();

    if (!apiKey) {
        return {
            success: false,
            error: 'No OpenAI API key provided',
            model: 'openai-fallback',
            provider: 'openai',
            text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
        };
    }

    const systemPrompt = buildSystemPrompt(dbContext, userObj, searchedOrder);
    const models = ['gpt-4o-mini', 'gpt-3.5-turbo'];

    for (const model of models) {
        try {
            const url = 'https://api.openai.com/v1/chat/completions';
            const payload = {
                model: model,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                ],
                temperature: 0.7,
                max_tokens: 1024
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify(payload),
                signal: AbortSignal.timeout(12000)
            });

            if (response.ok) {
                const data = await response.json();
                const replyText = data.choices?.[0]?.message?.content;
                if (replyText) {
                    return {
                        success: true,
                        text: replyText.trim(),
                        model: `OpenAI (${model})`,
                        provider: 'openai'
                    };
                }
            } else {
                const errData = await response.text();
                lastError = `HTTP ${response.status}: ${errData}`;
            }
        } catch (err) {
            lastError = err.message;
        }
    }

    return {
        success: false,
        error: lastError,
        model: 'OpenAI Fallback (Smart DB)',
        provider: 'openai',
        text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
    };
}

/**
 * Panggil Google Gemini API dengan auto-fallback daftar model
 */
async function callGeminiApi(userMessage, userParam = 'Pengunjung', dbContext = {}, searchedOrder = null, customKey = null) {
    let lastError = null;
    const apiKey = (customKey || GEMINI_API_KEY || '').trim();
    const userObj = typeof userParam === 'object' ? userParam : { nama: userParam };
    const userName = (userObj.nama || 'Pengunjung').trim();

    if (!apiKey) {
        return {
            success: false,
            error: 'No Gemini API key provided',
            model: 'smart-database-fallback',
            provider: 'database',
            text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
        };
    }

    const systemPrompt = buildSystemPrompt(dbContext, userObj, searchedOrder);

    for (const model of GEMINI_MODELS) {
        try {
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
            
            const promptPayload = {
                contents: [
                    {
                        role: 'user',
                        parts: [
                            {
                                text: `${systemPrompt}\n\nPertanyaan Pengguna: ${userMessage}`
                            }
                        ]
                    }
                ],
                generationConfig: {
                    temperature: 0.7,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 1024
                }
            };

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(promptPayload),
                signal: AbortSignal.timeout(10000)
            });

            if (response.ok) {
                const data = await response.json();
                const replyText = data.candidates?.[0]?.content?.parts?.[0]?.text;
                if (replyText) {
                    if (containsCodeLeak(replyText)) {
                        return {
                            success: true,
                            text: getCodingRefusalReply(),
                            model: `${model} [Guard]`,
                            provider: 'gemini'
                        };
                    }
                    return {
                        success: true,
                        text: replyText.trim(),
                        model: model,
                        provider: 'gemini'
                    };
                }
            } else {
                const errData = await response.json().catch(() => ({}));
                const errMsg = errData.error?.message || `HTTP ${response.status}`;
                console.warn(`[Gemini API] Model ${model} returned error: ${errMsg}`);
                lastError = errMsg;
            }
        } catch (err) {
            console.error(`[Gemini API] Model ${model} network error:`, err.message);
            lastError = err.message;
        }
    }

    // Jika seluruh model eksternal gagal dihubungi (misal kuota/timeout), gunakan Fallback cerdas berbasis data database
    return {
        success: false,
        error: lastError,
        model: 'Gemini Fallback (Smart DB)',
        provider: 'gemini',
        text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj)
    };
}

/**
 * Cek apakah jawaban model membocorkan kode atau percodingan
 */
function containsCodeLeak(replyText) {
    if (!replyText) return false;
    if (replyText.includes('```')) return true;
    const lower = replyText.toLowerCase();
    if (
        (lower.includes('function ') && lower.includes('{')) ||
        (lower.includes('def ') && lower.includes(':')) ||
        (lower.includes('class ') && lower.includes('{')) ||
        lower.includes('<?php') ||
        lower.includes('console.log(')
    ) {
        return true;
    }
    return false;
}

/**
 * Cek apakah pertanyaan berkaitan dengan percodingan / pemrograman
 */
function isCodingQuery(text) {
    const raw = text || '';
    const q = raw.toLowerCase().trim();
    
    // Pengecualian konteks pendidikan umum
    if (q.includes('program keahlian') || q.includes('program sekolah') || q.includes('program tkj')) {
        return false;
    }

    // Cek pola kode programming umum (regex)
    if (/(<\?php|<\/?[a-z0-9]+>|\bconsole\.log\b|\bfunction\s*\(|\bdef\s+[a-zA-Z0-9_]+\b|\bimport\s+[a-zA-Z0-9_]+\b|\bclass\s+[a-zA-Z0-9_]+\b|\bSELECT\s+.*?\s+FROM\b|\bINSERT\s+INTO\b|\bUPDATE\s+.*?\s+SET\b|\bDELETE\s+FROM\b|\bfor\s*\(.*?;.*?;.*?\)\b|\bwhile\s*\(.*?\)\b|```)/i.test(raw)) {
        return true;
    }

    const codingTerms = [
        'coding', 'koding', 'ngoding', 'ngode', 'perkodingan', 'kodingan', 'codingan', 'coder',
        'pemrograman', 'programmer', 'source code', 'sourcecode', 'bikin kode', 'buatkan kode',
        'buat kode', 'tulis kode', 'tuliskan kode', 'script kode', 'syntax', 'sintaks', 'sintak',
        'debugging', 'debug code', 'debug', 'bahasa pemrograman', 'bikin program', 'buatkan program',
        'buat program', 'bikin script', 'buatkan script', 'buat script', 'algoritma',
        'bikin website', 'buat website', 'buatkan web', 'bikin web', 'buat web', 'bikin aplikasi',
        'buat aplikasi', 'buatkan aplikasi', 'aplikasi web', 'software house', 'bikin software',
        'buat software', 'codingin', 'kodingin',
        'python', 'javascript', 'php', 'html', 'css', 'c++', 'c#', 'golang', 'rust', 'ruby',
        'sql query', 'query sql', 'framework', 'react', 'laravel', 'flutter', 'vue', 'nodejs', 'node.js',
        'codeigniter', 'django', 'flask', 'tailwind', 'bootstrap code', 'jquery',
        'looping', 'perulangan for', 'perulangan while', 'array', 'variable', 'variabel',
        'function code', 'fungsi koding', 'class oop', 'object oriented', 'rest api', 'api endpoint',
        'database query', 'bikin query', 'buat query', 'table database', 'create table', 'crud',
        'github', 'repository', 'git commit', 'git push', 'terminal command', 'npm install',
        'pip install', 'composer require'
    ];

    return codingTerms.some(term => q.includes(term));
}

function isWhoAmIQuery(text) {
    const q = (text || '').toLowerCase().trim();
    return q.includes('siapa saya') || q.includes('nama saya') || q.includes('akun saya') || q.includes('profil saya') || q.includes('identitas saya') || q.includes('data saya') || q === 'siapa aku';
}

function isOrderStatusQuery(text) {
    const q = (text || '').toLowerCase().trim();
    return q.includes('pesanan saya') || q.includes('order saya') || q.includes('status pesanan') || q.includes('cek pesanan') || q.includes('riwayat pesanan') || q.includes('progres pesanan');
}

/**
 * Respon penolakan ramah untuk pertanyaan seputar coding
 */
function getCodingRefusalReply() {
    return "Mohon maaf, kami hanya melayani konsultasi seputar layanan IT Hardware, Jaringan, dan CCTV (TKJ Smart Service). Kami tidak melayani perkodingan atau topik di luar layanan kami.";
}

/**
 * Cek kecocokan pertanyaan pengguna dengan data FAQ database
 */
function isFaqMatch(userMsg, faqQuestion) {
    const u = (userMsg || '').toLowerCase().trim();
    const f = (faqQuestion || '').toLowerCase().trim();
    if (!u || !f) return false;
    if (u.includes(f) || f.includes(u)) return true;

    const pairs = [
        ['cara memesan', 'bagaimana cara memesan'],
        ['cara pesan', 'bagaimana cara memesan'],
        ['apa saja layanan', 'apa saja layanan'],
        ['layanan apa', 'apa saja layanan'],
        ['berapa lama', 'berapa lama pengerjaan'],
        ['lama pengerjaan', 'berapa lama pengerjaan'],
        ['melihat status', 'bagaimana cara melihat status'],
        ['status pesanan', 'bagaimana cara melihat status'],
        ['menghubungi teknisi', 'bagaimana cara menghubungi teknisi'],
        ['kontak teknisi', 'bagaimana cara menghubungi teknisi'],
        ['memberikan review', 'bagaimana cara memberikan review'],
        ['beri review', 'bagaimana cara memberikan review'],
        ['ulasan', 'bagaimana cara memberikan review'],
        ['garansi', 'bergaransi'],
        ['pembayaran', 'metode pembayaran']
    ];

    for (const [p1, p2] of pairs) {
        if (u.includes(p1) && f.includes(p2)) return true;
    }

    const stopwords = ['bagaimana', 'apa', 'saja', 'cara', 'yang', 'di', 'ke', 'dari', 'dan', 'atau', 'ini', 'itu', 'saya', 'anda', 'kamu', 'bisa'];
    const uWords = u.replace(/[^\w\s]/g, '').split(/\s+/).filter(w => !stopwords.includes(w) && w.length > 2);
    const fWords = f.replace(/[^\w\s]/g, '').split(/\s+/).filter(w => !stopwords.includes(w) && w.length > 2);
    const common = uWords.filter(w => fWords.includes(w));
    return common.length >= 2;
}

/**
 * Deteksi apakah pengguna menanyakan jumlah atau statistik pengguna sistem
 */
function isUserStatsQuery(query) {
    const q = (query || '').toLowerCase();
    const triggers = [
        'berapa pengguna', 'jumlah pengguna', 'total pengguna', 'ada berapa pengguna',
        'berapa user', 'jumlah user', 'total user', 'ada berapa user',
        'berapa customer', 'jumlah customer', 'total customer', 'ada berapa customer',
        'berapa pelanggan', 'jumlah pelanggan', 'total pelanggan', 'ada berapa pelanggan',
        'berapa teknisi', 'jumlah teknisi', 'total teknisi', 'ada berapa teknisi',
        'berapa admin', 'jumlah admin', 'ada berapa admin',
        'berapa operator', 'jumlah operator', 'ada berapa operator',
        'berapa akun', 'jumlah akun', 'total akun', 'ada berapa akun',
        'ada berapa orang', 'banyaknya pengguna', 'banyak pengguna', 'banyaknya user'
    ];
    return triggers.some(t => q.includes(t));
}

/**
 * Respon Fallback Cerdas jika terjadi kendala ke Gemini API, membaca langsung dari Data Database
 */
function generateFallbackReply(message, userName, dbContext = {}, searchedOrder = null, userObj = {}) {
    if (isCodingQuery(message)) {
        return getCodingRefusalReply();
    }

    const q = (message || '').toLowerCase();

    // 0. Jika menanyakan statistik pengguna sistem (berapa pengguna, customer, teknisi, dll)
    if (isUserStatsQuery(message)) {
        const stats = dbContext.user_stats || { total: 13, customer: 8, teknisi: 2, operator: 1, kepala_sekolah: 1, admin: 1 };
        return `Halo **${userName}**! 👥 Berdasarkan data aktual dari database **TKJ Smart Service**, saat ini tercatat total **${stats.total} pengguna terdaftar**, dengan rincian peran (role):\n\n` +
            `• 👤 **Customer (Pelanggan):** ${stats.customer} akun\n` +
            `• 🛠️ **Teknisi Siswa (TEFA):** ${stats.teknisi} akun\n` +
            `• ⚙️ **Operator Pengelola:** ${stats.operator} akun\n` +
            `• 🎓 **Kepala Sekolah:** ${stats.kepala_sekolah} akun\n` +
            `• 🛡️ **Administrator (Superuser):** ${stats.admin} akun\n\n` +
            `Data ini disinkronkan secara langsung dan real-time dari tabel pengguna (database MySQL).`;
    }

    // 1. Jika pengguna menanyakan pesanan spesifik (ORD-xxx)
    if (searchedOrder) {
        const payStatus = searchedOrder.status_pembayaran ? searchedOrder.status_pembayaran.toUpperCase() : 'BELUM LUNAS';
        const tek = searchedOrder.nama_teknisi || 'Belum ditugaskan';
        const total = searchedOrder.total_harga ? `Rp ${Number(searchedOrder.total_harga).toLocaleString('id-ID')}` : '-';
        return `Halo **${userName}**! 📦 Informasi pesanan **#${searchedOrder.kode_pesanan}** (${searchedOrder.nama_jasa}) di database:\n- **Status:** ${searchedOrder.status.toUpperCase()}\n- **Teknisi:** ${tek}\n- **Total Biaya:** ${total}\n- **Status Pembayaran:** ${payStatus} (${searchedOrder.metode_pembayaran || 'Belum ditentukan'})\n- **Alamat:** ${searchedOrder.alamat || '-'}`;
    }

    // 2. Jika menanyakan pesanan aktif customer
    if (isOrderStatusQuery(message)) {
        const isLoggedIn = Boolean(userObj.isLoggedIn || (userObj.id && userObj.role && userObj.role !== 'guest'));
        if (!isLoggedIn) {
            return `Halo **${userName}**! Untuk melihat status pesanan Anda, silakan login ke akun customer Anda terlebih dahulu.`;
        }
        if (dbContext.customer_orders && dbContext.customer_orders.length > 0) {
            let reply = `Halo **${userName}**! Berikut pesanan aktif Anda yang tercatat di database:\n`;
            dbContext.customer_orders.forEach(o => {
                const tek = o.nama_teknisi ? `Teknisi: ${o.nama_teknisi}` : 'Teknisi: Sedang proses verifikasi operator';
                reply += `\n- **#${o.kode_pesanan}** (${o.nama_jasa})\n  Status: **${o.status.toUpperCase()}** | Total: Rp ${Number(o.total_harga || 0).toLocaleString('id-ID')}\n  ${tek}\n`;
            });
            reply += `\nAnda dapat memantau perkembangan pekerjaan lebih lanjut di menu **Pesanan Saya**.`;
            return reply;
        } else {
            return `Halo **${userName}**! Saat ini Anda tidak memiliki pesanan yang sedang aktif di database. Anda dapat memesan layanan baru melalui menu **Layanan Jasa**.`;
        }
    }

    // 3. Cek kecocokan dengan data FAQ resmi di database
    const faqs = dbContext.faqs || [];
    if (faqs.length > 0) {
        for (const faq of faqs) {
            const faqQ = (faq.pertanyaan || '').toLowerCase();
            if (faqQ && isFaqMatch(q, faqQ)) {
                return `❓ **${faq.pertanyaan}**\n\n${faq.jawaban}`;
            }
        }
    }

    // 4. Cocokkan dengan katalog jasa di database
    const services = dbContext.services || [];
    if (services.length > 0) {
        for (const s of services) {
            const title = (s.title || s.nama_jasa || '').toLowerCase();
            if (q.includes('cctv') && title.includes('cctv')) {
                return `Halo **${userName}**! 📹 Layanan **${s.title || s.nama_jasa}** di database bertarif **${s.price || 'Mulai Rp 250.000'}** (${s.estimasi_pengerjaan || '1 Hari'}).\n${s.description || s.deskripsi || ''}\nSilakan buat pesanan melalui menu Layanan Jasa di website agar langsung diverifikasi oleh tim Admin & Operator!`;
            }
            if ((q.includes('wifi') || q.includes('wi-fi') || q.includes('hotspot')) && title.includes('wi-fi')) {
                return `Halo **${userName}**! 🌐 Layanan **${s.title || s.nama_jasa}** di database bertarif **${s.price || 'Mulai Rp 100.000'}** (${s.estimasi_pengerjaan || '4-6 Jam'}).\n${s.description || s.deskripsi || ''}\nSiap memperluas jangkauan Wi-Fi tanpa deadzone dan membuat Hotspot voucheran.`;
            }
            if ((q.includes('jaringan') || q.includes('lan') || q.includes('mikrotik')) && title.includes('jaringan')) {
                return `Halo **${userName}**! 🔌 Layanan **${s.title || s.nama_jasa}** di database bertarif **${s.price || 'Mulai Rp 150.000'}** (${s.estimasi_pengerjaan || '1 Hari'}).\n${s.description || s.deskripsi || ''}\nMelayani penarikan kabel LAN CAT5e/CAT6 rapi dan konfigurasi router.`;
            }
            if ((q.includes('laptop') || q.includes('komputer') || q.includes('pc') || q.includes('service') || q.includes('lemot')) && (title.includes('komputer') || title.includes('laptop'))) {
                return `Halo **${userName}**! 💻 Layanan **${s.title || s.nama_jasa}** di database bertarif **${s.price || 'Mulai Rp 75.000'}** (${s.estimasi_pengerjaan || '1-2 Hari'}).\n${s.description || s.deskripsi || ''}\nMeliputi install ulang OS, pembersihan debu & ganti pasta thermal, serta upgrade SSD/RAM.`;
            }
            if (q.includes('maintenance') && title.includes('maintenance')) {
                return `Halo **${userName}**! 🛠️ Layanan **${s.title || s.nama_jasa}** di database bertarif **${s.price || 'Mulai Rp 300.000'}** (${s.estimasi_pengerjaan || 'Berkala 1 Bulan'}).\n${s.description || s.deskripsi || ''}`;
            }
        }
    }

    // Tangani pertanyaan jasa termurah / termahal
    if (q.includes('termurah') || q.includes('paling murah') || q.includes('paling terjangkau')) {
        return `Halo **${userName}**! 💡 Layanan jasa paling terjangkau di TKJ Smart Service adalah:\n1. **Service Komputer/Laptop** mulai dari **Rp 75.000** (pembersihan debu, ganti thermal paste, instal ulang OS).\n2. **Instalasi Wi-Fi** mulai dari **Rp 100.000** (perluasan sinyal / setting hotspot voucher).\nSemua layanan bergaransi resmi!`;
    }

    if (q.includes('termahal') || q.includes('paling mahal') || q.includes('biaya tertinggi')) {
        return `Halo **${userName}**! 💎 Layanan dengan paket pekerjaan paling komprehensif di TKJ Smart Service adalah:\n1. **Maintenance Perangkat IT** mulai dari **Rp 300.000** (pemeliharaan berkala laboratorium sekolah, kantor, atau UMKM).\n2. **Instalasi CCTV** mulai dari **Rp 250.000/titik** (pemasangan kamera IP/Analog 2MP - 4K + online smartphone monitoring).`;
    }

    // Tangani pertanyaan identitas bot "siapa anda / kamu"
    if (q.includes('siapa anda') || q.includes('siapa kamu') || q.includes('tentang anda') || q.includes('tentang kamu')) {
        return `Halo **${userName}**! 👋 Saya adalah **TKJ Smart Bot**, asisten virtual berbasis kecerdasan buatan (AI) resmi dari **TKJ Smart Service** (Unit Bisnis & Teaching Factory Jurusan Teknik Komputer dan Jaringan SMK). Saya terhubung langsung dengan sistem database untuk membantu konsultasi estimasi biaya, alur pemesanan jasa IT, serta pemantauan status pesanan Anda.`;
    }

    if (q.includes('biaya') || q.includes('tarif') || q.includes('harga') || q.includes('layanan') || q.includes('jasa')) {
        let listText = '';
        if (services.length > 0) {
            listText = services.map(s => `- **${s.title || s.nama_jasa}:** ${s.price || 'Mulai Rp ' + Number(s.harga_mulai).toLocaleString('id-ID')}`).join('\n');
        } else {
            listText = `- **Service Komputer/Laptop:** Mulai Rp 75.000\n- **Instalasi Wi-Fi:** Mulai Rp 100.000\n- **Instalasi Jaringan:** Mulai Rp 150.000\n- **Instalasi CCTV:** Mulai Rp 250.000\n- **Maintenance IT:** Mulai Rp 300.000`;
        }
        return `Halo **${userName}**! 💰 Berikut katalog tarif resmi dari database TKJ Smart Service:\n${listText}\nSemua pengerjaan bergaransi resmi dan dikerjakan oleh siswa bertalenta di bawah bimbingan teknisi ahli.`;
    }

    if (q.includes('pesan') || q.includes('order') || q.includes('cara')) {
        return `Halo **${userName}**! 📋 Cara memesan layanan jasa IT di TKJ Smart Service:\n1. Login ke akun Anda di sistem ini.\n2. Buka menu **Layanan Jasa** atau klik **Pesan Layanan**.\n3. Masukkan rincian kendala dan jadwal kunjungan yang diinginkan.\n4. Tim kami akan mengonfirmasi dan menugaskan teknisi siswa untuk pengerjaan!`;
    }

    if (q.includes('lupa password') || q.includes('reset password') || q.includes('ganti password') || q.includes('lupa kata sandi')) {
        return `Halo **${userName}**! 🔑 Jika Anda lupa password akun:\n1. Buka halaman **Login**.\n2. Klik tautan **Lupa Password?** di atas kolom input password (atau akses menu Lupa Password).\n3. Masukkan alamat email akun Anda untuk verifikasi identitas.\n4. Masukkan password baru yang Anda inginkan (minimal 6 karakter) lalu simpan. Anda dapat langsung masuk dengan password baru tersebut!`;
    }

    return `Halo **${userName}**! 👋 Selamat datang di **TKJ Smart Service**. Kami menyediakan layanan service komputer/laptop, instalasi jaringan Wi-Fi/LAN, pemasangan CCTV, serta maintenance IT bergaransi. Data tarif dan status pesanan terhubung langsung dengan sistem kami. Ada yang bisa kami bantu?`;
}

/**
 * Setup Server HTTP dengan Built-in CORS & Router
 */
const server = http.createServer(async (req, res) => {
    // Header CORS standar agar bisa diakses dari frontend PHP/XAMPP
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');

    // Tangani preflight OPTIONS request
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = parsedUrl.pathname;

    // 1. Endpoint Health / Status
    if (req.method === 'GET' && (pathname === '/' || pathname === '/api/status' || pathname === '/health')) {
        res.writeHead(200);
        res.end(JSON.stringify({
            status: 'online',
            service: 'TKJ Smart Service AI Chatbot (Multi-AI Engine)',
            databaseConnected: true,
            databaseSource: PHP_BACKEND_URL + '/ai/context',
            cachedServicesCount: dbCache.services.length,
            runtime: 'Node.js',
            nodeVersion: process.version,
            defaultProvider: DEFAULT_AI_PROVIDER,
            providers: {
                grok: {
                    name: 'Grok AI (xAI)',
                    models: GROK_MODELS,
                    configured: Boolean(GROK_API_KEY)
                },
                gemini: {
                    name: 'Google Gemini',
                    models: GEMINI_MODELS,
                    configured: Boolean(GEMINI_API_KEY)
                },
                database: {
                    name: 'Smart DB Engine (Lokal)',
                    models: ['local-db-intent'],
                    configured: true
                }
            },
            uptime: Math.round(process.uptime()) + ' seconds',
            timestamp: new Date().toISOString()
        }));
        return;
    }

    // 2. Endpoint Chat AI: POST /api/chat
    if (req.method === 'POST' && (pathname === '/api/chat' || pathname === '/chat')) {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });

        req.on('end', async () => {
            try {
                let parsedBody = {};
                if (body) {
                    try {
                        parsedBody = JSON.parse(body);
                    } catch (e) {
                        const params = new URLSearchParams(body);
                        parsedBody = Object.fromEntries(params);
                    }
                }

                const userObj = parsedBody.user || {};
                const userName = (userObj.nama || parsedBody.nama || 'Pengunjung').trim();
                const isLoggedIn = Boolean(userObj.isLoggedIn || (userObj.id && userObj.role && userObj.role !== 'guest') || (userName !== 'Pengunjung' && userName !== 'Kak'));
                const userRole = userObj.role || 'customer';
                const userEmail = userObj.email || '';
                const userMessage = (parsedBody.message || parsedBody.query || parsedBody.prompt || '').trim();

                console.log(`[Chatbot Node.js] Pesan dari ${userName} (Login: ${isLoggedIn}): "${userMessage.substring(0, 50)}..."`);

                // Validasi pesan kosong
                if (!userMessage) {
                    const now = new Date();
                    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                    res.writeHead(200);
                    res.end(JSON.stringify({
                        status: 'success',
                        response: `Halo **${userName}**! Silakan ketikkan pertanyaan atau kebutuhan layanan IT yang ingin Anda konsultasikan.`,
                        model: 'prompt-hint',
                        server: 'Node.js',
                        timestamp: timeStr
                    }));
                    return;
                }

                // Guard: Jika pertanyaan percodingan / di luar topik, tolak secara langsung dan ringkas
                if (isCodingQuery(userMessage)) {
                    console.log(`[Chatbot Node.js] Menolak pertanyaan percodingan dari ${userName}`);
                    const now = new Date();
                    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                    res.writeHead(200);
                    res.end(JSON.stringify({
                        status: 'success',
                        response: getCodingRefusalReply(),
                        model: 'domain-guard',
                        server: 'Node.js',
                        timestamp: timeStr
                    }));
                    return;
                }

                // Deteksi apakah pengguna menyebutkan kode pesanan unik (contoh: ORD-20260901-001)
                const orderCodeMatch = userMessage.match(/\bORD-[A-Za-z0-9-]+\b/i);
                const targetOrderCode = orderCodeMatch ? orderCodeMatch[0] : null;

                // Ambil konteks data riil database MySQL dari PHP Backend
                const dbContext = await fetchDatabaseContext(userObj.id, targetOrderCode);
                const searchedOrder = dbContext.searched_order || null;

                // Intent: Pertanyaan identitas "siapa saya"
                if (isWhoAmIQuery(userMessage)) {
                    const now = new Date();
                    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                    let whoReply = '';
                    if (isLoggedIn) {
                        const emailText = userEmail ? ` (${userEmail})` : '';
                        whoReply = `Anda login sebagai **${userName}** (**${userRole.toUpperCase()}**)${emailText}.`;
                    } else {
                        whoReply = `Anda belum login (Tamu). Silakan login terlebih dahulu.`;
                    }
                    res.writeHead(200);
                    res.end(JSON.stringify({
                        status: 'success',
                        response: whoReply,
                        model: 'identity-intent',
                        server: 'Node.js',
                        timestamp: timeStr
                    }));
                    return;
                }

                // Intent: Pertanyaan statistik pengguna sistem (Berapa jumlah pengguna / user / customer / teknisi / admin)
                if (isUserStatsQuery(userMessage)) {
                    const now = new Date();
                    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                    const stats = dbContext.user_stats || { total: 13, customer: 8, teknisi: 2, operator: 1, kepala_sekolah: 1, admin: 1 };
                    
                    const userStatsReply = `Halo **${userName}**! 👥 Berdasarkan data aktual dari database **TKJ Smart Service**, saat ini tercatat total **${stats.total} pengguna terdaftar**, dengan rincian peran (role):\n\n` +
                        `• 👤 **Customer (Pelanggan):** ${stats.customer} akun\n` +
                        `• 🛠️ **Teknisi Siswa (TEFA):** ${stats.teknisi} akun\n` +
                        `• ⚙️ **Operator Pengelola:** ${stats.operator} akun\n` +
                        `• 🎓 **Kepala Sekolah:** ${stats.kepala_sekolah} akun\n` +
                        `• 🛡️ **Administrator (Superuser):** ${stats.admin} akun\n\n` +
                        `Data ini disinkronkan secara langsung dan real-time dari tabel pengguna (database MySQL).`;

                    res.writeHead(200);
                    res.end(JSON.stringify({
                        status: 'success',
                        response: userStatsReply,
                        model: 'database-stats-intent',
                        server: 'Node.js',
                        timestamp: timeStr
                    }));
                    return;
                }

                // Pilihan AI Provider (gemini, deepseek, grok, database)
                const dyn = getDynamicAiConfig();
                const requestedProvider = (parsedBody.provider || (dyn && dyn.active_provider) || DEFAULT_AI_PROVIDER || 'gemini').toLowerCase();
                const customApiKey = parsedBody.apiKey || (dyn && dyn.primary_key) || null;

                let result;
                if (requestedProvider === 'gemini') {
                    result = await callGeminiApi(userMessage, userObj, dbContext, searchedOrder, customApiKey);
                } else if (requestedProvider === 'deepseek') {
                    result = await callDeepSeekApi(userMessage, userObj, dbContext, searchedOrder, customApiKey);
                } else if (requestedProvider === 'database' || requestedProvider === 'mock') {
                    result = {
                        success: true,
                        text: generateFallbackReply(userMessage, userName, dbContext, searchedOrder, userObj),
                        model: 'Smart DB Engine (Lokal)',
                        provider: 'database'
                    };
                } else {
                    // Fallback Grok AI
                    result = await callGrokApi(userMessage, userObj, dbContext, searchedOrder, customApiKey);
                }

                // Auto-Failover ke Backup Keys jika Primary gagal & auto_failover aktif
                if (result && !result.success) {
                    const dyn = getDynamicAiConfig();
                    if (dyn && dyn.auto_failover) {
                        const backups = [
                            { key: dyn.backup_key_1, provider: dyn.backup_provider_1 || 'gemini' },
                            { key: dyn.backup_key_2, provider: dyn.backup_provider_2 || 'grok' },
                            { key: dyn.backup_key_3, provider: dyn.backup_provider_3 || 'gemini' }
                        ];
                        for (const b of backups) {
                            if (b.key && b.key.trim()) {
                                console.log(`[Auto-Failover] Beralih ke backup key (${b.provider})...`);
                                let backupRes;
                                if (b.provider === 'gemini') {
                                    backupRes = await callGeminiApi(userMessage, userObj, dbContext, searchedOrder, b.key);
                                } else if (b.provider === 'deepseek') {
                                    backupRes = await callDeepSeekApi(userMessage, userObj, dbContext, searchedOrder, b.key);
                                } else if (b.provider === 'groq') {
                                    backupRes = await callGroqApi(userMessage, userObj, dbContext, searchedOrder, b.key);
                                } else if (b.provider === 'openai') {
                                    backupRes = await callOpenAiApi(userMessage, userObj, dbContext, searchedOrder, b.key);
                                } else {
                                    backupRes = await callGrokApi(userMessage, userObj, dbContext, searchedOrder, b.key);
                                }
                                if (backupRes && backupRes.success) {
                                    result = backupRes;
                                    break;
                                }
                            }
                        }
                    }
                }

                const now = new Date();
                const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

                res.writeHead(200);
                res.end(JSON.stringify({
                    status: 'success',
                    response: result.text,
                    model: result.model || 'smart-database-fallback',
                    provider: result.provider || requestedProvider,
                    server: 'Node.js',
                    timestamp: timeStr
                }));
            } catch (err) {
                console.error('[Chatbot Node.js] Internal Error:', err);
                res.writeHead(500);
                res.end(JSON.stringify({
                    status: 'error',
                    message: 'Internal server error: ' + err.message
                }));
            }
        });
        return;
    }

    // 404 Route Fallback
    res.writeHead(404);
    res.end(JSON.stringify({
        status: 'error',
        message: 'Endpoint tidak ditemukan. Gunakan POST /api/chat atau GET /api/status'
    }));
});

// Jalankan Server
server.listen(PORT, async () => {
    console.log(`=======================================================`);
    console.log(`🚀 TKJ Chatbot Node.js Server AKTIF di port: ${PORT}`);
    console.log(`📍 Endpoint Status:   http://localhost:${PORT}/api/status`);
    console.log(`📍 Endpoint Chat:     http://localhost:${PORT}/api/chat (POST)`);
    console.log(`🗄️  Database Sync:    ${PHP_BACKEND_URL}/ai/context`);
    console.log(`⚡ Default AI Engine: ${DEFAULT_AI_PROVIDER.toUpperCase()}`);
    console.log(`🤖 Support Engines:   xAI Grok (${GROK_MODELS[0]}), Google Gemini, Smart DB`);
    console.log(`🔑 Grok API Key:      ${GROK_API_KEY.substring(0, 15)}...`);
    console.log(`=======================================================`);

    // Inisialisasi awal pembacaan database MySQL
    try {
        const initData = await fetchDatabaseContext();
        console.log(`[DB Sync] Berhasil sinkronisasi awal: ${initData.services ? initData.services.length : 0} Layanan & ${initData.faqs ? initData.faqs.length : 0} FAQ dimuat dari database.`);
    } catch (e) {
        console.warn(`[DB Sync] Sinkronisasi awal database ditunda: ${e.message}`);
    }
});

// Tangani Uncaught Exception agar server tetap tegar
process.on('uncaughtException', err => {
    console.error('[Uncaught Exception]', err);
});
process.on('unhandledRejection', (reason, promise) => {
    console.error('[Unhandled Rejection]', reason);
});

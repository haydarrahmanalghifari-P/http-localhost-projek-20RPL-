<?php
/**
 * Database Handler Class - Native PDO MySQL Wrapper
 * Mempermudah interaksi database menggunakan PDO
 */

class Database {
    private $host = DB_HOST;
    private $user = DB_USER;
    private $pass = DB_PASS;
    private $dbname = DB_NAME;

    private $dbh;
    private $stmt;
    private $error;

    public function __construct() {
        $dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbname . ';charset=utf8mb4';
        $options = [
            PDO::ATTR_PERSISTENT => true,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ];

        try {
            $this->dbh = new PDO($dsn, $this->user, $this->pass, $options);
        } catch (PDOException $e) {
            try {
                $dsnNoDb = 'mysql:host=' . $this->host . ';charset=utf8mb4';
                $pdo = new PDO($dsnNoDb, $this->user, $this->pass, $options);
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . $this->dbname . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $this->dbh = new PDO($dsn, $this->user, $this->pass, $options);
            } catch (PDOException $ex) {
                $this->error = $e->getMessage();
                $this->dbh = null;
            }
        }
    }

    public function isConnected() {
        return $this->dbh !== null;
    }

    public function query($sql) {
        if (!$this->isConnected()) return false;
        $this->stmt = $this->dbh->prepare($sql);
        return true;
    }

    public function bind($param, $value, $type = null) {
        if (!$this->stmt) return;
        if (is_null($type)) {
            switch (true) {
                case is_int($value):
                    $type = PDO::PARAM_INT;
                    break;
                case is_bool($value):
                    $type = PDO::PARAM_BOOL;
                    break;
                case is_null($value):
                    $type = PDO::PARAM_NULL;
                    break;
                default:
                    $type = PDO::PARAM_STR;
            }
        }
        $this->stmt->bindValue($param, $value, $type);
    }

    public function execute() {
        if (!$this->stmt) return false;
        try {
            return $this->stmt->execute();
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
            return false;
        }
    }

    public function resultSet() {
        if (!$this->execute()) return [];
        return $this->stmt->fetchAll();
    }

    public function single() {
        if (!$this->execute()) return null;
        return $this->stmt->fetch();
    }

    public function rowCount() {
        return $this->stmt ? $this->stmt->rowCount() : 0;
    }

    public function getError() {
        return $this->error;
    }
}

<?php
/**
 * Konfigurasi Utama Aplikasi TKJ Smart Service
 */

// Pengaturan Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'tkj_smart_service');

// Pengaturan Nama & Informasii Aplikasi
define('APP_NAME', 'TKJ Smart Service');
define('APP_TAGLINE', 'Layanan Jasa IT Unit Bisnis Siswa TKJ');
define('APP_SCHOOL', 'SMK Negeri TKJ');
define('APP_PHONE', '0812-3456-7890');
define('APP_EMAIL', 'info@tkjsmartservice.sch.id');

// Auto Detect BASE_URL untuk XAMPP/Laragon
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 80) == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
$baseUrl = rtrim($protocol . $host . $scriptDir, '/');

define('BASE_URL', $baseUrl);

// Konfigurasi AI Assistant & Chatbot (Google Gemini, DeepSeek AI, Grok xAI, Smart DB Engine)
define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: 'AQ.Ab8RN6KVAVl6kSKykipYYZYNFml4nrNbMjoUaIbMAkbLSZcyFw');
define('DEEPSEEK_API_KEY', getenv('DEEPSEEK_API_KEY') ?: 'sk-70e0eb2e9efe49fa967af6da72b5cda9');
define('GROK_API_KEY', getenv('GROK_API_KEY') ?: '');
define('AI_API_KEY', GEMINI_API_KEY); // Backward compatibility
define('AI_PROVIDER', getenv('AI_PROVIDER') ?: 'gemini'); // Pilihan: 'gemini', 'deepseek', 'grok', 'database'
define('NODE_CHATBOT_URL', getenv('NODE_CHATBOT_URL') ?: 'http://localhost:5000');

// Konfigurasi Email & OTP Verifikasi via SMTP Gmail
define('OTP_EXPIRY_MINUTES', 5); // Durasi berlaku kode OTP (dalam menit)
define('MAIL_SMTP_ENABLED', true); // Aktifkan SMTP Gmail
define('MAIL_SMTP_HOST', 'smtp.gmail.com');
define('MAIL_SMTP_PORT', 465); // Port 465 (SSL) atau 587 (TLS)
define('MAIL_SMTP_USER', ''); // Masukkan alamat email Gmail Anda (contoh: tkjsmartservice@gmail.com)
define('MAIL_SMTP_PASS', ''); // Masukkan 16 karakter Sandi Aplikasi (App Password) dari Akun Google
define('MAIL_SMTP_SECURE', 'ssl'); // 'ssl' untuk port 465, 'tls' untuk port 587

// Konfigurasi WhatsApp Gateway (Fonnte API)
define('FONNTE_TOKEN', getenv('FONNTE_TOKEN') ?: 'XK9gTunu6eUntnSoWSWM');
define('FONNTE_API_URL', 'https://api.fonnte.com/send');




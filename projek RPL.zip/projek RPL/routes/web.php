<?php
/**
 * Routes Mapping Reference - TKJ Smart Service
 * 
 * Sistem routing otomatis memetakan URL ke Controller dan Method:
 * URL Format: {BASE_URL}/{controller}/{method}/{params}
 * 
 * Contoh Pemetaan Route:
 * - GET /                   -> HomeController -> index()
 * - GET /home               -> HomeController -> index()
 * - GET /home/index         -> HomeController -> index()
 * - GET /services           -> ServicesController -> index()
 */

return [
    'home' => [
        'index' => 'Halaman Utama TKJ Smart Service',
    ]
];

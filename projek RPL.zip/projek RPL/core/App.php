<?php
/**
 * Core Router / App Dispatcher Class
 * Mengolah URL dan memanggil Controller/Method/Parameter yang sesuai
 */

class App {
    protected $controller = 'HomeController';
    protected $method = 'index';
    protected $params = [];

    public function __construct() {
        $url = $this->parseUrl();

        // Direct Route Aliases untuk Auth
        if (isset($url[0])) {
            $firstSegment = strtolower($url[0]);
            if ($firstSegment === 'login') {
                $this->controller = 'AuthController';
                $this->method = 'login';
                unset($url[0]);
            } elseif ($firstSegment === 'login-wa' || $firstSegment === 'login-whatsapp') {
                $this->controller = 'AuthController';
                $this->method = 'loginWa';
                unset($url[0]);
            } elseif ($firstSegment === 'register') {
                $this->controller = 'AuthController';
                $this->method = 'register';
                unset($url[0]);
            } elseif ($firstSegment === 'verify-otp') {
                $this->controller = 'AuthController';
                $this->method = 'verifyOtp';
                unset($url[0]);
            } elseif ($firstSegment === 'login-otp' || $firstSegment === 'verify-login-otp') {
                $this->controller = 'AuthController';
                $this->method = 'verifyLoginOtp';
                unset($url[0]);
            } elseif ($firstSegment === 'resend-login-otp') {
                $this->controller = 'AuthController';
                $this->method = 'resendLoginOtp';
                unset($url[0]);
            } elseif ($firstSegment === 'cancel-login-otp') {
                $this->controller = 'AuthController';
                $this->method = 'cancelLoginOtp';
                unset($url[0]);
            } elseif ($firstSegment === 'check-login-otp-status') {
                $this->controller = 'AuthController';
                $this->method = 'checkLoginOtpStatus';
                unset($url[0]);
            } elseif ($firstSegment === 'login-telegram') {
                $this->controller = 'AuthController';
                $this->method = 'loginWithTelegram';
                unset($url[0]);
            } elseif ($firstSegment === 'resend-otp') {
                $this->controller = 'AuthController';
                $this->method = 'resendOtp';
                unset($url[0]);
            } elseif ($firstSegment === 'cancel-otp') {
                $this->controller = 'AuthController';
                $this->method = 'cancelOtp';
                unset($url[0]);
            } elseif ($firstSegment === 'logout') {
                $this->controller = 'AuthController';
                $this->method = 'logout';
                unset($url[0]);
            } elseif ($firstSegment === 'lupa-password' || $firstSegment === 'forgot-password') {
                $this->controller = 'AuthController';
                $this->method = 'lupaPassword';
                unset($url[0]);
            } elseif ($firstSegment === 'reset-password') {
                $this->controller = 'AuthController';
                $this->method = 'resetPassword';
                unset($url[0]);
            } elseif ($firstSegment === 'notifikasi') {
                $this->controller = 'NotifikasiController';
                unset($url[0]);
            } elseif ($firstSegment === 'kepala-sekolah') {
                $this->controller = 'KepalaSekolahController';
                unset($url[0]);
            } else {
                // Formatting Nama Controller (contoh: 'customer' -> 'CustomerController')
                $formattedName = str_replace(' ', '', ucwords(str_replace('-', ' ', $url[0]))) . 'Controller';
                $controllerFile = APPROOT . '/app/controllers/' . $formattedName . '.php';

                if (file_exists($controllerFile)) {
                    $this->controller = $formattedName;
                    unset($url[0]);
                } else {
                    $this->show404();
                    return;
                }
            }
        }

        // Require file controller
        $controllerFile = APPROOT . '/app/controllers/' . $this->controller . '.php';
        if (file_exists($controllerFile)) {
            require_once $controllerFile;
            $this->controller = new $this->controller;
        } else {
            $this->show404();
            return;
        }

        // 2. Cek Method
        if (isset($url[1])) {
            $methodName = str_replace('-', '_', $url[1]);
            if (method_exists($this->controller, $url[1])) {
                $this->method = $url[1];
                unset($url[1]);
            } elseif (method_exists($this->controller, $methodName)) {
                $this->method = $methodName;
                unset($url[1]);
            } else {
                $this->show404();
                return;
            }
        }


        // 3. Ambil Params
        $this->params = $url ? array_values($url) : [];

        // Jalankan Controller & Method
        call_user_func_array([$this->controller, $this->method], $this->params);
    }

    public function parseUrl() {
        if (isset($_GET['url'])) {
            $url = rtrim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);
            return $url;
        }
        return [];
    }

    private function show404() {
        http_response_code(404);
        $errorView = APPROOT . '/app/views/errors/404.php';
        if (file_exists($errorView)) {
            require_once APPROOT . '/app/views/templates/header.php';
            require_once APPROOT . '/app/views/templates/navbar.php';
            require_once $errorView;
            require_once APPROOT . '/app/views/templates/footer.php';
        } else {
            echo "<h1>404 - Halaman Tidak Ditemukan</h1>";
        }
    }
}
